#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Syntax test - Verify all Python files compile without errors
Usage: python test_syntax.py
"""

import sys
import py_compile
from pathlib import Path

def compile_file(filepath):
    """Try to compile a Python file"""
    try:
        py_compile.compile(filepath, doraise=True)
        return True, None
    except py_compile.PyCompileError as e:
        return False, str(e)

def main():
    print("\n" + "="*60)
    print("SYNTAX TEST - Verifying Python Files")
    print("="*60 + "\n")

    dev1_root = Path(__file__).resolve().parents[1]

    # Files to test
    files_to_test = [
        "src/agents/debug_agent.py",
        "src/agents/physical_design_graph.py",
        "src/tracker/langgraph_saver.py",
        "src/agents/__init__.py",
        "src/main.py",
    ]

    results = []
    for rel_path in files_to_test:
        target_path = dev1_root / rel_path
        if not target_path.exists():
            print(f"SKIP: {rel_path} (not found)")
            continue

        success, error = compile_file(str(target_path))
        results.append((rel_path, success, error))

        if success:
            print(f"[OK] {rel_path}")
        else:
            print(f"[FAIL] {rel_path}")
            print(f"      Error: {error}")

    # Summary
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)

    passed = sum(1 for _, success, _ in results if success)
    total = len(results)

    for filepath, success, error in results:
        status = "[OK]" if success else "[FAIL]"
        print(f"{status}: {filepath}")

    print("="*60)
    print(f"\nTotal: {passed}/{total} files compile successfully")

    if passed == total:
        print("\nSUCCESS: All files compile successfully!")
        print("\nNext steps:")
        print("1. Install dependencies: pip install anthropic langgraph")
        print("2. Run: python -m pytest dev1/tests/test_multi_user.py -q")
        print("3. Run: python dev1/tests/test_issue_tracking.py")
        print("4. Start server: python src/main.py ...")
        return 0
    else:
        print("\nFAILURE: Some files have syntax errors")
        return 1

if __name__ == "__main__":
    sys.exit(main())
