#!/usr/bin/env python3
"""
Verification script for Issue Tracking System
Tests core functionality without full package import
"""

import os
import sys
from pathlib import Path
import sqlite3

def test_database_creation():
    """Test that database files can be created"""
    print("\n" + "="*60)
    print("TEST: Database Creation")
    print("="*60)

    db_path = "/tmp/verify_test.db"
    if os.path.exists(db_path):
        os.remove(db_path)

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create issues table
    cursor.execute("""
        CREATE TABLE issues (
            id VARCHAR(50) PRIMARY KEY,
            user_id VARCHAR(50),
            error_type VARCHAR(100),
            error_message TEXT
        )
    """)

    # Insert test data
    cursor.execute("""
        INSERT INTO issues (id, user_id, error_type, error_message)
        VALUES (?, ?, ?, ?)
    """, ("syn_001", "user1", "ENV_VARIABLE_MISSING", "can't read env(RTL_FILELIST)"))

    conn.commit()

    # Verify
    cursor.execute("SELECT COUNT(*) FROM issues")
    count = cursor.fetchone()[0]

    conn.close()
    os.remove(db_path)

    assert count == 1, "Failed to insert/retrieve data"
    print("[OK] Database creation and operations working")
    return True


def test_models_import():
    """Test that model files are valid Python"""
    print("\n" + "="*60)
    print("TEST: Model Files Syntax")
    print("="*60)

    model_files = [
        "src/issues/models.py",
        "src/issues/issue_database.py",
        "src/issues/issue_manager.py",
        "src/issues/fix_repository.py",
        "src/issues/fix_engine.py",
        "src/issues/context_tracker.py",
        "src/issues/flow_integration.py",
        "src/api/issue_api.py",
        "fix_templates/predefined_fixes.py",
    ]

    for file_path in model_files:
        full_path = Path(__file__).parent / file_path
        if not full_path.exists():
            print(f"[FAIL] File not found: {file_path}")
            return False

        # Check syntax by compiling
        try:
            with open(full_path, 'r') as f:
                code = f.read()
            compile(code, file_path, 'exec')
            print(f"[OK] {file_path}")
        except SyntaxError as e:
            print(f"[FAIL] Syntax error in {file_path}: {e}")
            return False

    return True


def test_file_structure():
    """Test that all required files exist"""
    print("\n" + "="*60)
    print("TEST: File Structure")
    print("="*60)

    required_files = {
        "Core": [
            "src/issues/__init__.py",
            "src/issues/models.py",
            "src/issues/issue_database.py",
            "src/issues/issue_manager.py",
            "src/issues/fix_repository.py",
            "src/issues/fix_engine.py",
            "src/issues/context_tracker.py",
            "src/issues/flow_integration.py",
        ],
        "API": [
            "src/api/issue_api.py",
        ],
        "Templates": [
            "fix_templates/__init__.py",
            "fix_templates/predefined_fixes.py",
        ],
        "Documentation": [
            "ISSUE_TRACKING_DESIGN.md",
            "ISSUE_TRACKING_IMPLEMENTATION.md",
            "ISSUE_TRACKING_INTEGRATION_GUIDE.md",
            "IMPLEMENTATION_STATUS.md",
        ]
    }

    base_path = Path(__file__).parent
    all_exist = True

    for category, files in required_files.items():
        print(f"\n{category}:")
        for file in files:
            path = base_path / file
            exists = path.exists()
            status = "[OK]" if exists else "[FAIL]"
            size = f"{path.stat().st_size} bytes" if exists else "N/A"
            print(f"  {status} {file} ({size})")
            if not exists:
                all_exist = False

    return all_exist


def test_classes_defined():
    """Test that core classes are defined"""
    print("\n" + "="*60)
    print("TEST: Core Classes Definition")
    print("="*60)

    base_path = Path(__file__).parent

    # Check models.py for class definitions
    models_file = base_path / "src/issues/models.py"
    with open(models_file, 'r') as f:
        models_content = f.read()

    classes_to_find = [
        "class SeverityLevel",
        "class IssueStatus",
        "class Issue",
        "class FixTemplate",
        "class RunContext",
    ]

    for class_def in classes_to_find:
        if class_def in models_content:
            print(f"[OK] Found: {class_def}")
        else:
            print(f"[FAIL] Missing: {class_def}")
            return False

    # Check fix_repository.py
    fix_repo_file = base_path / "src/issues/fix_repository.py"
    with open(fix_repo_file, 'r') as f:
        fix_repo_content = f.read()

    if "class FixRepository" in fix_repo_content:
        print("[OK] Found: class FixRepository")
    else:
        print("[FAIL] Missing: class FixRepository")
        return False

    # Check issue_api.py
    api_file = base_path / "src/api/issue_api.py"
    with open(api_file, 'r') as f:
        api_content = f.read()

    if "@router.post(\"/create\"" in api_content or "create_issue" in api_content:
        print("[OK] Found: POST /issues/create endpoint")
    else:
        print("[FAIL] Missing: POST /issues/create endpoint")
        return False

    return True


def test_predefined_templates():
    """Test that predefined fix templates are defined"""
    print("\n" + "="*60)
    print("TEST: Predefined Fix Templates")
    print("="*60)

    base_path = Path(__file__).parent
    templates_file = base_path / "fix_templates/predefined_fixes.py"

    with open(templates_file, 'r') as f:
        content = f.read()

    templates = [
        "get_rtl_filelist_fix",
        "get_timing_violation_fix",
        "get_congestion_fix",
        "get_drc_violation_fix",
        "get_memory_issue_fix",
        "get_tool_script_not_found_fix",
        "get_syntax_error_fix",
        "get_default_fixes",
    ]

    found_count = 0
    for template_func in templates:
        if f"def {template_func}()" in content:
            print(f"[OK] Found: {template_func}()")
            found_count += 1
        else:
            print(f"[FAIL] Missing: {template_func}()")

    return found_count == len(templates)


def test_documentation():
    """Test that documentation is comprehensive"""
    print("\n" + "="*60)
    print("TEST: Documentation")
    print("="*60)

    base_path = Path(__file__).parent

    docs = {
        "ISSUE_TRACKING_DESIGN.md": ["Issue model", "FixTemplate", "RunContext"],
        "ISSUE_TRACKING_IMPLEMENTATION.md": ["CREATE TABLE", "user_id", "fix_templates"],
        "ISSUE_TRACKING_INTEGRATION_GUIDE.md": ["Integration", "HTTP API", "Example"],
        "IMPLEMENTATION_STATUS.md": ["COMPLETED", "implementation", "features"],
    }

    for doc_file, keywords in docs.items():
        path = base_path / doc_file
        if not path.exists():
            print(f"[FAIL] Missing: {doc_file}")
            return False

        with open(path, 'r') as f:
            content = f.read().lower()

        found = all(kw.lower() in content for kw in keywords)
        status = "[OK]" if found else "[FAIL]"
        size = path.stat().st_size

        print(f"{status} {doc_file} ({size} bytes)")
        if not found:
            missing = [kw for kw in keywords if kw.lower() not in content]
            print(f"     Missing keywords: {missing}")
            return False

    return True


def main():
    """Run all verification tests"""
    print("\n" + "="*60)
    print("=  Issue Tracking System - Verification")
    print("="*60)

    tests = [
        ("Database Creation", test_database_creation),
        ("Model Syntax", test_models_import),
        ("File Structure", test_file_structure),
        ("Classes Defined", test_classes_defined),
        ("Predefined Templates", test_predefined_templates),
        ("Documentation", test_documentation),
    ]

    passed = 0
    failed = 0

    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
                print(f"\n[FAIL] {test_name} returned False")
        except Exception as e:
            failed += 1
            print(f"\n[FAIL] {test_name} raised exception:")
            print(f"  {e}")

    # Summary
    print("\n" + "="*60)
    print("VERIFICATION SUMMARY")
    print("="*60)
    total = len(tests)
    print(f"[OK] Passed: {passed}/{total}")
    print(f"[FAIL] Failed: {failed}/{total}")

    if failed == 0:
        print("\n[SUCCESS] Issue Tracking System implementation verified!")
        print("\nNext steps:")
        print("1. Read ISSUE_TRACKING_INTEGRATION_GUIDE.md")
        print("2. Integrate with physical_design_graph.py")
        print("3. Mount issue_api.py on FastAPI app")
        print("4. Test with actual flows")
        return 0
    else:
        print(f"\n[WARNING] {failed} verification(s) failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
