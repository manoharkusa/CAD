#!/usr/bin/env python3
"""
Test script for Issue Tracking System

Tests:
1. Database initialization
2. Issue creation and retrieval
3. Fix templates and repository
4. Context tracking
5. Fix engine and learning
6. Flow integration
"""

import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

# Prevent importing the full src package which has yaml dependency
import importlib.util
def import_direct(module_path):
    """Import module directly without going through package __init__.py"""
    spec = importlib.util.spec_from_file_location(module_path.replace("/", "."), module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def test_database_init():
    """Test database initialization"""
    print("\n" + "="*60)
    print("TEST 1: Database Initialization")
    print("="*60)

    from src.issues.issue_database import IssueDatabase

    db = IssueDatabase(db_path="/tmp/test_issues.db")
    print("[OK] Database initialized successfully")

    # Check tables exist
    tables = db.select("sqlite_master", "type='table' AND name LIKE 'issues%'")
    print(f"[OK] Found {len(tables)} tables")

    return True


def test_issue_creation():
    """Test issue creation and retrieval"""
    print("\n" + "="*60)
    print("TEST 2: Issue Creation and Retrieval")
    print("="*60)

    from src.issues.issue_manager import IssueManager
    from src.issues.models import SeverityLevel

    manager = IssueManager(db_path="/tmp/test_issues.db")

    # Create issue
    issue = manager.create_issue(
        user_id="test_user",
        run_id="run001",
        thread_id="thread_001",
        stage="syn",
        error_type="ENV_VARIABLE_MISSING",
        error_message="can't read env(RTL_FILELIST)",
        phase="synthesis",
        root_cause="RTL_FILELIST not set in sourceproj.env",
        severity=SeverityLevel.CRITICAL,
        log_snippet="Error in line 42"
    )

    print(f"[OK] Created issue: {issue.issue_id}")
    print(f"  - Type: {issue.error_type}")
    print(f"  - Severity: {issue.severity.value}")
    print(f"  - Status: {issue.status.value}")

    # Retrieve issue
    retrieved = manager.get_issue_by_id(issue.issue_id)
    assert retrieved is not None, "Failed to retrieve issue"
    print(f"[OK] Retrieved issue: {retrieved.issue_id}")

    # Get all issues
    issues = manager.get_issues("test_user", "run001")
    print(f"[OK] Found {len(issues)} issues for user")

    return True


def test_fix_templates():
    """Test fix template repository"""
    print("\n" + "="*60)
    print("TEST 3: Fix Templates and Repository")
    print("="*60)

    from src.issues.fix_repository import FixRepository
    from fix_templates.predefined_fixes import get_default_fixes

    repo = FixRepository(db_path="/tmp/test_issues.db")

    # Get default fixes
    fixes = get_default_fixes()
    print(f"[OK] Loaded {len(fixes)} predefined fixes:")

    for fix in fixes:
        repo.add_template(fix)
        print(f"  - {fix.template_id}: {fix.description}")

    # Retrieve template
    template = repo.get_template("rtl_filelist_001")
    assert template is not None, "Failed to retrieve template"
    print(f"[OK] Retrieved template: {template.template_id}")

    # Find matching templates
    error_msg = "can't read env(RTL_FILELIST)"
    matches = repo.find_templates_for_error(error_msg, "ENV_VARIABLE_MISSING", "syn")
    print(f"[OK] Found {len(matches)} matching templates for error")

    return True


def test_context_tracking():
    """Test context tracking"""
    print("\n" + "="*60)
    print("TEST 4: Context Tracking")
    print("="*60)

    from src.issues.context_tracker import ContextTracker

    tracker = ContextTracker(db_path="/tmp/test_issues.db")

    # Create context
    context = tracker.create_context(
        thread_id="thread_001",
        user_id="test_user",
        run_id="run001",
        project="semicon_19-02",
        block="aes_cipher_top"
    )
    print(f"[OK] Created context: {context.thread_id}")

    # Record phase
    tracker.record_phase_result(context.thread_id, "synthesis", "completed")
    print("[OK] Recorded phase completion")

    # Get context summary
    summary = tracker.get_context_summary(context.thread_id)
    print(f"[OK] Context summary:")
    print(f"  - Project: {summary['project']}")
    print(f"  - Block: {summary['block']}")
    print(f"  - Flow status: {summary['flow_status']}")

    return True


def test_fix_engine():
    """Test fix engine"""
    print("\n" + "="*60)
    print("TEST 5: Fix Engine and Learning")
    print("="*60)

    from src.issues.fix_engine import FixEngine
    from src.issues.issue_manager import IssueManager
    from src.issues.models import SeverityLevel

    engine = FixEngine(db_path="/tmp/test_issues.db")

    # Create issue to fix
    manager = IssueManager(db_path="/tmp/test_issues.db")
    issue = manager.create_issue(
        user_id="test_user",
        run_id="run001",
        thread_id="thread_001",
        stage="syn",
        error_type="ENV_VARIABLE_MISSING",
        error_message="can't read env(RTL_FILELIST): no such variable",
        phase="synthesis",
        severity=SeverityLevel.CRITICAL
    )

    # Suggest fixes
    fixes = engine.suggest_fixes(issue, limit=3)
    print(f"[OK] Suggested {len(fixes)} fixes:")
    for fix in fixes:
        print(f"  - {fix.template_id}: {fix.success_rate*100:.0f}% success rate")

    # Apply fix
    if fixes:
        result = engine.apply_fix(issue.issue_id, fixes[0])
        print(f"[OK] Applied fix: {result['success']}")

        # Learn from fix
        engine.learn_from_fix(issue.issue_id, fixes[0], was_successful=True)
        print("[OK] Learned from fix application")

    return True


def test_flow_integration():
    """Test flow integration"""
    print("\n" + "="*60)
    print("TEST 6: Flow Integration")
    print("="*60)

    from src.issues.flow_integration import FlowIssueIntegration

    integration = FlowIssueIntegration(db_path="/tmp/test_issues.db")

    # Create context
    integration.create_context_for_flow(
        thread_id="test_flow_001",
        user_id="test_user",
        run_id="run001",
        project="semicon_19-02",
        block="aes_cipher_top"
    )
    print("[OK] Created flow context")

    # Simulate stage error
    error_info = integration.handle_stage_error(
        thread_id="test_flow_001",
        user_id="test_user",
        run_id="run001",
        stage="syn",
        error="can't read env(RTL_FILELIST)",
        phase="synthesis",
        log_snippet="Error occurred at line 42"
    )

    print(f"[OK] Handled stage error:")
    print(f"  - Issue ID: {error_info['issue_id']}")
    print(f"  - Error type: {error_info['error_type']}")
    print(f"  - Suggested fixes: {len(error_info['suggested_fixes'])}")

    # Record success
    integration.record_stage_success("test_flow_001", "syn")
    print("[OK] Recorded stage success")

    # Record phase
    integration.record_phase_completion("test_flow_001", "synthesis", "completed")
    print("[OK] Recorded phase completion")

    # Get completion report
    report = integration.record_flow_completion("test_flow_001", "completed")
    print(f"[OK] Flow completion report:")
    print(f"  - Status: {report['flow_status']}")
    if report['summary']:
        print(f"  - Issues: {report['summary'].get('total_issues', 0)}")

    return True


def test_error_classification():
    """Test error classification"""
    print("\n" + "="*60)
    print("TEST 7: Error Classification")
    print("="*60)

    from src.issues.flow_integration import FlowIssueIntegration

    integration = FlowIssueIntegration()

    test_cases = [
        ("can't read env(RTL_FILELIST)", "ENV_VARIABLE_MISSING"),
        ("Setup violation detected", "TIMING_VIOLATION"),
        ("Routing overflow detected", "ROUTING_CONGESTION"),
        ("DRC violation M1 spacing", "DRC_VIOLATION"),
        ("out of memory", "MEMORY_ISSUE"),
        ("file not found: tool.tcl", "FILE_NOT_FOUND"),
        ("Syntax error in TCL script", "SYNTAX_ERROR"),
    ]

    print("[OK] Error classification:")
    for error_msg, expected_type in test_cases:
        classified = integration._classify_error(error_msg)
        status = "[OK]" if classified == expected_type else "[FAIL]"
        print(f"  {status} '{error_msg[:40]}...' → {classified}")

    return True


def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("=  Issue Tracking System - Test Suite")
    print("="*60)

    tests = [
        ("Database Init", test_database_init),
        ("Issue Creation", test_issue_creation),
        ("Fix Templates", test_fix_templates),
        ("Context Tracking", test_context_tracking),
        ("Fix Engine", test_fix_engine),
        ("Flow Integration", test_flow_integration),
        ("Error Classification", test_error_classification),
    ]

    passed = 0
    failed = 0

    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
                print(f"[FAIL] {test_name} returned False")
        except Exception as e:
            failed += 1
            print(f"\n[FAIL] {test_name} FAILED:")
            print(f"  Error: {e}")
            import traceback
            traceback.print_exc()

    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    print(f"[OK] Passed: {passed}/{len(tests)}")
    print(f"[FAIL] Failed: {failed}/{len(tests)}")

    if failed == 0:
        print("\n[SUCCESS] ALL TESTS PASSED! Issue Tracking System is ready to use.")
        return 0
    else:
        print(f"\n[WARNING] {failed} test(s) failed. Please review.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
