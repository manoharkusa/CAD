"""Redis queue consumer that executes queued /jobs requests via PhysicalDesignGraph."""

from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime
from typing import Any, Dict, Optional

import redis

from ..agents.physical_design_graph import PhysicalDesignGraph
from ..config.env_loader import load_env_file
from ..config.runtime_config import RuntimeConfig
from ..infra.db import SessionLocal
from ..infra.feature_flags import FeatureFlags
from ..infra.lifecycle_utils import lifecycle_status_for_event, message_for_event, safe_int, safe_str
from ..infra.lifecycle_utils import derive_checkpoint_nodes
from ..infra.redis.job_events import RedisJobEventPublisher
from ..infra.redis.job_state_store import RedisJobStateStore
from ..infra.repositories import IssueKnowledgeRepository, SqlAlchemyJobRepository


def _default_from_env(name: str, fallback: str) -> str:
    value = os.getenv(name, fallback)
    return value.strip() if isinstance(value, str) else fallback


class LifecycleWorker:
    def __init__(self) -> None:
        load_env_file()

        self.flags = FeatureFlags.from_env()
        self.runtime = RuntimeConfig.from_env()

        self.default_project = _default_from_env("PROJECT_NAME", "demo_project")
        self.default_user = _default_from_env("USER_NAME", "demo_user")
        self.default_block = _default_from_env("BLOCK_NAME", "demo_block")
        self.default_rtl_tag = _default_from_env("RTL_TAG", "demo_rtl")

        self.redis_client = redis.Redis.from_url(self.runtime.redis_url, decode_responses=True)
        self.queue_key = self.runtime.redis_queue_key

        self.job_state_store: Optional[RedisJobStateStore] = None
        self.job_event_publisher: Optional[RedisJobEventPublisher] = None
        if self.flags.use_redis_job_state:
            self.job_state_store = RedisJobStateStore(runtime_config=self.runtime)
            self.job_event_publisher = RedisJobEventPublisher(runtime_config=self.runtime)

        self.graph = PhysicalDesignGraph(max_retries=3)

    def lifecycle_bridge(self, event_type: str, payload: Dict[str, Any], state: Dict[str, Any]) -> None:
        if not self.flags.use_job_lifecycle_api:
            return

        job_id = state.get("job_id") or payload.get("job_id")
        if not job_id:
            return

        if event_type == "agent_log":
            if self.job_event_publisher is not None:
                self.job_event_publisher.publish_job_log(
                    job_id,
                    message=safe_str(payload.get("message")) or "Agent log",
                    payload=payload,
                    source=safe_str(payload.get("source")) or "SPD_Agent",
                    level=safe_str(payload.get("level")) or "INFO",
                )
            return

        status, phase = lifecycle_status_for_event(event_type, payload)
        current_tool = payload.get("tool") or payload.get("stage")  # Prefer tool, fallback to stage
        run_id = safe_str(state.get("run_id") or payload.get("run_id"))
        progress_message = payload.get("message") or message_for_event(event_type, payload)
        iteration = safe_int(payload.get("current_stage_index"))
        if iteration is not None:
            iteration += 1

        state_snapshot = {
            "job_id": job_id,
            "run_id": run_id,
            "status": status,
            "phase": phase,
            "iteration": iteration,
            "current_tool": current_tool,
            "current_stage": safe_str(payload.get("stage")),
            "progress_message": progress_message,
            "stages_executed": payload.get("stages_executed", state.get("stages_executed", [])),
            "stages_failed": payload.get("stages_failed", state.get("stages_failed", [])),
            "end_time": payload.get("end_time"),
            "decision_status": safe_str(payload.get("decision_status")),
            "interaction_type": safe_str(payload.get("interaction_type")),
            "hitl_version": safe_int(payload.get("version")),
            "requested_at": safe_str(payload.get("requested_at")),
            "expires_at": safe_str(payload.get("expires_at")),
        }

        checkpoint_current_node, checkpoint_next_node = derive_checkpoint_nodes(event_type, payload, state)
        state_snapshot["current_node"] = checkpoint_current_node
        state_snapshot["next_node"] = checkpoint_next_node

        if self.flags.use_redis_job_state and self.job_state_store is not None:
            current_state = self.job_state_store.get_job_state(job_id) or {}
            merged_state = {
                **current_state,
                **state_snapshot,
            }
            self.job_state_store.set_job_state(job_id, merged_state)
            state_snapshot = merged_state

        if self.flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                issue_kb_repository = IssueKnowledgeRepository(session)

                def _extract_file_change_payloads() -> list[Dict[str, Any]]:
                    extracted: list[Dict[str, Any]] = []
                    file_edits = payload.get("file_edits")
                    if isinstance(file_edits, list):
                        for edit in file_edits:
                            if isinstance(edit, dict) and safe_str(edit.get("file_path")):
                                extracted.append(edit)

                    if safe_str(payload.get("file_path")):
                        extracted.append(payload)

                    details = payload.get("details")
                    if isinstance(details, dict) and safe_str(details.get("file_path")):
                        extracted.append(details)

                    return extracted

                repository.update_job_status(
                    job_id=job_id,
                    status=status,
                    phase=phase,
                    current_tool=safe_str(current_tool),
                    completed_at=safe_str(payload.get("end_time")) if status in {"SUCCESS", "FAILED", "CANCELLED"} else None,
                )
                repository.add_history(
                    job_id=job_id,
                    payload={
                        "sequence_num": iteration if iteration is not None else 0,
                        "action_type": event_type,
                        "tool_name": safe_str(current_tool),
                        "input_params": payload,
                        "output_result": {
                            "status": status,
                            "phase": phase,
                            "message": progress_message,
                        },
                        "duration_ms": safe_int(payload.get("duration_ms")),
                        "error_message": safe_str(payload.get("error")),
                    },
                )
                stage = safe_str(payload.get("stage"))
                if stage and event_type in {"stage_started", "stage_completed", "stage_failed"}:
                    stage_status_map = {
                        "stage_started": "running",
                        "stage_completed": "pass",
                        "stage_failed": "fail",
                    }
                    repository.add_stage_record(
                        job_id=job_id,
                        payload={
                            "run_id": run_id,
                            "stage": stage,
                            "tool": safe_str(current_tool),
                            "stage_order": iteration,
                            "status": stage_status_map.get(event_type, "running"),
                            "summary": safe_str(payload.get("summary") or payload.get("reason") or progress_message),
                            "error_details": safe_str(payload.get("error")),
                            "started_at": safe_str(payload.get("started_at")) if event_type == "stage_started" else None,
                            "ended_at": safe_str(payload.get("end_time")) if event_type in {"stage_completed", "stage_failed"} else None,
                            "duration_ms": safe_int(payload.get("duration_ms")),
                            "metadata": {
                                "event_type": event_type,
                                "payload": payload,
                            },
                        },
                    )

                for file_change in _extract_file_change_payloads():
                    repository.add_file_change(
                        job_id=job_id,
                        payload={
                            "run_id": run_id,
                            "stage": safe_str(file_change.get("stage") or payload.get("stage")),
                            "file_path": safe_str(file_change.get("file_path")),
                            "change_type": safe_str(file_change.get("change_type") or file_change.get("edit_type") or "edit"),
                            "tool_name": safe_str(file_change.get("tool_name") or current_tool),
                            "before_hash": safe_str(file_change.get("before_hash")),
                            "after_hash": safe_str(file_change.get("after_hash")),
                            "diff_excerpt": safe_str(file_change.get("diff_excerpt") or file_change.get("diff")),
                            "happened_at": safe_str(file_change.get("timestamp") or payload.get("timestamp")),
                            "metadata": {
                                "event_type": event_type,
                                "payload": file_change,
                            },
                        },
                    )

                repository.save_checkpoint(
                    job_id=job_id,
                    state=state_snapshot,
                    current_node=checkpoint_current_node,
                    next_node=checkpoint_next_node,
                )
                if event_type == "hitl_required":
                    requested_at = safe_str(payload.get("requested_at")) or datetime.utcnow().isoformat()
                    repository.add_human_interaction(
                        job_id=job_id,
                        prompt=safe_str(payload.get("prompt")) or "Human confirmation required",
                        options=payload.get("options") or ["Approved", "Declined", "UserInput"],
                        response=None,
                        interaction_type=safe_str(payload.get("interaction_type")) or "generic",
                        decision=None,
                        additional_context=None,
                        decision_status=safe_str(payload.get("decision_status")) or "waiting_for_human",
                        requested_at=requested_at,
                        expires_at=safe_str(payload.get("expires_at")),
                        version=safe_int(payload.get("version")),
                        interaction_metadata={
                            "payload": payload,
                            "source": "worker.lifecycle_bridge",
                        },
                    )
                if event_type in {"stage_failed", "failed"}:
                    error_message = safe_str(payload.get("error")) or progress_message
                    stage = safe_str(payload.get("stage"))
                    repository.add_error_log(
                        job_id=job_id,
                        error_type=event_type,
                        error_message=error_message,
                        stage=stage,
                        tool=safe_str(current_tool),
                        context={
                            "payload": payload,
                            "status": status,
                            "phase": phase,
                            "current_tool": safe_str(current_tool),
                            "stage": stage,
                        },
                    )

                # When an issue is resolved, update the error_log
                if event_type == "issue_resolution_captured":
                    stage = safe_str(payload.get("stage"))
                    resolution = safe_str(payload.get("resolution")) or safe_str(payload.get("summary"))
                    repository.resolve_error_log(
                        job_id=job_id,
                        stage=stage,
                        resolution=resolution,
                        error_type="resolved",
                        tool=safe_str(current_tool),
                    )

                if event_type in {"stage_failed", "failed", "issue_resolution_captured"}:
                    error_message = safe_str(payload.get("error")) or progress_message
                    # Get proper tool name from payload (not falling back to stage)
                    tool_name = safe_str(payload.get("tool")) or safe_str(current_tool)
                    stage_name = safe_str(payload.get("stage")) or phase

                    # Get technology from TECH_NAME env var (set via sourceproj.env)
                    technology = safe_str(payload.get("technology"))
                    if not technology or technology == "others":
                        technology = IssueKnowledgeRepository.get_technology_from_env()

                    # Get or classify issue category
                    issue_category = safe_str(payload.get("issue_category"))
                    if not issue_category or issue_category == "others":
                        issue_category = IssueKnowledgeRepository.classify_issue_from_error(
                            error_message, stage_name
                        )

                    # Generate descriptive title instead of generic "stage failure"
                    title = IssueKnowledgeRepository.generate_descriptive_title(
                        stage=stage_name,
                        tool=tool_name,
                        error_message=error_message,
                        issue_category=issue_category,
                    )

                    issue_kb_repository.upsert_issue(
                        job_id=job_id,
                        payload={
                            "run_id": run_id,
                            "session_id": safe_str(state.get("session_id") or payload.get("session_id")),
                            "title": title,
                            "description": error_message,
                            "error_message": error_message,
                            "error_signature": safe_str(payload.get("error_signature") or payload.get("error")),
                            "tool": tool_name,
                            "technology": technology,
                            "issue_category": issue_category,
                            "stage": stage_name,
                            "summary": progress_message,
                            "debug_steps": safe_str(payload.get("debug_steps")),
                            "resolution": safe_str(payload.get("resolution")),
                            "metadata": {
                                "event_type": event_type,
                                "phase": phase,
                                "status": status,
                                "payload": payload,
                            },
                        },
                    )
            finally:
                session.close()

        if self.job_event_publisher is not None:
            if event_type == "hitl_required":
                self.job_event_publisher.publish_hitl_required(job_id)
            self.job_event_publisher.publish_job_event(
                job_id,
                {
                    "event_type": event_type,
                    "status": status,
                    "phase": phase,
                    "message": progress_message,
                    "run_id": run_id,
                    "payload": payload,
                },
            )

    # NOTE: Per-class admission is intentionally disabled for now.
    # Keeping helper method commented for fast re-enable after business confirmation.
    # def _infer_resource_class(self, config: Dict[str, Any]) -> str:
    #     explicit = safe_str(config.get("resource_class"))
    #     if explicit:
    #         return explicit.lower()
    #
    #     hint_text = " ".join(
    #         filter(
    #             None,
    #             [
    #                 safe_str(config.get("prompt")),
    #                 safe_str(config.get("script_path")),
    #                 safe_str(config.get("instructions_path")),
    #                 safe_str(config.get("experiment_name")),
    #             ],
    #         )
    #     ).lower()
    #
    #     signoff_keywords = {"signoff", "sta", "tempus", "qrc", "pv", "drc", "lvs", "lec", "timing"}
    #     pnr_keywords = {"pnr", "place", "route", "cts", "floorplan", "chip_finish", "innovus", "init_design"}
    #     syn_keywords = {"syn", "synthesis", "genus"}
    #
    #     has_signoff = any(token in hint_text for token in signoff_keywords)
    #     has_pnr = any(token in hint_text for token in pnr_keywords)
    #     has_syn = any(token in hint_text for token in syn_keywords)
    #
    #     if (has_signoff and has_pnr) or (has_signoff and has_syn) or (has_pnr and has_syn):
    #         return "mixed"
    #     if has_signoff:
    #         return "signoff"
    #     if has_pnr:
    #         return "pnr"
    #     if has_syn:
    #         return "syn"
    #     return "default"

    async def process_job(self, job_id: str, config: Dict[str, Any]) -> None:
        run_id = config.get("run_id")
        session_id = config.get("session_id")
        prompt = config.get("prompt") or f"run syn for {config.get('script_path', 'default design')}"
        req_user_name = config.get("user_name") or self.default_user
        proj = config.get("project") or self.default_project
        blk = config.get("block") or self.default_block
        rtl = config.get("rtl_tag") or self.default_rtl_tag
        exp = config.get("experiment_name") or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        debug_mode = config.get("debug_mode") or "interactive"
        require_plan_confirmation = bool(config.get("require_plan_confirmation", True))

        log_prefix = f"[WORKER][session={session_id}][job={job_id}]" if session_id else f"[WORKER][job={job_id}]"

        if self.job_state_store is not None and self.job_state_store.is_abort_requested(job_id):
            print(f"{log_prefix} Abort flag set before execution; marking cancelled")
            self.lifecycle_bridge(
                "abort_requested",
                {"message": "Abort requested before worker start", "job_id": job_id, "run_id": run_id},
                {"job_id": job_id, "run_id": run_id},
            )
            return

        print(f"{log_prefix} Invoking PhysicalDesignGraph")

        if self.job_state_store is not None:
            self.job_state_store.clear_hitl_responses(job_id)

        def resolve_hitl(interaction_type: str, request_payload: Dict[str, Any], _state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            if self.job_state_store is None:
                return {"response": "approve", "additional_context": "no_state_store"}

            if self.job_state_store.is_abort_requested(job_id):
                return {"abort_requested": True, "message": "Abort requested by user"}

            if interaction_type == "abort_check":
                return {}

            response = self.job_state_store.pop_hitl_response(job_id)
            if response:
                expected_type = safe_str(interaction_type)
                response_type = safe_str(response.get("interaction_type"))
                if response_type and expected_type and response_type != expected_type:
                    print(
                        f"{log_prefix} Ignoring stale HITL response for interaction_type={response_type}; "
                        f"expected={expected_type}"
                    )
                    return {}

                response_text = safe_str(response.get("response"))
                has_context = bool((safe_str(response.get("additional_context")) or "").strip())
                if response_text in {"Approved", "Declined"} and not has_context:
                    persisted_state = self.job_state_store.get_job_state(job_id) or {}
                    pending_context = safe_str(persisted_state.get("pending_human_context"))
                    if pending_context:
                        response["additional_context"] = pending_context
                response.setdefault("interaction_type", interaction_type)
                response.setdefault("requested_prompt", request_payload.get("prompt"))
            return response

        def lookup_issue_kb(lookup_payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            if not self.flags.use_postgres_job_repo:
                return None
            session = SessionLocal()
            try:
                issue_repo = IssueKnowledgeRepository(session)
                items = issue_repo.search_issues(
                    text_query=safe_str(lookup_payload.get("error_message")),
                    project=proj,
                    block=blk,
                    stage=safe_str(lookup_payload.get("stage")),
                    limit=5,
                    include_internal=True,
                )
                return {"count": len(items), "items": items}
            except Exception as exc:
                print(f"{log_prefix} Issue KB lookup failed: {exc}")
                return None
            finally:
                session.close()

        self.lifecycle_bridge(
            "started",
            {"message": "Worker started execution", "job_id": job_id, "run_id": run_id, "current_stage_index": 0},
            {"job_id": job_id, "run_id": run_id},
        )

        try:
            result = await self.graph.invoke(
                prompt=prompt,
                debug_mode=debug_mode,
                project_name=proj,
                user_name=req_user_name,
                block_name=blk,
                rtl_tag=rtl,
                experiment_name=exp,
                run_id=run_id,
                job_id=job_id,
                session_id=session_id,
                lifecycle_hook=self.lifecycle_bridge,
                hitl_resolver=resolve_hitl,
                issue_kb_lookup=lookup_issue_kb,
                require_plan_confirmation=require_plan_confirmation,
            )
            print(f"{log_prefix} Graph result: {result.get('execution_status', result.get('status', 'unknown'))}")
        except Exception as exc:
            print(f"{log_prefix} Unhandled worker error: {exc}")
            self.lifecycle_bridge(
                "failed",
                {
                    "job_id": job_id,
                    "run_id": run_id,
                    "error": str(exc),
                    "end_time": datetime.now().isoformat(),
                    "stages_executed": [],
                    "stages_failed": [],
                },
                {"job_id": job_id, "run_id": run_id},
            )

    def _send_to_dead_letter(self, payload: Dict[str, Any], reason: str, *, error: Optional[str] = None) -> None:
        if self.job_state_store is None:
            return
        self.job_state_store.dead_letter_job(payload, reason=reason, error=error)
        self.job_state_store.incr_metric("dlq_routed_total", 1)
        self.job_state_store.incr_metric(f"dlq_reason:{reason}", 1)
        self.job_state_store.ack_job(payload)
        print(f"[WORKER] Routed message to DLQ: reason={reason}, payload_job={payload.get('job_id')}")

    def _retry_or_dead_letter(self, payload: Dict[str, Any], *, reason: str, error: Optional[str] = None) -> None:
        if self.job_state_store is None:
            return

        attempts = safe_int(payload.get("_attempt_count")) or 0
        attempts += 1
        payload["_attempt_count"] = attempts

        if attempts >= self.runtime.max_queue_attempts:
            self._send_to_dead_letter(payload, reason=reason, error=error)
            return

        self.job_state_store.requeue_job(payload)
        self.job_state_store.incr_metric("queue_retry_total", 1)
        self.job_state_store.ack_job(payload)
        if self.runtime.admission_defer_seconds > 0:
            import time
            time.sleep(self.runtime.admission_defer_seconds)
        print(
            f"[WORKER] Requeued message for retry reason={reason}; "
            f"attempt={attempts}/{self.runtime.max_queue_attempts}, payload_job={payload.get('job_id')}"
        )

    def _admit_or_defer(self, payload: Dict[str, Any]) -> bool:
        if self.job_state_store is None:
            return True

        max_active_runs = self.runtime.max_active_runs
        if max_active_runs <= 0:
            return True

        config = payload.get("config", {})
        run_id = safe_str(config.get("run_id") or payload.get("run_id") or payload.get("job_id"))
        if not run_id:
            return True

        # NOTE: Per-class admission is intentionally disabled for now.
        # resource_class = self._infer_resource_class(config)
        # config["resource_class"] = resource_class
        # per_class_limits = self.runtime.max_active_runs_per_class
        # class_limit = max(0, int(per_class_limits.get(resource_class, 0)))

        admitted = self.job_state_store.try_acquire_run_slot(run_id, max_active_runs)
        if admitted:
            # NOTE: Per-class admission is intentionally disabled for now.
            # if class_limit > 0:
            #     class_admitted = self.job_state_store.try_acquire_class_slot(resource_class, run_id, class_limit)
            #     if not class_admitted:
            #         self.job_state_store.release_run_slot(run_id)
            #         admitted = False
            #     else:
            #         payload["_admitted_resource_class"] = resource_class
            payload["_admitted_run_id"] = run_id
            if admitted:
                self.job_state_store.incr_metric("admitted_total", 1)
                return True

        defer_count = safe_int(payload.get("_defer_count")) or 0
        payload["_defer_count"] = defer_count + 1
        self.job_state_store.incr_metric("admission_deferred_total", 1)

        if payload["_defer_count"] >= self.runtime.max_admission_defers:
            self._send_to_dead_letter(payload, reason="admission_defer_limit_exceeded")
            return False

        self.job_state_store.requeue_job(payload)
        self.job_state_store.ack_job(payload)
        if self.runtime.admission_defer_seconds > 0:
            import time
            time.sleep(self.runtime.admission_defer_seconds)
        print(
            f"[WORKER] Admission deferred run_id={run_id}; "
            f"active-run limit reached ({max_active_runs}), defer_count={payload['_defer_count']}"
        )
        return False

    def run_forever(self) -> None:
        print("[WORKER] Starting lifecycle worker")
        print(f"[WORKER] Queue backend: {self.runtime.queue_backend}")
        if self.runtime.queue_backend == "stream":
            print(f"[WORKER] Redis stream: {self.runtime.redis_stream_key}, group={self.runtime.redis_stream_group}, consumer={self.runtime.redis_stream_consumer}")
        else:
            print(f"[WORKER] Redis queue: {self.queue_key}")

        while True:
            if self.job_state_store is not None:
                payload = self.job_state_store.dequeue_job(timeout_seconds=5)
            else:
                item = self.redis_client.brpop(self.queue_key, timeout=5)
                if not item:
                    continue
                _, raw_payload = item
                try:
                    payload = json.loads(raw_payload)
                except Exception as exc:
                    print(f"[WORKER] Skipping invalid queue payload: {exc}; payload={raw_payload}")
                    continue

            if not payload:
                continue

            if payload.get("_recovered_pending"):
                print(f"[WORKER] Recovered pending stream message for job_id={payload.get('job_id')}")
                if self.job_state_store is not None:
                    self.job_state_store.incr_metric("pending_recovered_total", 1)

            if payload.get("_invalid"):
                print(f"[WORKER] Skipping invalid queue payload envelope: {payload}")
                if self.job_state_store is not None:
                    self._send_to_dead_letter(payload, reason="invalid_payload_envelope")
                continue

            if not self._admit_or_defer(payload):
                continue

            job_id = payload.get("job_id")
            config = payload.get("config", {})
            if not job_id:
                print(f"[WORKER] Skipping payload without job_id: {payload}")
                if self.job_state_store is not None:
                    self._send_to_dead_letter(payload, reason="missing_job_id")
                continue

            try:
                asyncio.run(self.process_job(job_id, config))
                if self.job_state_store is not None:
                    self.job_state_store.incr_metric("job_processed_total", 1)
                    self.job_state_store.ack_job(payload)
            except Exception as exc:
                print(f"[WORKER][job={job_id}] Fatal processing error: {exc}")
                if self.job_state_store is not None:
                    self.job_state_store.incr_metric("job_processing_exception_total", 1)
                    self._retry_or_dead_letter(payload, reason="worker_processing_exception", error=str(exc))
            finally:
                if self.job_state_store is not None:
                    admitted_run_id = safe_str(payload.get("_admitted_run_id"))
                    if admitted_run_id:
                        self.job_state_store.release_run_slot(admitted_run_id)
                    # NOTE: Per-class admission is intentionally disabled for now.
                    # admitted_resource_class = safe_str(payload.get("_admitted_resource_class"))
                    # if admitted_run_id and admitted_resource_class:
                    #     self.job_state_store.release_class_slot(admitted_resource_class, admitted_run_id)


def main() -> None:
    worker = LifecycleWorker()
    worker.run_forever()


if __name__ == "__main__":
    main()
