"""Worker processes for lifecycle queue execution."""
