#!/usr/bin/env python3
"""
Flow API - FastAPI endpoints for physical design flow

Provides REST API for:
- Executing flow with natural language prompts
- Querying execution status
- Accessing stage logs
- Monitoring progress
- WebSocket real-time updates
"""

import asyncio
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

from fastapi import FastAPI, WebSocket, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from ..config import ConfigManager
from ..executor import StageExecutor
from ..agents import OrchestratorAgent
from ..tracker import StateTracker
from ..tracker.langgraph_saver import create_thread_id, get_config_for_thread
from ..agents.physical_design_graph import FlowState
from ..infra import FeatureFlags, initialize_lifecycle_runtime
from ..infra.db import SessionLocal
from ..infra.lifecycle_utils import safe_int, safe_str
from ..infra.mappers import make_identity
from ..infra.repositories import SqlAlchemyJobRepository


# ============================================================================
# Request/Response Models
# ============================================================================


class ExecuteRequest(BaseModel):
    """Request to execute flow"""
    prompt: str
    debug_mode: str = "interactive"
    enable_ai: bool = False
    # UI Metadata (selected from dropdowns)
    user_id: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    rtl_tag: Optional[str] = None
    experiment_name: Optional[str] = None  # Experiment selected from UI


class ExecuteResponse(BaseModel):
    """Response from flow execution"""
    thread_id: Optional[str] = None  # {user}_{block}_{experiment}_{timestamp}
    experiment_name: Optional[str] = None  # Echo back the experiment
    status: str
    stages_executed: List[str]
    stages_failed: List[str]
    duration: float
    start_time: str
    end_time: Optional[str]


class StatusResponse(BaseModel):
    """Current flow status"""
    thread_id: Optional[str] = None  # Multi-user support
    run_id: str
    status: str
    current_stage: Optional[str]
    stages: Dict[str, str]
    progress_percent: int
    start_time: str
    end_time: Optional[str]
    duration: float


class StageLogResponse(BaseModel):
    """Stage log content"""
    stage_name: str
    log_content: str
    size_bytes: int


class HistoryResponse(BaseModel):
    """Execution history"""
    run_id: str
    status: str
    duration: float
    start_time: str
    end_time: Optional[str]
    stages_count: int


class StageInfo(BaseModel):
    """Information about a stage"""
    name: str
    tool: str
    description: str
    depends_on: List[str]


class JobCreateRequest(BaseModel):
    script_path: str
    instructions_path: Optional[str] = None
    allowed_paths: List[str] = []
    max_retries: int = 3
    max_iterations: int = 5
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    # NOTE: Reserved for future per-class admission policy.
    # resource_class: Optional[str] = None


class JobCreateResponse(BaseModel):
    job_id: str
    run_id: str
    status: str
    phase: str


class JobStatusResponse(BaseModel):
    job_id: str
    run_id: Optional[str] = None
    status: str
    phase: str
    iteration: Optional[int] = None
    current_tool: Optional[str] = None
    progress_message: Optional[str] = None


# ============================================================================
# API Router
# ============================================================================


def create_flow_api(
    config_manager: ConfigManager,
    stage_executor: StageExecutor,
    orchestrator_agent: OrchestratorAgent,
    state_tracker: StateTracker,
) -> FastAPI:
    """
    Create FastAPI application with flow endpoints

    Args:
        config_manager: ConfigManager instance
        stage_executor: StageExecutor instance
        orchestrator_agent: OrchestratorAgent instance
        state_tracker: StateTracker instance

    Returns:
        Configured FastAPI application
    """

    app = FastAPI(
        title="Physical Design Flow API",
        description="API for orchestrating physical design flow execution",
        version="1.0.0",
    )

    # Add CORS middleware for web UI integration
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure for your web UI domain
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Store references
    app.state.config_manager = config_manager
    app.state.stage_executor = stage_executor
    app.state.orchestrator = orchestrator_agent
    app.state.state_tracker = state_tracker
    initialize_lifecycle_runtime(app)

    @app.post("/jobs", response_model=JobCreateResponse, status_code=202, deprecated=True)
    async def create_job_compat(payload: JobCreateRequest) -> JobCreateResponse:
        """Compatibility endpoint mirroring legacy lifecycle job submission."""
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        identity = make_identity(session_id=payload.session_id)

        if flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                repository.create_job(
                    job_id=identity.job_id,
                    user_id=payload.user_id,  # Now accepts string directly (user_name)
                    session_id=identity.session_id,
                    run_id=identity.run_id,
                    config_payload=payload.model_dump(),
                )
            finally:
                session.close()

        state = {
            "job_id": identity.job_id,
            "run_id": identity.run_id,
            "user_id": payload.user_id,
            "session_id": identity.session_id,
            "status": "PENDING",
            "phase": "QUEUED",
            "iteration": 0,
            "current_tool": None,
            "progress_message": "Job accepted",
            "max_retries": payload.max_retries,
            "max_iterations": payload.max_iterations,
            "script_path": payload.script_path,
            "instructions_path": payload.instructions_path,
            "allowed_paths": payload.allowed_paths,
            # "resource_class": safe_str(payload.resource_class) or None,
        }

        if flags.use_redis_job_state and app.state.job_state_store is not None:
            app.state.job_state_store.enqueue_job_with_state(
                identity.job_id,
                state,
                {
                    "job_id": identity.job_id,
                    "run_id": identity.run_id,
                    "config": {
                        **payload.model_dump(),
                        "run_id": identity.run_id,
                        # "resource_class": safe_str(payload.resource_class) or None,
                    },
                },
            )

            if app.state.job_event_publisher is not None:
                app.state.job_event_publisher.publish_job_event(
                    identity.job_id,
                    {
                        "event_type": "queued",
                        "status": "PENDING",
                        "phase": "QUEUED",
                        "run_id": identity.run_id,
                        "message": "Job accepted and queued",
                    },
                )

        return JobCreateResponse(job_id=identity.job_id, run_id=identity.run_id or "", status="PENDING", phase="QUEUED")

    @app.get("/jobs/{job_id}/job_status", response_model=JobStatusResponse, deprecated=True)
    async def get_job_status_compat(job_id: str) -> JobStatusResponse:
        """Compatibility endpoint mirroring legacy lifecycle status checks."""
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        if flags.use_redis_job_state and app.state.job_state_store is not None:
            redis_state = app.state.job_state_store.get_job_state(job_id)
            if redis_state:
                return JobStatusResponse(
                    job_id=job_id,
                    run_id=safe_str(redis_state.get("run_id")),
                    status=str(redis_state.get("status", "UNKNOWN")),
                    phase=str(redis_state.get("phase", "UNKNOWN")),
                    iteration=safe_int(redis_state.get("iteration")),
                    current_tool=safe_str(redis_state.get("current_tool")),
                    progress_message=safe_str(redis_state.get("progress_message")),
                )

        if flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                job = repository.get_job(job_id)
            finally:
                session.close()

            if job:
                return JobStatusResponse(
                    job_id=job_id,
                    run_id=safe_str(job.get("run_id")),
                    status=str(job.get("status", "UNKNOWN")),
                    phase=str(job.get("phase", "UNKNOWN")),
                    iteration=None,
                    current_tool=safe_str(job.get("current_tool")),
                    progress_message=None,
                )

        raise HTTPException(status_code=404, detail="Job not found")

    # ========================================================================
    # Health & Info Endpoints
    # ========================================================================

    @app.get("/health")
    async def health() -> Dict[str, str]:
        """Health check endpoint"""
        return {
            "status": "healthy",
            "service": "Physical Design Flow API",
        }

    @app.get("/info")
    async def info() -> Dict[str, Any]:
        """Get API and project information"""
        return {
            "service": "Physical Design Flow API",
            "version": "1.0.0",
            "project": config_manager.config_paths.project_root.name,
            "block": config_manager._get_block_name(),
        }

    # ========================================================================
    # Flow Execution Endpoints
    # ========================================================================

    @app.post("/flow/execute", response_model=ExecuteResponse)
    async def execute_flow(
        request: ExecuteRequest,
        background_tasks: BackgroundTasks,
        http_request: Request,
    ) -> ExecuteResponse:
        """
        Execute flow with natural language prompt (multi-user capable)

        Args:
            request: ExecuteRequest with prompt and options
            background_tasks: For background execution
            http_request: HTTP request for app state access

        Returns:
            ExecuteResponse with execution details and thread_id
        """
        try:
            # Check if using new multi-user mode (with PhysicalDesignGraph)
            physical_design_graph = getattr(http_request.app.state, 'physical_design_graph', None)
            saver = getattr(http_request.app.state, 'saver', None)

            if physical_design_graph is not None and saver is not None:
                # NEW: Multi-user mode with PhysicalDesignGraph
                print(f"\n[API] Using PhysicalDesignGraph (multi-user mode)")

                # Extract UI metadata (from dropdown selections)
                user_id = request.user_id or "anonymous"
                block_name = request.block or "default"
                experiment_name = request.experiment_name or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

                # Generate thread_id: {user}_{block}_{experiment}_{timestamp}
                # This ensures complete isolation per user/block/experiment combination
                thread_id = create_thread_id(
                    user_id=user_id,
                    block_name=block_name,
                    run_id=experiment_name,  # Internal name: run_id (for compatibility)
                )
                print(f"[API] Thread ID: {thread_id}")
                print(f"[API] User: {user_id}, Block: {block_name}, Experiment: {experiment_name}")

                # Create initial state with UI metadata
                start_time = datetime.now().isoformat()
                flow_state: FlowState = {
                    "prompt": request.prompt,
                    "debug_mode": request.debug_mode or "interactive",
                    "user_id": user_id,
                    "run_id": experiment_name,  # Internal field (maps to experiment_name)
                    "intent": None,
                    "plan": [],
                    "current_stage_index": 0,
                    "stages_executed": [],
                    "stages_failed": [],
                    "stages_skipped": [],
                    "stage_results": {},
                    "error_info": None,
                    "error_retry_count": 0,
                    "max_retries": 3,
                    "debug_history": {},
                    "debug_result": None,
                    "start_time": start_time,
                    "end_time": None,
                    "execution_status": "pending",
                }

                # Store UI parameters in state for graph nodes
                if request.project:
                    flow_state["project"] = request.project
                if request.block:
                    flow_state["block"] = request.block
                if request.rtl_tag:
                    flow_state["rtl_tag"] = request.rtl_tag

                # Invoke graph with checkpointing
                config = get_config_for_thread(thread_id)
                result = await physical_design_graph.graph.ainvoke(flow_state, config)

                return ExecuteResponse(
                    thread_id=thread_id,
                    experiment_name=experiment_name,
                    status=result.get("execution_status", "completed"),
                    stages_executed=result.get("stages_executed", []),
                    stages_failed=result.get("stages_failed", []),
                    duration=0.0,
                    start_time=start_time,
                    end_time=result.get("end_time"),
                )

            else:
                # LEGACY: Single-user mode with OrchestratorAgent
                print(f"\n[API] Using OrchestratorAgent (legacy single-user mode)")

                # Start execution tracking
                await state_tracker.start_execution(
                    debug_mode=request.debug_mode,
                    enable_ai=request.enable_ai,
                )

                # Execute flow
                result = await orchestrator_agent.process_prompt(
                    prompt=request.prompt,
                    debug_mode=request.debug_mode,
                )

                # Complete tracking
                await state_tracker.complete_execution(
                    overall_status=result.get("status", "completed")
                )

                # Get state
                state = state_tracker.get_state()

                return ExecuteResponse(
                    thread_id=None,  # No thread_id in legacy mode
                    experiment_name=None,  # No experiment in legacy mode
                    status=result.get("status", "completed"),
                    stages_executed=result.get("stages_executed", []),
                    stages_failed=result.get("stages_failed", []),
                    duration=result.get("duration", 0.0),
                    start_time=result.get("start_time", ""),
                    end_time=result.get("end_time"),
                )

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/flow/execute-async")
    async def execute_flow_async(
        request: ExecuteRequest,
        background_tasks: BackgroundTasks,
    ) -> Dict[str, str]:
        """
        Execute flow asynchronously (returns immediately)

        Args:
            request: ExecuteRequest with prompt and options
            background_tasks: For background execution

        Returns:
            Dictionary with run_id and status
        """
        try:
            # Start execution in background
            background_tasks.add_task(
                orchestrator_agent.process_prompt,
                request.prompt,
                request.debug_mode,
            )

            # Get state
            state = state_tracker.get_state()

            return {
                "run_id": state.get("run_id", ""),
                "status": "started",
                "message": "Flow execution started in background",
            }

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # ========================================================================
    # Status Endpoints
    # ========================================================================

    @app.get("/flow/status", response_model=StatusResponse)
    async def get_status(thread_id: Optional[str] = None, http_request: Request = None) -> StatusResponse:
        """Get current flow status (multi-user capable)

        Args:
            thread_id: Thread ID for multi-user mode (optional)
            http_request: HTTP request for app state access
        """
        try:
            # Check if using multi-user mode
            if thread_id and hasattr(http_request.app.state, 'saver'):
                saver = http_request.app.state.saver
                config = get_config_for_thread(thread_id)
                checkpoint = await saver.aget(config)

                if not checkpoint:
                    raise HTTPException(status_code=404, detail=f"Thread {thread_id} not found")

                state = checkpoint.get("channel_values", {})
                stages_result = state.get("stage_results", {})

                # Calculate progress
                completed = sum(1 for s in stages_result.values() if s.get("status") == "success")
                total = len(stages_result) if stages_result else 1
                progress = int((completed / total * 100)) if total > 0 else 0

                return StatusResponse(
                    thread_id=thread_id,
                    run_id=state.get("run_id", ""),
                    status=state.get("execution_status", "pending"),
                    current_stage=None,
                    stages={name: ("completed" if s.get("status") == "success" else "failed")
                            for name, s in stages_result.items()},
                    progress_percent=progress,
                    start_time=state.get("start_time", ""),
                    end_time=state.get("end_time"),
                    duration=0.0,
                )
            else:
                # Legacy single-user mode
                state = state_tracker.get_state()
                stages = state.get("stages", {})

                # Calculate progress
                completed = sum(
                    1
                    for s in stages.values()
                    if s.get("status") == "completed"
                )
                total = len(stages) if stages else 1
                progress = int((completed / total * 100)) if total > 0 else 0

                return StatusResponse(
                    thread_id=None,
                    run_id=state.get("run_id", ""),
                    status=state.get("status", "pending"),
                    current_stage=state.get("current_stage"),
                    stages={name: s.get("status", "pending") for name, s in stages.items()},
                    progress_percent=progress,
                    start_time=state.get("start_time", ""),
                    end_time=state.get("end_time"),
                    duration=state.get("duration", 0.0),
                )

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/flow/stages", response_model=List[StageInfo])
    async def get_stages() -> List[StageInfo]:
        """Get list of available stages"""
        stages = []
        for stage_name, stage_info in orchestrator_agent.STAGES.items():
            stages.append(
                StageInfo(
                    name=stage_name,
                    tool=stage_info.get("tool", ""),
                    description=stage_info.get("description", ""),
                    depends_on=stage_info.get("depends_on", []),
                )
            )
        return stages

    @app.get("/flow/history", response_model=List[HistoryResponse])
    async def get_history() -> List[HistoryResponse]:
        """Get execution history"""
        try:
            history_records = state_tracker.get_execution_history()
            history = []
            for record in history_records:
                history.append(
                    HistoryResponse(
                        run_id=record.get("run_id", ""),
                        status=record.get("status", ""),
                        duration=record.get("duration", 0.0),
                        start_time=record.get("start_time", ""),
                        end_time=record.get("end_time"),
                        stages_count=len(record.get("stages", {})),
                    )
                )
            return history

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # ========================================================================
    # Logs Endpoints
    # ========================================================================

    @app.get("/flow/logs/{stage_name}", response_model=StageLogResponse)
    async def get_stage_log(stage_name: str) -> StageLogResponse:
        """Get log for a specific stage"""
        try:
            log_path = state_tracker.get_stage_log_path(stage_name)
            if not log_path or not log_path.exists():
                raise HTTPException(status_code=404, detail=f"Log not found for {stage_name}")

            with open(log_path, "r") as f:
                content = f.read()

            return StageLogResponse(
                stage_name=stage_name,
                log_content=content,
                size_bytes=len(content),
            )

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/flow/logs")
    async def list_stage_logs() -> Dict[str, str]:
        """List all available stage logs"""
        try:
            state = state_tracker.get_state()
            stages = state.get("stages", {})

            logs = {}
            for stage_name, stage_info in stages.items():
                log_file = stage_info.get("log_file")
                if log_file:
                    logs[stage_name] = log_file

            return logs

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # ========================================================================
    # WebSocket Endpoint for Real-time Updates
    # ========================================================================

    @app.websocket("/flow/ws")
    async def websocket_endpoint(websocket: WebSocket):
        """
        WebSocket endpoint for real-time status updates

        Clients connect and receive status updates as stages complete
        """
        await websocket.accept()

        try:
            while True:
                # Send current status every second
                state = state_tracker.get_state()
                stages = state.get("stages", {})

                # Calculate progress
                completed = sum(
                    1
                    for s in stages.values()
                    if s.get("status") == "completed"
                )
                total = len(stages) if stages else 1
                progress = int((completed / total * 100)) if total > 0 else 0

                update = {
                    "type": "status_update",
                    "run_id": state.get("run_id"),
                    "status": state.get("status"),
                    "current_stage": state.get("current_stage"),
                    "progress": progress,
                    "stages": stages,
                }

                await websocket.send_json(update)

                # Wait before next update
                await asyncio.sleep(1)

        except Exception as e:
            print(f"WebSocket error: {e}")
        finally:
            await websocket.close()

    # ========================================================================
    # Control Endpoints
    # ========================================================================

    @app.post("/flow/pause")
    async def pause_execution() -> Dict[str, str]:
        """Pause current execution (stub for future implementation)"""
        return {"status": "paused"}

    @app.post("/flow/resume")
    async def resume_execution() -> Dict[str, str]:
        """Resume paused execution (stub for future implementation)"""
        return {"status": "resumed"}

    @app.post("/flow/abort")
    async def abort_execution() -> Dict[str, str]:
        """Abort current execution (stub for future implementation)"""
        return {"status": "aborted"}

    # ========================================================================
    # Multi-User Thread Management Endpoints
    # ========================================================================

    @app.get("/threads")
    async def list_threads(
        user_id: Optional[str] = None,
        http_request: Request = None,
    ) -> Dict[str, Any]:
        """
        List all threads, optionally filtered by user_id

        Args:
            user_id: Optional user_id to filter by
            http_request: HTTP request for app state access

        Returns:
            Dict with list of threads
        """
        try:
            saver = getattr(http_request.app.state, 'saver', None)
            if not saver:
                raise HTTPException(status_code=501, detail="Multi-user mode not enabled")

            # This would require querying all threads from saver
            # For now, return empty list until threaded checkpoint listing endpoint is added
            return {"threads": []}

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.delete("/thread/{thread_id}")
    async def delete_thread(
        thread_id: str,
        http_request: Request = None,
    ) -> Dict[str, str]:
        """
        Delete a thread and its checkpoint

        Args:
            thread_id: Thread ID to delete
            http_request: HTTP request for app state access

        Returns:
            Confirmation message
        """
        try:
            saver = getattr(http_request.app.state, 'saver', None)
            if not saver:
                raise HTTPException(status_code=501, detail="Multi-user mode not enabled")

            config = get_config_for_thread(thread_id)
            await saver.adelete_thread(config)

            return {"message": f"Thread {thread_id} deleted"}

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/thread/{thread_id}/history")
    async def get_thread_history(
        thread_id: str,
        http_request: Request = None,
    ) -> Dict[str, Any]:
        """
        Get full execution history for a thread

        Args:
            thread_id: Thread ID to query
            http_request: HTTP request for app state access

        Returns:
            Dict with thread state and checkpoint info
        """
        try:
            saver = getattr(http_request.app.state, 'saver', None)
            if not saver:
                raise HTTPException(status_code=501, detail="Multi-user mode not enabled")

            config = get_config_for_thread(thread_id)
            checkpoint = await saver.aget(config)

            if not checkpoint:
                raise HTTPException(status_code=404, detail=f"Thread {thread_id} not found")

            return {
                "thread_id": thread_id,
                "state": checkpoint.get("channel_values", {}),
                "checkpoint_id": checkpoint.get("checkpoint_id"),
                "timestamp": checkpoint.get("timestamp"),
            }

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/thread/{thread_id}/resume")
    async def resume_thread(
        thread_id: str,
        http_request: Request = None,
    ) -> ExecuteResponse:
        """
        Resume execution from a checkpoint

        Args:
            thread_id: Thread ID to resume
            http_request: HTTP request for app state access

        Returns:
            ExecuteResponse with updated status
        """
        try:
            physical_design_graph = getattr(http_request.app.state, 'physical_design_graph', None)
            saver = getattr(http_request.app.state, 'saver', None)

            if not physical_design_graph or not saver:
                raise HTTPException(status_code=501, detail="Multi-user mode not enabled")

            config = get_config_for_thread(thread_id)
            checkpoint = await saver.aget(config)

            if not checkpoint:
                raise HTTPException(status_code=404, detail=f"Thread {thread_id} not found")

            # Resume execution from checkpoint
            result = await physical_design_graph.graph.ainvoke(None, config)

            # Extract experiment_name from result or thread_id
            experiment_name = result.get("run_id", "")
            if not experiment_name:
                # Parse from thread_id: {user}_{block}_{experiment}_{timestamp}
                from ..tracker.langgraph_saver import parse_thread_id
                parsed = parse_thread_id(thread_id)
                experiment_name = parsed.get("experiment")

            return ExecuteResponse(
                thread_id=thread_id,
                experiment_name=experiment_name,
                status=result.get("execution_status", "completed"),
                stages_executed=result.get("stages_executed", []),
                stages_failed=result.get("stages_failed", []),
                duration=0.0,
                start_time=result.get("start_time", ""),
                end_time=result.get("end_time"),
            )

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    return app


# ============================================================================
# Standalone Application Factory
# ============================================================================


def create_app() -> FastAPI:
    """Create standalone FastAPI application"""
    # This would be used when running the API independently
    # In practice, you'd pass real instances from main.py

    print("Creating FastAPI application...")
    print("Note: This is a factory function. Use run_server() to start with real components.")

    app = FastAPI(title="Physical Design Flow API")

    @app.get("/health")
    async def health():
        return {"status": "healthy"}

    return app
