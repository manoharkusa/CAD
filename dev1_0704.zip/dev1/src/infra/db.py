"""SQLAlchemy engine/session providers for lifecycle persistence."""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from ..config.env_loader import load_env_file
from ..config.runtime_config import RuntimeConfig
from .models import Base

load_env_file()
_runtime = RuntimeConfig.from_env()
engine = create_engine(_runtime.postgres_uri, echo=False, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def get_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def initialize_lifecycle_schema() -> None:
    """Create lifecycle persistence tables if they do not already exist."""
    Base.metadata.create_all(bind=engine)
    with engine.begin() as connection:
        connection.execute(text("ALTER TABLE jobs ADD COLUMN IF NOT EXISTS run_id VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS run_id VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS max_iterations INTEGER"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS prompt TEXT"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS user_name VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS project VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS block VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS rtl_tag VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS experiment_name VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS debug_mode VARCHAR"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS require_plan_confirmation BOOLEAN"))
        connection.execute(text("ALTER TABLE job_configurations ADD COLUMN IF NOT EXISTS config_payload JSONB"))
        connection.execute(text("ALTER TABLE human_interactions ADD COLUMN IF NOT EXISTS interaction_type VARCHAR"))
        connection.execute(text("ALTER TABLE human_interactions ADD COLUMN IF NOT EXISTS decision VARCHAR"))
        connection.execute(text("ALTER TABLE human_interactions ADD COLUMN IF NOT EXISTS additional_context TEXT"))
        connection.execute(text("ALTER TABLE human_interactions ADD COLUMN IF NOT EXISTS decision_status VARCHAR"))
        connection.execute(text("ALTER TABLE human_interactions ADD COLUMN IF NOT EXISTS expires_at TIMESTAMP"))
        connection.execute(text("ALTER TABLE human_interactions ADD COLUMN IF NOT EXISTS version INTEGER"))
        connection.execute(text("ALTER TABLE human_interactions ADD COLUMN IF NOT EXISTS interaction_metadata JSONB"))

        # Design runs table columns (if table created via ORM, ensure extra columns exist)
        connection.execute(text("ALTER TABLE design_runs ADD COLUMN IF NOT EXISTS stages_failed JSONB DEFAULT '[]'"))
        connection.execute(text("ALTER TABLE design_runs ADD COLUMN IF NOT EXISTS validation_results JSONB DEFAULT '{}'"))

        # Stage progress table columns
        connection.execute(text("ALTER TABLE stage_progress ADD COLUMN IF NOT EXISTS progress_percent INTEGER DEFAULT 0"))
        connection.execute(text("ALTER TABLE stage_progress ADD COLUMN IF NOT EXISTS slurm_job_id VARCHAR"))
        connection.execute(text("ALTER TABLE stage_progress ADD COLUMN IF NOT EXISTS validation_issues JSONB"))
        connection.execute(text("ALTER TABLE stage_progress ADD COLUMN IF NOT EXISTS error_category VARCHAR"))

        # Create partial unique index for design run locking (if not exists)
        connection.execute(text("""
            DO $$
            BEGIN
                IF NOT EXISTS (
                    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_unique_running_design'
                ) THEN
                    CREATE UNIQUE INDEX idx_unique_running_design
                    ON design_runs (project, block, rtl_tag, experiment)
                    WHERE status = 'running';
                END IF;
            END $$;
        """))
