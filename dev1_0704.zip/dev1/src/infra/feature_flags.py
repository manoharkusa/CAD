"""Feature flags for incremental lifecycle integration."""

from __future__ import annotations

import os
from dataclasses import dataclass


def _to_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class FeatureFlags:
    use_job_lifecycle_api: bool
    use_postgres_job_repo: bool
    use_redis_job_state: bool

    @classmethod
    def from_env(cls) -> "FeatureFlags":
        return cls(
            use_job_lifecycle_api=_to_bool(os.getenv("USE_JOB_LIFECYCLE_API"), default=False),
            use_postgres_job_repo=_to_bool(os.getenv("USE_POSTGRES_JOB_REPO"), default=False),
            use_redis_job_state=_to_bool(os.getenv("USE_REDIS_JOB_STATE"), default=False),
        )
