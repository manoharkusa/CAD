"""PostgreSQL ORM models for design run tracking and locking."""

from __future__ import annotations

from datetime import datetime
import uuid

from sqlalchemy import (
    Column, String, Integer, Boolean, DateTime, Text, ForeignKey,
    Index, UniqueConstraint
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship

from .job_models import Base


class DesignRun(Base):
    """
    Tracks active design runs with locking capability.

    The unique partial index on (project, block, rtl_tag, experiment) WHERE status='running'
    ensures only one running job per design combination.
    """
    __tablename__ = "design_runs"

    run_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Design identity
    project = Column(String, nullable=False)
    block = Column(String, nullable=False)
    rtl_tag = Column(String, nullable=False)
    experiment = Column(String, nullable=False)

    # Session info
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"), nullable=True)
    session_id = Column(String, nullable=True)
    user_name = Column(String, nullable=True)

    # Status: running, completed, failed, cancelled
    status = Column(String, nullable=False, default="running")

    # Progress tracking
    current_stage = Column(String, nullable=True)
    current_stage_index = Column(Integer, default=0)
    total_stages = Column(Integer, default=0)
    progress_percent = Column(Integer, default=0)

    # Plan and execution state
    plan = Column(JSONB, nullable=True)  # ["syn", "place", "cts", ...]
    stages_completed = Column(JSONB, default=list)
    stages_failed = Column(JSONB, default=list)

    # Validation results
    validation_results = Column(JSONB, default=dict)

    # Timestamps
    started_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

    # Relationships
    stage_progress = relationship("StageProgress", back_populates="design_run", cascade="all, delete-orphan")

    __table_args__ = (
        # Partial unique index for locking - only one running job per design
        Index(
            'idx_unique_running_design',
            project, block, rtl_tag, experiment,
            unique=True,
            postgresql_where=(status == 'running')
        ),
        Index('idx_design_runs_status', status),
        Index('idx_design_runs_design', project, block, rtl_tag, experiment),
    )

    def to_dict(self) -> dict:
        """Convert to dictionary for API responses."""
        return {
            "run_id": str(self.run_id),
            "project": self.project,
            "block": self.block,
            "rtl_tag": self.rtl_tag,
            "experiment": self.experiment,
            "job_id": str(self.job_id) if self.job_id else None,
            "session_id": self.session_id,
            "user_name": self.user_name,
            "status": self.status,
            "current_stage": self.current_stage,
            "current_stage_index": self.current_stage_index,
            "total_stages": self.total_stages,
            "progress_percent": self.progress_percent,
            "plan": self.plan,
            "stages_completed": self.stages_completed,
            "stages_failed": self.stages_failed,
            "validation_results": self.validation_results,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class StageProgress(Base):
    """
    Detailed progress tracking for each stage in a run.

    This table is denormalized for easy Web UI queries - design identity
    fields are duplicated from DesignRun for faster lookups without joins.

    Status values: pending, inprogress, completed, failed, cancelled, skipped
    """
    __tablename__ = "stage_progress"

    progress_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    run_id = Column(UUID(as_uuid=True), ForeignKey("design_runs.run_id", ondelete="CASCADE"), nullable=False)

    # Session and job tracking (denormalized for Web UI)
    session_id = Column(String, nullable=True, index=True)
    job_id = Column(UUID(as_uuid=True), nullable=True, index=True)
    user_name = Column(String, nullable=True, index=True)

    # Design identity (denormalized for Web UI queries)
    project_name = Column(String, nullable=True, index=True)
    block_name = Column(String, nullable=True, index=True)
    rtl_tag = Column(String, nullable=True)
    experiment_name = Column(String, nullable=True)

    # Stage info
    stage_name = Column(String, nullable=False)
    tool_name = Column(String, nullable=True)  # genus, innovus, dc_shell, icc2, etc.
    stage_index = Column(Integer, nullable=True)

    # Status: pending, inprogress, completed, failed, cancelled, skipped
    status = Column(String, nullable=False, default="pending")

    # Progress
    progress_percent = Column(Integer, default=0)

    # Timing (renamed for clarity)
    start_time = Column(DateTime, nullable=True)
    end_time = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, nullable=True)

    # Legacy timing columns (kept for backward compatibility)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    # Execution results
    return_code = Column(Integer, nullable=True)
    log_file = Column(String, nullable=True)
    slurm_job_id = Column(String, nullable=True)

    # Validation
    validation_status = Column(String, nullable=True)  # passed, failed, skipped
    validation_metrics = Column(JSONB, nullable=True)
    validation_issues = Column(JSONB, nullable=True)

    # Error info
    error_message = Column(Text, nullable=True)
    error_category = Column(String, nullable=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    design_run = relationship("DesignRun", back_populates="stage_progress")

    __table_args__ = (
        UniqueConstraint('run_id', 'stage_name', name='uq_run_stage'),
        Index('idx_stage_progress_run', run_id),
        Index('idx_stage_progress_status', status),
        Index('idx_stage_progress_project_block', project_name, block_name),
        Index('idx_stage_progress_session', session_id),
        Index('idx_stage_progress_job', job_id),
    )

    def to_dict(self) -> dict:
        """Convert to dictionary for API responses."""
        return {
            "progress_id": str(self.progress_id),
            "run_id": str(self.run_id),
            "session_id": self.session_id,
            "job_id": str(self.job_id) if self.job_id else None,
            "user_name": self.user_name,
            "project_name": self.project_name,
            "block_name": self.block_name,
            "rtl_tag": self.rtl_tag,
            "experiment_name": self.experiment_name,
            "stage_name": self.stage_name,
            "tool_name": self.tool_name,
            "stage_index": self.stage_index,
            "status": self.status,
            "progress_percent": self.progress_percent,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "duration_seconds": self.duration_seconds,
            "return_code": self.return_code,
            "log_file": self.log_file,
            "slurm_job_id": self.slurm_job_id,
            "validation_status": self.validation_status,
            "validation_metrics": self.validation_metrics,
            "validation_issues": self.validation_issues,
            "error_message": self.error_message,
            "error_category": self.error_category,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
