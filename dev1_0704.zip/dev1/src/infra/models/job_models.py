"""PostgreSQL ORM models for job lifecycle tracking."""

from __future__ import annotations

from datetime import datetime
import uuid

from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, ForeignKey, UniqueConstraint, Index
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class Job(Base):
    __tablename__ = "jobs"
    job_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    run_id = Column(String, nullable=True)
    user_id = Column(String, nullable=True)  # Can be user_name directly
    session_id = Column(String, nullable=True)
    status = Column(String, nullable=False)
    phase = Column(String, nullable=False)
    current_tool = Column(String, nullable=True)
    retry_count = Column(Integer, default=0)
    triggered_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    result_summary = Column(JSONB, nullable=True)

    config = relationship("JobConfiguration", uselist=False, back_populates="job")
    history = relationship("ExecutionHistory", back_populates="job")
    interactions = relationship("HumanInteraction", back_populates="job")
    checkpoints = relationship("JobCheckpoint", back_populates="job")
    stage_records = relationship("JobStageRecord", back_populates="job")
    file_changes = relationship("JobFileChange", back_populates="job")
    issue_incidents = relationship("IssueIncident", back_populates="job")


class JobConfiguration(Base):
    __tablename__ = "job_configurations"
    config_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"))
    run_id = Column(String, nullable=True)
    script_path = Column(String, nullable=False)
    instructions_path = Column(String, nullable=True)
    allowed_paths = Column(JSONB, nullable=True)
    max_retries = Column(Integer, default=3)
    max_iterations = Column(Integer, default=5)
    prompt = Column(Text, nullable=True)
    user_name = Column(String, nullable=True)
    project = Column(String, nullable=True)
    block = Column(String, nullable=True)
    rtl_tag = Column(String, nullable=True)
    experiment_name = Column(String, nullable=True)
    debug_mode = Column(String, nullable=True)
    require_plan_confirmation = Column(Boolean, default=True)
    config_payload = Column(JSONB, nullable=True)

    job = relationship("Job", back_populates="config")


class ExecutionHistory(Base):
    __tablename__ = "execution_history"
    history_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"))
    sequence_num = Column(Integer, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    action_type = Column(String, nullable=False)
    tool_name = Column(String, nullable=True)
    input_params = Column(JSONB, nullable=True)
    output_result = Column(JSONB, nullable=True)
    duration_ms = Column(Integer, nullable=True)
    error_message = Column(Text, nullable=True)

    job = relationship("Job", back_populates="history")


class HumanInteraction(Base):
    __tablename__ = "human_interactions"
    interaction_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"))
    prompt = Column(Text, nullable=False)
    options = Column(JSONB, nullable=True)
    interaction_type = Column(String, nullable=True)
    decision = Column(String, nullable=True)
    additional_context = Column(Text, nullable=True)
    decision_status = Column(String, nullable=True)
    expires_at = Column(DateTime, nullable=True)
    version = Column(Integer, nullable=True)
    interaction_metadata = Column(JSONB, nullable=True)
    human_response = Column(Text, nullable=True)
    requested_at = Column(DateTime, default=datetime.utcnow)
    responded_at = Column(DateTime, nullable=True)
    timeout_seconds = Column(Integer, default=3600)

    job = relationship("Job", back_populates="interactions")


class ErrorLog(Base):
    __tablename__ = "error_logs"
    error_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"))
    stage = Column(String, nullable=True)
    tool = Column(String, nullable=True)
    error_type = Column(String, nullable=False)
    error_message = Column(Text, nullable=False)
    stack_trace = Column(Text, nullable=True)
    context = Column(JSONB, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    resolved = Column(Boolean, default=False)
    resolution = Column(Text, nullable=True)


class JobCheckpoint(Base):
    __tablename__ = "job_checkpoints"
    checkpoint_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"))
    state = Column(JSONB, nullable=False)
    current_node = Column(String, nullable=True)
    next_node = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    job = relationship("Job", back_populates="checkpoints")


class JobStageRecord(Base):
    __tablename__ = "job_stage_records"
    record_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"), nullable=False)
    run_id = Column(String, nullable=True)
    stage = Column(String, nullable=False)
    tool = Column(String, nullable=True)
    stage_order = Column(Integer, nullable=True)
    attempt = Column(Integer, default=1)
    status = Column(String, nullable=False)
    summary = Column(Text, nullable=True)
    error_details = Column(Text, nullable=True)
    started_at = Column(DateTime, nullable=True)
    ended_at = Column(DateTime, nullable=True)
    duration_ms = Column(Integer, nullable=True)
    stage_metadata = Column(JSONB, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    job = relationship("Job", back_populates="stage_records")

    __table_args__ = (
        Index("ix_job_stage_records_job_stage", "job_id", "stage"),
        Index("ix_job_stage_records_run_stage", "run_id", "stage"),
    )


class JobFileChange(Base):
    __tablename__ = "job_file_changes"
    change_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"), nullable=False)
    run_id = Column(String, nullable=True)
    stage = Column(String, nullable=True)
    file_path = Column(String, nullable=False)
    change_type = Column(String, nullable=False)
    tool_name = Column(String, nullable=True)
    before_hash = Column(String, nullable=True)
    after_hash = Column(String, nullable=True)
    diff_excerpt = Column(Text, nullable=True)
    change_metadata = Column(JSONB, nullable=True)
    happened_at = Column(DateTime, default=datetime.utcnow)

    job = relationship("Job", back_populates="file_changes")

    __table_args__ = (
        Index("ix_job_file_changes_job", "job_id"),
        Index("ix_job_file_changes_run_stage", "run_id", "stage"),
        Index("ix_job_file_changes_path", "file_path"),
    )


class IssueKnowledge(Base):
    __tablename__ = "issue_knowledge"
    issue_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    canonical_key = Column(String, nullable=False)
    fingerprint_hash = Column(String, nullable=False)
    session_id = Column(String, nullable=True)
    project = Column(String, nullable=True)
    block = Column(String, nullable=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    tool = Column(String, nullable=True)
    technology = Column(String, nullable=True)
    issue_category = Column(String, nullable=False, default="others")
    stage = Column(String, nullable=False)
    debug_steps = Column(Text, nullable=True)
    resolution = Column(Text, nullable=True)
    taxonomy_version = Column(String, nullable=False, default="v1")
    first_seen_at = Column(DateTime, default=datetime.utcnow)
    last_seen_at = Column(DateTime, default=datetime.utcnow)
    occurrence_count = Column(Integer, default=1)
    issue_metadata = Column(JSONB, nullable=True)

    incidents = relationship("IssueIncident", back_populates="issue")
    fix_variants = relationship("IssueFixVariant", back_populates="issue")

    __table_args__ = (
        UniqueConstraint("fingerprint_hash", name="uq_issue_knowledge_fingerprint_hash"),
        UniqueConstraint("canonical_key", name="uq_issue_knowledge_canonical_key"),
        Index("ix_issue_knowledge_session", "session_id"),
        Index("ix_issue_knowledge_stage_category", "stage", "issue_category"),
        Index("ix_issue_knowledge_tool", "tool"),
    )


class IssueIncident(Base):
    __tablename__ = "issue_incidents"
    incident_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    issue_id = Column(UUID(as_uuid=True), ForeignKey("issue_knowledge.issue_id"), nullable=False)
    job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"), nullable=False)
    run_id = Column(String, nullable=True)
    session_id = Column(String, nullable=True)
    stage = Column(String, nullable=False)
    error_signature = Column(String, nullable=True)
    error_message = Column(Text, nullable=False)
    summary = Column(Text, nullable=True)
    incident_metadata = Column(JSONB, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    issue = relationship("IssueKnowledge", back_populates="incidents")
    job = relationship("Job", back_populates="issue_incidents")

    __table_args__ = (
        Index("ix_issue_incidents_issue", "issue_id"),
        Index("ix_issue_incidents_job", "job_id"),
        Index("ix_issue_incidents_session", "session_id"),
        Index("ix_issue_incidents_run_stage", "run_id", "stage"),
    )


class IssueTaxonomyEntry(Base):
    __tablename__ = "issue_taxonomy_entries"
    taxonomy_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    taxonomy_type = Column(String, nullable=False)
    canonical_value = Column(String, nullable=False)
    aliases = Column(JSONB, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("taxonomy_type", "canonical_value", name="uq_issue_taxonomy_type_value"),
        Index("ix_issue_taxonomy_type", "taxonomy_type"),
        Index("ix_issue_taxonomy_type_active", "taxonomy_type", "is_active"),
    )


class IssueSemanticIndex(Base):
    __tablename__ = "issue_semantic_index"
    semantic_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    issue_id = Column(UUID(as_uuid=True), ForeignKey("issue_knowledge.issue_id"), nullable=False)
    semantic_text = Column(Text, nullable=False)
    embedding_model = Column(String, nullable=True)
    embedding_vector = Column(JSONB, nullable=True)
    embedding_version = Column(String, nullable=True)
    last_indexed_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("issue_id", name="uq_issue_semantic_issue"),
        Index("ix_issue_semantic_indexed", "last_indexed_at"),
    )


class IssueFixVariant(Base):
    __tablename__ = "issue_fix_variants"
    variant_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    issue_id = Column(UUID(as_uuid=True), ForeignKey("issue_knowledge.issue_id"), nullable=False)
    variant_hash = Column(String, nullable=False)
    fix_title = Column(String, nullable=True)
    fix_applied = Column(Text, nullable=False)
    fix_steps = Column(Text, nullable=True)
    fix_payload = Column(JSONB, nullable=True)
    fix_source = Column(String, nullable=False, default="autofix")
    fix_status = Column(String, nullable=False, default="verified")
    success_count = Column(Integer, nullable=False, default=1)
    failure_count = Column(Integer, nullable=False, default=0)
    confidence_score = Column(Integer, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    last_fix_job_id = Column(UUID(as_uuid=True), ForeignKey("jobs.job_id"), nullable=True)
    last_fix_run_id = Column(String, nullable=True)
    last_used_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

    issue = relationship("IssueKnowledge", back_populates="fix_variants")

    __table_args__ = (
        UniqueConstraint("issue_id", "variant_hash", name="uq_issue_fix_variant_issue_hash"),
        Index("ix_issue_fix_variant_issue", "issue_id"),
        Index("ix_issue_fix_variant_active", "issue_id", "is_active"),
        Index("ix_issue_fix_variant_status", "fix_status"),
    )
