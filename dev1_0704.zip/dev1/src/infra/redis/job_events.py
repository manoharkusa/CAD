"""Redis pub/sub event adapter for job lifecycle events."""

from __future__ import annotations

import json
import time
from typing import Any, Dict, Optional

import redis

from ...config.runtime_config import RuntimeConfig


class RedisJobEventPublisher:
    def __init__(self, *, channel_prefix: str = "jobs", runtime_config: RuntimeConfig | None = None):
        runtime = runtime_config or RuntimeConfig.from_env()
        self.client = redis.Redis.from_url(runtime.redis_url, decode_responses=True)
        self.channel_prefix = channel_prefix

    def _event_channel(self, job_id: str) -> str:
        return f"{self.channel_prefix}:{job_id}:events"

    def _log_channel(self, job_id: str) -> str:
        return f"{self.channel_prefix}:{job_id}:logs"

    def _log_stream(self, job_id: str) -> str:
        return f"{self.channel_prefix}:{job_id}:logs:stream"

    def _timeline_stream(self, job_id: str) -> str:
        return f"{self.channel_prefix}:{job_id}:timeline:stream"

    def _seq_key(self, job_id: str) -> str:
        return f"{self.channel_prefix}:{job_id}:seq"

    def _next_seq(self, job_id: str) -> int:
        return int(self.client.incr(self._seq_key(job_id)))

    def _build_envelope(
        self,
        *,
        job_id: str,
        kind: str,
        message: str,
        payload: Dict[str, Any],
        source: str,
        level: str,
    ) -> Dict[str, Any]:
        seq = self._next_seq(job_id)
        ts_ms = int(time.time() * 1000)
        envelope: Dict[str, Any] = {
            "job_id": job_id,
            "kind": kind,
            "seq": seq,
            "ts_ms": ts_ms,
            "source": source,
            "level": level,
            "message": message,
            "payload": payload,
        }
        if kind == "event":
            envelope["event_type"] = payload.get("event_type")
            envelope["status"] = payload.get("status")
            envelope["phase"] = payload.get("phase")
        elif kind == "log":
            envelope["event_type"] = "log"
        return envelope

    def publish_job_event(self, job_id: str, payload: Dict[str, Any]) -> None:
        envelope = self._build_envelope(
            job_id=job_id,
            kind="event",
            message=str(payload.get("message") or payload.get("event_type") or "Lifecycle event"),
            payload=payload,
            source="lifecycle",
            level="INFO",
        )
        body = json.dumps(envelope)
        self.client.publish(self._event_channel(job_id), body)
        self.client.xadd(
            self._timeline_stream(job_id),
            {
                "seq": str(envelope["seq"]),
                "ts_ms": str(envelope["ts_ms"]),
                "kind": "event",
                "level": str(envelope["level"]),
                "source": str(envelope["source"]),
                "message": str(envelope["message"]),
                "data": body,
            },
            maxlen=10000,
            approximate=True,
        )

    def publish_job_log(
        self,
        job_id: str,
        *,
        message: str,
        payload: Dict[str, Any] | None = None,
        source: str = "agent",
        level: str = "INFO",
    ) -> None:
        envelope = self._build_envelope(
            job_id=job_id,
            kind="log",
            message=message,
            payload=payload or {},
            source=source,
            level=level,
        )
        body = json.dumps(envelope)
        self.client.publish(self._log_channel(job_id), body)
        self.client.xadd(
            self._log_stream(job_id),
            {
                "seq": str(envelope["seq"]),
                "ts_ms": str(envelope["ts_ms"]),
                "kind": "log",
                "level": str(envelope["level"]),
                "source": str(envelope["source"]),
                "message": str(envelope["message"]),
                "data": body,
            },
            maxlen=5000,
            approximate=True,
        )
        self.client.xadd(
            self._timeline_stream(job_id),
            {
                "seq": str(envelope["seq"]),
                "ts_ms": str(envelope["ts_ms"]),
                "kind": "log",
                "level": str(envelope["level"]),
                "source": str(envelope["source"]),
                "message": str(envelope["message"]),
                "data": body,
            },
            maxlen=10000,
            approximate=True,
        )

    def publish_abort(self, job_id: str) -> None:
        self.client.publish(f"{self.channel_prefix}:{job_id}:abort", json.dumps({"job_id": job_id, "event": "abort"}))

    def publish_hitl_response(self, job_id: str) -> None:
        self.client.publish(
            f"{self.channel_prefix}:{job_id}:hitl_response",
            json.dumps({"job_id": job_id, "event": "hitl_response"}),
        )

    def publish_hitl_required(self, job_id: str) -> None:
        self.client.publish(
            f"{self.channel_prefix}:{job_id}:hitl_required",
            json.dumps({"job_id": job_id, "event": "hitl_required"}),
        )

    def get_job_logs(self, job_id: str, *, limit: int = 100, before_seq: Optional[int] = None) -> list[Dict[str, Any]]:
        stream = self._log_stream(job_id)
        if limit < 1:
            return []

        fetch_count = max(limit * 5, limit)
        rows = self.client.xrevrange(stream, "+", "-", count=fetch_count)
        if not rows:
            return []

        selected: list[Dict[str, Any]] = []
        for _, fields in rows:
            raw_data = fields.get("data")
            if not raw_data:
                continue
            try:
                item = json.loads(raw_data)
            except Exception:
                continue

            seq_val = item.get("seq")
            if before_seq is not None and isinstance(seq_val, int) and seq_val >= before_seq:
                continue

            selected.append(item)
            if len(selected) >= limit:
                break

        selected.reverse()
        return selected

    def get_job_timeline(self, job_id: str, *, limit: int = 100, before_seq: Optional[int] = None) -> list[Dict[str, Any]]:
        stream = self._timeline_stream(job_id)
        if limit < 1:
            return []

        fetch_count = max(limit * 5, limit)
        rows = self.client.xrevrange(stream, "+", "-", count=fetch_count)
        if not rows:
            return []

        selected: list[Dict[str, Any]] = []
        for _, fields in rows:
            raw_data = fields.get("data")
            if not raw_data:
                continue
            try:
                item = json.loads(raw_data)
            except Exception:
                continue

            seq_val = item.get("seq")
            if before_seq is not None and isinstance(seq_val, int) and seq_val >= before_seq:
                continue

            selected.append(item)
            if len(selected) >= limit:
                break

        selected.reverse()
        return selected
