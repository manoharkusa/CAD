"""Redis-backed job state store adapter."""

from __future__ import annotations

import json
from enum import Enum
from typing import Any, Dict, Optional

import redis

from ...config.runtime_config import RuntimeConfig


class RedisJobStateStore:
    def __init__(self, *, key_prefix: str = "job", queue_key: str = "jobs:queue", runtime_config: Optional[RuntimeConfig] = None):
        runtime = runtime_config or RuntimeConfig.from_env()
        self.client = redis.Redis.from_url(runtime.redis_url, decode_responses=True)
        self.key_prefix = key_prefix
        self.queue_backend = runtime.queue_backend
        self.queue_key = runtime.redis_queue_key or queue_key
        self.stream_key = runtime.redis_stream_key
        self.stream_group = runtime.redis_stream_group
        self.stream_consumer = runtime.redis_stream_consumer
        self.stream_claim_idle_ms = runtime.redis_stream_claim_idle_ms
        self.stream_claim_count = runtime.redis_stream_claim_count
        self.active_runs_key = runtime.active_runs_key
        self.active_runs_class_prefix = runtime.active_runs_class_prefix
        self.dlq_key = runtime.redis_dlq_key
        self.ops_metrics_key = runtime.redis_ops_metrics_key

        if self.queue_backend == "stream":
            self._ensure_stream_group()

    def _ensure_stream_group(self) -> None:
        try:
            self.client.xgroup_create(self.stream_key, self.stream_group, id="0", mkstream=True)
        except redis.exceptions.ResponseError as exc:
            if "BUSYGROUP" not in str(exc):
                raise

    def _state_key(self, job_id: str) -> str:
        return f"{self.key_prefix}:{job_id}:state"

    @staticmethod
    def _encode(value: Any) -> Any:
        if value is None:
            return ""
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, Enum):
            return value.value
        if isinstance(value, (dict, list)):
            return json.dumps(value)
        if hasattr(value, "isoformat"):
            return value.isoformat()
        return value

    def enqueue_job_with_state(self, job_id: str, state: Dict[str, Any], payload: Dict[str, Any]) -> None:
        mapping = {k: self._encode(v) for k, v in state.items()}
        pipe = self.client.pipeline()
        pipe.hset(self._state_key(job_id), mapping=mapping)
        if self.queue_backend == "stream":
            pipe.xadd(self.stream_key, {"payload": json.dumps(payload)})
        else:
            pipe.lpush(self.queue_key, json.dumps(payload))
        pipe.execute()

    def dequeue_job(self, timeout_seconds: int = 5) -> Optional[Dict[str, Any]]:
        if self.queue_backend == "stream":
            self._ensure_stream_group()
            messages = self.client.xreadgroup(
                groupname=self.stream_group,
                consumername=self.stream_consumer,
                streams={self.stream_key: ">"},
                count=1,
                block=max(0, int(timeout_seconds * 1000)),
            )
            if messages:
                _, entries = messages[0]
                if entries:
                    return self._decode_stream_entry(entries[0], recovered_pending=False)

            # Recover stuck pending messages from failed/terminated consumers
            try:
                autoclaim_result = self.client.xautoclaim(
                    name=self.stream_key,
                    groupname=self.stream_group,
                    consumername=self.stream_consumer,
                    min_idle_time=self.stream_claim_idle_ms,
                    start_id="0-0",
                    count=self.stream_claim_count,
                )
            except redis.exceptions.ResponseError:
                return None

            claimed_entries = []
            if isinstance(autoclaim_result, tuple) and len(autoclaim_result) >= 2:
                claimed_entries = autoclaim_result[1] or []

            if claimed_entries:
                return self._decode_stream_entry(claimed_entries[0], recovered_pending=True)

            return None

        item = self.client.brpop(self.queue_key, timeout=timeout_seconds)
        if not item:
            return None
        _, raw_payload = item
        try:
            payload = json.loads(raw_payload)
        except Exception:
            return {"_queue_backend": "list", "_invalid": True}

        if not isinstance(payload, dict):
            return {"_queue_backend": "list", "_invalid": True}

        payload["_queue_backend"] = "list"
        return payload

    def _decode_stream_entry(self, entry: Any, *, recovered_pending: bool) -> Dict[str, Any]:
        message_id, fields = entry
        raw_payload = fields.get("payload") if isinstance(fields, dict) else None
        if not raw_payload:
            return {
                "_queue_backend": "stream",
                "_stream_message_id": message_id,
                "_invalid": True,
                "_recovered_pending": recovered_pending,
            }

        try:
            payload = json.loads(raw_payload)
        except Exception:
            payload = None

        if not isinstance(payload, dict):
            return {
                "_queue_backend": "stream",
                "_stream_message_id": message_id,
                "_invalid": True,
                "_recovered_pending": recovered_pending,
            }

        payload["_queue_backend"] = "stream"
        payload["_stream_message_id"] = message_id
        payload["_recovered_pending"] = recovered_pending
        return payload

    def ack_job(self, payload: Dict[str, Any]) -> None:
        if payload.get("_queue_backend") != "stream":
            return
        message_id = payload.get("_stream_message_id")
        if not message_id:
            return
        self.client.xack(self.stream_key, self.stream_group, message_id)

    def requeue_job(self, payload: Dict[str, Any]) -> None:
        payload_copy = dict(payload)
        payload_copy.pop("_queue_backend", None)
        payload_copy.pop("_stream_message_id", None)
        payload_copy.pop("_invalid", None)

        if self.queue_backend == "stream":
            self.client.xadd(self.stream_key, {"payload": json.dumps(payload_copy)})
        else:
            self.client.lpush(self.queue_key, json.dumps(payload_copy))

    def dead_letter_job(self, payload: Dict[str, Any], *, reason: str, error: Optional[str] = None) -> None:
        payload_copy = dict(payload)
        payload_copy.pop("_queue_backend", None)
        payload_copy.pop("_stream_message_id", None)
        payload_copy.pop("_invalid", None)

        envelope = {
            "reason": reason,
            "error": error,
            "payload": payload_copy,
        }

        if self.queue_backend == "stream":
            self.client.xadd(self.dlq_key, {"payload": json.dumps(envelope)})
        else:
            self.client.lpush(self.dlq_key, json.dumps(envelope))

    def incr_metric(self, name: str, amount: int = 1) -> None:
        if not name:
            return
        self.client.hincrby(self.ops_metrics_key, name, amount)

    def get_ops_metrics(self) -> Dict[str, Any]:
        metrics_raw = self.client.hgetall(self.ops_metrics_key) or {}
        metrics = {}
        for key, value in metrics_raw.items():
            try:
                metrics[key] = int(value)
            except Exception:
                metrics[key] = value

        queue_depth = self.client.xlen(self.stream_key) if self.queue_backend == "stream" else self.client.llen(self.queue_key)
        dlq_depth = self.client.xlen(self.dlq_key) if self.queue_backend == "stream" else self.client.llen(self.dlq_key)
        active_runs = self.client.scard(self.active_runs_key)

        pending_total = 0
        if self.queue_backend == "stream":
            try:
                pending_info = self.client.xpending(self.stream_key, self.stream_group)
                if isinstance(pending_info, dict):
                    pending_total = int(pending_info.get("pending", 0))
                elif isinstance(pending_info, (tuple, list)) and pending_info:
                    pending_total = int(pending_info[0])
            except Exception:
                pending_total = 0

        return {
            "backend": self.queue_backend,
            "queue_depth": int(queue_depth),
            "dlq_depth": int(dlq_depth),
            "active_runs": int(active_runs),
            "pending_stream": int(pending_total),
            "counters": metrics,
        }

    def try_acquire_slot(self, slot_key: str, member_id: str, max_slots: int) -> bool:
        if max_slots <= 0:
            return True
        if not member_id:
            return True

        script = """
local set_key = KEYS[1]
local member_id = ARGV[1]
local max_runs = tonumber(ARGV[2])

if redis.call('SISMEMBER', set_key, member_id) == 1 then
    return 1
end

local current = redis.call('SCARD', set_key)
if current >= max_runs then
    return 0
end

redis.call('SADD', set_key, member_id)
return 1
"""
        result = self.client.eval(script, 1, slot_key, member_id, max_slots)
        return int(result) == 1

    def try_acquire_run_slot(self, run_id: str, max_active_runs: int) -> bool:
        return self.try_acquire_slot(self.active_runs_key, run_id, max_active_runs)

    def release_run_slot(self, run_id: str) -> None:
        if not run_id:
            return
        self.release_slot(self.active_runs_key, run_id)

    def try_acquire_class_slot(self, resource_class: str, run_id: str, max_active_runs: int) -> bool:
        if not resource_class:
            return True
        class_key = f"{self.active_runs_class_prefix}:{resource_class}"
        return self.try_acquire_slot(class_key, run_id, max_active_runs)

    def release_class_slot(self, resource_class: str, run_id: str) -> None:
        if not resource_class or not run_id:
            return
        class_key = f"{self.active_runs_class_prefix}:{resource_class}"
        self.release_slot(class_key, run_id)

    def release_slot(self, slot_key: str, member_id: str) -> None:
        if not slot_key or not member_id:
            return
        self.client.srem(slot_key, member_id)

    def set_job_state(self, job_id: str, state: Dict[str, Any]) -> None:
        self.client.hset(self._state_key(job_id), mapping={k: self._encode(v) for k, v in state.items()})

    def get_job_state(self, job_id: str) -> Optional[Dict[str, Any]]:
        data = self.client.hgetall(self._state_key(job_id))
        if not data:
            return None
        result: Dict[str, Any] = {}
        for key, value in data.items():
            try:
                result[key] = json.loads(value)
            except (TypeError, json.JSONDecodeError):
                result[key] = value
        return result

    def push_hitl_response(self, job_id: str, response: Dict[str, Any]) -> None:
        self.client.lpush(f"{self.key_prefix}:{job_id}:hitl_response", json.dumps(response))

    def pop_hitl_response(self, job_id: str) -> Optional[Dict[str, Any]]:
        raw = self.client.rpop(f"{self.key_prefix}:{job_id}:hitl_response")
        if not raw:
            return None
        try:
            return json.loads(raw)
        except Exception:
            return {"response": str(raw)}

    def clear_hitl_responses(self, job_id: str) -> None:
        self.client.delete(f"{self.key_prefix}:{job_id}:hitl_response")

    def set_abort_flag(self, job_id: str, ttl_seconds: int = 86400) -> None:
        self.client.set(f"{self.key_prefix}:{job_id}:abort", 1, ex=ttl_seconds)

    def clear_abort_flag(self, job_id: str) -> None:
        self.client.delete(f"{self.key_prefix}:{job_id}:abort")

    def is_abort_requested(self, job_id: str) -> bool:
        return str(self.client.get(f"{self.key_prefix}:{job_id}:abort")) == "1"
