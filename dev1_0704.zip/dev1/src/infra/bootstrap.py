"""Shared lifecycle runtime initialization for API apps."""

from __future__ import annotations

from fastapi import FastAPI

from ..config import RuntimeConfig
from ..config.env_loader import load_env_file
from .feature_flags import FeatureFlags
from .db import initialize_lifecycle_schema
from .redis import RedisJobEventPublisher, RedisJobStateStore


def initialize_lifecycle_runtime(app: FastAPI) -> None:
    """Initialize feature flags and optional lifecycle adapters on app state."""
    load_env_file()
    flags = FeatureFlags.from_env()
    runtime = RuntimeConfig.from_env()

    app.state.feature_flags = flags
    app.state.runtime_config = runtime

    if flags.use_postgres_job_repo:
        try:
            initialize_lifecycle_schema()
        except Exception as exc:
            print(f"[WARN] Failed to initialize lifecycle Postgres schema: {exc}")

    if flags.use_redis_job_state:
        try:
            app.state.job_state_store = RedisJobStateStore(runtime_config=runtime)
            app.state.job_event_publisher = RedisJobEventPublisher(runtime_config=runtime)
        except Exception as exc:
            print(f"[WARN] Failed to initialize Redis lifecycle adapters: {exc}")
            app.state.job_state_store = None
            app.state.job_event_publisher = None
    else:
        app.state.job_state_store = None
        app.state.job_event_publisher = None
