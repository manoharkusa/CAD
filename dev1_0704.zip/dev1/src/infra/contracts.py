"""Canonical contracts for lifecycle infrastructure adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol


@dataclass(frozen=True)
class LifecycleStatus:
    status: str
    phase: str


class JobRepository(Protocol):
    def create_job(
        self,
        job_id: str,
        user_id: Optional[str],
        session_id: Optional[str],
        run_id: Optional[str],
        config_payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        ...

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        ...

    def update_job_status(
        self,
        job_id: str,
        status: str,
        phase: str,
        *,
        retry_count: Optional[int] = None,
        current_tool: Optional[str] = None,
        completed_at: Optional[str] = None,
    ) -> None:
        ...


class JobStateStore(Protocol):
    def set_job_state(self, job_id: str, state: Dict[str, Any]) -> None:
        ...

    def get_job_state(self, job_id: str) -> Optional[Dict[str, Any]]:
        ...

    def enqueue_job_with_state(self, job_id: str, state: Dict[str, Any], payload: Dict[str, Any]) -> None:
        ...


class JobEventPublisher(Protocol):
    def publish_job_event(self, job_id: str, payload: Dict[str, Any]) -> None:
        ...

    def publish_abort(self, job_id: str) -> None:
        ...

    def publish_hitl_response(self, job_id: str) -> None:
        ...
