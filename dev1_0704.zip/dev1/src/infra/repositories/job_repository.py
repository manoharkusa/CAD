"""Repository adapter for lifecycle persistence in Postgres."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from ..models.job_models import (
    ErrorLog,
    ExecutionHistory,
    HumanInteraction,
    Job,
    JobCheckpoint,
    JobConfiguration,
    JobFileChange,
    JobStageRecord,
)


class SqlAlchemyJobRepository:
    @staticmethod
    def _parse_iso_datetime(value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        try:
            return datetime.fromisoformat(value)
        except Exception:
            return None

    def __init__(self, session: Session):
        self.session = session

    def create_job(
        self,
        job_id: str,
        user_id: Optional[str],
        session_id: Optional[str],
        run_id: Optional[str],
        config_payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        job = Job(
            job_id=job_id,
            run_id=run_id,
            user_id=user_id,
            session_id=session_id,
            status="PENDING",
            phase="QUEUED",
            retry_count=0,
            triggered_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        cfg = JobConfiguration(
            job_id=job_id,
            run_id=run_id,
            script_path=config_payload.get("script_path", ""),
            instructions_path=config_payload.get("instructions_path"),
            allowed_paths=config_payload.get("allowed_paths"),
            max_retries=config_payload.get("max_retries", 3),
            max_iterations=config_payload.get("max_iterations", 5),
            prompt=config_payload.get("prompt"),
            user_name=config_payload.get("user_name"),
            project=config_payload.get("project"),
            block=config_payload.get("block"),
            rtl_tag=config_payload.get("rtl_tag"),
            experiment_name=config_payload.get("experiment_name"),
            debug_mode=config_payload.get("debug_mode"),
            require_plan_confirmation=config_payload.get("require_plan_confirmation", True),
            config_payload=config_payload,
        )
        self.session.add(job)
        self.session.add(cfg)
        self.session.commit()
        self.session.refresh(job)
        return self._job_to_dict(job)

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        job = self.session.get(Job, job_id)
        if not job:
            return None
        return self._job_to_dict(job)

    def update_job_status(
        self,
        job_id: str,
        status: str,
        phase: str,
        *,
        retry_count: Optional[int] = None,
        current_tool: Optional[str] = None,
        completed_at: Optional[str] = None,
    ) -> None:
        job = self.session.get(Job, job_id)
        if not job:
            return
        job.status = status
        job.phase = phase
        if retry_count is not None:
            job.retry_count = retry_count
        if current_tool is not None:
            job.current_tool = current_tool
        job.updated_at = datetime.utcnow()
        if completed_at:
            try:
                job.completed_at = datetime.fromisoformat(completed_at)
            except ValueError:
                job.completed_at = datetime.utcnow()
        self.session.commit()

    def add_history(self, job_id: str, payload: Dict[str, Any]) -> None:
        entry = ExecutionHistory(
            job_id=job_id,
            sequence_num=payload.get("sequence_num", 0),
            action_type=payload.get("action_type", ""),
            tool_name=payload.get("tool_name"),
            input_params=payload.get("input_params"),
            output_result=payload.get("output_result"),
            duration_ms=payload.get("duration_ms"),
            error_message=payload.get("error_message"),
        )
        self.session.add(entry)
        self.session.commit()

    def add_human_interaction(
        self,
        job_id: str,
        prompt: str,
        options: list[Any],
        response: Optional[str] = None,
        *,
        interaction_type: Optional[str] = None,
        decision: Optional[str] = None,
        additional_context: Optional[str] = None,
        decision_status: Optional[str] = None,
        requested_at: Optional[str] = None,
        expires_at: Optional[str] = None,
        version: Optional[int] = None,
        interaction_metadata: Optional[Dict[str, Any]] = None,
        timeout_seconds: int = 3600,
    ) -> Dict[str, Any]:
        requested_dt = self._parse_iso_datetime(requested_at) or datetime.utcnow()
        expires_dt = self._parse_iso_datetime(expires_at)
        interaction = HumanInteraction(
            job_id=job_id,
            prompt=prompt,
            options=options,
            human_response=response,
            interaction_type=interaction_type,
            decision=decision,
            additional_context=additional_context,
            decision_status=decision_status,
            expires_at=expires_dt,
            version=version,
            interaction_metadata=interaction_metadata,
            requested_at=requested_dt,
            responded_at=datetime.utcnow() if response else None,
            timeout_seconds=timeout_seconds,
        )
        self.session.add(interaction)
        self.session.commit()
        self.session.refresh(interaction)
        return {
            "interaction_id": str(interaction.interaction_id),
            "job_id": str(interaction.job_id),
            "prompt": interaction.prompt,
            "human_response": interaction.human_response,
        }

    def resolve_latest_pending_interaction(
        self,
        job_id: str,
        *,
        decision: str,
        additional_context: Optional[str],
        decision_status: str,
        interaction_type: Optional[str] = None,
        version: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        query = (
            self.session.query(HumanInteraction)
            .filter(HumanInteraction.job_id == job_id)
            .filter(HumanInteraction.responded_at.is_(None))
        )
        if interaction_type:
            query = query.filter(HumanInteraction.interaction_type == interaction_type)
        if version is not None:
            query = query.filter(HumanInteraction.version == version)

        interaction = query.order_by(HumanInteraction.requested_at.desc()).first()
        if interaction is None:
            return None

        interaction.decision = decision
        interaction.human_response = decision
        interaction.additional_context = additional_context
        interaction.decision_status = decision_status
        interaction.responded_at = datetime.utcnow()
        self.session.commit()
        self.session.refresh(interaction)
        return {
            "interaction_id": str(interaction.interaction_id),
            "job_id": str(interaction.job_id),
            "interaction_type": interaction.interaction_type,
            "decision": interaction.decision,
            "decision_status": interaction.decision_status,
            "version": interaction.version,
        }

    def add_error_log(
        self,
        job_id: str,
        error_type: str,
        error_message: str,
        *,
        stack_trace: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        stage: Optional[str] = None,
        tool: Optional[str] = None,
    ) -> None:
        """Add a new error log entry."""
        # Store stage in context for later resolution matching (backward compat)
        if context is None:
            context = {}
        if stage:
            context["stage"] = stage
        if tool:
            context["tool"] = tool

        entry = ErrorLog(
            job_id=job_id,
            stage=stage,
            tool=tool,
            error_type=error_type,
            error_message=error_message,
            stack_trace=stack_trace,
            context=context,
        )
        self.session.add(entry)
        self.session.commit()

    def resolve_error_log(
        self,
        job_id: str,
        stage: Optional[str] = None,
        resolution: Optional[str] = None,
        error_type: Optional[str] = None,
        tool: Optional[str] = None,
    ) -> bool:
        """
        Mark the most recent unresolved error log for a job/stage as resolved.

        Args:
            job_id: Job ID
            stage: Optional stage name to match specific error
            resolution: Resolution description
            error_type: Optional error type to update
            tool: Optional tool name to update

        Returns:
            True if an error was resolved, False if no matching error found
        """
        # Find the most recent unresolved error for this job
        query = self.session.query(ErrorLog).filter(
            ErrorLog.job_id == job_id,
            ErrorLog.resolved == False,
        )

        # If stage is provided, try to match by stage column first, then context
        if stage:
            # Try direct stage column match first
            matching_error = query.filter(ErrorLog.stage == stage).order_by(ErrorLog.timestamp.desc()).first()

            # Fall back to context-based matching for backward compatibility
            if not matching_error:
                errors = query.order_by(ErrorLog.timestamp.desc()).all()
                for error in errors:
                    error_stage = error.context.get("stage") if error.context else None
                    if error_stage == stage:
                        matching_error = error
                        break
                if not matching_error and errors:
                    # Fall back to most recent error if no stage match
                    matching_error = errors[0]
        else:
            matching_error = query.order_by(ErrorLog.timestamp.desc()).first()

        if not matching_error:
            return False

        matching_error.resolved = True
        if resolution:
            matching_error.resolution = resolution
        if error_type:
            matching_error.error_type = error_type
        if tool:
            matching_error.tool = tool
        # Also update stage if not set
        if stage and not matching_error.stage:
            matching_error.stage = stage

        self.session.commit()
        return True

    def update_error_log(
        self,
        job_id: str,
        stage: Optional[str] = None,
        *,
        error_type: Optional[str] = None,
        error_message: Optional[str] = None,
        resolved: Optional[bool] = None,
        resolution: Optional[str] = None,
    ) -> bool:
        """
        Update the most recent error log for a job/stage.

        Args:
            job_id: Job ID
            stage: Optional stage name to match specific error
            error_type: New error type
            error_message: New error message
            resolved: Whether the error is resolved
            resolution: Resolution description

        Returns:
            True if an error was updated, False if no matching error found
        """
        # Find the most recent error for this job (resolved or not)
        query = self.session.query(ErrorLog).filter(ErrorLog.job_id == job_id)

        if stage:
            errors = query.order_by(ErrorLog.timestamp.desc()).all()
            matching_error = None
            for error in errors:
                error_stage = error.context.get("stage") if error.context else None
                if error_stage == stage:
                    matching_error = error
                    break
            if not matching_error and errors:
                matching_error = errors[0]
        else:
            matching_error = query.order_by(ErrorLog.timestamp.desc()).first()

        if not matching_error:
            return False

        if error_type is not None:
            matching_error.error_type = error_type
        if error_message is not None:
            matching_error.error_message = error_message
        if resolved is not None:
            matching_error.resolved = resolved
        if resolution is not None:
            matching_error.resolution = resolution

        self.session.commit()
        return True

    def add_stage_record(self, job_id: str, payload: Dict[str, Any]) -> None:
        """Add or update a stage record (upsert by job_id + stage + attempt)."""
        stage = payload.get("stage") or "unknown"
        tool = payload.get("tool")
        attempt = payload.get("attempt", 1)

        # Try to find existing record for this job + stage + attempt
        existing = self.session.query(JobStageRecord).filter(
            JobStageRecord.job_id == job_id,
            JobStageRecord.stage == stage,
            JobStageRecord.attempt == attempt,
        ).first()

        if existing:
            # Update existing record with non-None values
            if payload.get("status"):
                existing.status = payload.get("status")
            if payload.get("tool"):
                existing.tool = payload.get("tool")
            if payload.get("summary"):
                existing.summary = payload.get("summary")
            if payload.get("error_details"):
                existing.error_details = payload.get("error_details")
            if payload.get("started_at"):
                existing.started_at = self._parse_iso_datetime(payload.get("started_at"))
            if payload.get("ended_at"):
                existing.ended_at = self._parse_iso_datetime(payload.get("ended_at"))
            if payload.get("duration_ms"):
                existing.duration_ms = payload.get("duration_ms")
            if payload.get("metadata"):
                # Merge metadata
                existing_meta = existing.stage_metadata or {}
                existing_meta.update(payload.get("metadata"))
                existing.stage_metadata = existing_meta
        else:
            # Create new record
            entry = JobStageRecord(
                job_id=job_id,
                run_id=payload.get("run_id"),
                stage=stage,
                tool=tool,
                stage_order=payload.get("stage_order"),
                attempt=attempt,
                status=payload.get("status") or "running",
                summary=payload.get("summary"),
                error_details=payload.get("error_details"),
                started_at=self._parse_iso_datetime(payload.get("started_at")),
                ended_at=self._parse_iso_datetime(payload.get("ended_at")),
                duration_ms=payload.get("duration_ms"),
                stage_metadata=payload.get("metadata"),
            )
            self.session.add(entry)

        self.session.commit()

    def add_file_change(self, job_id: str, payload: Dict[str, Any]) -> None:
        file_path = payload.get("file_path")
        if not file_path:
            return
        entry = JobFileChange(
            job_id=job_id,
            run_id=payload.get("run_id"),
            stage=payload.get("stage"),
            file_path=file_path,
            change_type=payload.get("change_type") or "edit",
            tool_name=payload.get("tool_name"),
            before_hash=payload.get("before_hash"),
            after_hash=payload.get("after_hash"),
            diff_excerpt=payload.get("diff_excerpt"),
            change_metadata=payload.get("metadata"),
            happened_at=self._parse_iso_datetime(payload.get("happened_at")) or datetime.utcnow(),
        )
        self.session.add(entry)
        self.session.commit()

    def save_checkpoint(
        self,
        job_id: str,
        state: Dict[str, Any],
        current_node: Optional[str],
        next_node: Optional[str],
    ) -> Dict[str, Any]:
        checkpoint = JobCheckpoint(
            job_id=job_id,
            state=state,
            current_node=current_node,
            next_node=next_node,
            created_at=datetime.utcnow(),
        )
        self.session.add(checkpoint)
        self.session.commit()
        self.session.refresh(checkpoint)
        return {
            "checkpoint_id": str(checkpoint.checkpoint_id),
            "job_id": str(checkpoint.job_id),
            "created_at": checkpoint.created_at.isoformat(),
        }

    def get_latest_checkpoint(self, job_id: str) -> Optional[Dict[str, Any]]:
        checkpoint = (
            self.session.query(JobCheckpoint)
            .filter(JobCheckpoint.job_id == job_id)
            .order_by(JobCheckpoint.created_at.desc())
            .first()
        )
        if not checkpoint:
            return None
        return {
            "checkpoint_id": str(checkpoint.checkpoint_id),
            "job_id": str(checkpoint.job_id),
            "state": checkpoint.state,
            "current_node": checkpoint.current_node,
            "next_node": checkpoint.next_node,
            "created_at": checkpoint.created_at.isoformat(),
        }

    @staticmethod
    def _job_to_dict(job: Job) -> Dict[str, Any]:
        return {
            "job_id": str(job.job_id),
            "run_id": job.run_id,
            "user_id": str(job.user_id) if job.user_id else None,
            "session_id": job.session_id,
            "status": job.status,
            "phase": job.phase,
            "current_tool": job.current_tool,
            "retry_count": job.retry_count,
        }
