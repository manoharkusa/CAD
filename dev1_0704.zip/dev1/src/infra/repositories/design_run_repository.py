"""Repository for design run tracking and locking."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from uuid import UUID

from sqlalchemy import and_, or_
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from ..models.design_run_models import DesignRun, StageProgress


class DesignRunRepository:
    """
    Repository for managing design runs with locking.

    Uses PostgreSQL partial unique index to ensure only one
    running job per (project, block, rtl_tag, experiment) combination.
    """

    def __init__(self, session: Session):
        self.session = session

    def try_acquire_lock(
        self,
        project: str,
        block: str,
        rtl_tag: str,
        experiment: str,
        job_id: Optional[UUID] = None,
        session_id: Optional[str] = None,
        user_name: Optional[str] = None,
        plan: Optional[List[str]] = None,
    ) -> Tuple[bool, Optional[DesignRun], Optional[str]]:
        """
        Try to acquire exclusive lock for a design run.

        Uses INSERT with conflict detection on partial unique index.

        Args:
            project: Project name
            block: Block name
            rtl_tag: RTL tag
            experiment: Experiment name
            job_id: Associated job ID
            session_id: Session ID
            user_name: User name
            plan: List of stages to execute

        Returns:
            Tuple of:
                - acquired: True if lock acquired, False if already locked
                - design_run: The DesignRun object if acquired, None otherwise
                - holder_info: Info about current holder if locked by another
        """
        # First check if there's already a running job
        existing = self.get_running_design(project, block, rtl_tag, experiment)
        if existing:
            holder_info = f"session={existing.session_id}, user={existing.user_name}, started={existing.started_at}"
            return False, None, holder_info

        # Try to create new run (atomic with unique constraint)
        design_run = DesignRun(
            project=project,
            block=block,
            rtl_tag=rtl_tag,
            experiment=experiment,
            job_id=job_id,
            session_id=session_id,
            user_name=user_name,
            status="running",
            plan=plan or [],
            total_stages=len(plan) if plan else 0,
            stages_completed=[],
            stages_failed=[],
            validation_results={},
        )

        try:
            self.session.add(design_run)
            self.session.flush()  # Force constraint check
            return True, design_run, None
        except IntegrityError:
            self.session.rollback()
            # Someone else acquired the lock between our check and insert
            existing = self.get_running_design(project, block, rtl_tag, experiment)
            if existing:
                holder_info = f"session={existing.session_id}, user={existing.user_name}, started={existing.started_at}"
                return False, None, holder_info
            return False, None, "Lock conflict"

    def release_lock(self, run_id: UUID, final_status: str = "completed") -> bool:
        """
        Release lock by updating status to non-running.

        Args:
            run_id: The run ID to release
            final_status: Final status (completed, failed, cancelled)

        Returns:
            True if released, False if not found
        """
        design_run = self.session.query(DesignRun).filter(
            DesignRun.run_id == run_id
        ).first()

        if not design_run:
            return False

        design_run.status = final_status
        design_run.completed_at = datetime.utcnow()
        self.session.flush()
        return True

    def get_running_design(
        self,
        project: str,
        block: str,
        rtl_tag: str,
        experiment: str,
    ) -> Optional[DesignRun]:
        """Get currently running design if exists."""
        return self.session.query(DesignRun).filter(
            and_(
                DesignRun.project == project,
                DesignRun.block == block,
                DesignRun.rtl_tag == rtl_tag,
                DesignRun.experiment == experiment,
                DesignRun.status == "running",
            )
        ).first()

    def get_design_run(self, run_id: UUID) -> Optional[DesignRun]:
        """Get design run by ID."""
        return self.session.query(DesignRun).filter(
            DesignRun.run_id == run_id
        ).first()

    def get_design_history(
        self,
        project: str,
        block: str,
        rtl_tag: str,
        experiment: str,
        limit: int = 10,
    ) -> List[DesignRun]:
        """Get run history for a design."""
        return self.session.query(DesignRun).filter(
            and_(
                DesignRun.project == project,
                DesignRun.block == block,
                DesignRun.rtl_tag == rtl_tag,
                DesignRun.experiment == experiment,
            )
        ).order_by(DesignRun.started_at.desc()).limit(limit).all()

    def update_progress(
        self,
        run_id: UUID,
        current_stage: Optional[str] = None,
        current_stage_index: Optional[int] = None,
        progress_percent: Optional[int] = None,
        stages_completed: Optional[List[str]] = None,
        stages_failed: Optional[List[str]] = None,
        validation_results: Optional[Dict] = None,
    ) -> Optional[DesignRun]:
        """Update run progress."""
        design_run = self.get_design_run(run_id)
        if not design_run:
            return None

        if current_stage is not None:
            design_run.current_stage = current_stage
        if current_stage_index is not None:
            design_run.current_stage_index = current_stage_index
        if progress_percent is not None:
            design_run.progress_percent = progress_percent
        if stages_completed is not None:
            design_run.stages_completed = stages_completed
        if stages_failed is not None:
            design_run.stages_failed = stages_failed
        if validation_results is not None:
            design_run.validation_results = validation_results

        design_run.updated_at = datetime.utcnow()
        self.session.flush()
        return design_run

    # Stage Progress Methods

    # Status mapping: normalize to consistent values for Web UI
    STATUS_MAP = {
        "running": "inprogress",
        "in_progress": "inprogress",
        "in-progress": "inprogress",
        "pass": "completed",
        "passed": "completed",
        "success": "completed",
        "fail": "failed",
        "error": "failed",
        "abort": "cancelled",
        "aborted": "cancelled",
    }

    def _normalize_status(self, status: Optional[str]) -> str:
        """Normalize status to one of: pending, inprogress, completed, failed, cancelled, skipped."""
        if not status:
            return "pending"
        status_lower = status.lower().strip()
        return self.STATUS_MAP.get(status_lower, status_lower)

    def create_stage_progress(
        self,
        run_id: UUID,
        stage_name: str,
        stage_index: int,
        tool_name: Optional[str] = None,
        # Denormalized fields for Web UI
        session_id: Optional[str] = None,
        job_id: Optional[UUID] = None,
        user_name: Optional[str] = None,
        project_name: Optional[str] = None,
        block_name: Optional[str] = None,
        rtl_tag: Optional[str] = None,
        experiment_name: Optional[str] = None,
    ) -> StageProgress:
        """
        Create stage progress entry with denormalized design identity.

        Args:
            run_id: Parent design run ID
            stage_name: Name of the stage (syn, place, cts, route, etc.)
            stage_index: Order index in the execution plan
            tool_name: EDA tool name (genus, innovus, dc_shell, icc2, etc.)
            session_id: Web UI session ID
            job_id: Job ID for tracking
            user_name: User running the job
            project_name: Project name
            block_name: Block name
            rtl_tag: RTL tag/version
            experiment_name: Experiment name

        Returns:
            Created StageProgress entry
        """
        progress = StageProgress(
            run_id=run_id,
            stage_name=stage_name,
            tool_name=tool_name,
            stage_index=stage_index,
            status="pending",
            # Denormalized fields for Web UI queries
            session_id=session_id,
            job_id=job_id,
            user_name=user_name,
            project_name=project_name,
            block_name=block_name,
            rtl_tag=rtl_tag,
            experiment_name=experiment_name,
        )
        self.session.add(progress)
        self.session.flush()
        return progress

    def update_stage_progress(
        self,
        run_id: UUID,
        stage_name: str,
        status: Optional[str] = None,
        tool_name: Optional[str] = None,
        progress_percent: Optional[int] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        return_code: Optional[int] = None,
        log_file: Optional[str] = None,
        slurm_job_id: Optional[str] = None,
        validation_status: Optional[str] = None,
        validation_metrics: Optional[Dict] = None,
        validation_issues: Optional[List[str]] = None,
        error_message: Optional[str] = None,
        error_category: Optional[str] = None,
        # Denormalized fields (in case they weren't set at creation)
        session_id: Optional[str] = None,
        job_id: Optional[UUID] = None,
        user_name: Optional[str] = None,
        project_name: Optional[str] = None,
        block_name: Optional[str] = None,
        rtl_tag: Optional[str] = None,
        experiment_name: Optional[str] = None,
        # Legacy parameter names (for backward compatibility)
        tool: Optional[str] = None,
        started_at: Optional[datetime] = None,
        completed_at: Optional[datetime] = None,
    ) -> Optional[StageProgress]:
        """
        Update stage progress with new status and timing information.

        Status values: pending, inprogress, completed, failed, cancelled, skipped
        """
        progress = self.session.query(StageProgress).filter(
            and_(
                StageProgress.run_id == run_id,
                StageProgress.stage_name == stage_name,
            )
        ).first()

        if not progress:
            return None

        # Normalize and update status
        if status is not None:
            progress.status = self._normalize_status(status)

        # Tool name (prefer tool_name, fall back to legacy 'tool' param)
        effective_tool = tool_name or tool
        if effective_tool is not None:
            progress.tool_name = effective_tool

        if progress_percent is not None:
            progress.progress_percent = progress_percent

        # Timing - use new names, fall back to legacy names
        effective_start = start_time or started_at
        effective_end = end_time or completed_at

        if effective_start is not None:
            progress.start_time = effective_start
            progress.started_at = effective_start  # Keep legacy column in sync

        if effective_end is not None:
            progress.end_time = effective_end
            progress.completed_at = effective_end  # Keep legacy column in sync
            if progress.start_time:
                progress.duration_seconds = int((effective_end - progress.start_time).total_seconds())

        if return_code is not None:
            progress.return_code = return_code
        if log_file is not None:
            progress.log_file = log_file
        if slurm_job_id is not None:
            progress.slurm_job_id = slurm_job_id
        if validation_status is not None:
            progress.validation_status = validation_status
        if validation_metrics is not None:
            progress.validation_metrics = validation_metrics
        if validation_issues is not None:
            progress.validation_issues = validation_issues
        if error_message is not None:
            progress.error_message = error_message
        if error_category is not None:
            progress.error_category = error_category

        # Update denormalized fields if provided
        if session_id is not None:
            progress.session_id = session_id
        if job_id is not None:
            progress.job_id = job_id
        if user_name is not None:
            progress.user_name = user_name
        if project_name is not None:
            progress.project_name = project_name
        if block_name is not None:
            progress.block_name = block_name
        if rtl_tag is not None:
            progress.rtl_tag = rtl_tag
        if experiment_name is not None:
            progress.experiment_name = experiment_name

        progress.updated_at = datetime.utcnow()
        self.session.flush()
        return progress

    def get_stage_progress(self, run_id: UUID, stage_name: str) -> Optional[StageProgress]:
        """Get stage progress for a specific stage."""
        return self.session.query(StageProgress).filter(
            and_(
                StageProgress.run_id == run_id,
                StageProgress.stage_name == stage_name,
            )
        ).first()

    def get_all_stage_progress(self, run_id: UUID) -> List[StageProgress]:
        """Get all stage progress for a run."""
        return self.session.query(StageProgress).filter(
            StageProgress.run_id == run_id
        ).order_by(StageProgress.stage_index).all()

    def get_completed_stages(self, run_id: UUID) -> List[str]:
        """Get list of completed stage names."""
        stages = self.session.query(StageProgress.stage_name).filter(
            and_(
                StageProgress.run_id == run_id,
                StageProgress.status == "completed",
            )
        ).all()
        return [s[0] for s in stages]

    def query_stage_progress(
        self,
        session_id: Optional[str] = None,
        job_id: Optional[UUID] = None,
        user_name: Optional[str] = None,
        project_name: Optional[str] = None,
        block_name: Optional[str] = None,
        rtl_tag: Optional[str] = None,
        experiment_name: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict]:
        """
        Query stage progress with filters for Web UI.

        All filters are optional - returns all if no filters provided.
        Results are ordered by updated_at descending (most recent first).

        Args:
            session_id: Filter by session ID
            job_id: Filter by job ID
            user_name: Filter by user name
            project_name: Filter by project
            block_name: Filter by block
            rtl_tag: Filter by RTL tag
            experiment_name: Filter by experiment
            status: Filter by status (pending, inprogress, completed, failed, cancelled, skipped)
            limit: Max number of results (default 100)
            offset: Offset for pagination (default 0)

        Returns:
            List of stage progress dictionaries
        """
        query = self.session.query(StageProgress)

        # Apply filters
        if session_id:
            query = query.filter(StageProgress.session_id == session_id)
        if job_id:
            query = query.filter(StageProgress.job_id == job_id)
        if user_name:
            query = query.filter(StageProgress.user_name == user_name)
        if project_name:
            query = query.filter(StageProgress.project_name == project_name)
        if block_name:
            query = query.filter(StageProgress.block_name == block_name)
        if rtl_tag:
            query = query.filter(StageProgress.rtl_tag == rtl_tag)
        if experiment_name:
            query = query.filter(StageProgress.experiment_name == experiment_name)
        if status:
            # Normalize status for query
            status_lower = status.lower().strip()
            normalized = self._normalize_status(status_lower)
            query = query.filter(StageProgress.status == normalized)

        # Order by most recent first, then by stage index
        query = query.order_by(
            StageProgress.updated_at.desc(),
            StageProgress.stage_index.asc()
        )

        # Apply pagination
        query = query.offset(offset).limit(limit)

        # Execute and convert to dicts
        results = query.all()
        return [p.to_dict() for p in results]

    def get_block_progress_summary(
        self,
        project_name: str,
        block_name: str,
        rtl_tag: Optional[str] = None,
    ) -> Dict:
        """
        Get progress summary for a block - useful for Web UI dashboard.

        Args:
            project_name: Project name
            block_name: Block name
            rtl_tag: Optional RTL tag filter

        Returns:
            Summary dictionary with stage counts and latest run info
        """
        # Get the latest design run for this block
        query = self.session.query(DesignRun).filter(
            and_(
                DesignRun.project == project_name,
                DesignRun.block == block_name,
            )
        )
        if rtl_tag:
            query = query.filter(DesignRun.rtl_tag == rtl_tag)

        latest_run = query.order_by(DesignRun.started_at.desc()).first()

        if not latest_run:
            return {
                "project_name": project_name,
                "block_name": block_name,
                "rtl_tag": rtl_tag,
                "has_runs": False,
                "latest_run": None,
                "stage_summary": {},
            }

        # Get stage progress for the latest run
        stages = self.get_all_stage_progress(latest_run.run_id)

        # Build summary
        stage_summary = {}
        for stage in stages:
            stage_summary[stage.stage_name] = {
                "status": stage.status,
                "tool_name": stage.tool_name,
                "start_time": stage.start_time.isoformat() if stage.start_time else None,
                "end_time": stage.end_time.isoformat() if stage.end_time else None,
                "duration_seconds": stage.duration_seconds,
                "progress_percent": stage.progress_percent,
            }

        # Count by status
        status_counts = {
            "pending": 0,
            "inprogress": 0,
            "completed": 0,
            "failed": 0,
            "cancelled": 0,
            "skipped": 0,
        }
        for stage in stages:
            status = stage.status or "pending"
            if status in status_counts:
                status_counts[status] += 1

        return {
            "project_name": project_name,
            "block_name": block_name,
            "rtl_tag": latest_run.rtl_tag,
            "experiment_name": latest_run.experiment,
            "has_runs": True,
            "latest_run": {
                "run_id": str(latest_run.run_id),
                "job_id": str(latest_run.job_id) if latest_run.job_id else None,
                "session_id": latest_run.session_id,
                "user_name": latest_run.user_name,
                "status": latest_run.status,
                "progress_percent": latest_run.progress_percent,
                "started_at": latest_run.started_at.isoformat() if latest_run.started_at else None,
                "updated_at": latest_run.updated_at.isoformat() if latest_run.updated_at else None,
            },
            "stage_summary": stage_summary,
            "status_counts": status_counts,
            "total_stages": len(stages),
        }

    # Prerequisite checking

    def check_stage_completed(
        self,
        project: str,
        block: str,
        rtl_tag: str,
        experiment: str,
        stage_name: str,
    ) -> Tuple[bool, Optional[Dict]]:
        """
        Check if a stage has been completed for this design.

        Args:
            project, block, rtl_tag, experiment: Design identity
            stage_name: Stage to check

        Returns:
            Tuple of:
                - completed: True if stage completed successfully
                - stage_info: Stage progress info if found
        """
        # Find the most recent run for this design
        recent_run = self.session.query(DesignRun).filter(
            and_(
                DesignRun.project == project,
                DesignRun.block == block,
                DesignRun.rtl_tag == rtl_tag,
                DesignRun.experiment == experiment,
                or_(
                    DesignRun.status == "completed",
                    DesignRun.status == "running",
                )
            )
        ).order_by(DesignRun.started_at.desc()).first()

        if not recent_run:
            return False, None

        # Check if stage completed in this run
        stage_progress = self.session.query(StageProgress).filter(
            and_(
                StageProgress.run_id == recent_run.run_id,
                StageProgress.stage_name == stage_name,
                StageProgress.status == "completed",
            )
        ).first()

        if stage_progress:
            return True, stage_progress.to_dict()
        return False, None

    def check_prerequisites_met(
        self,
        project: str,
        block: str,
        rtl_tag: str,
        experiment: str,
        required_stages: List[str],
    ) -> Tuple[bool, List[str]]:
        """
        Check if all prerequisite stages have been completed.

        Args:
            project, block, rtl_tag, experiment: Design identity
            required_stages: List of stage names that must be completed

        Returns:
            Tuple of:
                - all_met: True if all prerequisites are met
                - missing: List of missing stages
        """
        missing = []
        for stage in required_stages:
            completed, _ = self.check_stage_completed(
                project, block, rtl_tag, experiment, stage
            )
            if not completed:
                missing.append(stage)

        return len(missing) == 0, missing

    # Active runs queries

    def get_active_runs(self, user_name: Optional[str] = None) -> List[DesignRun]:
        """Get all currently running designs."""
        query = self.session.query(DesignRun).filter(
            DesignRun.status == "running"
        )
        if user_name:
            query = query.filter(DesignRun.user_name == user_name)
        return query.order_by(DesignRun.started_at.desc()).all()

    def get_runs_summary(
        self,
        project: Optional[str] = None,
        user_name: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict]:
        """Get summary of runs for UI display."""
        query = self.session.query(DesignRun)

        if project:
            query = query.filter(DesignRun.project == project)
        if user_name:
            query = query.filter(DesignRun.user_name == user_name)
        if status:
            query = query.filter(DesignRun.status == status)

        runs = query.order_by(DesignRun.started_at.desc()).limit(limit).all()
        return [run.to_dict() for run in runs]
