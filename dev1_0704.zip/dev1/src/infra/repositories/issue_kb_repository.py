"""Dedicated repository for issue knowledge base persistence and dedup logic."""

from __future__ import annotations

from datetime import datetime
import hashlib
import math
import os
import re
from typing import Any, Dict, Optional

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

from sqlalchemy import desc, func, or_
from sqlalchemy.orm import Session

from ...config.env_loader import load_env_file
from ..lifecycle_utils import safe_int, safe_str
from ..models.job_models import (
    IssueFixVariant,
    IssueIncident,
    IssueKnowledge,
    IssueSemanticIndex,
    IssueTaxonomyEntry,
    Job,
    JobConfiguration,
)


class IssueKnowledgeRepository:
    TAXONOMY_VERSION = "v1"
    STAGE_VALUES = [
        "synthesis",
        "design_initialization",
        "floorplan",
        "placement",
        "cts",
        "post_cts_optimization",
        "routing",
        "post_route_optimization",
        "filler_insertion",
        "pd_outputs",
        "rc_extraction",
        "eco",
        "sta",
        "emir",
        "physical_verification",
        "clp",
        "lec",
        "others",
    ]
    # Comprehensive issue category taxonomy for Physical Design
    # Organized by stage for reference, but all categories are valid across stages
    ISSUE_CATEGORY_VALUES = [
        # Synthesis categories
        "sdc", "rtl", "lib", "optimization", "timing", "area", "power", "clock_gating", "multibit_flops",
        # Design Initialization categories
        "tech_lef", "lef", "ndm", "tlf", "tluplus", "qrc_tech", "netlist", "mmmc",
        # Floorplan categories
        "macro_placement", "power_planning", "endcap", "tap_cells", "placement_blockages", "macro_halo",
        # Placement categories
        "bounds", "port_buffers", "setup_timing", "drvs", "cell_density", "pin_density", "congestion", "scan_reordering",
        # CTS categories
        "clock_skew", "clock_latency", "clock_tree_exceptions", "clock_cells", "clock_ndr", "clock_routing", "cdc", "ccopt", "clock_path_drvs", "clock_gating_setup",
        # Post CTS Optimization categories
        "hold_cells", "hold_timing", "clock_gating_hold",
        # Routing categories
        "antenna", "crosstalk", "detour", "open", "short", "drcs", "clock_drcs", "preroute_postroute_correlation",
        # Filler Insertion categories
        "filler_gaps", "decap_density", "flow_issue", "cell_padding",
        # PD Outputs categories
        "def", "physical_netlist", "gds",
        # RC Extraction categories
        "spef", "flow", "inputs", "shorts", "opens",
        # ECO categories
        "setup_timing_fixes", "hold_timing_fixes", "eco_implementation", "eco_flow", "drv_fixes", "crosstalk_delay_fixes", "crosstalk_noise_fixes",
        # STA categories
        "dmsa", "annotation", "crosstalk_delay", "crosstalk_noise", "clock_drvs", "clock_gating_violations", "eco_generation", "physical_aware_eco",
        # EMIR categories
        "static_ir_drop", "dynamic_vectorless", "dynamic_vectored", "power_em", "signal_em", "ir_fix", "ir_hotspots", "em_fix", "ploc_file", "vcd",
        # Physical Verification categories
        "drc", "lvs", "erc", "perc", "bump", "esd",
        # CLP categories
        "isolation_cell", "level_shifter", "power_switch", "upf",
        # LEC categories
        "settings", "debug_analysis",
        # Tool-related
        "tool",
        # Fallback
        "others",
    ]
    STAGE_ALIASES = {
        "syn": "synthesis",
        "synth": "synthesis",
        "init_design": "design_initialization",
        "design initialization": "design_initialization",
        "design_init": "design_initialization",
        "place": "placement",
        "post_cts": "post_cts_optimization",
        "postcts": "post_cts_optimization",
        "postroute": "post_route_optimization",
        "post_route": "post_route_optimization",
        "post_route_opt": "post_route_optimization",
        "pv": "physical_verification",
        "signoff": "physical_verification",
        "filler": "filler_insertion",
        "fill": "filler_insertion",
        "outputs": "pd_outputs",
        "extraction": "rc_extraction",
        "qrc": "rc_extraction",
        "starrc": "rc_extraction",
        "execution": "others",
        "failed": "others",
        "waiting_for_human": "others",
        "queued": "others",
        "completed": "others",
    }
    ISSUE_CATEGORY_ALIASES = {
        ".lib": "lib",
        "library": "lib",
        "timing_violation": "timing",
        "timing_violations": "timing",
        "setup_violation": "setup_timing",
        "setup_violations": "setup_timing",
        "hold_violation": "hold_timing",
        "hold_violations": "hold_timing",
        "design_rule_violation": "drvs",
        "design_rule_violations": "drvs",
        "drv": "drvs",
        "constraint": "sdc",
        "constraints": "sdc",
        "syntax_error": "sdc",
        "file_not_found": "rtl",
        "configuration_error": "tool",
        "constraint_conflict": "sdc",
        "physical_design_error": "timing",
        "convergence_failure": "optimization",
        "memory_error": "tool",
        "kb_reuse": "others",
        "clock": "clock_skew",
        "clock_tree": "cts",
        "cts_violation": "clock_skew",
        "ir_drop": "static_ir_drop",
        "em_violation": "power_em",
    }

    # Mapping of stages to their valid issue categories (for AI classification hints)
    STAGE_CATEGORY_MAP = {
        "synthesis": ["sdc", "rtl", "lib", "optimization", "timing", "area", "power", "clock_gating", "multibit_flops", "others"],
        "design_initialization": ["tech_lef", "lef", "ndm", "tlf", "tluplus", "qrc_tech", "netlist", "sdc", "mmmc", "others"],
        "floorplan": ["macro_placement", "power_planning", "endcap", "tap_cells", "placement_blockages", "macro_halo", "others"],
        "placement": ["sdc", "bounds", "port_buffers", "setup_timing", "drvs", "cell_density", "pin_density", "congestion", "optimization", "scan_reordering", "others"],
        "cts": ["clock_skew", "clock_latency", "clock_tree_exceptions", "clock_cells", "clock_ndr", "clock_routing", "congestion", "cell_density", "cdc", "ccopt", "setup_timing", "clock_path_drvs", "clock_gating_setup", "others"],
        "post_cts_optimization": ["hold_cells", "hold_timing", "setup_timing", "congestion", "cell_density", "drvs", "clock_path_drvs", "clock_ndr", "clock_routing", "clock_gating_setup", "clock_gating_hold", "others"],
        "routing": ["antenna", "crosstalk", "detour", "open", "short", "drcs", "setup_timing", "hold_timing", "drvs", "clock_drvs", "clock_drcs", "preroute_postroute_correlation", "others"],
        "post_route_optimization": ["antenna", "crosstalk", "detour", "open", "short", "drcs", "setup_timing", "hold_timing", "drvs", "clock_drvs", "clock_drcs", "preroute_postroute_correlation", "others"],
        "filler_insertion": ["filler_gaps", "decap_density", "flow_issue", "cell_padding", "others"],
        "pd_outputs": ["def", "lef", "netlist", "physical_netlist", "gds", "others"],
        "rc_extraction": ["spef", "flow", "inputs", "shorts", "opens", "others"],
        "eco": ["setup_timing_fixes", "hold_timing_fixes", "eco_implementation", "eco_flow", "drv_fixes", "crosstalk_delay_fixes", "crosstalk_noise_fixes", "others"],
        "sta": ["sdc", "flow", "dmsa", "annotation", "setup_timing", "hold_timing", "drvs", "crosstalk_delay", "crosstalk_noise", "clock_drvs", "clock_gating_violations", "eco_generation", "physical_aware_eco", "others"],
        "emir": ["static_ir_drop", "dynamic_vectorless", "dynamic_vectored", "power_em", "signal_em", "ir_fix", "ir_hotspots", "em_fix", "ploc_file", "inputs", "vcd", "others"],
        "physical_verification": ["drc", "lvs", "antenna", "erc", "perc", "bump", "esd", "others"],
        "clp": ["isolation_cell", "level_shifter", "power_switch", "upf", "others"],
        "lec": ["settings", "debug_analysis", "others"],
        "others": ["others"],
    }

    def __init__(self, session: Session):
        load_env_file()
        self.session = session
        self._openai_client = None
        self.embedding_model = os.getenv("ISSUE_KB_EMBEDDING_MODEL", "text-embedding-3-large")
        self.embedding_enabled = os.getenv("ISSUE_KB_EMBEDDING_ENABLED", "true").strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }
        self._ensure_taxonomy_seed()

    @staticmethod
    def _normalize_token(value: Optional[str]) -> str:
        if not value:
            return ""
        lowered = value.strip().lower()
        lowered = re.sub(r"\s+", " ", lowered)
        return lowered

    @staticmethod
    def _normalize_key(value: Optional[str]) -> str:
        token = IssueKnowledgeRepository._normalize_token(value)
        token = token.replace("-", "_").replace(" ", "_")
        token = re.sub(r"_+", "_", token)
        return token

    @staticmethod
    def get_technology_from_env() -> str:
        """Get technology name from TECH_NAME environment variable (set via sourceproj.env).

        Returns:
            Technology name (e.g., '7nm', '28nm', '14nm') or 'unknown' if not set.
        """
        tech_name = os.getenv("TECH_NAME", "").strip()
        if tech_name:
            return tech_name
        # Fallback: check common alternative env var names
        for alt_var in ["TECHNOLOGY", "TECH_NODE", "PROCESS_NODE"]:
            alt_value = os.getenv(alt_var, "").strip()
            if alt_value:
                return alt_value
        return "unknown"

    @staticmethod
    def generate_descriptive_title(
        stage: str,
        tool: str,
        error_message: str,
        issue_category: str = "others",
    ) -> str:
        """Generate a descriptive title for the issue based on context.

        Args:
            stage: Stage name (e.g., 'synthesis', 'placement')
            tool: Tool name (e.g., 'genus', 'innovus')
            error_message: The error message or description
            issue_category: Classified issue category

        Returns:
            Descriptive title (max ~80 chars)
        """
        # Stage display names
        stage_display = {
            "synthesis": "Synthesis",
            "design_initialization": "Design Initialization",
            "floorplan": "Floorplan",
            "placement": "Placement",
            "cts": "CTS",
            "post_cts_optimization": "Post-CTS Optimization",
            "routing": "Routing",
            "post_route_optimization": "Post-Route Optimization",
            "filler_insertion": "Filler Insertion",
            "pd_outputs": "PD Outputs",
            "rc_extraction": "RC Extraction",
            "eco": "ECO",
            "sta": "STA",
            "emir": "EMIR Analysis",
            "physical_verification": "Physical Verification",
            "clp": "CLP",
            "lec": "LEC",
        }.get(stage, stage.replace("_", " ").title() if stage else "Flow")

        # Tool display names
        tool_display = {
            "genus": "Genus",
            "dc_shell": "DC Shell",
            "innovus": "Innovus",
            "icc2": "ICC2",
            "calibre": "Calibre",
            "tempus": "Tempus",
            "voltus": "Voltus",
            "conformal": "Conformal",
            "primetime": "PrimeTime",
            "starrc": "StarRC",
        }.get(tool.lower() if tool else "", tool or "unknown")

        # Category to description mapping
        category_desc = {
            "sdc": "SDC constraint",
            "rtl": "RTL",
            "lib": "library",
            "timing": "timing",
            "setup_timing": "setup timing",
            "hold_timing": "hold timing",
            "drvs": "design rule",
            "congestion": "congestion",
            "clock_skew": "clock skew",
            "clock_latency": "clock latency",
            "antenna": "antenna",
            "crosstalk": "crosstalk",
            "drcs": "DRC",
            "drc": "DRC",
            "lvs": "LVS",
            "optimization": "optimization",
            "area": "area",
            "power": "power",
            "cell_density": "cell density",
            "macro_placement": "macro placement",
            "static_ir_drop": "IR drop",
            "tool": "tool",
        }

        # Extract key error patterns from message
        error_lower = (error_message or "").lower()
        error_hints = []

        # Pattern detection for common errors
        patterns = [
            (r"sdc|constraint|clock\s*defin", "SDC constraints"),
            (r"setup\s*(slack|violation|timing)", "setup timing violations"),
            (r"hold\s*(slack|violation|timing)", "hold timing violations"),
            (r"timing\s*(violation|error)", "timing violations"),
            (r"drc|design\s*rule", "DRC violations"),
            (r"lvs|layout\s*vs", "LVS errors"),
            (r"congestion|overflow|grc", "routing congestion"),
            (r"antenna", "antenna violations"),
            (r"cross\s*talk", "crosstalk issues"),
            (r"syntax\s*error", "syntax errors"),
            (r"file\s*not\s*found|missing\s*file", "missing files"),
            (r"memory|oom|out\s*of\s*memory", "memory issues"),
            (r"clock\s*(skew|tree|latency)", "clock tree issues"),
            (r"macro\s*place", "macro placement issues"),
            (r"ir\s*(drop|hotspot)", "IR drop issues"),
            (r"em\s*(violation|fail)", "EM violations"),
        ]

        for pattern, hint in patterns:
            if re.search(pattern, error_lower):
                error_hints.append(hint)
                break  # Use first match

        # Build title
        if error_hints:
            reason = error_hints[0]
        elif issue_category and issue_category != "others":
            reason = f"{category_desc.get(issue_category, issue_category.replace('_', ' '))} issues"
        else:
            # Extract first meaningful part of error message
            if error_message:
                # Take first line or first 40 chars
                first_line = error_message.split("\n")[0].strip()
                if len(first_line) > 50:
                    first_line = first_line[:47] + "..."
                reason = first_line if first_line else "execution failure"
            else:
                reason = "execution failure"

        title = f"{stage_display} failed in {tool_display} due to {reason}"

        # Truncate if too long
        if len(title) > 80:
            title = title[:77] + "..."

        return title

    @staticmethod
    def classify_issue_from_error(error_message: str, stage: str = "") -> str:
        """Classify issue category from error message patterns.

        Args:
            error_message: The error message text
            stage: Stage name for context

        Returns:
            Issue category string
        """
        error_lower = (error_message or "").lower()

        # Pattern to category mapping (order matters - more specific first)
        patterns = [
            (r"sdc\s*(syntax|error)|constraint.*error|missing.*constraint|clock.*defin", "sdc"),
            (r"setup\s*(slack|violation|timing)|wns|worst.*negative.*slack", "setup_timing"),
            (r"hold\s*(slack|violation|timing)|tns.*hold", "hold_timing"),
            (r"timing\s*(violation|error)|slack.*violation", "timing"),
            (r"drc|design\s*rule\s*violation", "drcs"),
            (r"lvs\s*(error|fail)", "lvs"),
            (r"antenna\s*(violation|error)", "antenna"),
            (r"cross\s*talk|xtalk", "crosstalk"),
            (r"congestion|overflow|grc.*overflow", "congestion"),
            (r"clock\s*skew", "clock_skew"),
            (r"clock\s*latency", "clock_latency"),
            (r"clock\s*(tree|cts)", "clock_cells"),
            (r"ir\s*(drop|hotspot)", "static_ir_drop"),
            (r"em\s*(violation|fail)|electromigration", "power_em"),
            (r"rtl\s*(error|syntax)|verilog.*error|vhdl.*error", "rtl"),
            (r"library\s*(error|missing)|\.lib|cell.*not.*found", "lib"),
            (r"memory|oom|out\s*of\s*memory", "tool"),
            (r"area\s*(violation|exceed)", "area"),
            (r"power\s*(violation|exceed)", "power"),
            (r"macro\s*place", "macro_placement"),
            (r"filler|decap", "filler_gaps"),
            (r"optimization\s*(fail|error)|opt.*fail", "optimization"),
        ]

        for pattern, category in patterns:
            if re.search(pattern, error_lower):
                return category

        return "others"

    @staticmethod
    def generate_fix_title(
        stage: str,
        tool: str,
        issue_category: str,
        resolution: str = "",
        file_edits: list = None,
    ) -> str:
        """Generate a descriptive title for the fix variant.

        Args:
            stage: Stage name (e.g., 'synthesis', 'placement')
            tool: Tool name (e.g., 'genus', 'innovus')
            issue_category: Issue category being fixed
            resolution: Resolution text
            file_edits: List of file edits made

        Returns:
            Descriptive fix title (max ~80 chars)
        """
        # Stage display names
        stage_display = {
            "synthesis": "Synthesis",
            "design_initialization": "Design Init",
            "floorplan": "Floorplan",
            "placement": "Placement",
            "cts": "CTS",
            "post_cts_optimization": "Post-CTS",
            "routing": "Routing",
            "post_route_optimization": "Post-Route",
            "sta": "STA",
            "emir": "EMIR",
            "physical_verification": "PV",
        }.get(stage, stage.replace("_", " ").title() if stage else "")

        # Tool display names
        tool_display = {
            "genus": "Genus",
            "dc_shell": "DC Shell",
            "innovus": "Innovus",
            "icc2": "ICC2",
            "calibre": "Calibre",
            "tempus": "Tempus",
            "primetime": "PrimeTime",
        }.get(tool.lower() if tool else "", tool or "")

        # Category to fix action mapping
        fix_actions = {
            "sdc": "SDC constraint fix",
            "rtl": "RTL correction",
            "lib": "library path fix",
            "timing": "timing optimization",
            "setup_timing": "setup timing fix",
            "hold_timing": "hold timing fix",
            "drvs": "DRV fix",
            "congestion": "congestion mitigation",
            "clock_skew": "clock skew reduction",
            "clock_latency": "clock latency fix",
            "antenna": "antenna fix",
            "crosstalk": "crosstalk mitigation",
            "drcs": "DRC fix",
            "drc": "DRC fix",
            "lvs": "LVS fix",
            "optimization": "optimization adjustment",
            "area": "area optimization",
            "power": "power optimization",
            "macro_placement": "macro placement adjustment",
            "static_ir_drop": "IR drop fix",
            "tool": "tool configuration fix",
        }

        action = fix_actions.get(issue_category, f"{issue_category.replace('_', ' ')} fix")

        # Determine fix type from file edits
        if file_edits:
            edited_files = [e.get("file_path", "") for e in file_edits if isinstance(e, dict)]
            if any(".sdc" in f or "constraint" in f.lower() for f in edited_files):
                action = "SDC constraint modification"
            elif any(".tcl" in f for f in edited_files):
                action = "TCL script modification"
            elif any(".v" in f or ".sv" in f for f in edited_files):
                action = "RTL modification"

        # Extract key action from resolution if available
        if resolution:
            res_lower = resolution.lower()
            if "added" in res_lower:
                action_verb = "Added"
            elif "removed" in res_lower or "deleted" in res_lower:
                action_verb = "Removed"
            elif "modified" in res_lower or "changed" in res_lower or "updated" in res_lower:
                action_verb = "Modified"
            elif "fixed" in res_lower:
                action_verb = "Fixed"
            else:
                action_verb = "Applied"

            # Try to extract what was changed
            patterns = [
                (r"(clock\s*(group|definition|constraint)s?)", "clock constraints"),
                (r"(set_clock_groups|set_false_path|set_multicycle_path)", "timing exceptions"),
                (r"(soft\s*blockage|placement\s*blockage)", "placement blockages"),
                (r"(cell\s*density|utilization)", "density settings"),
                (r"(max_fanout|max_cap|max_trans)", "DRV constraints"),
            ]
            for pattern, what in patterns:
                if re.search(pattern, res_lower):
                    action = f"{action_verb} {what}"
                    break

        # Build title
        if stage_display and tool_display:
            title = f"{stage_display} {action} for {tool_display}"
        elif stage_display:
            title = f"{stage_display} {action}"
        else:
            title = action.capitalize()

        # Truncate if too long
        if len(title) > 80:
            title = title[:77] + "..."

        return title

    @staticmethod
    def format_fix_steps(
        debug_steps: str,
        resolution: str = "",
        file_edits: list = None,
    ) -> str:
        """Format debug/fix steps in a structured way.

        Args:
            debug_steps: Raw debug steps text
            resolution: Resolution text
            file_edits: List of file edits

        Returns:
            Formatted fix steps string
        """
        steps = []

        # Parse existing debug steps if available
        if debug_steps:
            # Check if already formatted as numbered list
            if re.search(r"^\d+\.", debug_steps.strip()):
                steps.append("## Debug Analysis\n" + debug_steps)
            else:
                steps.append("## Debug Analysis\n" + debug_steps)

        # Add file modifications section
        if file_edits and isinstance(file_edits, list):
            mod_lines = ["## File Modifications"]
            for i, edit in enumerate(file_edits, 1):
                if isinstance(edit, dict):
                    file_path = edit.get("file_path", "unknown")
                    change_type = edit.get("change_type", edit.get("edit_type", "edit"))
                    mod_lines.append(f"{i}. {change_type.capitalize()}: `{file_path}`")
            if len(mod_lines) > 1:
                steps.append("\n".join(mod_lines))

        # Add resolution section
        if resolution:
            steps.append(f"## Resolution\n{resolution}")

        return "\n\n".join(steps) if steps else debug_steps or ""

    @staticmethod
    def summarize_fix_applied(
        resolution: str,
        file_edits: list = None,
        issue_category: str = "",
    ) -> str:
        """Generate a concise summary of the fix that was applied.

        Args:
            resolution: Full resolution text
            file_edits: List of file edits
            issue_category: Issue category

        Returns:
            Concise fix summary
        """
        if not resolution and not file_edits:
            return "Applied debug fix"

        summaries = []

        # Summarize from resolution text
        if resolution:
            res_lower = resolution.lower()

            # Extract key actions
            action_patterns = [
                (r"added\s+(set_clock_groups|clock\s*group)", "Added clock group definition"),
                (r"added\s+(set_false_path|false\s*path)", "Added false path constraint"),
                (r"added\s+(set_multicycle_path|multicycle)", "Added multicycle path constraint"),
                (r"(created|added)\s+soft\s*blockage", "Created soft placement blockage"),
                (r"(increased|decreased)\s+(max_fanout|fanout)", "Adjusted max fanout constraint"),
                (r"(increased|decreased)\s+(max_cap|capacitance)", "Adjusted max capacitance constraint"),
                (r"(fixed|corrected)\s+sdc\s*syntax", "Fixed SDC syntax error"),
                (r"(updated|modified)\s+clock\s*defin", "Updated clock definition"),
                (r"(added|inserted)\s+buffer", "Inserted buffer for timing fix"),
                (r"(relaxed|tightened)\s+timing", "Adjusted timing constraints"),
            ]

            for pattern, summary in action_patterns:
                if re.search(pattern, res_lower):
                    summaries.append(summary)
                    break

            # If no pattern matched, take first sentence or first 100 chars
            if not summaries:
                first_sentence = re.split(r'[.!?\n]', resolution)[0].strip()
                if first_sentence:
                    if len(first_sentence) > 100:
                        first_sentence = first_sentence[:97] + "..."
                    summaries.append(first_sentence)

        # Add file edit summary
        if file_edits and isinstance(file_edits, list):
            num_files = len(file_edits)
            file_types = set()
            for edit in file_edits:
                if isinstance(edit, dict):
                    fp = edit.get("file_path", "")
                    if ".sdc" in fp:
                        file_types.add("SDC")
                    elif ".tcl" in fp:
                        file_types.add("TCL")
                    elif ".v" in fp or ".sv" in fp:
                        file_types.add("RTL")
                    elif ".def" in fp:
                        file_types.add("DEF")

            if file_types:
                types_str = "/".join(sorted(file_types))
                summaries.append(f"Modified {num_files} {types_str} file(s)")
            elif num_files > 0:
                summaries.append(f"Modified {num_files} file(s)")

        return "; ".join(summaries) if summaries else "Applied debug fix"

    @staticmethod
    def calculate_fix_confidence(
        resolution: str = "",
        file_edits: list = None,
        fix_source: str = "",
        previous_success_count: int = 0,
    ) -> int:
        """Calculate confidence score for a fix (0-100).

        Args:
            resolution: Resolution text
            file_edits: List of file edits
            fix_source: Source of the fix (autofix, manual, kb_reuse)
            previous_success_count: Number of previous successful applications

        Returns:
            Confidence score 0-100
        """
        score = 50  # Base score

        # Boost for detailed resolution
        if resolution:
            if len(resolution) > 200:
                score += 10  # Detailed explanation
            if re.search(r"verified|confirmed|tested", resolution.lower()):
                score += 15  # Mentions verification

        # Boost for specific file edits
        if file_edits and isinstance(file_edits, list):
            num_edits = len(file_edits)
            if num_edits == 1:
                score += 10  # Single targeted fix
            elif num_edits <= 3:
                score += 5   # Few focused changes
            # Penalty for too many edits (might be risky)
            elif num_edits > 5:
                score -= 5

        # Boost based on fix source
        if fix_source:
            source_lower = fix_source.lower()
            if "kb_reuse" in source_lower or "knowledge" in source_lower:
                score += 15  # Previously successful fix
            elif "manual" in source_lower or "human" in source_lower:
                score += 10  # Human-verified
            elif "autofix" in source_lower:
                score += 5   # Auto-generated

        # Boost for repeated success
        if previous_success_count > 0:
            score += min(previous_success_count * 5, 20)  # Max +20 for history

        # Clamp to 0-100
        return max(0, min(100, score))

    def _ensure_taxonomy_seed(self) -> None:
        existing = self.session.query(IssueTaxonomyEntry.taxonomy_type).distinct().all()
        existing_types = {item[0] for item in existing}

        rows: list[IssueTaxonomyEntry] = []
        if "stage" not in existing_types:
            for value in self.STAGE_VALUES:
                rows.append(
                    IssueTaxonomyEntry(
                        taxonomy_type="stage",
                        canonical_value=value,
                        aliases=[],
                        is_active=True,
                    )
                )
        if "issue_category" not in existing_types:
            for value in self.ISSUE_CATEGORY_VALUES:
                rows.append(
                    IssueTaxonomyEntry(
                        taxonomy_type="issue_category",
                        canonical_value=value,
                        aliases=[],
                        is_active=True,
                    )
                )

        if rows:
            self.session.add_all(rows)
            self.session.commit()

    def _normalize_stage(self, value: Optional[str]) -> str:
        key = self._normalize_key(value)
        if not key:
            return "others"
        if key in self.STAGE_ALIASES:
            key = self.STAGE_ALIASES[key]
        if key not in self.STAGE_VALUES:
            # Don't raise an exception - default to "others" for unknown stages
            # This allows the system to gracefully handle new/unexpected stages
            return "others"
        return key

    def _normalize_issue_category(self, value: Optional[str]) -> str:
        key = self._normalize_key(value)
        if not key:
            return "others"
        if key in self.ISSUE_CATEGORY_ALIASES:
            key = self.ISSUE_CATEGORY_ALIASES[key]
        if key not in self.ISSUE_CATEGORY_VALUES:
            # Don't raise an exception - default to "others" for unknown categories
            # This allows the system to gracefully handle new/unexpected categories
            return "others"
        return key

    @staticmethod
    def _tokenize_search_text(text: str) -> list[str]:
        return [token for token in re.findall(r"[a-zA-Z0-9_]+", text.lower()) if len(token) >= 2]

    @staticmethod
    def _serialize_fix_payload(payload: Any) -> str:
        if payload is None:
            return ""
        try:
            import json

            return json.dumps(payload, sort_keys=True, default=str)
        except Exception:
            return str(payload)

    def _build_fix_variant_hash(self, *, fix_applied: Optional[str], fix_steps: Optional[str], fix_payload: Any) -> str:
        source = "|".join(
            [
                self._normalize_token(fix_applied),
                self._normalize_token(fix_steps),
                self._serialize_fix_payload(fix_payload),
            ]
        )
        return hashlib.sha256(source.encode("utf-8")).hexdigest()

    def _upsert_fix_variant(
        self,
        *,
        issue: IssueKnowledge,
        job_id: str,
        run_id: Optional[str],
        payload: Dict[str, Any],
    ) -> None:
        metadata = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        event_type = safe_str(metadata.get("event_type") or payload.get("event_type"))
        if event_type != "issue_resolution_captured":
            return

        # Extract fix information from payload
        resolution = safe_str(payload.get("resolution"))
        debug_steps = safe_str(payload.get("debug_steps"))
        file_edits = payload.get("file_edits") if isinstance(payload.get("file_edits"), list) else []
        stage = safe_str(payload.get("stage"))
        tool = safe_str(payload.get("tool"))
        issue_category = safe_str(payload.get("issue_category")) or issue.issue_category
        fix_source = safe_str(payload.get("fix_source")) or "autofix"

        fix_payload = {
            "file_edits": file_edits,
            "summary": payload.get("summary"),
            "stage": stage,
            "tool": tool,
            "technology": payload.get("technology"),
        }
        if not resolution and not debug_steps and not file_edits:
            return

        variant_hash = self._build_fix_variant_hash(
            fix_applied=resolution,
            fix_steps=debug_steps,
            fix_payload=fix_payload,
        )

        variant = (
            self.session.query(IssueFixVariant)
            .filter(IssueFixVariant.issue_id == issue.issue_id, IssueFixVariant.variant_hash == variant_hash)
            .first()
        )

        # Generate descriptive fix title
        fix_title = self.generate_fix_title(
            stage=stage,
            tool=tool,
            issue_category=issue_category,
            resolution=resolution,
            file_edits=file_edits,
        )

        # Format fix steps with structure
        formatted_fix_steps = self.format_fix_steps(
            debug_steps=debug_steps,
            resolution=resolution,
            file_edits=file_edits,
        )

        # Generate concise fix summary
        fix_applied_summary = self.summarize_fix_applied(
            resolution=resolution,
            file_edits=file_edits,
            issue_category=issue_category,
        )

        if variant is None:
            self.session.query(IssueFixVariant).filter(IssueFixVariant.issue_id == issue.issue_id).update(
                {IssueFixVariant.is_active: False}, synchronize_session=False
            )

            # Calculate initial confidence score
            confidence = safe_int(payload.get("fix_confidence"))
            if not confidence:
                confidence = self.calculate_fix_confidence(
                    resolution=resolution,
                    file_edits=file_edits,
                    fix_source=fix_source,
                    previous_success_count=0,
                )

            variant = IssueFixVariant(
                issue_id=issue.issue_id,
                variant_hash=variant_hash,
                fix_title=fix_title,
                fix_applied=fix_applied_summary,
                fix_steps=formatted_fix_steps,
                fix_payload=fix_payload,
                fix_source=fix_source,
                fix_status=safe_str(payload.get("fix_status")) or "verified",
                success_count=1,
                failure_count=0,
                confidence_score=confidence,
                is_active=True,
                last_fix_job_id=job_id,
                last_fix_run_id=run_id,
                last_used_at=datetime.utcnow(),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            self.session.add(variant)
            return

        # Update existing variant
        previous_success = variant.success_count or 0
        variant.fix_title = fix_title or variant.fix_title
        variant.fix_applied = fix_applied_summary or variant.fix_applied
        variant.fix_steps = formatted_fix_steps or variant.fix_steps
        variant.fix_payload = fix_payload or variant.fix_payload
        variant.fix_source = fix_source or variant.fix_source or "autofix"
        variant.fix_status = safe_str(payload.get("fix_status")) or variant.fix_status or "verified"
        variant.success_count = previous_success + 1

        # Recalculate confidence with updated success count
        new_confidence = safe_int(payload.get("fix_confidence"))
        if not new_confidence:
            new_confidence = self.calculate_fix_confidence(
                resolution=resolution,
                file_edits=file_edits,
                fix_source=fix_source,
                previous_success_count=previous_success + 1,
            )
        variant.confidence_score = new_confidence

        variant.is_active = True
        variant.last_fix_job_id = job_id
        variant.last_fix_run_id = run_id
        variant.last_used_at = datetime.utcnow()
        variant.updated_at = datetime.utcnow()
        self.session.query(IssueFixVariant).filter(
            IssueFixVariant.issue_id == issue.issue_id,
            IssueFixVariant.variant_id != variant.variant_id,
        ).update({IssueFixVariant.is_active: False}, synchronize_session=False)

    def _get_active_fix_variant(self, issue_id: str) -> Optional[IssueFixVariant]:
        return (
            self.session.query(IssueFixVariant)
            .filter(IssueFixVariant.issue_id == issue_id, IssueFixVariant.is_active.is_(True))
            .order_by(desc(IssueFixVariant.success_count), desc(IssueFixVariant.last_used_at))
            .first()
        )

    def _build_fix_variant_response(self, variant: Optional[IssueFixVariant]) -> Optional[Dict[str, Any]]:
        if variant is None:
            return None
        return {
            "variant_id": str(variant.variant_id),
            "fix_title": variant.fix_title,
            "fix_applied": variant.fix_applied,
            "fix_steps": variant.fix_steps,
            "fix_source": variant.fix_source,
            "fix_status": variant.fix_status,
            "success_count": variant.success_count,
            "failure_count": variant.failure_count,
            "confidence_score": variant.confidence_score,
            "last_fix_job_id": str(variant.last_fix_job_id) if variant.last_fix_job_id else None,
            "last_fix_run_id": variant.last_fix_run_id,
            "last_used_at": variant.last_used_at.isoformat() if variant.last_used_at else None,
            "fix_payload": variant.fix_payload,
        }

    def _score_issue_match(self, *, record: IssueKnowledge, text_query: Optional[str]) -> float:
        score = 0.0
        if text_query:
            normalized_query = self._normalize_token(text_query)
            query_tokens = set(self._tokenize_search_text(normalized_query))
            if query_tokens:
                field_weights = {
                    "title": 4.0,
                    "description": 3.0,
                    "debug_steps": 2.0,
                    "resolution": 2.5,
                }
                for field_name, weight in field_weights.items():
                    field_value = self._normalize_token(getattr(record, field_name, None))
                    if not field_value:
                        continue
                    matched = query_tokens.intersection(set(self._tokenize_search_text(field_value)))
                    if matched:
                        score += weight * (len(matched) / max(1, len(query_tokens)))
                    if normalized_query and normalized_query in field_value:
                        score += weight * 0.75

        score += min(3.0, math.log1p(max(0, int(record.occurrence_count or 0))))
        if record.last_seen_at:
            age_days = max(0.0, (datetime.utcnow() - record.last_seen_at).total_seconds() / 86400.0)
            score += max(0.0, 2.0 - (age_days / 30.0))
        return score

    @staticmethod
    def _cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
        if not vec_a or not vec_b or len(vec_a) != len(vec_b):
            return 0.0
        dot = sum(a * b for a, b in zip(vec_a, vec_b))
        norm_a = math.sqrt(sum(a * a for a in vec_a))
        norm_b = math.sqrt(sum(b * b for b in vec_b))
        if norm_a == 0.0 or norm_b == 0.0:
            return 0.0
        return dot / (norm_a * norm_b)

    def _get_openai_client(self):
        if not self.embedding_enabled:
            return None
        if OpenAI is None:
            return None
        if not (os.getenv("OPENAI_API_KEY") or "").strip():
            return None
        if self._openai_client is None:
            self._openai_client = OpenAI()
        return self._openai_client

    def _generate_embedding(self, text: str) -> tuple[Optional[str], Optional[list[float]], Optional[str]]:
        client = self._get_openai_client()
        if client is None:
            return None, None, None

        try:
            response = client.embeddings.create(
                model=self.embedding_model,
                input=text,
            )
            vector = response.data[0].embedding if response and response.data else None
            if not isinstance(vector, list):
                return None, None, None
            return self.embedding_model, [float(item) for item in vector], "v1"
        except Exception:
            return None, None, None

    def _build_semantic_text(self, issue: IssueKnowledge) -> str:
        parts = [
            f"title: {issue.title}",
            f"stage: {issue.stage}",
            f"issue_category: {issue.issue_category}",
            f"tool: {issue.tool or 'unknown'}",
            f"technology: {issue.technology or 'unknown'}",
            f"project: {issue.project or 'unknown'}",
            f"block: {issue.block or 'unknown'}",
            f"description: {issue.description or ''}",
            f"debug_steps: {issue.debug_steps or ''}",
            f"resolution: {issue.resolution or ''}",
        ]
        return "\n".join(parts)

    def _upsert_semantic_index(self, issue: IssueKnowledge) -> None:
        semantic_text = self._build_semantic_text(issue)
        embedding_model, embedding_vector, embedding_version = self._generate_embedding(semantic_text)
        semantic_row = self.session.query(IssueSemanticIndex).filter(IssueSemanticIndex.issue_id == issue.issue_id).first()
        if semantic_row is None:
            semantic_row = IssueSemanticIndex(
                issue_id=issue.issue_id,
                semantic_text=semantic_text,
                embedding_model=embedding_model,
                embedding_vector=embedding_vector,
                embedding_version=embedding_version,
                last_indexed_at=datetime.utcnow(),
            )
            self.session.add(semantic_row)
            return

        semantic_row.semantic_text = semantic_text
        if embedding_vector is not None:
            semantic_row.embedding_model = embedding_model
            semantic_row.embedding_vector = embedding_vector
            semantic_row.embedding_version = embedding_version
        semantic_row.last_indexed_at = datetime.utcnow()

    def _build_fingerprint(
        self,
        *,
        project: Optional[str],
        block: Optional[str],
        stage: Optional[str],
        tool: Optional[str],
        technology: Optional[str],
        issue_category: Optional[str],
        title: Optional[str],
        error_signature: Optional[str],
    ) -> str:
        source = "|".join(
            [
                self._normalize_token(project),
                self._normalize_token(block),
                self._normalize_token(stage),
                self._normalize_token(tool),
                self._normalize_token(technology),
                self._normalize_token(issue_category),
                self._normalize_token(title),
                self._normalize_token(error_signature),
            ]
        )
        return hashlib.sha256(source.encode("utf-8")).hexdigest()

    def upsert_issue(self, *, job_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        stage = self._normalize_stage(payload.get("stage"))
        issue_category = self._normalize_issue_category(payload.get("issue_category"))
        title = payload.get("title") or f"{stage} failure"
        description = payload.get("description") or payload.get("error_message") or "No description"

        config = self.session.query(JobConfiguration).filter(JobConfiguration.job_id == job_id).first()
        job = self.session.query(Job).filter(Job.job_id == job_id).first()

        project = payload.get("project") or (config.project if config else None)
        block = payload.get("block") or (config.block if config else None)
        run_id = payload.get("run_id") or (config.run_id if config else None)
        session_id = payload.get("session_id") or (job.session_id if job else None)
        tool = payload.get("tool")
        technology = payload.get("technology") or "others"
        error_signature = payload.get("error_signature") or payload.get("error_message") or description

        fingerprint_hash = self._build_fingerprint(
            project=project,
            block=block,
            stage=stage,
            tool=tool,
            technology=technology,
            issue_category=issue_category,
            title=title,
            error_signature=error_signature,
        )
        canonical_key = f"{stage}:{issue_category}:{fingerprint_hash[:12]}"

        issue = self.session.query(IssueKnowledge).filter(IssueKnowledge.fingerprint_hash == fingerprint_hash).first()
        if issue is None:
            issue = IssueKnowledge(
                canonical_key=canonical_key,
                fingerprint_hash=fingerprint_hash,
                session_id=session_id,
                project=project,
                block=block,
                title=title,
                description=description,
                tool=tool,
                technology=technology,
                issue_category=issue_category,
                stage=stage,
                debug_steps=payload.get("debug_steps"),
                resolution=payload.get("resolution"),
                taxonomy_version=payload.get("taxonomy_version") or self.TAXONOMY_VERSION,
                first_seen_at=datetime.utcnow(),
                last_seen_at=datetime.utcnow(),
                occurrence_count=1,
                issue_metadata=payload.get("metadata"),
            )
            self.session.add(issue)
            self.session.flush()
        else:
            issue.last_seen_at = datetime.utcnow()
            issue.occurrence_count = (issue.occurrence_count or 0) + 1
            if session_id and not issue.session_id:
                issue.session_id = session_id

            # Check if this is a resolution capture event - always update resolution
            metadata_payload = payload.get("metadata")
            event_type = safe_str(
                (metadata_payload.get("event_type") if isinstance(metadata_payload, dict) else None)
                or payload.get("event_type")
            )
            if event_type == "issue_resolution_captured":
                # Always update resolution, tool, and stage when captured from debug agent fix
                if payload.get("resolution"):
                    issue.resolution = payload.get("resolution")
                if payload.get("debug_steps"):
                    issue.debug_steps = payload.get("debug_steps")
                if payload.get("tool"):
                    issue.tool = payload.get("tool")
                if payload.get("stage"):
                    issue.stage = self._normalize_stage(payload.get("stage"))
            elif payload.get("resolution") and not issue.resolution:
                # For other events, only set if not already present
                issue.resolution = payload.get("resolution")

            # Update tool if provided and not already set
            if payload.get("tool") and not issue.tool:
                issue.tool = payload.get("tool")

            if metadata_payload:
                issue.issue_metadata = metadata_payload

        incident = IssueIncident(
            issue_id=issue.issue_id,
            job_id=job_id,
            run_id=run_id,
            session_id=session_id,
            stage=stage,
            error_signature=error_signature,
            error_message=payload.get("error_message") or description,
            summary=payload.get("summary"),
            incident_metadata=payload.get("metadata"),
        )
        self.session.add(incident)
        self._upsert_fix_variant(issue=issue, job_id=job_id, run_id=run_id, payload=payload)
        self._upsert_semantic_index(issue)
        self.session.commit()
        self.session.refresh(issue)
        self.session.refresh(incident)

        return {
            "issue_id": str(issue.issue_id),
            "canonical_key": issue.canonical_key,
            "incident_id": str(incident.incident_id),
            "occurrence_count": issue.occurrence_count,
            "session_id": session_id,
        }

    def search_issues(
        self,
        *,
        text_query: Optional[str] = None,
        project: Optional[str] = None,
        block: Optional[str] = None,
        stage: Optional[str] = None,
        issue_category: Optional[str] = None,
        tool: Optional[str] = None,
        technology: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: int = 20,
        include_internal: bool = False,
    ) -> list[Dict[str, Any]]:
        query = self.session.query(IssueKnowledge)

        if project:
            query = query.filter(IssueKnowledge.project == project)
        if block:
            query = query.filter(IssueKnowledge.block == block)
        normalized_stage = self._normalize_stage(stage) if stage else None
        normalized_category = self._normalize_issue_category(issue_category) if issue_category else None

        if normalized_stage:
            query = query.filter(IssueKnowledge.stage == normalized_stage)
        if normalized_category:
            query = query.filter(IssueKnowledge.issue_category == normalized_category)
        if tool:
            query = query.filter(IssueKnowledge.tool == tool)
        if technology:
            query = query.filter(IssueKnowledge.technology == technology)
        if session_id:
            query = query.filter(IssueKnowledge.session_id == session_id)

        if text_query and text_query.strip():
            pattern = f"%{text_query.strip()}%"
            query = query.filter(
                or_(
                    IssueKnowledge.title.ilike(pattern),
                    IssueKnowledge.description.ilike(pattern),
                    IssueKnowledge.debug_steps.ilike(pattern),
                    IssueKnowledge.resolution.ilike(pattern),
                )
            )

        expanded_limit = max(20, min(max(1, limit) * 5, 500))
        records = query.order_by(desc(IssueKnowledge.last_seen_at), desc(IssueKnowledge.occurrence_count)).limit(expanded_limit).all()
        ranked = sorted(
            records,
            key=lambda item: self._score_issue_match(record=item, text_query=text_query),
            reverse=True,
        )
        sliced = ranked[: max(1, min(limit, 200))]
        results: list[Dict[str, Any]] = []
        for item in sliced:
            active_fix = self._get_active_fix_variant(item.issue_id)
            variant_count = (
                self.session.query(func.count(IssueFixVariant.variant_id))
                .filter(IssueFixVariant.issue_id == item.issue_id)
                .scalar()
                or 0
            )
            results.append(
                {
                    "issue_id": str(item.issue_id),
                    "canonical_key": item.canonical_key,
                    "project": item.project,
                    "block": item.block,
                    "session_id": item.session_id,
                    "stage": item.stage,
                    "issue_category": item.issue_category,
                    "tool": item.tool,
                    "technology": item.technology,
                    "title": item.title,
                    "description": item.description,
                    "debug_steps": item.debug_steps,
                    "resolution": item.resolution,
                    "occurrence_count": item.occurrence_count,
                    "retrieval_score": round(self._score_issue_match(record=item, text_query=text_query), 4),
                    "first_seen_at": item.first_seen_at.isoformat() if item.first_seen_at else None,
                    "last_seen_at": item.last_seen_at.isoformat() if item.last_seen_at else None,
                    "fix_variant_count": int(variant_count),
                    "active_fix": self._build_fix_variant_response(active_fix),
                    **({"issue_metadata": item.issue_metadata} if include_internal else {}),
                }
            )
        return results

    def hybrid_search_issues(
        self,
        *,
        text_query: Optional[str] = None,
        project: Optional[str] = None,
        block: Optional[str] = None,
        stage: Optional[str] = None,
        issue_category: Optional[str] = None,
        tool: Optional[str] = None,
        technology: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: int = 20,
    ) -> Dict[str, Any]:
        normalized_stage = self._normalize_stage(stage) if stage else None
        normalized_category = self._normalize_issue_category(issue_category) if issue_category else None

        base_query = self.session.query(IssueKnowledge)
        if project:
            base_query = base_query.filter(IssueKnowledge.project == project)
        if block:
            base_query = base_query.filter(IssueKnowledge.block == block)
        if normalized_stage:
            base_query = base_query.filter(IssueKnowledge.stage == normalized_stage)
        if normalized_category:
            base_query = base_query.filter(IssueKnowledge.issue_category == normalized_category)
        if tool:
            base_query = base_query.filter(IssueKnowledge.tool == tool)
        if technology:
            base_query = base_query.filter(IssueKnowledge.technology == technology)
        if session_id:
            base_query = base_query.filter(IssueKnowledge.session_id == session_id)

        candidate_cap = max(100, min(max(1, limit) * 25, 2000))
        candidates = base_query.order_by(desc(IssueKnowledge.last_seen_at)).limit(candidate_cap).all()
        if not candidates:
            return {
                "query": text_query,
                "count": 0,
                "items": [],
                "weights": {"lexical": 0.55, "semantic": 0.45},
                "embedding_enabled": bool((os.getenv("OPENAI_API_KEY") or "").strip()),
            }

        lexical_scores: Dict[str, float] = {}
        lexical_max = 0.0
        for item in candidates:
            score = self._score_issue_match(record=item, text_query=text_query)
            lexical_scores[str(item.issue_id)] = score
            lexical_max = max(lexical_max, score)

        semantic_scores: Dict[str, float] = {}
        embedding_enabled = bool((os.getenv("OPENAI_API_KEY") or "").strip())
        embedding_model = None
        query_text = (text_query or "").strip()
        if embedding_enabled and query_text:
            query_model, query_vector, _ = self._generate_embedding(query_text)
            embedding_model = query_model
            if query_vector:
                issue_ids = [item.issue_id for item in candidates]
                semantic_rows = (
                    self.session.query(IssueSemanticIndex)
                    .filter(IssueSemanticIndex.issue_id.in_(issue_ids))
                    .all()
                )
                for semantic in semantic_rows:
                    vector = semantic.embedding_vector
                    if not isinstance(vector, list):
                        continue
                    similarity = self._cosine_similarity(query_vector, [float(value) for value in vector])
                    if similarity > 0:
                        semantic_scores[str(semantic.issue_id)] = similarity

        semantic_max = max(semantic_scores.values(), default=0.0)
        lexical_weight = 0.55
        semantic_weight = 0.45 if semantic_scores else 0.0
        if semantic_weight == 0.0:
            lexical_weight = 1.0

        ranked: list[Dict[str, Any]] = []
        for item in candidates:
            issue_id = str(item.issue_id)
            lexical_norm = (lexical_scores.get(issue_id, 0.0) / lexical_max) if lexical_max > 0 else 0.0
            semantic_norm = (semantic_scores.get(issue_id, 0.0) / semantic_max) if semantic_max > 0 else 0.0
            combined = (lexical_norm * lexical_weight) + (semantic_norm * semantic_weight)
            if combined <= 0:
                continue

            active_fix = self._get_active_fix_variant(item.issue_id)
            variant_count = (
                self.session.query(func.count(IssueFixVariant.variant_id))
                .filter(IssueFixVariant.issue_id == item.issue_id)
                .scalar()
                or 0
            )

            confidence = max(0.01, min(0.99, combined))
            rationale = [
                f"lexical_match={lexical_norm:.3f}",
                f"semantic_match={semantic_norm:.3f}",
                f"occurrences={int(item.occurrence_count or 0)}",
                f"fix_variants={int(variant_count)}",
            ]
            recommended_resolution = None
            if active_fix and active_fix.fix_applied:
                recommended_resolution = active_fix.fix_applied
            elif item.resolution:
                recommended_resolution = item.resolution

            ranked.append(
                {
                    "issue_id": issue_id,
                    "canonical_key": item.canonical_key,
                    "project": item.project,
                    "block": item.block,
                    "session_id": item.session_id,
                    "stage": item.stage,
                    "issue_category": item.issue_category,
                    "tool": item.tool,
                    "technology": item.technology,
                    "title": item.title,
                    "description": item.description,
                    "occurrence_count": item.occurrence_count,
                    "lexical_score": round(lexical_norm, 6),
                    "semantic_score": round(semantic_norm, 6),
                    "hybrid_score": round(combined, 6),
                    "confidence": round(confidence, 4),
                    "rationale": rationale,
                    "fix_variant_count": int(variant_count),
                    "active_fix": self._build_fix_variant_response(active_fix),
                    "recommended_resolution": recommended_resolution,
                    "last_seen_at": item.last_seen_at.isoformat() if item.last_seen_at else None,
                }
            )

        ranked.sort(key=lambda row: row["hybrid_score"], reverse=True)
        sliced = ranked[: max(1, min(limit, 200))]

        for index, row in enumerate(sliced):
            row["similar_issues"] = [
                {
                    "issue_id": other["issue_id"],
                    "title": other["title"],
                    "hybrid_score": other["hybrid_score"],
                }
                for j, other in enumerate(sliced)
                if j != index
            ][:3]

        return {
            "query": text_query,
            "count": len(sliced),
            "items": sliced,
            "weights": {"lexical": lexical_weight, "semantic": semantic_weight},
            "embedding_enabled": embedding_enabled,
            "embedding_model": embedding_model,
        }

    def semantic_search_issues(
        self,
        *,
        text_query: str,
        project: Optional[str] = None,
        block: Optional[str] = None,
        stage: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: int = 10,
    ) -> Dict[str, Any]:
        query_text = (text_query or "").strip()
        if not (os.getenv("OPENAI_API_KEY") or "").strip():
            return {
                "query": text_query,
                "count": 0,
                "items": [],
                "embedding_enabled": False,
                "message": "Semantic search is not supported because OPENAI_API_KEY is missing.",
            }

        if not query_text:
            return {"query": text_query, "count": 0, "items": [], "embedding_enabled": True}

        query_model, query_vector, _ = self._generate_embedding(query_text)
        if not query_vector:
            return {
                "query": text_query,
                "count": 0,
                "items": [],
                "embedding_enabled": False,
                "message": "Semantic search is unavailable because embeddings could not be generated.",
            }

        issue_query = self.session.query(IssueKnowledge, IssueSemanticIndex).join(
            IssueSemanticIndex, IssueSemanticIndex.issue_id == IssueKnowledge.issue_id
        )
        if project:
            issue_query = issue_query.filter(IssueKnowledge.project == project)
        if block:
            issue_query = issue_query.filter(IssueKnowledge.block == block)
        if stage:
            issue_query = issue_query.filter(IssueKnowledge.stage == self._normalize_stage(stage))
        if session_id:
            issue_query = issue_query.filter(IssueKnowledge.session_id == session_id)

        rows = issue_query.limit(2000).all()
        scored_items = []
        for issue, semantic in rows:
            vector = semantic.embedding_vector
            if not isinstance(vector, list):
                continue
            similarity = self._cosine_similarity(query_vector, [float(item) for item in vector])
            if similarity <= 0:
                continue
            scored_items.append(
                {
                    "issue_id": str(issue.issue_id),
                    "canonical_key": issue.canonical_key,
                    "title": issue.title,
                    "stage": issue.stage,
                    "issue_category": issue.issue_category,
                    "resolution": issue.resolution,
                    "occurrence_count": issue.occurrence_count,
                    "similarity_score": round(similarity, 6),
                    "last_seen_at": issue.last_seen_at.isoformat() if issue.last_seen_at else None,
                }
            )

        scored_items.sort(key=lambda item: item["similarity_score"], reverse=True)
        sliced = scored_items[: max(1, min(limit, 100))]
        return {
            "query": text_query,
            "count": len(sliced),
            "items": sliced,
            "embedding_enabled": True,
            "embedding_model": query_model,
        }

    def find_duplicate_candidates(
        self,
        *,
        payload: Dict[str, Any],
        limit: int = 10,
    ) -> Dict[str, Any]:
        stage = self._normalize_stage(payload.get("stage"))
        issue_category = self._normalize_issue_category(payload.get("issue_category"))
        title = payload.get("title") or f"{stage} failure"
        description = payload.get("description") or payload.get("error_message") or ""
        tool = payload.get("tool")
        technology = payload.get("technology") or "others"
        project = payload.get("project")
        block = payload.get("block")
        error_signature = payload.get("error_signature") or payload.get("error_message") or description

        fingerprint_hash = self._build_fingerprint(
            project=project,
            block=block,
            stage=stage,
            tool=tool,
            technology=technology,
            issue_category=issue_category,
            title=title,
            error_signature=error_signature,
        )

        exact = self.session.query(IssueKnowledge).filter(IssueKnowledge.fingerprint_hash == fingerprint_hash).first()
        if exact is not None:
            return {
                "is_exact_duplicate": True,
                "fingerprint_hash": fingerprint_hash,
                "exact_match": {
                    "issue_id": str(exact.issue_id),
                    "canonical_key": exact.canonical_key,
                    "title": exact.title,
                    "stage": exact.stage,
                    "issue_category": exact.issue_category,
                    "occurrence_count": exact.occurrence_count,
                },
                "candidates": [],
            }

        pattern = f"%{title[:80]}%" if title else None
        query = self.session.query(IssueKnowledge).filter(IssueKnowledge.stage == stage)
        if issue_category:
            query = query.filter(IssueKnowledge.issue_category == issue_category)
        if tool:
            query = query.filter(IssueKnowledge.tool == tool)
        if project:
            query = query.filter(IssueKnowledge.project == project)
        if block:
            query = query.filter(IssueKnowledge.block == block)
        if pattern:
            query = query.filter(or_(IssueKnowledge.title.ilike(pattern), IssueKnowledge.description.ilike(pattern)))

        records = query.order_by(desc(IssueKnowledge.last_seen_at), desc(IssueKnowledge.occurrence_count)).limit(max(1, min(limit, 50))).all()
        return {
            "is_exact_duplicate": False,
            "fingerprint_hash": fingerprint_hash,
            "exact_match": None,
            "candidates": [
                {
                    "issue_id": str(item.issue_id),
                    "canonical_key": item.canonical_key,
                    "title": item.title,
                    "stage": item.stage,
                    "issue_category": item.issue_category,
                    "tool": item.tool,
                    "technology": item.technology,
                    "occurrence_count": item.occurrence_count,
                    "last_seen_at": item.last_seen_at.isoformat() if item.last_seen_at else None,
                }
                for item in records
            ],
        }

    def get_issue_stats(self) -> Dict[str, Any]:
        total = self.session.query(func.count(IssueKnowledge.issue_id)).scalar() or 0
        top_stages = (
            self.session.query(IssueKnowledge.stage, func.sum(IssueKnowledge.occurrence_count))
            .group_by(IssueKnowledge.stage)
            .order_by(desc(func.sum(IssueKnowledge.occurrence_count)))
            .limit(10)
            .all()
        )
        top_categories = (
            self.session.query(IssueKnowledge.issue_category, func.sum(IssueKnowledge.occurrence_count))
            .group_by(IssueKnowledge.issue_category)
            .order_by(desc(func.sum(IssueKnowledge.occurrence_count)))
            .limit(10)
            .all()
        )
        return {
            "total_canonical_issues": total,
            "top_stages": [{"stage": stage, "occurrences": int(count or 0)} for stage, count in top_stages],
            "top_categories": [
                {"issue_category": category, "occurrences": int(count or 0)} for category, count in top_categories
            ],
        }

    def get_taxonomy(self) -> Dict[str, Any]:
        rows = (
            self.session.query(IssueTaxonomyEntry)
            .filter(IssueTaxonomyEntry.is_active.is_(True))
            .order_by(IssueTaxonomyEntry.taxonomy_type.asc(), IssueTaxonomyEntry.canonical_value.asc())
            .all()
        )
        grouped: Dict[str, list[str]] = {}
        for row in rows:
            grouped.setdefault(row.taxonomy_type, []).append(row.canonical_value)

        return {
            "taxonomy_version": self.TAXONOMY_VERSION,
            "values": grouped,
        }

    def get_semantic_document(self, *, issue_id: str) -> Optional[Dict[str, Any]]:
        semantic_row = self.session.query(IssueSemanticIndex).filter(IssueSemanticIndex.issue_id == issue_id).first()
        if semantic_row is None:
            return None
        return {
            "issue_id": issue_id,
            "semantic_text": semantic_row.semantic_text,
            "embedding_model": semantic_row.embedding_model,
            "embedding_version": semantic_row.embedding_version,
            "last_indexed_at": semantic_row.last_indexed_at.isoformat() if semantic_row.last_indexed_at else None,
            "has_embedding_vector": bool(semantic_row.embedding_vector),
        }

    def rebuild_semantic_index(self, *, limit: int = 500) -> Dict[str, Any]:
        issues = (
            self.session.query(IssueKnowledge)
            .order_by(desc(IssueKnowledge.last_seen_at), desc(IssueKnowledge.occurrence_count))
            .limit(max(1, min(limit, 5000)))
            .all()
        )
        processed = 0
        for issue in issues:
            self._upsert_semantic_index(issue)
            processed += 1
        self.session.commit()
        return {
            "processed": processed,
            "limit": max(1, min(limit, 5000)),
            "status": "ok",
        }
