"""Status vocabulary mapping between lifecycle and dev1 runtime."""

from __future__ import annotations

from typing import Tuple


# lifecycle (legacy/src style) -> dev1
LIFECYCLE_TO_DEV1_STATUS = {
    "PENDING": "pending",
    "IN_PROGRESS": "in_progress",
    "SUCCESS": "completed",
    "FAILED": "failed",
    "CANCELLED": "failed",
}

DEV1_TO_LIFECYCLE_STATUS = {v: k for k, v in LIFECYCLE_TO_DEV1_STATUS.items() if v != "failed"}
DEV1_TO_LIFECYCLE_STATUS["failed"] = "FAILED"


def to_dev1_status(lifecycle_status: str) -> str:
    return LIFECYCLE_TO_DEV1_STATUS.get(lifecycle_status.upper(), "pending")


def to_lifecycle_status(dev1_status: str) -> str:
    return DEV1_TO_LIFECYCLE_STATUS.get(dev1_status.lower(), "PENDING")


def to_lifecycle_status_phase(dev1_status: str, current_stage: str | None = None) -> Tuple[str, str]:
    status = to_lifecycle_status(dev1_status)
    if status == "PENDING":
        return status, "QUEUED"
    if status == "IN_PROGRESS":
        return status, "EXECUTING"
    if status == "SUCCESS":
        return status, "COMPLETED"
    if status == "FAILED":
        if current_stage:
            return status, f"FAILED:{current_stage}"
        return status, "FAILED"
    return status, "UNKNOWN"
