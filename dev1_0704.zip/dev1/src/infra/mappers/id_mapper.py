"""Identity mapping helpers for lifecycle IDs."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional
import uuid


@dataclass(frozen=True)
class JobIdentity:
    job_id: str
    session_id: Optional[str]
    thread_id: Optional[str]
    run_id: Optional[str]


def create_job_id() -> str:
    return str(uuid.uuid4())


def create_run_id() -> str:
    return str(uuid.uuid4())


def normalize_session_id(session_id: Optional[str]) -> Optional[str]:
    if not session_id:
        return None
    try:
        return str(uuid.UUID(session_id))
    except Exception:
        return None


def make_identity(
    *,
    session_id: Optional[str] = None,
    thread_id: Optional[str] = None,
    run_id: Optional[str] = None,
    job_id: Optional[str] = None,
) -> JobIdentity:
    return JobIdentity(
        job_id=job_id or create_job_id(),
        session_id=normalize_session_id(session_id),
        thread_id=thread_id,
        run_id=run_id or create_run_id(),
    )


def to_metadata(identity: JobIdentity) -> Dict[str, Any]:
    return {
        "job_id": identity.job_id,
        "session_id": identity.session_id,
        "thread_id": identity.thread_id,
        "run_id": identity.run_id,
    }
