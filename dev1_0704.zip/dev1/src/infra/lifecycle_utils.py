"""Shared utility helpers for lifecycle compatibility routes and bridge events."""

from __future__ import annotations

from typing import Any, Optional, Tuple
import uuid


def normalize_optional_uuid(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    try:
        return str(uuid.UUID(value))
    except Exception:
        return None


# Namespace for generating deterministic UUIDs from user names
USER_NAME_NAMESPACE = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")  # DNS namespace


def user_name_to_uuid(user_name: Optional[str]) -> Optional[str]:
    """Generate a deterministic UUID from user_name.

    The same user_name will always produce the same UUID.

    Args:
        user_name: The user name string (e.g., "bharath")

    Returns:
        A UUID string, or None if user_name is empty
    """
    if not user_name:
        return None
    # UUID5 generates deterministic UUID from namespace + name
    return str(uuid.uuid5(USER_NAME_NAMESPACE, user_name.lower().strip()))


def safe_int(value: Any) -> Optional[int]:
    try:
        if value is None:
            return None
        return int(value)
    except Exception:
        return None


def safe_str(value: Any) -> Optional[str]:
    if value is None:
        return None
    return str(value)


def lifecycle_status_for_event(event_type: str, payload: dict) -> Tuple[str, str]:
    stage = safe_str(payload.get("stage"))
    if event_type in {"started", "stage_started", "stage_completed", "hitl_response"}:
        return "IN_PROGRESS", f"EXECUTING:{stage}" if stage else "EXECUTING"
    if event_type == "hitl_required":
        return "IN_PROGRESS", "WAITING_FOR_HUMAN"
    if event_type == "stage_failed":
        return "IN_PROGRESS", f"FAILED:{stage}" if stage else "FAILED"
    if event_type == "validation_started":
        return "IN_PROGRESS", f"VALIDATING:{stage}" if stage else "VALIDATING"
    if event_type == "validation_completed":
        passed = payload.get("passed", False)
        if passed:
            return "IN_PROGRESS", f"VALIDATED:{stage}" if stage else "VALIDATED"
        else:
            return "IN_PROGRESS", f"VALIDATION_FAILED:{stage}" if stage else "VALIDATION_FAILED"
    if event_type == "completed":
        return "SUCCESS", "COMPLETED"
    if event_type == "failed":
        return "FAILED", f"FAILED:{stage}" if stage else "FAILED"
    if event_type == "abort_requested":
        return "CANCELLED", "ABORT_REQUESTED"
    return "IN_PROGRESS", "EXECUTING"


def message_for_event(event_type: str, payload: dict) -> str:
    stage = safe_str(payload.get("stage"))
    if event_type == "started":
        return "Flow execution started"
    if event_type == "stage_started":
        return f"Stage started: {stage}" if stage else "Stage started"
    if event_type == "stage_completed":
        return f"Stage completed: {stage}" if stage else "Stage completed"
    if event_type == "stage_failed":
        error = safe_str(payload.get("error"))
        if stage and error:
            return f"Stage failed: {stage} ({error})"
        if stage:
            return f"Stage failed: {stage}"
        return "Stage failed"
    if event_type == "validation_started":
        return f"Validating {stage}..." if stage else "Running validation..."
    if event_type == "validation_completed":
        passed = payload.get("passed", False)
        if passed:
            return f"Validation passed for {stage}" if stage else "Validation passed"
        else:
            issues = payload.get("issues", [])
            issue_preview = issues[0] if issues else "Check failed"
            return f"Validation failed for {stage}: {issue_preview}"
    if event_type == "completed":
        return "Flow execution completed"
    if event_type == "failed":
        return safe_str(payload.get("error")) or "Flow execution failed"
    if event_type == "abort_requested":
        return "Abort requested"
    if event_type == "hitl_response":
        return "Human input received"
    if event_type == "hitl_required":
        return safe_str(payload.get("message")) or "Waiting for human confirmation"
    return "Lifecycle update"


def derive_checkpoint_nodes(event_type: str, payload: dict, state: dict) -> Tuple[Optional[str], Optional[str]]:
    """Map lifecycle event/state to workflow-level checkpoint pointers."""
    current_stage_index = safe_int(payload.get("current_stage_index"))
    if current_stage_index is None:
        current_stage_index = safe_int(state.get("current_stage_index"))

    plan_size = safe_int(payload.get("plan_size"))
    if plan_size is None:
        plan = state.get("plan")
        if isinstance(plan, list):
            plan_size = len(plan)

    require_plan_confirmation = bool(state.get("require_plan_confirmation", True))

    if event_type == "started":
        return "create_plan", "confirm_plan" if require_plan_confirmation else "execute_stage"
    if event_type == "hitl_required":
        return "confirm_plan", "confirm_plan"
    if event_type == "hitl_response":
        return "confirm_plan", "execute_stage"
    if event_type == "stage_started":
        return "execute_stage", "execute_stage"
    if event_type == "stage_completed":
        if current_stage_index is not None and plan_size is not None and (current_stage_index + 1) >= plan_size:
            return "execute_stage", "handle_result"
        return "execute_stage", "execute_stage"
    if event_type == "stage_failed":
        return "execute_stage", "debug_stage"
    if event_type in {"completed", "failed", "abort_requested"}:
        return "handle_result", None

    current_node = safe_str(state.get("current_node"))
    next_node = safe_str(state.get("next_node"))
    return current_node, next_node
