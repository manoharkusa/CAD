"""Centralized token usage tracking for all LLM calls.

Usage:
    from src.infra.token_tracker import token_tracker

    # After any Anthropic API call:
    token_tracker.record(response, source="debug_agent.analyze")

    # At end of run:
    token_tracker.print_summary()
    stats = token_tracker.get_stats()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
import threading


@dataclass
class TokenRecord:
    """Single LLM call record."""
    source: str
    input_tokens: int  # Total input tokens (including cache)
    output_tokens: int
    model: str
    cost_usd: float = 0.0  # Cost in USD if available
    num_turns: int = 0  # Number of turns if from Agent SDK
    cache_read_tokens: int = 0  # Tokens read from cache (cheaper)
    cache_creation_tokens: int = 0  # Tokens written to cache
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class TokenTracker:
    """Thread-safe token usage tracker for all LLM calls."""

    def __init__(self):
        self._records: List[TokenRecord] = []
        self._lock = threading.Lock()
        self._run_id: Optional[str] = None

    def set_run_id(self, run_id: str):
        """Set current run ID for context."""
        self._run_id = run_id

    def reset(self):
        """Reset tracker for new run."""
        with self._lock:
            self._records = []
            self._run_id = None

    def record(self, response: Any, source: str, model: str = "unknown"):
        """Record token usage from an Anthropic API response.

        Args:
            response: Anthropic API response object with .usage attribute
            source: Identifier for the call source (e.g., "debug_agent.analyze")
            model: Model name if not in response
        """
        try:
            usage = getattr(response, "usage", None)
            if usage is None:
                return

            input_tokens = getattr(usage, "input_tokens", 0)
            output_tokens = getattr(usage, "output_tokens", 0)
            response_model = getattr(response, "model", model)

            record = TokenRecord(
                source=source,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                model=response_model,
            )

            with self._lock:
                self._records.append(record)

            # Print inline (internal log)
            total_in, total_out, total_cost = self._get_totals_unlocked()
            print(
                f"[TOKEN] {source}: in={input_tokens} out={output_tokens} | "
                f"cumulative: in={total_in} out={total_out} total={total_in + total_out}"
            )

        except Exception as e:
            print(f"[TOKEN] Failed to record usage: {e}")

    def record_manual(
        self,
        input_tokens: int,
        output_tokens: int,
        source: str,
        model: str = "unknown",
        cost_usd: float = 0.0,
        num_turns: int = 0,
        cache_read_tokens: int = 0,
        cache_creation_tokens: int = 0,
    ):
        """Manually record token usage (for Agent SDK or other sources).

        Args:
            input_tokens: Total number of input tokens (including cache)
            output_tokens: Number of output tokens
            source: Identifier for the call source
            model: Model name
            cost_usd: Cost in USD if available
            num_turns: Number of API turns if from Agent SDK
            cache_read_tokens: Tokens read from cache (cheaper)
            cache_creation_tokens: Tokens written to cache
        """
        record = TokenRecord(
            source=source,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model=model,
            cost_usd=cost_usd,
            num_turns=num_turns,
            cache_read_tokens=cache_read_tokens,
            cache_creation_tokens=cache_creation_tokens,
        )

        with self._lock:
            self._records.append(record)

        total_in, total_out, total_cost = self._get_totals_unlocked()
        cost_str = f" cost=${cost_usd:.4f}" if cost_usd else ""
        turns_str = f" turns={num_turns}" if num_turns else ""
        cache_str = f" (cache_read={cache_read_tokens})" if cache_read_tokens else ""
        print(
            f"[TOKEN] {source}: in={input_tokens}{cache_str} out={output_tokens}{cost_str}{turns_str} | "
            f"cumulative: in={total_in} out={total_out} total={total_in + total_out} cost=${total_cost:.4f}"
        )

    def _get_totals_unlocked(self) -> tuple:
        """Get totals without lock (caller must hold lock or accept race)."""
        total_in = sum(r.input_tokens for r in self._records)
        total_out = sum(r.output_tokens for r in self._records)
        total_cost = sum(r.cost_usd for r in self._records)
        return total_in, total_out, total_cost

    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive usage statistics."""
        with self._lock:
            if not self._records:
                return {"total_calls": 0, "total_input": 0, "total_output": 0, "total_tokens": 0, "total_cost": 0.0}

            total_input = sum(r.input_tokens for r in self._records)
            total_output = sum(r.output_tokens for r in self._records)
            total_cost = sum(r.cost_usd for r in self._records)
            total_turns = sum(r.num_turns for r in self._records)
            total_cache_read = sum(r.cache_read_tokens for r in self._records)
            total_cache_creation = sum(r.cache_creation_tokens for r in self._records)

            # Group by source
            by_source: Dict[str, Dict[str, Any]] = {}
            for r in self._records:
                if r.source not in by_source:
                    by_source[r.source] = {"calls": 0, "input": 0, "output": 0, "cost": 0.0, "turns": 0, "cache_read": 0}
                by_source[r.source]["calls"] += 1
                by_source[r.source]["input"] += r.input_tokens
                by_source[r.source]["output"] += r.output_tokens
                by_source[r.source]["cost"] += r.cost_usd
                by_source[r.source]["turns"] += r.num_turns
                by_source[r.source]["cache_read"] += r.cache_read_tokens

            # Group by model
            by_model: Dict[str, Dict[str, Any]] = {}
            for r in self._records:
                if r.model not in by_model:
                    by_model[r.model] = {"calls": 0, "input": 0, "output": 0, "cost": 0.0}
                by_model[r.model]["calls"] += 1
                by_model[r.model]["input"] += r.input_tokens
                by_model[r.model]["output"] += r.output_tokens
                by_model[r.model]["cost"] += r.cost_usd

            return {
                "run_id": self._run_id,
                "total_calls": len(self._records),
                "total_input": total_input,
                "total_output": total_output,
                "total_tokens": total_input + total_output,
                "total_cost": total_cost,
                "total_turns": total_turns,
                "total_cache_read": total_cache_read,
                "total_cache_creation": total_cache_creation,
                "by_source": by_source,
                "by_model": by_model,
                "records": [
                    {
                        "source": r.source,
                        "input": r.input_tokens,
                        "output": r.output_tokens,
                        "cost": r.cost_usd,
                        "turns": r.num_turns,
                        "cache_read": r.cache_read_tokens,
                        "model": r.model,
                        "timestamp": r.timestamp,
                    }
                    for r in self._records
                ],
            }

    def print_summary(self):
        """Print a formatted summary of token usage."""
        stats = self.get_stats()

        if stats["total_calls"] == 0:
            print("\n[TOKEN SUMMARY] No LLM calls recorded")
            return

        print("\n" + "=" * 60)
        print("TOKEN USAGE SUMMARY")
        print("=" * 60)

        if stats.get("run_id"):
            print(f"Run ID: {stats['run_id']}")

        print(f"\nTotal Calls: {stats['total_calls']}")
        print(f"Total Input Tokens:  {stats['total_input']:,}")
        if stats.get("total_cache_read", 0) > 0:
            print(f"  - Cache Read:      {stats['total_cache_read']:,} (90% cheaper)")
            print(f"  - Cache Creation:  {stats.get('total_cache_creation', 0):,}")
        print(f"Total Output Tokens: {stats['total_output']:,}")
        print(f"Total Tokens:        {stats['total_tokens']:,}")
        if stats.get("total_cost", 0) > 0:
            print(f"Total Cost (USD):    ${stats['total_cost']:.4f}")
        if stats.get("total_turns", 0) > 0:
            print(f"Total API Turns:     {stats['total_turns']}")

        print("\n--- By Source ---")
        for source, data in stats.get("by_source", {}).items():
            print(f"  {source}:")
            cost_str = f", Cost: ${data['cost']:.4f}" if data.get('cost', 0) > 0 else ""
            turns_str = f", Turns: {data['turns']}" if data.get('turns', 0) > 0 else ""
            print(f"    Calls: {data['calls']}, Input: {data['input']:,}, Output: {data['output']:,}{cost_str}{turns_str}")

        print("\n--- By Model ---")
        for model, data in stats.get("by_model", {}).items():
            print(f"  {model}:")
            cost_str = f", Cost: ${data['cost']:.4f}" if data.get('cost', 0) > 0 else ""
            print(f"    Calls: {data['calls']}, Input: {data['input']:,}, Output: {data['output']:,}{cost_str}")

        print("=" * 60 + "\n")


# Global singleton instance
token_tracker = TokenTracker()
