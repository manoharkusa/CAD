"""Infrastructure compatibility layer for job lifecycle integration.

This package provides non-invasive adapters so `dev1/src` core agent logic
can stay unchanged while end-to-end lifecycle plumbing is integrated.
"""

from .contracts import JobEventPublisher, JobRepository, JobStateStore
from .feature_flags import FeatureFlags
from .bootstrap import initialize_lifecycle_runtime

__all__ = [
    "JobRepository",
    "JobStateStore",
    "JobEventPublisher",
    "FeatureFlags",
    "initialize_lifecycle_runtime",
]
