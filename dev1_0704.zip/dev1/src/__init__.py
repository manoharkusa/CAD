"""
Physical Design Flow - Python Orchestration

Approach B: TCL-based YAML Loading with External Setup

Architecture:
- ConfigManager: Manages YAML file paths and environment variables
- StageExecutor: Executes EDA tool stages with fresh YAML config
- OrchestratorAgent: Orchestrates the flow using Claude Agent SDK
- DebugAgent: Handles automatic debugging and error recovery
- UnifiedPhysicalDesignAgent: Claude Agent SDK-based intelligent tool execution

Assumptions:
- Working directory structure: Pre-created by external setup scripts
- YAML configuration: Managed externally, loaded by TCL scripts
- Python role: Orchestration, tool execution, error analysis
- TCL role: YAML loading, environment setup, tool script execution

For each stage execution:
1. ConfigManager provides YAML file paths as environment variables
2. StageExecutor creates per-stage log/work directories
3. StageExecutor passes yaml_config_reader.tcl to EDA tool
4. TCL loads all YAML files fresh (approach B)
5. Tool executes with full configuration
"""

__version__ = "0.1.0"
__author__ = "Physical Design Team"

from .config import ConfigManager, create_config_manager
from .executor import StageExecutor

__all__ = [
    "ConfigManager",
    "create_config_manager",
    "StageExecutor",
]
