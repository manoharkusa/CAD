#!/usr/bin/env python3
"""
DebugAgent - Intelligent debugging engine for stage failures

Responsibilities:
1. Analyze stage failures using Claude AI
2. Generate fix suggestions for editable files
3. Support auto, interactive, and human-loop debug modes
4. Apply fixes with safety mechanisms (backups, validation, rollback)
5. Track debug history for learning and analysis
"""

import asyncio
import json
import re
import hashlib
import difflib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict, field
from enum import Enum

try:
    from anthropic import Anthropic
except ImportError:
    Anthropic = None
    print("[WARN] anthropic SDK not installed. DebugAgent will use fallback analysis mode.")

from src.infra.token_tracker import token_tracker
from src.config.runtime_config import get_claude_model
import yaml

try:
    from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, ResultMessage
except ImportError:
    query = None
    AssistantMessage = None
    ResultMessage = None
    print("[WARN] Claude Agent SDK not installed. Using fallback mode for debugging.")

from ..config import ConfigManager
from ..tracker import StateTracker


class DebugMode(Enum):
    """Debug modes for different execution contexts"""
    AUTO = "auto"  # Automatically apply best fix
    INTERACTIVE = "interactive"  # Present options for user selection
    HUMAN_LOOP = "human-loop"  # Show analysis, wait for engineer


class ErrorCategory(Enum):
    """Error categories recognized by DebugAgent"""
    TIMING_VIOLATION = "timing_violation"
    DESIGN_RULE_VIOLATION = "design_rule_violation"
    SYNTAX_ERROR = "syntax_error"
    FILE_NOT_FOUND = "file_not_found"
    MEMORY_ERROR = "memory_error"
    CONVERGENCE_FAILURE = "convergence_failure"
    CONFIGURATION_ERROR = "configuration_error"
    CONSTRAINT_CONFLICT = "constraint_conflict"
    PHYSICAL_DESIGN_ERROR = "physical_design_error"
    OTHER = "other"


@dataclass
class FileModification:
    """A specific file modification"""
    file_path: str
    operation: str  # "edit", "append", "create"
    content: Optional[str] = None  # For create/append
    line_number: Optional[int] = None  # For edit
    old_content: Optional[str] = None  # For edit
    new_content: Optional[str] = None  # For edit


@dataclass
class FixSuggestion:
    """A suggested fix for an error"""
    title: str
    description: str
    rationale: str
    risk_level: str  # "low", "medium", "high"
    confidence: float  # 0-1
    modifications: List[FileModification] = field(default_factory=list)
    estimated_impact: str = ""
    prerequisites: List[str] = field(default_factory=list)


@dataclass
class ErrorAnalysis:
    """Claude's analysis of an error"""
    category: str
    root_cause: str
    confidence: float
    fixable: bool
    suggested_investigation: List[str] = field(default_factory=list)
    relevant_log_sections: List[str] = field(default_factory=list)


@dataclass
class FixResult:
    """Result of applying a fix"""
    status: str  # "applied", "failed", "skipped"
    modified_files: List[str] = field(default_factory=list)
    backups: List[str] = field(default_factory=list)
    error_message: Optional[str] = None
    validation_errors: List[str] = field(default_factory=list)
    file_edits: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class DebugAttempt:
    """Record of a single debug attempt"""
    attempt_number: int
    stage_name: str
    error_category: str
    error_analysis: ErrorAnalysis
    fix_applied: Optional[FixSuggestion] = None
    fix_result: Optional[FixResult] = None
    outcome: str = "pending"  # "success", "failed", "skipped"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class DebugAgent:
    """
    Intelligent debugging engine for physical design flow failures

    Uses Claude AI to:
    1. Analyze errors from stage execution
    2. Understand root causes and fixability
    3. Generate context-aware fix suggestions
    4. Apply fixes safely with validation and rollback
    5. Track debug history for learning

    Safety guarantees:
    - Only editable files can be modified
    - Automatic backups before changes
    - Syntax validation and rollback on failure
    - Retry limits to prevent loops
    """

    # Files and directories that can be modified
    EDITABLE_PATTERNS = [
        "block_scripts/block.yaml",
        "block_inputs/*.sdc",
        "block_inputs/*.tcl",
        "block_inputs/mem_list.txt",
        "block_inputs/*.rtl.f",
    ]

    # Directories that are read-only
    READONLY_PATTERNS = [
        "tool_scripts/**/*",
        "tech_scripts/**/*",
    ]

    def __init__(
        self,
        config_manager: ConfigManager,
        state_tracker: Optional[StateTracker] = None,
        max_retry_attempts: int = 3,
        log_callback: Optional[Any] = None,
    ):
        """
        Initialize DebugAgent

        Args:
            config_manager: ConfigManager for file paths and configuration
            state_tracker: StateTracker for persisting debug history (optional)
            max_retry_attempts: Maximum retry attempts per stage (default: 3)
            log_callback: Optional callback for emitting logs to Redis (callable(message, level, payload))
        """
        self.config_manager = config_manager
        self.state_tracker = state_tracker
        self.max_retry_attempts = max_retry_attempts
        self.log_callback = log_callback

        # Claude client for error analysis and fix generation
        self.client = Anthropic() if Anthropic is not None else None
        self.model = get_claude_model()

        # Debug history and artifacts
        self.debug_history: Dict[str, List[DebugAttempt]] = {}

        # Get run_dir from ConfigManager (no path creation needed)
        run_dir = self.config_manager.get_run_dir()
        self.backups_dir = run_dir / ".debug_backups"

        # Only create directory if state_tracker is provided (for backward compatibility)
        # Otherwise just store the path without creating it
        if self.state_tracker:
            self.backups_dir.mkdir(parents=True, exist_ok=True)

        # Flag for Claude Agent SDK availability
        self.use_agent_sdk = query is not None

        # Abort checker callback (set per debug_stage call)
        self.abort_checker = None

        # Debug skills directory and cache
        self.skills_dir = Path(__file__).parent.parent.parent / "skills" / "debug"
        self._skill_cache: Dict[str, Path] = {}

    # Stage name aliases for skill matching
    STAGE_ALIASES = {
        "synthesis": "syn",
        "synth": "syn",
        "placement": "place",
        "cts": "cts",
        "clock_tree": "cts",
        "routing": "route",
        "route": "route",
    }

    def _parse_skill_file(self, path: Path) -> tuple:
        """Parse YAML frontmatter and content from skill file.

        Args:
            path: Path to the skill file

        Returns:
            Tuple of (metadata dict, body content string)
        """
        try:
            content = path.read_text()
        except Exception as e:
            self._emit_log(f"[DEBUG] Error reading skill file {path}: {e}")
            return None, ""

        # Extract YAML frontmatter between --- markers
        match = re.match(r"^---\n(.*?)\n---\n(.*)$", content, re.DOTALL)
        if not match:
            return None, content

        try:
            metadata = yaml.safe_load(match.group(1))
            body = match.group(2).strip()
            return metadata, body
        except yaml.YAMLError as e:
            self._emit_log(f"[DEBUG] Error parsing YAML in {path}: {e}")
            return None, content

    def _load_skills_index(self) -> Dict[str, Path]:
        """Build index of debug skills by (stage:tool) key from frontmatter.

        Returns:
            Dict mapping "stage:tool" keys to skill file paths
        """
        if self._skill_cache:
            return self._skill_cache

        if not self.skills_dir.exists():
            self._emit_log(f"[DEBUG] Skills directory not found: {self.skills_dir}")
            return {}

        for skill_file in self.skills_dir.glob("*.skill.md"):
            meta, _ = self._parse_skill_file(skill_file)
            if meta:
                stage = meta.get("stage", "")
                tool = meta.get("tool", "")
                if stage and tool:
                    key = f"{stage}:{tool}"
                    self._skill_cache[key] = skill_file
                    self._emit_log(f"[DEBUG] Indexed debug skill: {key} -> {skill_file.name}")

        return self._skill_cache

    def _find_debug_skill(self, stage: str, tool: str) -> tuple:
        """Find debug skill file matching stage and tool.

        Args:
            stage: Stage name (e.g., "syn", "place")
            tool: Tool name (e.g., "genus", "dc_shell")

        Returns:
            Tuple of (metadata, body) if found, (None, "") otherwise
        """
        index = self._load_skills_index()

        # Normalize stage name
        stage_normalized = self.STAGE_ALIASES.get(stage.lower(), stage.lower())
        tool_normalized = tool.lower().replace("-", "_")

        # Try exact match
        key = f"{stage_normalized}:{tool_normalized}"
        if key in index:
            return self._parse_skill_file(index[key])

        # Try stage with any tool (fallback)
        for k, path in index.items():
            if k.startswith(f"{stage_normalized}:"):
                self._emit_log(f"[DEBUG] Using fallback skill {path.name} for {stage}/{tool}")
                return self._parse_skill_file(path)

        return None, ""

    def _get_debug_instructions(self, stage_name: str) -> str:
        """Load debug instructions for a specific stage/tool.

        Args:
            stage_name: Name of the stage being debugged

        Returns:
            Debug instructions string (empty if no skill found)
        """
        try:
            tool, _ = self.config_manager.get_stage_tool_script(stage_name)
            tool = tool.lower().replace("-", "_")
        except Exception:
            tool = "unknown"

        meta, body = self._find_debug_skill(stage_name, tool)

        if body:
            self._emit_log(f"[DEBUG] Loaded debug skill for {stage_name}/{tool}")
            return f"\n## Stage-Specific Debug Instructions\n\n{body}\n"

        return ""

    def _emit_log(self, message: str, level: str = "INFO", payload: Optional[Dict[str, Any]] = None) -> None:
        """Emit detailed log to terminal only."""
        print(message)

    def _emit_ui_log(self, message: str, level: str = "INFO", payload: Optional[Dict[str, Any]] = None) -> None:
        """Emit summarized log to UI via callback (human-readable format)."""
        print(message)  # Also print to terminal for debugging
        if self.log_callback:
            try:
                self.log_callback(message, level=level, payload=payload or {})
            except Exception as e:
                print(f"[WARN] log_callback failed: {e}")

    def _format_tool_call(self, tool_name: str, tool_input: Dict[str, Any]) -> str:
        """Format tool call for human-readable display.

        Args:
            tool_name: Name of the tool (Read, Bash, Grep, etc.)
            tool_input: Tool input arguments

        Returns:
            Formatted string like "Reading /path/to/file" or "Running: ls -la"
        """
        if tool_name == "Read":
            file_path = tool_input.get("file_path", "unknown")
            return f"Reading {file_path}"

        elif tool_name == "Bash":
            command = tool_input.get("command", "")
            # Truncate long commands
            if len(command) > 80:
                command = command[:77] + "..."
            return f"Running: {command}"

        elif tool_name == "Grep":
            pattern = tool_input.get("pattern", "")
            path = tool_input.get("path", ".")
            return f"Searching for '{pattern}' in {path}"

        elif tool_name == "Glob":
            pattern = tool_input.get("pattern", "")
            path = tool_input.get("path", ".")
            return f"Finding files matching '{pattern}' in {path}"

        elif tool_name == "Write":
            file_path = tool_input.get("file_path", "unknown")
            return f"Writing to {file_path}"

        elif tool_name == "Edit":
            file_path = tool_input.get("file_path", "unknown")
            return f"Editing {file_path}"

        else:
            return f"Calling {tool_name}"

    def _check_abort(self) -> bool:
        """Check if abort has been requested.

        Returns:
            True if abort requested, False otherwise
        """
        if self.abort_checker and callable(self.abort_checker):
            try:
                result = self.abort_checker()
                if result and result.get("abort_requested"):
                    self._emit_log("[DEBUG] Abort requested, stopping debug analysis")
                    self._emit_ui_log("Debug aborted by user", level="WARN")
                    return True
            except Exception as e:
                print(f"[WARN] abort_checker failed: {e}")
        return False

    async def _debug_with_claude_agent_sdk(
        self,
        stage_name: str,
        error_info: Dict[str, Any],
        run_dir: Path,
    ) -> Dict[str, Any]:
        """
        Use Claude Agent SDK for intelligent debugging with tool access

        Claude can use tools like:
        - Read: Read log files and error outputs
        - Bash: Run commands to check tool status
        - Grep: Search for error patterns in files
        - Glob: Find relevant files

        Args:
            stage_name: Name of the failed stage
            error_info: Error information from StageExecutor
            run_dir: Run directory path

        Returns:
            Debug analysis and suggested fixes
        """
        if not self.use_agent_sdk:
            return None

        self._emit_log(f"[DEBUG] Using SPD Agent for intelligent debugging...")

        # Build validation context if this is a validation failure
        validation_context = ""
        if error_info.get("category") == "validation_failure":
            validation_result = error_info.get("validation_result", {})
            validation_issues = validation_result.get("issues", [])
            validation_metrics = validation_result.get("metrics", {})

            if validation_issues:
                validation_context = f"""
**Validation Failures**:
{chr(10).join(f'- {issue}' for issue in validation_issues)}

**Validation Metrics**:
{chr(10).join(f'- {k}: {v}' for k, v in validation_metrics.items()) if validation_metrics else '- No metrics extracted'}

The stage execution completed but validation checks failed. Focus on fixing the issues identified above.
"""

        # Get block directory for editable files
        # block_inputs_dir is from BLOCK_INPUTS env var, block_dir is its parent
        block_inputs_dir = self.config_manager.block_inputs_dir
        if block_inputs_dir:
            block_dir = block_inputs_dir.parent
            block_scripts_dir = block_dir / "block_scripts"
        else:
            # Fallback: use run_dir as base
            block_dir = run_dir
            block_inputs_dir = run_dir / "block_inputs"
            block_scripts_dir = run_dir / "block_scripts"

        # List existing editable files for context
        editable_files = self._list_editable_files()
        editable_files_list = "\n".join(f"  - {f}" for f in editable_files.keys()) if editable_files else "  (none found)"

        # Load stage-specific debug instructions from skill file
        debug_instructions = self._get_debug_instructions(stage_name)

        # Build debug prompt with context
        debug_prompt = f"""Debug {stage_name} stage failure. BE CONCISE.

**Error**: {error_info.get('error_preview', error_info.get('error', 'Unknown error'))}
**Logs**: {run_dir}/{stage_name}/logs/
{validation_context}
**Editable files** (ONLY these):
- {block_inputs_dir}/*.sdc, *.tcl, mem_list.txt, *.rtl.f
- {block_scripts_dir}/block.yaml

## Instructions
1. Read log file to find error
2. If fixable, edit the appropriate file
3. Give brief summary (max 3-4 sentences)

## Edit Requirements
When editing any file, you MUST add a comment ABOVE the edited/added lines with timestamp:
  #Agent_info: Added by SPD agent (<brief description of fix>) [YYYY-MM-DD HH:MM:SS]
Example:
  #Agent_info: Added by SPD agent (increased clock uncertainty to fix setup violation) [2026-03-25 14:30:00]
  set_clock_uncertainty 0.2 [get_clocks clk]
Use the current date and time when adding the comment.
{debug_instructions}
## Response Format (STRICT - follow exactly)
**Issue**: [One sentence describing the problem]
**Fix**: [One sentence describing fix applied, or "Manual review needed"]
**File**: [Path to modified file, or "None"]
"""

        try:
            # Try Claude Agent SDK with streaming tool access first
            if self.use_agent_sdk:
                try:
                    self._emit_log(f"[DEBUG] Starting intelligent debugging with SPD Agent...")

                    reasoning = ""  # Claude's reasoning
                    tool_calls = []
                    files_modified = []  # Track files that were edited/written

                    aborted_during_sdk = False
                    async for message in query(
                        prompt=debug_prompt,
                        options=ClaudeAgentOptions(
                            model=self.model,
                            allowed_tools=["Read", "Bash", "Grep", "Glob", "Write", "Edit"],
                            permission_mode="acceptEdits",  # Allow Claude to auto-apply fixes
                            cwd=str(block_dir),  # Set working directory to block dir
                        )
                    ):
                        # Check for abort on each message
                        if self._check_abort():
                            self._emit_log("[DEBUG] Abort requested during SDK analysis, stopping...")
                            aborted_during_sdk = True
                            break

                        # Emit Claude's reasoning in real-time
                        if AssistantMessage and isinstance(message, AssistantMessage):
                            for block in message.content:
                                if hasattr(block, "text"):
                                    reasoning += block.text
                                    self._emit_log(f"[DEBUG] {block.text}")
                                    # Send Claude's analysis to UI in real-time
                                    self._emit_ui_log(
                                        block.text,
                                        payload={
                                            "stage": stage_name,
                                            "type": "analysis",
                                            "format": "markdown",
                                            "streaming": True,
                                            "content_type": "debug_analysis",
                                        }
                                    )
                                elif hasattr(block, "name"):
                                    tool_name = block.name
                                    tool_input = getattr(block, "input", {}) or {}
                                    tool_calls.append(tool_name)

                                    # Track file modifications for retry decision
                                    if tool_name in ("Write", "Edit"):
                                        file_path = tool_input.get("file_path", "")
                                        if file_path:
                                            files_modified.append(file_path)
                                            self._emit_ui_log(
                                                f"Applying fix to {file_path}",
                                                level="INFO",
                                                payload={"stage": stage_name, "tool": tool_name, "file": file_path, "type": "fix_applied"}
                                            )

                                    # Format tool call for human-readable display
                                    tool_detail = self._format_tool_call(tool_name, tool_input)

                                    self._emit_log(f"[DEBUG] {tool_detail}")
                                    self._emit_ui_log(
                                        tool_detail,
                                        payload={"stage": stage_name, "tool": tool_name, "input": tool_input}
                                    )

                        # Track completion and token usage
                        elif ResultMessage and isinstance(message, ResultMessage):
                            self._emit_log(f"[DEBUG] SPD Agent debugging complete ({message.subtype})")

                            # Track token usage from ResultMessage (usage is a dict in Python SDK)
                            usage = getattr(message, "usage", None) or {}

                            if isinstance(usage, dict):
                                # Extract cache tokens
                                cache_read = usage.get("cache_read_input_tokens", 0)
                                cache_creation = usage.get("cache_creation_input_tokens", 0)
                                base_input = usage.get("input_tokens", 0)
                                # Calculate total input tokens (including cache tokens)
                                input_tokens = base_input + cache_creation + cache_read
                                output_tokens = usage.get("output_tokens", 0)
                            else:
                                input_tokens = getattr(usage, "input_tokens", 0)
                                output_tokens = getattr(usage, "output_tokens", 0)
                                cache_read = 0
                                cache_creation = 0

                            # Get cost and turns
                            total_cost = getattr(message, "total_cost_usd", None) or 0.0
                            num_turns = getattr(message, "num_turns", None) or 0

                            # Always record if we have any data (tokens, cost, or turns)
                            if input_tokens or output_tokens or total_cost or num_turns:
                                token_tracker.record_manual(
                                    input_tokens=input_tokens,
                                    output_tokens=output_tokens,
                                    source=f"debug_agent.sdk.{stage_name}",
                                    model=getattr(message, "model", "claude-agent-sdk"),
                                    cost_usd=total_cost,
                                    num_turns=num_turns,
                                    cache_read_tokens=cache_read,
                                    cache_creation_tokens=cache_creation,
                                )

                    # Handle abort during SDK analysis
                    if aborted_during_sdk:
                        return {
                            "analysis": reasoning if reasoning else "Aborted during analysis",
                            "fixable": False,
                            "fixes_applied": False,
                            "files_modified": files_modified,
                            "approach": "agent_sdk_aborted",
                            "tools_used": tool_calls,
                            "aborted": True,
                        }

                    if reasoning:
                        # Determine if fixes were applied
                        fixes_applied = len(files_modified) > 0

                        # Send complete analysis summary to UI
                        self._emit_ui_log(
                            reasoning,
                            payload={
                                "stage": stage_name,
                                "type": "analysis_complete",
                                "format": "markdown",
                                "content_type": "debug_summary",
                                "tools_used": tool_calls,
                                "files_modified": files_modified,
                                "fixes_applied": fixes_applied,
                            }
                        )

                        if fixes_applied:
                            self._emit_ui_log(
                                f"Fixed {len(files_modified)} file(s): {', '.join(Path(f).name for f in files_modified)}",
                                level="INFO",
                                payload={"stage": stage_name, "type": "fixes_summary", "files": files_modified}
                            )

                        return {
                            "analysis": reasoning,
                            "fixable": "fix" in reasoning.lower() or "update" in reasoning.lower() or len(tool_calls) > 0,
                            "fixes_applied": fixes_applied,
                            "files_modified": files_modified,
                            "approach": "agent_sdk",
                            "tools_used": tool_calls,
                        }
                    else:
                        raise ValueError("No response from Agent SDK streaming")

                except Exception as sdk_error:
                    self._emit_log(f"[DEBUG] SPD Agent debugging failed: {sdk_error}, using direct API...")
                    self._emit_ui_log(f"Switching to fallback analysis...", level="WARN", payload={"stage": stage_name})

            # Fallback to direct API for debugging
            try:
                self._emit_log(f"[DEBUG] Using direct API for debugging analysis...")
                response = Anthropic().messages.create(
                    model=self.model,
                    max_tokens=500,  # Keep response concise
                    messages=[{"role": "user", "content": debug_prompt}],
                )
                token_tracker.record(response, source="debug_agent.debug_with_sdk_fallback")

                analysis = response.content[0].text
                self._emit_log(f"[DEBUG] Analysis complete")
                # Send analysis to UI
                self._emit_ui_log(
                    analysis,
                    payload={
                        "stage": stage_name,
                        "type": "analysis_complete",
                        "format": "markdown",
                        "content_type": "debug_summary",
                        "approach": "direct_api",
                    }
                )
                return {
                    "analysis": analysis,
                    "fixable": "fix" in analysis.lower() or "update" in analysis.lower(),
                    "approach": "direct_api",
                    "tools_used": [],
                }

            except Exception as api_error:
                self._emit_log(f"[DEBUG] Direct API debugging also failed: {api_error}")
                return None

        except Exception as e:
            self._emit_log(f"[DEBUG] Debug analysis completely failed: {e}")
            self._emit_ui_log(f"Analysis failed", level="ERROR", payload={"stage": stage_name, "error": str(e)})
            return None

    async def debug_stage(
        self,
        stage_name: str,
        error_info: Dict[str, Any],
        mode: str = "interactive",
        log_callback: Optional[Any] = None,
        abort_checker: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Main entry point: Debug a failed stage

        Args:
            stage_name: Name of the failed stage
            error_info: Error information from StageExecutor
            mode: Debug mode ("auto", "interactive", "human-loop")
            log_callback: Optional callback for emitting logs to Redis
            abort_checker: Optional callback to check if abort requested (returns {"abort_requested": bool})

        Returns:
            Dictionary with:
            - action: "retry", "abort", "human_intervention"
            - attempt: DebugAttempt record
            - fix_result: FixResult if fix was applied
        """
        # Use per-call callbacks if provided
        if log_callback:
            self.log_callback = log_callback
        if abort_checker:
            self.abort_checker = abort_checker

        self._emit_log(f"[DEBUG] Analyzing failure in {stage_name}...")
        self._emit_ui_log(f"Analyzing {stage_name} failure...", payload={"stage": stage_name})

        # Initialize debug history for this stage
        if stage_name not in self.debug_history:
            self.debug_history[stage_name] = []

        attempt_number = len(self.debug_history[stage_name]) + 1

        # Check retry limit
        if attempt_number > self.max_retry_attempts:
            self._emit_log(f"[DEBUG] Max retry attempts ({self.max_retry_attempts}) reached")
            self._emit_ui_log(f"Max retries reached ({self.max_retry_attempts})", level="ERROR", payload={"stage": stage_name})
            return {
                "action": "abort",
                "reason": f"Max retries exceeded ({self.max_retry_attempts})",
            }

        try:
            # Step 1: Create error context
            error_context = self._create_error_context(stage_name, error_info)

            # Step 1b: KB-first auto-fix replay for known, high-confidence fixes
            if mode == "auto":
                kb_fix = self._extract_kb_fix_suggestion(error_context)
                if kb_fix is not None:
                    self._emit_log(f"[DEBUG] KB-first auto-fix candidate found: {kb_fix.title}")
                    self._emit_ui_log(
                        f"Applying known KB fix first: {kb_fix.title}",
                        payload={"stage": stage_name, "source": "issue_kb"},
                    )
                    kb_result = await self._apply_fix(kb_fix)
                    kb_analysis = ErrorAnalysis(
                        category="kb_reuse",
                        root_cause="Reusing historical issue KB fix before full analysis",
                        confidence=0.95,
                        fixable=True,
                        suggested_investigation=["Verify KB-derived fix result", "Continue normal debug if replay fails"],
                    )
                    debug_attempt = DebugAttempt(
                        attempt_number=attempt_number,
                        stage_name=stage_name,
                        error_category=kb_analysis.category,
                        error_analysis=kb_analysis,
                        fix_applied=kb_fix,
                        fix_result=kb_result,
                        outcome="success" if kb_result.status == "applied" else "failed",
                    )
                    self.debug_history[stage_name].append(debug_attempt)
                    await self._record_debug_attempt(stage_name, debug_attempt)

                    if kb_result.status == "applied":
                        return {
                            "action": "retry",
                            "source": "issue_kb_auto_fix",
                            "fix": asdict(kb_fix),
                            "result": asdict(kb_result),
                            "analysis": asdict(kb_analysis),
                        }

                    self._emit_ui_log(
                        "KB-first fix failed, continuing full debug flow",
                        level="WARN",
                        payload={"stage": stage_name, "error": kb_result.error_message},
                    )

            # Check for abort after context creation
            if self._check_abort():
                return {"action": "abort", "reason": "Abort requested by user"}

            # Step 2: Try intelligent debugging with Claude Agent SDK first
            if self.use_agent_sdk:
                self._emit_log(f"[DEBUG] Using SPD Agent with tool access...")
                self._emit_ui_log(f"Starting intelligent analysis...", payload={"stage": stage_name})
                run_dir = self.config_manager.get_run_dir()
                sdk_result = await self._debug_with_claude_agent_sdk(
                    stage_name, error_info, run_dir
                )
                if sdk_result:
                    # Check if SDK analysis was aborted
                    if sdk_result.get("aborted"):
                        self._emit_log(f"[DEBUG] SPD Agent analysis aborted by user")
                        self._emit_ui_log("Debug analysis aborted", level="WARN", payload={"stage": stage_name})
                        return {"action": "abort", "reason": "Abort requested during SDK analysis"}

                    self._emit_log(f"[DEBUG] SPD Agent analysis complete")
                    self._emit_ui_log(f"Analysis complete", payload={"stage": stage_name, "approach": sdk_result.get("approach")})

                    # If Claude Agent SDK already applied fixes, return retry immediately
                    if sdk_result.get("fixes_applied"):
                        files_modified = sdk_result.get("files_modified", [])
                        self._emit_log(f"[DEBUG] Fixes applied by SPD Agent: {files_modified}")
                        self._emit_ui_log(
                            f"Fixes applied, retrying stage...",
                            level="INFO",
                            payload={
                                "stage": stage_name,
                                "action": "retry",
                                "files_modified": files_modified,
                            }
                        )
                        return {
                            "action": "retry",
                            "source": "agent_sdk_fix",
                            "analysis": sdk_result.get("analysis"),
                            "files_modified": files_modified,
                            "tools_used": sdk_result.get("tools_used", []),
                        }

                    # Use SDK result for further processing if no fixes applied
                    error_context["sdk_analysis"] = sdk_result["analysis"]
                    error_context["fixable"] = sdk_result["fixable"]

            # Check for abort after SDK analysis
            if self._check_abort():
                return {"action": "abort", "reason": "Abort requested by user"}

            # Step 3: Analyze error using direct API (for fallback or supplementary analysis)
            self._emit_log(f"[DEBUG] Analyzing error...")
            analysis = await self._analyze_error(error_context)
            self._emit_log(f"  Category: {analysis.category} (confidence: {analysis.confidence:.0%})")
            self._emit_ui_log(
                f"Found: {analysis.category.replace('_', ' ').title()} ({analysis.confidence:.0%} confidence)",
                payload={"stage": stage_name, "category": analysis.category, "confidence": analysis.confidence},
            )

            # Check for abort after error analysis
            if self._check_abort():
                return {"action": "abort", "reason": "Abort requested by user"}

            # Step 4: Generate fix suggestions
            if analysis.fixable:
                self._emit_log(f"[DEBUG] Generating fix suggestions...")
                self._emit_ui_log(f"Generating fix suggestions...", payload={"stage": stage_name})
                fix_suggestions = await self._generate_fix_suggestions(
                    error_context, analysis
                )
                if fix_suggestions:
                    self._emit_ui_log(f"Found {len(fix_suggestions)} potential fix(es)", payload={"stage": stage_name, "fixes_count": len(fix_suggestions)})
            else:
                self._emit_log(f"[DEBUG] Error marked as non-fixable by analysis")
                self._emit_ui_log(f"Error requires manual intervention", level="WARN", payload={"stage": stage_name})
                fix_suggestions = []

            # Check for abort after fix generation
            if self._check_abort():
                return {"action": "abort", "reason": "Abort requested by user"}

            # Step 5: Handle based on mode
            debug_attempt = DebugAttempt(
                attempt_number=attempt_number,
                stage_name=stage_name,
                error_category=analysis.category,
                error_analysis=analysis,
            )

            if mode == "auto":
                result = await self._handle_auto_mode(
                    debug_attempt, fix_suggestions, error_context
                )
            elif mode == "interactive":
                result = await self._handle_interactive_mode(
                    debug_attempt, fix_suggestions, error_context
                )
            elif mode == "human-loop":
                result = await self._handle_human_loop_mode(
                    debug_attempt, fix_suggestions, error_context
                )
            else:
                result = {
                    "action": "abort",
                    "reason": f"Unknown debug mode: {mode}",
                }

            # Step 5: Record attempt
            self.debug_history[stage_name].append(debug_attempt)
            await self._record_debug_attempt(stage_name, debug_attempt)

            # Emit final debug result
            action = result.get('action', 'unknown')
            self._emit_log(f"Debug analysis complete for {stage_name}: {action}")

            # Summarized UI message based on action
            if action == "retry":
                ui_msg = f"Fix applied, retrying {stage_name}"
            elif action == "human_intervention":
                ui_msg = f"Manual review needed for {stage_name}"
            elif action == "abort":
                ui_msg = f"Debug aborted for {stage_name}"
            else:
                ui_msg = f"Debug complete: {action}"

            self._emit_ui_log(
                ui_msg,
                payload={
                    "stage": stage_name,
                    "action": action,
                    "category": analysis.category if analysis else None,
                    "fixes_count": len(fix_suggestions),
                    "attempt": attempt_number,
                },
            )

            return result

        except Exception as e:
            self._emit_log(f"[DEBUG] Debug error: {str(e)}")
            self._emit_ui_log(f"Debug failed: {str(e)}", level="ERROR", payload={"stage": stage_name, "error": str(e)})
            return {
                "action": "abort",
                "reason": f"Debug error: {str(e)}",
            }

    def _create_error_context(
        self, stage_name: str, error_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Create error context from stage executor result"""
        context = {
            "stage_name": stage_name,
            "return_code": error_info.get("return_code"),
            "error_preview": error_info.get("error_preview", ""),
            "log_file": error_info.get("log_file"),
            "issue_kb_context": error_info.get("issue_kb_context") if isinstance(error_info, dict) else None,
            "timestamp": datetime.now().isoformat(),
        }

        # Include validation failures if this is a validation error
        if error_info.get("category") == "validation_failure":
            validation_result = error_info.get("validation_result", {})
            context["validation_issues"] = validation_result.get("issues", [])
            context["validation_metrics"] = validation_result.get("metrics", {})

        # Include stage_result if available
        if error_info.get("stage_result"):
            context["stage_result"] = error_info.get("stage_result")

        return context

    def _extract_kb_fix_suggestion(self, error_context: Dict[str, Any]) -> Optional[FixSuggestion]:
        issue_kb_context = error_context.get("issue_kb_context") or {}
        kb_items = issue_kb_context.get("items") if isinstance(issue_kb_context, dict) else None
        if not isinstance(kb_items, list) or not kb_items:
            return None

        top = kb_items[0]
        retrieval_score = float(top.get("retrieval_score") or 0.0)
        occurrence_count = int(top.get("occurrence_count") or 0)
        if retrieval_score < 1.5 or occurrence_count < 1:
            return None

        metadata = top.get("issue_metadata") if isinstance(top.get("issue_metadata"), dict) else {}
        payload = metadata.get("payload") if isinstance(metadata.get("payload"), dict) else {}
        applied_fix = payload.get("applied_fix") if isinstance(payload.get("applied_fix"), dict) else {}
        modifications_raw = applied_fix.get("modifications") if isinstance(applied_fix.get("modifications"), list) else []

        modifications: List[FileModification] = []
        for mod in modifications_raw:
            if not isinstance(mod, dict):
                continue
            file_path = mod.get("file_path")
            operation = mod.get("operation")
            if not file_path or not operation:
                continue
            try:
                modifications.append(
                    FileModification(
                        file_path=file_path,
                        operation=operation,
                        content=mod.get("content"),
                        line_number=mod.get("line_number"),
                        old_content=mod.get("old_content"),
                        new_content=mod.get("new_content"),
                    )
                )
            except Exception:
                continue

        if not modifications:
            return None

        risk_level = str(applied_fix.get("risk_level") or "low").lower()
        confidence = float(applied_fix.get("confidence") or 0.8)
        if risk_level not in {"low", "medium"}:
            return None
        if confidence < 0.7:
            return None

        return FixSuggestion(
            title=str(applied_fix.get("title") or top.get("title") or "KB replay fix"),
            description=str(applied_fix.get("description") or top.get("resolution") or "KB-derived fix replay"),
            rationale=str(applied_fix.get("rationale") or top.get("debug_steps") or "Historical successful fix"),
            risk_level=risk_level,
            confidence=confidence,
            modifications=modifications,
            estimated_impact=str(applied_fix.get("estimated_impact") or "Reduce repeated debugging time"),
            prerequisites=applied_fix.get("prerequisites") or [],
        )

    async def _analyze_error(self, error_context: Dict[str, Any]) -> ErrorAnalysis:
        """
        Analyze error using Claude AI

        Args:
            error_context: Error information container

        Returns:
            ErrorAnalysis with categorization and root cause
        """
        try:
            # Load log file if available
            log_content = ""
            if error_context.get("log_file"):
                log_content = self._load_log_file(error_context["log_file"])

            # Extract relevant sections
            relevant_sections = self._extract_relevant_log_sections(log_content)

            # Create analysis prompt
            prompt = self._create_analysis_prompt(error_context, relevant_sections)

            # Call Claude
            response = self.client.messages.create(
                model=self.model,
                max_tokens=1000,
                messages=[{"role": "user", "content": prompt}],
            )
            token_tracker.record(response, source="debug_agent.analyze_error")

            # Parse response
            try:
                response_text = response.content[0].text
                analysis_json = json.loads(response_text)

                return ErrorAnalysis(
                    category=analysis_json.get("category", "other"),
                    root_cause=analysis_json.get("root_cause", "Unknown"),
                    confidence=analysis_json.get("confidence", 0.5),
                    fixable=analysis_json.get("fixable", False),
                    suggested_investigation=analysis_json.get(
                        "suggested_investigation", []
                    ),
                    relevant_log_sections=analysis_json.get(
                        "relevant_log_sections", []
                    ),
                )
            except json.JSONDecodeError:
                print(f"⚠ Failed to parse Claude response, using fallback")
                return self._fallback_error_analysis(error_context)

        except Exception as e:
            print(f"⚠ Claude analysis failed: {e}, using fallback")
            return self._fallback_error_analysis(error_context)

    def _create_analysis_prompt(
        self, error_context: Dict[str, Any], log_content: str
    ) -> str:
        """Create Claude prompt for error analysis"""
        issue_kb_context = error_context.get("issue_kb_context") or {}
        kb_items = issue_kb_context.get("items") if isinstance(issue_kb_context, dict) else []
        kb_summary_lines = []
        if isinstance(kb_items, list):
            for item in kb_items[:3]:
                kb_summary_lines.append(
                    f"- canonical_key={item.get('canonical_key')}, title={item.get('title')}, "
                    f"resolution={item.get('resolution')}, stage={item.get('stage')}"
                )
        kb_summary = "\n".join(kb_summary_lines) if kb_summary_lines else "No prior KB matches found"

        return f"""
You are a physical design flow debugging expert. Analyze this stage failure and provide:

1. **Error Category**: Classify from:
   - timing_violation: Setup/hold time violations
   - design_rule_violation: Max transition, capacitance, fanout violations
   - syntax_error: TCL/SDC/YAML syntax errors
   - file_not_found: Missing input files
   - memory_error: Out of memory, license issues
   - convergence_failure: Optimization not converging
   - configuration_error: Wrong tool settings/parameters
   - constraint_conflict: Conflicting timing constraints
   - physical_design_error: Placement, routing issues
   - other: Unknown or unclassified

2. **Root Cause**: What is the fundamental issue?

3. **Fixability**: Can this be fixed by modifying:
   - block.yaml (flow configuration)
   - SDC files (timing constraints)
   - TCL files (user scripts)
   - mem_list.txt (SRAM configuration)

4. **Investigation Steps**: What should an engineer check?

5. **Confidence**: How confident are you? (0-1)

Stage: {error_context.get('stage_name')}
Return Code: {error_context.get('return_code')}
Error Preview: {error_context.get('error_preview')}

Prior Issue KB Matches:
{kb_summary}

Log Content (last 500 lines):
{log_content[:10000]}

Respond ONLY in JSON format (no markdown, no extra text):
{{
    "category": "category_name",
    "root_cause": "brief explanation",
    "confidence": 0.85,
    "fixable": true,
    "suggested_investigation": ["step 1", "step 2"],
    "relevant_log_sections": ["section 1", "section 2"]
}}
"""

    def _fallback_error_analysis(
        self, error_context: Dict[str, Any]
    ) -> ErrorAnalysis:
        """
        Fallback pattern-based error analysis

        Used if Claude API fails
        """
        error_preview = error_context.get("error_preview", "").lower()
        return_code = error_context.get("return_code", -1)

        # Pattern matching for common errors
        if "setup" in error_preview or "hold" in error_preview:
            category = ErrorCategory.TIMING_VIOLATION.value
            fixable = True
        elif "max_transition" in error_preview or "capacitance" in error_preview:
            category = ErrorCategory.DESIGN_RULE_VIOLATION.value
            fixable = True
        elif "syntax" in error_preview or "parse error" in error_preview:
            category = ErrorCategory.SYNTAX_ERROR.value
            fixable = True
        elif "file not found" in error_preview or "no such file" in error_preview:
            category = ErrorCategory.FILE_NOT_FOUND.value
            fixable = True
        elif "memory" in error_preview or "license" in error_preview:
            category = ErrorCategory.MEMORY_ERROR.value
            fixable = False
        else:
            category = ErrorCategory.OTHER.value
            fixable = False

        return ErrorAnalysis(
            category=category,
            root_cause="Detected via pattern matching (Claude unavailable)",
            confidence=0.5,
            fixable=fixable,
            suggested_investigation=[
                "Review error preview above",
                "Check log file for details",
                "Verify configuration files",
            ],
        )

    async def _generate_fix_suggestions(
        self, error_context: Dict[str, Any], analysis: ErrorAnalysis
    ) -> List[FixSuggestion]:
        """
        Generate fix suggestions using Claude AI

        Args:
            error_context: Error information
            analysis: Error analysis result

        Returns:
            List of FixSuggestion objects ordered by confidence
        """
        if not analysis.fixable:
            return []

        try:
            # Load current configuration
            block_config = self._load_block_config()
            available_files = self._list_editable_files()

            # Create fix generation prompt
            prompt = self._create_fix_generation_prompt(
                error_context, analysis, block_config, available_files
            )

            # Call Claude
            response = self.client.messages.create(
                model=self.model,
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}],
            )
            token_tracker.record(response, source="debug_agent.generate_fixes")

            # Parse response
            try:
                response_text = response.content[0].text
                fixes_json = json.loads(response_text)

                fixes = []
                for fix_data in fixes_json.get("fixes", []):
                    modifications = [
                        FileModification(**mod)
                        for mod in fix_data.get("modifications", [])
                    ]

                    fix = FixSuggestion(
                        title=fix_data.get("title", ""),
                        description=fix_data.get("description", ""),
                        rationale=fix_data.get("rationale", ""),
                        risk_level=fix_data.get("risk_level", "medium"),
                        confidence=fix_data.get("confidence", 0.5),
                        modifications=modifications,
                        estimated_impact=fix_data.get("estimated_impact", ""),
                        prerequisites=fix_data.get("prerequisites", []),
                    )
                    fixes.append(fix)

                # Sort by confidence
                fixes.sort(key=lambda x: x.confidence, reverse=True)
                return fixes

            except json.JSONDecodeError:
                print(f"⚠ Failed to parse fixes response")
                return []

        except Exception as e:
            print(f"⚠ Fix generation failed: {e}")
            return []

    def _create_fix_generation_prompt(
        self,
        error_context: Dict[str, Any],
        analysis: ErrorAnalysis,
        block_config: Dict[str, Any],
        available_files: Dict[str, str],
    ) -> str:
        """Create Claude prompt for fix generation"""
        issue_kb_context = error_context.get("issue_kb_context") or {}
        kb_items = issue_kb_context.get("items") if isinstance(issue_kb_context, dict) else []
        kb_fix_lines = []
        if isinstance(kb_items, list):
            for item in kb_items[:3]:
                kb_fix_lines.append(
                    f"- title={item.get('title')}, resolution={item.get('resolution')}, "
                    f"debug_steps={item.get('debug_steps')}"
                )
        kb_fix_context = "\n".join(kb_fix_lines) if kb_fix_lines else "No historical fixes found"

        return f"""
You are a physical design flow expert. Generate 1-3 specific fixes for this error.

For each fix:
1. **Title**: Brief fix name
2. **Description**: What the fix does
3. **Rationale**: Why this should fix the issue
4. **Risk Level**: "low", "medium", or "high"
5. **Confidence**: Probability this fixes the issue (0-1)
6. **Estimated Impact**: Expected outcome
7. **Prerequisites**: Any setup needed
8. **Modifications**: Exact file changes (can only modify editable files)

Editable files:
- block_scripts/block.yaml (flow configuration)
- block_inputs/*.sdc (timing constraints)
- block_inputs/*.tcl (user scripts)
- block_inputs/mem_list.txt (SRAM list)

IMPORTANT: When specifying file modifications, include a comment ABOVE edited/added lines with timestamp:
  #Agent_info: Added by SPD agent (<brief description of fix>) [YYYY-MM-DD HH:MM:SS]
Use the current date and time when adding the comment.

Available files to modify:
{json.dumps(available_files, indent=2)}

Current block configuration:
{json.dumps(block_config, indent=2)}

Error Information:
- Stage: {error_context.get('stage_name')}
- Category: {analysis.category}
- Root Cause: {analysis.root_cause}
- Confidence: {analysis.confidence:.0%}

Historical KB Fix Hints:
{kb_fix_context}

Generate fixes in JSON format ONLY:
{{
    "fixes": [
        {{
            "title": "Fix title",
            "description": "What it does",
            "rationale": "Why it works",
            "risk_level": "low|medium|high",
            "confidence": 0.85,
            "estimated_impact": "Expected result",
            "prerequisites": [],
            "modifications": [
                {{
                    "file_path": "path/to/file",
                    "operation": "edit|append|create",
                    "content": "for create/append",
                    "line_number": 10,
                    "old_content": "for edit",
                    "new_content": "for edit"
                }}
            ]
        }}
    ]
}}
"""

    async def _handle_auto_mode(
        self,
        debug_attempt: DebugAttempt,
        fix_suggestions: List[FixSuggestion],
        error_context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Auto debug mode: automatically apply best fix

        Only applies low-risk fixes with high confidence
        """
        if not fix_suggestions:
            print(f"  No fixes available")
            return {"action": "human_intervention", "reason": "No fixes generated"}

        # Find best fix (high confidence + low risk)
        best_fix = None
        for fix in fix_suggestions:
            if fix.confidence >= 0.8 and fix.risk_level == "low":
                best_fix = fix
                break

        if not best_fix:
            best_fix = fix_suggestions[0]

        print(f"  Applying: {best_fix.title}")
        result = await self._apply_fix(best_fix)

        debug_attempt.fix_applied = best_fix
        debug_attempt.fix_result = result
        debug_attempt.outcome = "success" if result.status == "applied" else "failed"

        if result.status == "applied":
            return {
                "action": "retry",
                "fix": asdict(best_fix),
                "result": asdict(result),
                "analysis": asdict(debug_attempt.error_analysis),
            }
        else:
            return {
                "action": "human_intervention",
                "reason": "Fix application failed",
                "error": result.error_message,
                "result": asdict(result),
                "analysis": asdict(debug_attempt.error_analysis),
            }

    async def _handle_interactive_mode(
        self,
        debug_attempt: DebugAttempt,
        fix_suggestions: List[FixSuggestion],
        error_context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Interactive mode: show options for user selection

        In real implementation, would show UI. For now, apply best fix.
        """
        if not fix_suggestions:
            print(f"  No fixes available")
            return {"action": "human_intervention", "reason": "No fixes generated"}

        # In a real implementation, show UI to user
        # For now, apply best fix
        best_fix = fix_suggestions[0]

        print(f"  Applying: {best_fix.title}")
        result = await self._apply_fix(best_fix)

        debug_attempt.fix_applied = best_fix
        debug_attempt.fix_result = result
        debug_attempt.outcome = "success" if result.status == "applied" else "failed"

        if result.status == "applied":
            return {
                "action": "retry",
                "fix": asdict(best_fix),
                "result": asdict(result),
                "analysis": asdict(debug_attempt.error_analysis),
            }
        else:
            return {
                "action": "human_intervention",
                "reason": "Fix application failed",
                "error": result.error_message,
                "result": asdict(result),
                "analysis": asdict(debug_attempt.error_analysis),
            }

    async def _handle_human_loop_mode(
        self,
        debug_attempt: DebugAttempt,
        fix_suggestions: List[FixSuggestion],
        error_context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Human-loop mode: show analysis, wait for engineer

        In real implementation, would wait for engineer input.
        For now, return human_intervention.
        """
        print(f"  Waiting for human intervention...")
        print(f"  Error Category: {debug_attempt.error_analysis.category}")
        print(f"  Root Cause: {debug_attempt.error_analysis.root_cause}")

        if fix_suggestions:
            print(f"  Suggested Fixes:")
            for i, fix in enumerate(fix_suggestions[:3], 1):
                print(f"    {i}. {fix.title} (confidence: {fix.confidence:.0%})")

        return {
            "action": "human_intervention",
            "reason": "Waiting for engineer fix",
            "analysis": asdict(debug_attempt.error_analysis),
            "suggestions": [asdict(f) for f in fix_suggestions[:3]],
        }

    async def _apply_fix(self, fix: FixSuggestion) -> FixResult:
        """
        Apply a fix suggestion

        Args:
            fix: FixSuggestion to apply

        Returns:
            FixResult with status and details
        """
        result = FixResult(status="applied")
        backups = {}
        before_contents: Dict[str, Optional[str]] = {}

        try:
            # Step 1: Validate all modifications are safe
            for mod in fix.modifications:
                if not self._is_file_editable(mod.file_path):
                    result.status = "failed"
                    result.error_message = f"File not editable: {mod.file_path}"
                    return result

            # Step 2: Create backups
            for mod in fix.modifications:
                file_path = self._resolve_file_path(mod.file_path)
                before_contents[mod.file_path] = file_path.read_text() if file_path.exists() else None
                if file_path.exists():
                    backup_path = self._create_backup(file_path)
                    backups[mod.file_path] = str(backup_path)
                    result.backups.append(str(backup_path))

            # Step 3: Apply modifications
            for mod in fix.modifications:
                try:
                    self._apply_edit(mod)
                    result.modified_files.append(mod.file_path)
                except Exception as e:
                    result.status = "failed"
                    result.error_message = f"Failed to modify {mod.file_path}: {str(e)}"
                    result.validation_errors.append(str(e))
                    await self._rollback_modifications(backups)
                    return result

            # Step 4: Validate syntax
            for mod in fix.modifications:
                if mod.file_path.endswith(".yaml"):
                    if not self._validate_file_syntax(mod.file_path):
                        result.status = "failed"
                        result.error_message = f"YAML validation failed: {mod.file_path}"
                        result.validation_errors.append(f"YAML syntax error in {mod.file_path}")
                        await self._rollback_modifications(backups)
                        return result

            # Step 5: Capture deterministic edit artifacts
            seen_files = set()
            for mod in fix.modifications:
                if mod.file_path in seen_files:
                    continue
                seen_files.add(mod.file_path)
                resolved = self._resolve_file_path(mod.file_path)
                after_content = resolved.read_text() if resolved.exists() else None
                before_content = before_contents.get(mod.file_path)
                diff_excerpt = self._build_diff_excerpt(before_content, after_content)
                result.file_edits.append(
                    {
                        "file_path": mod.file_path,
                        "change_type": mod.operation,
                        "before_hash": self._content_hash(before_content),
                        "after_hash": self._content_hash(after_content),
                        "diff_excerpt": diff_excerpt,
                        "timestamp": datetime.now().isoformat(),
                    }
                )

            return result

        except Exception as e:
            result.status = "failed"
            result.error_message = str(e)
            await self._rollback_modifications(backups)
            return result

    @staticmethod
    def _content_hash(content: Optional[str]) -> Optional[str]:
        if content is None:
            return None
        return hashlib.sha256(content.encode("utf-8", errors="ignore")).hexdigest()

    @staticmethod
    def _build_diff_excerpt(before: Optional[str], after: Optional[str], max_lines: int = 80) -> Optional[str]:
        before_lines = (before or "").splitlines()
        after_lines = (after or "").splitlines()
        diff_lines = list(
            difflib.unified_diff(
                before_lines,
                after_lines,
                fromfile="before",
                tofile="after",
                lineterm="",
            )
        )
        if not diff_lines:
            return None
        return "\n".join(diff_lines[:max_lines])

    def _is_file_editable(self, file_path: str) -> bool:
        """Check if file is in editable list"""
        file_path = str(file_path).lower()

        # Check editable patterns
        for pattern in self.EDITABLE_PATTERNS:
            pattern_re = pattern.replace("*", ".*")
            if re.match(f".*{pattern_re}.*", file_path, re.IGNORECASE):
                return True

        return False

    def _get_block_dir(self) -> Path:
        """Get the block directory (parent of block_inputs)"""
        block_inputs_dir = self.config_manager.block_inputs_dir
        if block_inputs_dir:
            return block_inputs_dir.parent
        # Fallback: use run_dir
        return self.config_manager.get_run_dir()

    def _resolve_file_path(self, file_path: str) -> Path:
        """Resolve relative file path to absolute"""
        # If absolute, return as-is
        if Path(file_path).is_absolute():
            return Path(file_path)

        # Otherwise, resolve relative to block directory
        return self._get_block_dir() / file_path

    def _create_backup(self, file_path: Path) -> Path:
        """Create timestamped backup of file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = self.backups_dir / f"{file_path.name}.{timestamp}.bak"
        backup_path.parent.mkdir(parents=True, exist_ok=True)

        if file_path.exists():
            backup_path.write_text(file_path.read_text())

        return backup_path

    def _apply_edit(self, modification: FileModification):
        """Apply a single file modification"""
        file_path = self._resolve_file_path(modification.file_path)

        if modification.operation == "create":
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(modification.content or "")

        elif modification.operation == "append":
            file_path.parent.mkdir(parents=True, exist_ok=True)
            if file_path.exists():
                content = file_path.read_text()
                file_path.write_text(content + "\n" + (modification.content or ""))
            else:
                file_path.write_text(modification.content or "")

        elif modification.operation == "edit":
            if not file_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")

            content = file_path.read_text()

            # Find and replace old_content with new_content
            if modification.old_content and modification.new_content:
                if modification.old_content in content:
                    content = content.replace(modification.old_content, modification.new_content)
                    file_path.write_text(content)
                else:
                    raise ValueError(
                        f"Old content not found in {modification.file_path}"
                    )

    def _validate_file_syntax(self, file_path: str) -> bool:
        """Validate file syntax"""
        resolved_path = self._resolve_file_path(file_path)

        if not resolved_path.exists():
            return False

        try:
            if file_path.endswith(".yaml"):
                yaml.safe_load(resolved_path.read_text())
                return True

            elif file_path.endswith(".tcl"):
                # Basic TCL validation: check balanced braces
                content = resolved_path.read_text()
                open_braces = content.count("{")
                close_braces = content.count("}")
                return open_braces == close_braces

            else:
                # Unknown format, assume valid
                return True

        except Exception as e:
            print(f"⚠ Syntax validation error: {e}")
            return False

    async def _rollback_modifications(self, backups: Dict[str, str]):
        """Rollback modifications from backup"""
        for original_path, backup_path in backups.items():
            try:
                resolved = self._resolve_file_path(original_path)
                backup_content = Path(backup_path).read_text()
                resolved.write_text(backup_content)
                print(f"  Rolled back: {original_path}")
            except Exception as e:
                print(f"  ⚠ Rollback failed for {original_path}: {e}")

    def _load_log_file(self, log_file: str) -> str:
        """Load log file content, limit size"""
        try:
            path = Path(log_file)
            if not path.exists():
                return ""

            # Read last 500 lines to limit size
            content = path.read_text()
            lines = content.split("\n")
            relevant_lines = lines[-500:]
            return "\n".join(relevant_lines)

        except Exception as e:
            print(f"⚠ Failed to load log: {e}")
            return ""

    def _extract_relevant_log_sections(self, log_content: str) -> str:
        """Extract relevant sections from log"""
        if not log_content:
            return ""

        # Limit to 10KB for Claude prompt
        if len(log_content) > 10000:
            return log_content[-10000:]

        return log_content

    def _load_block_config(self) -> Dict[str, Any]:
        """Load block.yaml configuration"""
        try:
            config_path = self._get_block_dir() / "block_scripts/block.yaml"
            if config_path.exists():
                with open(config_path) as f:
                    return yaml.safe_load(f) or {}
        except Exception as e:
            print(f"⚠ Failed to load block config: {e}")

        return {}

    def _list_editable_files(self) -> Dict[str, str]:
        """List available editable files"""
        files = {}

        block_dir = self._get_block_dir()
        block_scripts_dir = block_dir / "block_scripts"

        # List YAML files
        if block_scripts_dir.exists():
            for yaml_file in block_scripts_dir.glob("*.yaml"):
                files[f"block_scripts/{yaml_file.name}"] = str(yaml_file)

        # List SDC files
        inputs_dir = block_dir / "block_inputs"
        if inputs_dir.exists():
            for sdc_file in inputs_dir.glob("*.sdc"):
                files[f"block_inputs/{sdc_file.name}"] = str(sdc_file)

            for tcl_file in inputs_dir.glob("*.tcl"):
                files[f"block_inputs/{tcl_file.name}"] = str(tcl_file)

            # mem_list.txt
            mem_list = inputs_dir / "mem_list.txt"
            if mem_list.exists():
                files["block_inputs/mem_list.txt"] = str(mem_list)

            # <design>.rtl.f (RTL filelist)
            for rtl_file in inputs_dir.glob("*.rtl.f"):
                files[f"block_inputs/{rtl_file.name}"] = str(rtl_file)

        return files

    async def _record_debug_attempt(
        self, stage_name: str, attempt: DebugAttempt
    ):
        """Record debug attempt in StateTracker"""
        try:
            await self.state_tracker.record_debug_attempt(
                stage_name=stage_name,
                attempt_number=attempt.attempt_number,
                error_category=attempt.error_category,
                fix_applied=attempt.fix_applied is not None,
                outcome=attempt.outcome,
            )
        except Exception as e:
            print(f"⚠ Failed to record debug attempt: {e}")
