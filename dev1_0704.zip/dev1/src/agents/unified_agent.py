#!/usr/bin/env python3
"""
Unified Physical Design Agent
Single agent with multiple contexts using Claude Agent SDK

Supports:
- 8 execution contexts (EXECUTE_*, DEBUG_*, ANALYZE_*)
- Skill-based system (loaded from .md files)
- Token-optimized skill loading (cached)
- Iterative tool execution with error recovery

Architecture:
- Working directory structure: Pre-created by external setup scripts
- YAML configuration: Loaded by TCL scripts (yaml_config_reader.tcl)
- Python role: Orchestration, tool execution, error analysis
- TCL role: YAML parsing, environment setup, tool invocation
"""

import asyncio
import io
import sys
from pathlib import Path
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

# Configure UTF-8 encoding for stdout
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

try:
    from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, ResultMessage
except ImportError:
    raise ImportError("Claude Agent SDK not installed. Install with: pip install claude-agent-sdk")

from src.config.runtime_config import get_claude_model


class AgentContext(Enum):
    """Agent execution contexts - determines behavior and skills"""
    # Execution contexts
    EXECUTE_SYNTHESIS = "execute_synthesis"
    EXECUTE_PNR = "execute_pnr"
    EXECUTE_STA = "execute_sta"

    # Debug contexts
    DEBUG_TIMING = "debug_timing"
    DEBUG_LINKING = "debug_linking"
    DEBUG_CONVERGENCE = "debug_convergence"
    DEBUG_DRV = "debug_drv"

    # Analysis context
    ANALYZE_ERROR = "analyze_error"


@dataclass
class AgentConfig:
    """Configuration for agent execution"""
    context: AgentContext
    project_path: str
    stage_name: str
    max_iterations: int = 5
    allowed_files: Optional[List[str]] = None
    error_info: Optional[Dict[str, Any]] = None


@dataclass
class AgentResult:
    """Result from agent execution"""
    status: str  # "success", "failed", "partial"
    iterations: int
    actions: List[Dict[str, Any]] = field(default_factory=list)
    final_output: Optional[str] = None
    files_modified: List[str] = field(default_factory=list)
    error_message: Optional[str] = None
    reasoning: Optional[str] = None


class SkillLoader:
    """Load and cache skills from markdown files"""

    def __init__(self, skills_dir: Optional[Path] = None):
        self.skills_dir = skills_dir or Path(__file__).parent.parent.parent / "skills"
        self.cache: Dict[AgentContext, str] = {}

    def get_cached_skills(self, context: AgentContext) -> str:
        """Get skills from cache or load them"""
        if context in self.cache:
            return self.cache[context]

        skills_content = self._load_skills_for_context(context)
        self.cache[context] = skills_content
        return skills_content

    def _load_skills_for_context(self, context: AgentContext) -> str:
        """Load only applicable skills for this context"""

        # Map contexts to skill files
        skill_files_map = {
            AgentContext.EXECUTE_SYNTHESIS: ["synthesis_skills.md"],
            AgentContext.EXECUTE_PNR: ["pnr_skills.md", "knowledge_skills.md"],
            AgentContext.EXECUTE_STA: ["knowledge_skills.md"],
            AgentContext.DEBUG_TIMING: ["debug_skills.md", "pnr_skills.md"],
            AgentContext.DEBUG_LINKING: ["debug_skills.md"],
            AgentContext.DEBUG_CONVERGENCE: ["debug_skills.md", "synthesis_skills.md"],
            AgentContext.DEBUG_DRV: ["debug_skills.md"],
            AgentContext.ANALYZE_ERROR: ["debug_skills.md", "knowledge_skills.md"],
        }

        files = skill_files_map.get(context, [])
        skills_content = ""

        for skill_file in files:
            skill_path = self.skills_dir / skill_file
            if skill_path.exists():
                try:
                    with open(skill_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    skills_content += f"\n{content}\n"
                except Exception as e:
                    print(f"[WARN] Failed to load skill file {skill_file}: {e}")

        return skills_content

    def clear_cache(self):
        """Clear skill cache"""
        self.cache.clear()


class UnifiedPhysicalDesignAgent:
    """Single unified agent with multiple contexts"""

    def __init__(self):
        self.allowed_tools = ["Read", "Edit", "Glob", "Bash"]
        self.skill_loader = SkillLoader()
        self.execution_history: List[Dict[str, Any]] = []

    async def execute(self, config: AgentConfig) -> AgentResult:
        """Execute agent with given configuration"""

        try:
            # Build prompts
            system_prompt = self._build_system_prompt(config)
            user_prompt = self._build_user_prompt(config)

            # Execute with Claude Agent SDK
            result = await self._run_claude_agent_sdk(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                config=config
            )

            # Record execution
            self.execution_history.append({
                "context": config.context.value,
                "stage": config.stage_name,
                "status": result.status,
                "iterations": result.iterations,
            })

            return result

        except Exception as e:
            return AgentResult(
                status="failed",
                iterations=0,
                error_message=str(e),
                reasoning="Exception during execution"
            )

    def _build_system_prompt(self, config: AgentConfig) -> str:
        """Build context-specific system prompt with skills"""

        base_prompt = f"""You are a hardware design automation expert.

Project: {config.project_path}
Stage: {config.stage_name}
Context: {config.context.value}

Available Tools (ONLY these 4):
1. Read   - Read file contents
2. Edit   - Modify file contents
3. Glob   - Find files by pattern
4. Bash   - Execute bash commands

Do NOT use any other tools or make assumptions about tools that don't exist."""

        # Load and add applicable skills
        skills = self.skill_loader.get_cached_skills(config.context)
        if skills:
            base_prompt += f"""

SPECIALIZED SKILLS:
==================
{skills}"""

        # Add context-specific instructions
        context_instructions = self._get_context_instructions(config)
        base_prompt += f"""

EXECUTION CONTEXT:
==================
{context_instructions}"""

        # Add file restrictions
        if config.allowed_files:
            base_prompt += f"""

ALLOWED FILE MODIFICATIONS:
===========================
You can ONLY modify these files/patterns:
{chr(10).join(f'- {f}' for f in config.allowed_files)}

Do NOT modify any other files."""

        return base_prompt

    def _build_user_prompt(self, config: AgentConfig) -> str:
        """Build context-specific user prompt"""

        context_prompts = {
            AgentContext.EXECUTE_SYNTHESIS: self._prompt_execute_synthesis,
            AgentContext.EXECUTE_PNR: self._prompt_execute_pnr,
            AgentContext.EXECUTE_STA: self._prompt_execute_sta,
            AgentContext.DEBUG_TIMING: self._prompt_debug_timing,
            AgentContext.DEBUG_LINKING: self._prompt_debug_linking,
            AgentContext.DEBUG_CONVERGENCE: self._prompt_debug_convergence,
            AgentContext.DEBUG_DRV: self._prompt_debug_drv,
            AgentContext.ANALYZE_ERROR: self._prompt_analyze_error,
        }

        prompt_func = context_prompts.get(config.context)
        if prompt_func:
            return prompt_func(config)

        return f"Execute {config.stage_name} stage with best practices."

    def _get_context_instructions(self, config: AgentConfig) -> str:
        """Get detailed instructions for this context"""

        instructions = {
            AgentContext.EXECUTE_SYNTHESIS: """GOAL: Run synthesis and produce clean results
WORKFLOW:
1. Run synthesis with proper logging
2. ALWAYS analyze the log file after execution
3. Check for: errors, warnings, linking issues, timing violations
4. If issues found: Fix ONE issue at a time, then retry
5. Continue until: clean synthesis OR max iterations reached
6. Report each iteration's findings""",

            AgentContext.EXECUTE_PNR: """GOAL: Run place and route and close timing
WORKFLOW:
1. Run PNR tool with proper settings
2. Analyze timing and congestion reports
3. If violations found: Apply placement or routing fixes
4. Continue until: timing met OR max iterations reached""",

            AgentContext.EXECUTE_STA: """GOAL: Run static timing analysis
WORKFLOW:
1. Run STA tool
2. Analyze timing report
3. Report timing margins and critical paths""",

            AgentContext.DEBUG_TIMING: """GOAL: Fix timing violations
WORKFLOW:
1. Analyze timing reports to identify violations
2. Understand constraint and clock issues
3. Apply fixes using constraint modifications or tool settings
4. Re-run synthesis/PNR to verify
5. Continue until: timing met OR max iterations reached""",

            AgentContext.DEBUG_LINKING: """GOAL: Fix linking errors
WORKFLOW:
1. Identify missing modules or files from error message
2. Check design.filelist for missing entries
3. Update filelist or SDC includes
4. Re-run synthesis
5. Continue until: no linking errors OR max iterations reached""",

            AgentContext.DEBUG_CONVERGENCE: """GOAL: Fix convergence issues
WORKFLOW:
1. Analyze optimization logs
2. Identify convergence problems
3. Adjust tool settings or synthesis strategy
4. Re-run synthesis
5. Continue until: convergence achieved OR max iterations reached""",

            AgentContext.DEBUG_DRV: """GOAL: Fix design rule violations
WORKFLOW:
1. Read DRV reports (max_transition, fanout, capacitance)
2. Identify violations
3. Apply constraint modifications
4. Re-run synthesis
5. Continue until: all DRVs resolved OR max iterations reached""",

            AgentContext.ANALYZE_ERROR: """GOAL: Analyze error and suggest fixes (NO modifications)
WORKFLOW:
1. Read error message and context
2. Analyze root cause
3. Determine if fixable
4. Suggest fixes (but DO NOT apply them)
5. Report findings in structured format""",
        }

        return instructions.get(config.context.value, "Execute task with best practices")

    def _prompt_execute_synthesis(self, config: AgentConfig) -> str:
        return f"""Execute synthesis for {config.stage_name}:

PREREQUISITES (already created by external setup):
- Working directory: work/
- Logs directory: logs/
- Reports directory: reports/
- All YAML files loaded by TCL scripts

ITERATION PATTERN (max {config.max_iterations} iterations):
1. RUN SYNTHESIS
   - Command: cd work && dc_shell -f ../scripts/dc_syn.tcl 2>&1 | tee ../logs/synthesis.log
   - TCL script handles all YAML loading via yaml_config_reader.tcl

2. CHECK RESULTS
   - Use Read to read logs/synthesis.log
   - Analyze for ALL errors and warnings
   - Use Glob to find reports (check_timing.rpt, check_design.rpt)
   - Read and analyze reports carefully

3. DECIDE NEXT STEP
   - If NO errors: Report SUCCESS
   - If errors found: Identify issue, apply fix, go to step 4

4. APPLY FIX
   - Use Edit to modify ONE file only:
     * block_scripts/block.yaml
     * block_inputs/*.sdc files
     * scripts/dc_syn.tcl
   - Make ONE logical change per iteration
   - Document what you changed and why

5. RETRY
   - Go back to step 1

IMPORTANT:
- Always read the full log file after synthesis
- Check BOTH log file AND reports
- Never assume success - always verify
- Each iteration should make progress toward clean synthesis
- Stop at max {config.max_iterations} iterations even if not fully clean
- Report final status and any remaining issues"""

    def _prompt_execute_pnr(self, config: AgentConfig) -> str:
        return f"""Execute place and route for {config.stage_name}:

WORKFLOW:
1. Run PNR tool
2. Analyze timing and congestion
3. Apply fixes if needed
4. Iterate until timing met or max {config.max_iterations} iterations

Report: timing margins, critical paths, any violations"""

    def _prompt_execute_sta(self, config: AgentConfig) -> str:
        return f"""Run static timing analysis for {config.stage_name}:

WORKFLOW:
1. Execute STA tool
2. Read and analyze timing report
3. Report timing margins and critical paths"""

    def _prompt_debug_timing(self, config: AgentConfig) -> str:
        error_info = config.error_info or {}
        return f"""Fix timing violation for {config.stage_name}:

ERROR DETAILS:
{error_info.get('error_preview', 'Timing violation detected')}

WORKFLOW (max {config.max_iterations} iterations):
1. ANALYZE
   - Read reports/check_timing.rpt
   - Understand the violation (setup/hold/max_delay)
   - Identify critical path

2. SUGGEST FIX
   - Using timing constraint skill
   - Recommend SDC changes or tool settings

3. APPLY FIX
   - Edit ONLY *.sdc files or dc_syn.tcl
   - Add/modify constraints with proper syntax
   - Document changes

4. VERIFY
   - Re-run synthesis with updated constraints
   - Check timing report again

5. ITERATE
   - If still failing: refine fix, go to step 2
   - If fixed: report success

IMPORTANT:
- Use proper SDC syntax
- Conservative margins (10-15%)
- One constraint change per iteration
- Max {config.max_iterations} iterations"""

    def _prompt_debug_linking(self, config: AgentConfig) -> str:
        error_info = config.error_info or {}
        return f"""Fix linking error for {config.stage_name}:

ERROR: {error_info.get('error_preview', 'Linking error')}

WORKFLOW:
1. Identify missing module/file from error message
2. Check design.filelist for missing entries
3. Update design.filelist or SDC includes
4. Re-run synthesis to verify
5. Report changes made"""

    def _prompt_debug_convergence(self, config: AgentConfig) -> str:
        return f"""Fix convergence issue for {config.stage_name}:

WORKFLOW (max {config.max_iterations} iterations):
1. Analyze optimization logs for convergence issues
2. Identify stuck/looping optimization
3. Modify dc_syn.tcl to change strategy:
   - Reduce effort level
   - Change optimization approach
   - Adjust compiler settings
4. Re-run synthesis
5. Iterate if needed (max {config.max_iterations} times)
6. Report optimization strategy changes"""

    def _prompt_debug_drv(self, config: AgentConfig) -> str:
        return f"""Fix design rule violations for {config.stage_name}:

WORKFLOW:
1. Read DRV report from reports/
2. Identify violation types (max_transition, fanout, capacitance)
3. Modify *.sdc or dc_syn.tcl to address violations
4. Re-run synthesis
5. Verify violations resolved"""

    def _prompt_analyze_error(self, config: AgentConfig) -> str:
        error_info = config.error_info or {}
        return f"""Analyze error and suggest fixes (DO NOT APPLY):

ERROR: {error_info.get('error_preview', 'Error detected')}

WORKFLOW:
1. Read error message and all context
2. Determine root cause
3. Classify: design vs flow vs tool issue
4. Assess fixability
5. Suggest fixes (but do NOT apply them)
6. Report findings in structured format

OUTPUT FORMAT:
- Root Cause: [explain]
- Classification: [design/flow/tool/unknown]
- Fixable: [yes/no/maybe]
- Suggested Fixes: [list 1-3 fixes]
- Risk Level: [low/medium/high]"""

    async def _run_claude_agent_sdk(
        self,
        system_prompt: str,
        user_prompt: str,
        config: AgentConfig
    ) -> AgentResult:
        """Execute using Claude Agent SDK"""

        result = AgentResult(
            status="failed",
            iterations=0,
            actions=[],
            reasoning=""
        )

        try:
            print(f"\n[AGENT] Starting {config.context.value} for {config.stage_name}")
            print(f"[AGENT] Max iterations: {config.max_iterations}")
            print(f"[AGENT] Allowed files: {config.allowed_files}")
            print("=" * 70)

            # Execute with Claude Agent SDK
            async for message in query(
                prompt=user_prompt,
                options=ClaudeAgentOptions(
                    model=get_claude_model(),
                    system_prompt=system_prompt,
                    allowed_tools=self.allowed_tools,
                    permission_mode="acceptEdits"
                )
            ):
                # Process AssistantMessage (reasoning and tool calls)
                if isinstance(message, AssistantMessage):
                    result.iterations += 1

                    for block in message.content:
                        if hasattr(block, "text"):
                            # Claude's reasoning
                            print(f"\n[THINKING] {block.text[:200]}...")
                            result.reasoning = block.text
                        elif hasattr(block, "name"):
                            # Tool being called
                            print(f"[TOOL] Calling {block.name}")
                            result.actions.append({"tool": block.name})

                # Process ResultMessage (final result)
                elif isinstance(message, ResultMessage):
                    result.status = "success" if message.subtype == "success" else "failed"
                    result.final_output = getattr(message, "text", "")
                    print(f"\n[RESULT] {message.subtype}")
                    break

            print("=" * 70)
            print(f"[AGENT] Completed: {result.status} ({result.iterations} iterations)")

        except Exception as e:
            result.status = "failed"
            result.error_message = str(e)
            print(f"[ERROR] Agent execution failed: {e}")

        return result

    def get_execution_history(self) -> List[Dict[str, Any]]:
        """Get execution history"""
        return self.execution_history

    def clear_history(self):
        """Clear execution history"""
        self.execution_history.clear()
