#!/usr/bin/env python3
"""
PhysicalDesignGraph - LangGraph-based orchestration for multi-user flows

Replaces OrchestratorAgent with LangGraph for:
- Multi-user support (thread isolation)
- Automatic checkpointing (crash recovery)
- Better state management (TypedDict)
- Production-grade orchestration

Reuses:
- DebugAgent (for error analysis and fix generation)
- StageExecutor (for stage execution)
- STAGES definitions
"""

import asyncio
import json
import re
import functools
import sys
import os
import importlib
from datetime import datetime
from typing import TypedDict, Optional, Any, Callable
from pathlib import Path

# Ensure output is not buffered for real-time logging
_print = print
print = functools.partial(_print, flush=True)

try:
    _anthropic_module = importlib.import_module("anthropic")
    Anthropic = _anthropic_module.Anthropic
except Exception:
    Anthropic = None
    print("[WARN] anthropic SDK not installed. PhysicalDesignGraph will use fallback intent parsing.")
from langgraph.graph import StateGraph, END, START

from src.infra.token_tracker import token_tracker
from src.config.runtime_config import get_claude_model

try:
    from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, ResultMessage
    AGENT_SDK_AVAILABLE = True
except ImportError:
    query = None
    ClaudeAgentOptions = None
    AssistantMessage = None
    ResultMessage = None
    AGENT_SDK_AVAILABLE = False
    print("[WARN] SPD Agent SDK not installed. PhysicalDesignGraph will use fallback intent parsing.")

from ..config import ConfigManager
from ..executor import StageExecutor
from ..executor.validation_runner import ValidationRunner
from .debug_agent import DebugAgent


# ============================================================================
# State Model
# ============================================================================

class FlowState(TypedDict, total=False):
    """
    Complete state for physical design flow execution

    Uses TypedDict for type safety and IDE support.
    total=False allows optional fields for easier state updates.
    """

    # Input
    prompt: str
    debug_mode: str  # "auto" | "interactive" | "human-loop" | "none"

    # Parsed intent
    intent: Optional[dict]  # {action, stages, start_from, ...}
    action_type: str  # "execute" | "analyze" | "query" - determines flow path

    # Execution plan
    plan: list[str]  # ["syn", "place", "route", ...]
    current_stage_index: int  # Current position in plan

    # Results
    stages_executed: list[str]
    stages_failed: list[str]
    stages_skipped: list[str]
    stage_results: dict[str, dict]  # {stage_name: {status, return_code, ...}}
    validation_results: dict[str, dict]  # {stage_name: {passed, metrics, issues, summary}}

    # Analysis results (for analyze/query actions)
    analysis_target: Optional[str]  # Stage or report to analyze (e.g., "syn", "place", "timing")
    analysis_type: Optional[str]  # "summarize" | "check" | "report" | "compare" | "status"
    analysis_result: Optional[dict]  # {summary, metrics, issues, recommendations, raw_data}
    analysis_files: Optional[list]  # List of files analyzed

    # Error handling
    error_info: Optional[dict]  # Last error details
    error_retry_count: int  # Per-stage retry counter
    max_retries: int  # Maximum retries per stage

    # Debug
    debug_history: dict[str, list]  # {stage_name: [debug_attempts]}
    debug_result: Optional[dict]  # Last debug action result

    # Metadata
    start_time: str  # ISO timestamp
    end_time: Optional[str]
    run_id: str
    user_id: Optional[str]  # For multi-user tracking
    execution_status: str  # "pending" | "in_progress" | "completed" | "failed"

    # Tracking IDs (from web UI)
    job_id: Optional[str]  # Unique job identifier for tracking
    session_id: Optional[str]  # Web UI session identifier

    # Design identity (for stage progress tracking)
    project: Optional[str]
    block: Optional[str]
    rtl_tag: Optional[str]
    experiment: Optional[str]
    user_name: Optional[str]

    # Optional lifecycle bridge hook
    lifecycle_hook: Optional[Any]
    hitl_resolver: Optional[Callable[[str, dict, dict], Optional[dict]]]
    issue_kb_lookup: Optional[Callable[[dict], Optional[dict]]]

    # Plan confirmation HITL
    require_plan_confirmation: bool
    awaiting_plan_confirmation: bool
    plan_approved: bool
    plan_confirmation_request: Optional[dict]
    plan_confirmation_response: Optional[dict]
    hitl_version: int
    interaction_type: Optional[str]
    decision_status: Optional[str]
    pending_human_context: Optional[str]
    last_applied_human_context: Optional[str]


# ============================================================================
# PhysicalDesignGraph
# ============================================================================

class PhysicalDesignGraph:
    """
    LangGraph-based orchestration engine for physical design flows

    Provides:
    - Multi-user support (thread isolation via thread_id)
    - Automatic checkpointing (crash recovery)
    - Type-safe state (TypedDict)
    - Reusable components (DebugAgent, StageExecutor)
    """

    # Stage definitions (same as OrchestratorAgent)
    STAGES = {
        "syn": {
            "tool": "genus",
            "script": "tool_scripts/genus_syn.tcl",
            "depends_on": [],
            "description": "Synthesis with Genus",
        },
        "init_design": {
            "tool": "innovus",
            "script": "tool_scripts/design_init.tcl",
            "depends_on": ["syn"],
            "description": "PnR Init Design",
        },
        "floorplan": {
            "tool": "innovus",
            "script": "tool_scripts/floorplan.tcl",
            "depends_on": ["init_design"],
            "description": "PnR Floorplan",
        },
        "place": {
            "tool": "innovus",
            "script": "tool_scripts/place.tcl",
            "depends_on": ["floorplan"],
            "description": "PnR Place",
        },
        "cts": {
            "tool": "innovus",
            "script": "tool_scripts/cts.tcl",
            "depends_on": ["place"],
            "description": "PnR CTS",
        },
        "post_cts": {
            "tool": "innovus",
            "script": "tool_scripts/post_cts.tcl",
            "depends_on": ["cts"],
            "description": "PnR Post CTS",
        },
        "route": {
            "tool": "innovus",
            "script": "tool_scripts/route.tcl",
            "depends_on": ["post_cts"],
            "description": "PnR Route",
        },
        "postroute": {
            "tool": "innovus",
            "script": "tool_scripts/post_route.tcl",
            "depends_on": ["route"],
            "description": "PnR Post Route",
        },
        "chip_finish": {
            "tool": "innovus",
            "script": "tool_scripts/chip_finish.tcl",
            "depends_on": ["postroute"],
            "description": "PnR Chip Finish",
        },
        "qrc": {
            "tool": "quantus",
            "script": "tool_scripts/qrc/qrc.cmd",
            "depends_on": ["chip_finish"],
            "description": "RC Extraction",
        },
        "sta": {
            "tool": "tempus",
            "script": "tool_scripts/tempus/tempus.tcl",
            "depends_on": ["chip_finish", "qrc"],
            "description": "Static Timing Analysis",
        },
        "pv": {
            "tool": "calibre",
            "script": "tool_scripts/pv/pv_runset.tcl",
            "depends_on": ["chip_finish"],
            "description": "Physical Verification",
        },
        "lec": {
            "tool": "lec",
            "script": "tool_scripts/lec/lec.tcl",
            "depends_on": ["chip_finish"],
            "description": "Logical Equivalence Check",
        },
    }

    STAGE_GROUPS = {
        "pnr": [
            "init_design",
            "floorplan",
            "place",
            "cts",
            "post_cts",
            "route",
            "postroute",
            "chip_finish",
        ],
        "signoff": ["qrc", "sta", "pv", "lec"],
        "flow": [
            "syn",
            "init_design",
            "floorplan",
            "place",
            "cts",
            "post_cts",
            "route",
            "postroute",
            "chip_finish",
        ],
    }

    def __init__(
        self,
        max_retries: int = 3,
    ):
        """
        Initialize PhysicalDesignGraph

        Configuration is managed internally per flow execution.
        PhysicalDesignGraph creates its own ConfigManager, StageExecutor, and DebugAgent
        based on prompt parameters at runtime.

        Args:
            max_retries: Maximum retries per stage (default: 3)
        """
        self.max_retries = max_retries

        # Claude client for NLP
        self.client = Anthropic() if Anthropic is not None else None
        self.model = get_claude_model()

        # Components initialized on-demand during invoke
        self.config_manager = None
        self.stage_executor = None
        self.debug_agent = None
        self.validation_runner = None

        # Build graph
        self.graph = self._build_graph()

    def _log_prefix(self, state: FlowState) -> str:
        """Create log prefix from state for consistent tracking"""
        session_id = state.get("session_id", "")
        job_id = state.get("job_id", "")
        if session_id and job_id:
            return f"[session={session_id}][job={job_id}]"
        elif job_id:
            return f"[job={job_id}]"
        elif session_id:
            return f"[session={session_id}]"
        return ""

    def _emit_lifecycle_hook(self, state: FlowState, event_type: str, payload: Optional[dict] = None):
        """Best-effort hook for external lifecycle adapters (Redis/Postgres/eventing)."""
        hook = state.get("lifecycle_hook")
        if not callable(hook):
            return
        try:
            hook(event_type, payload or {}, state)
        except Exception as e:
            print(f"[WARN] lifecycle_hook failed for event '{event_type}': {e}")

    def _emit_agent_log(self, state: FlowState, message: str, *, level: str = "INFO", payload: Optional[dict] = None):
        """Emit non-lifecycle diagnostic logs for timeline/debug UIs."""
        self._emit_lifecycle_hook(
            state,
            "agent_log",
            {
                "source": "SPD_Agent",
                "level": level,
                "message": message,
                "details": payload or {},
            },
        )

    @staticmethod
    def _normalize_human_decision(value: str) -> Optional[str]:
        normalized = (value or "").strip().lower().replace("-", "_").replace(" ", "_")
        if normalized in {"approved", "approve", "yes", "y", "ok", "continue", "rerun", "run", "execute"}:
            return "approved"
        if normalized in {"declined", "decline", "reject", "rejected", "no", "n", "skip", "cancel", "abort", "stop"}:
            return "declined"
        if normalized in {"userinput", "user_input", "context", "comment", "need_context", "more_info"}:
            return "user_input"
        return None

    def _build_hitl_request_payload(
        self,
        state: FlowState,
        *,
        interaction_type: str,
        prompt: str,
        message: str,
        options: list[str],
        extra: Optional[dict] = None,
    ) -> dict:
        version = int(state.get("hitl_version", 0) or 0) + 1
        payload = {
            "interaction_type": interaction_type,
            "decision": None,
            "additional_context": None,
            "decision_status": "waiting_for_human",
            "requested_at": datetime.utcnow().isoformat(),
            "expires_at": None,
            "version": version,
            "prompt": prompt,
            "message": message,
            "options": options,
        }
        if extra:
            payload.update(extra)
        return payload

    def _re_evaluate_plan_with_context(
        self,
        plan: list[str],
        current_stage_index: int,
        context: str,
    ) -> tuple[list[str], int, dict]:
        ctx = (context or "").strip().lower()
        if not ctx:
            return plan, current_stage_index, {"changed": False}

        original_plan = list(plan)
        new_plan = list(plan)
        removed_stages: list[str] = []
        group_applied: Optional[str] = None

        if re.search(r"\b(run|execute|start)\s+pnr\b|\bpnr\s+only\b", ctx):
            candidate = [stage for stage in original_plan if stage in self.STAGE_GROUPS.get("pnr", [])]
            if candidate:
                new_plan = candidate
                group_applied = "pnr"
        elif re.search(r"\b(run|execute|start)\s+signoff\b|\bsignoff\s+only\b", ctx):
            candidate = [stage for stage in original_plan if stage in self.STAGE_GROUPS.get("signoff", [])]
            if candidate:
                new_plan = candidate
                group_applied = "signoff"

        for stage in list(new_plan):
            if re.search(rf"\\bskip\\s+{re.escape(stage.lower())}\\b", ctx):
                removed_stages.append(stage)
                new_plan.remove(stage)

        mentioned_stages = [
            stage for stage in original_plan if re.search(rf"\\b{re.escape(stage.lower())}\\b", ctx)
        ]
        if "only" in ctx and mentioned_stages:
            new_plan = [stage for stage in original_plan if stage in mentioned_stages]

        if not new_plan:
            new_plan = list(original_plan)

        new_index = current_stage_index
        for stage in new_plan:
            if re.search(rf"\\b(start\\s+from|from)\\s+{re.escape(stage.lower())}\\b", ctx):
                new_index = new_plan.index(stage)
                break

        if new_index >= len(new_plan):
            new_index = 0

        changed = (new_plan != original_plan) or (new_index != current_stage_index)
        details = {
            "changed": changed,
            "old_plan": original_plan,
            "new_plan": new_plan,
            "old_index": current_stage_index,
            "new_index": new_index,
            "removed_stages": removed_stages,
            "mentioned_stages": mentioned_stages,
            "group_applied": group_applied,
        }
        return new_plan, new_index, details

    def _build_graph(self) -> StateGraph:
        """Build the LangGraph execution graph"""

        workflow = StateGraph(FlowState)

        # Add nodes
        workflow.add_node("parse_intent", self._parse_intent_node)
        workflow.add_node("create_plan", self._create_plan_node)
        workflow.add_node("confirm_plan", self._confirm_plan_node)
        workflow.add_node("execute_stage", self._execute_stage_node)
        workflow.add_node("debug_stage", self._debug_stage_node)
        workflow.add_node("analyze_results", self._analyze_results_node)  # New: Analysis node
        workflow.add_node("handle_result", self._handle_result_node)

        # Add edges
        workflow.add_edge(START, "parse_intent")

        # Conditional routing after parse_intent based on action_type
        workflow.add_conditional_edges(
            "parse_intent",
            self._route_after_intent,
            {
                "create_plan": "create_plan",      # Execute actions
                "analyze_results": "analyze_results",  # Analyze/summarize actions
                "handle_result": "handle_result",  # Simple queries or errors
            },
        )

        workflow.add_edge("create_plan", "confirm_plan")

        # Conditional edges after confirm_plan
        workflow.add_conditional_edges(
            "confirm_plan",
            self._route_after_plan_confirmation,
            {
                "execute_stage": "execute_stage",
                "handle_result": "handle_result",
            },
        )

        # Conditional edges after execute_stage
        workflow.add_conditional_edges(
            "execute_stage",
            self._route_after_execution,
            {
                "execute_stage": "execute_stage",  # Retry (next stage in loop)
                "debug": "debug_stage",
                "handle_result": "handle_result",
            },
        )

        # Conditional edges after debug_stage
        workflow.add_conditional_edges(
            "debug_stage",
            self._route_after_debug,
            {
                "execute_stage": "execute_stage",  # Retry with fix
                "handle_result": "handle_result",  # Stop
            },
        )

        # Analysis node goes to handle_result
        workflow.add_edge("analyze_results", "handle_result")

        # Final edge
        workflow.add_edge("handle_result", END)

        # Compile with checkpointer support
        # In multi-user mode, checkpointer will be passed during ainvoke
        return workflow.compile()

    def _route_after_intent(self, state: FlowState) -> str:
        """Route after intent parsing based on action type."""
        action_type = state.get("action_type", "execute")
        intent = state.get("intent", {})

        # Check for parsing errors
        if state.get("error_info"):
            return "handle_result"

        # Route based on action type
        if action_type == "off_topic":
            # Off-topic questions go directly to handle_result (skip HITL)
            return "handle_result"
        elif action_type == "analyze":
            return "analyze_results"
        elif action_type == "query":
            # Simple queries can go directly to handle_result
            # More complex queries might need analyze_results
            analysis_type = intent.get("analysis_type", "")
            if analysis_type in ("status", "list"):
                return "handle_result"
            return "analyze_results"
        else:
            # Default: execution flow
            return "create_plan"

    async def _parse_intent_node(self, state: FlowState) -> dict:
        """Parse natural language prompt into execution intent using SPD Agent"""
        prompt = state.get("prompt", "")
        log_prefix = self._log_prefix(state)
        print(f"\n{log_prefix}[INTENT] Parsing: {prompt}")
        self._emit_agent_log(state, "Parsing user intent", payload={"prompt": prompt})

        system_prompt = """You are a physical design flow orchestrator. When given a user request,
you MUST respond ONLY with a valid JSON object - no markdown, no explanation, no code fences.

**Available stages:**
- Synthesis: syn
- PnR: init_design, floorplan, place, cts, post_cts, route, postroute, chip_finish
- Post-design: qrc, sta, pv, lec
- Groups: pnr (all PnR stages), signoff (qrc, sta, pv, lec), flow (all stages)

**Action Types:**
1. EXECUTE actions (action_type: "execute"): run, rerun, restart, resume, debug, clean
   - For running or re-running PD flow stages
2. ANALYZE actions (action_type: "analyze"): summarize, analyze, check, report, compare
   - For analyzing results, logs, reports of completed stages
3. QUERY actions (action_type: "query"): status, show, list, info
   - For querying current status or information
4. OFF_TOPIC actions (action_type: "off_topic"):
   - For questions NOT related to physical design (personal questions, general chat, etc.)
   - Examples: "what is my name", "tell me a joke", "what's the weather", "who are you"

**JSON schema to follow exactly:**
{
    "action_type": "execute|analyze|query|off_topic",
    "action": "run|rerun|summarize|analyze|check|report|status|off_topic|...",
    "stages": ["stage1", "stage2"],
    "target_stage": "stage_name or null",
    "analysis_type": "timing|area|power|qor|congestion|drc|logs|all",
    "start_from": "stage_name or null",
    "skip_completed": true/false,
    "force_clean": true/false,
    "enable_ai": true/false,
    "confidence": 0.0-1.0,
    "reasoning": "brief explanation",
    "off_topic_response": "polite message if off_topic (e.g., 'I can only help with physical design tasks')"
}

**Examples:**
- "run synthesis" -> action_type: "execute", action: "run", stages: ["syn"]
- "summarize synthesis results" -> action_type: "analyze", action: "summarize", target_stage: "syn", analysis_type: "all"
- "check timing after placement" -> action_type: "analyze", action: "check", target_stage: "place", analysis_type: "timing"
- "show current status" -> action_type: "query", action: "status"
- "analyze congestion in routing" -> action_type: "analyze", action: "analyze", target_stage: "route", analysis_type: "congestion"
- "report QoR for synthesis" -> action_type: "analyze", action: "report", target_stage: "syn", analysis_type: "qor"
- "what is my name" -> action_type: "off_topic", action: "off_topic", off_topic_response: "I'm a Physical Design assistant. I can help with synthesis, placement, routing, and other PD tasks."
- "tell me a joke" -> action_type: "off_topic", action: "off_topic", off_topic_response: "I'm focused on Physical Design workflows. Please ask about running stages, analyzing results, or checking status."
"""

        agent_prompt = f'Analyze this physical design flow request and return JSON only:\nUser request: "{prompt}"'

        # --- Attempt 1: claude_agent_sdk ----------------------------------------
        try:
            print("  Trying SPD Agent...")
            self._emit_agent_log(state, "Attempting intent parse via SPD Agent")
            from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, TextBlock

            options = ClaudeAgentOptions(
                model=self.model,
                system_prompt=system_prompt,
                max_turns=1,
            )

            collected_text = ""
            async for message in query(prompt=agent_prompt, options=options):
                if isinstance(message, AssistantMessage):
                    for block in message.content:
                        if isinstance(block, TextBlock):
                            collected_text += block.text

            if collected_text.strip():
                clean = re.sub(r"^```(?:json)?\s*", "", collected_text.strip())
                clean = re.sub(r"\s*```$", "", clean)
                intent = json.loads(clean)
                print(f"  ? Intent parsed with SPD Agent")
                print(f"  Action type: {intent.get('action_type', 'execute')}")
                print(f"  Reasoning: {intent.get('reasoning')}")
                print(f"  Confidence: {intent.get('confidence', 0):.0%}")
                self._emit_agent_log(
                    state,
                    f"Intent parsed via SPD Agent: {intent.get('reasoning', '')}",
                    payload={
                        "confidence": intent.get("confidence"),
                        "action_type": intent.get("action_type"),
                        "action": intent.get("action"),
                        "stages": intent.get("stages"),
                        "target_stage": intent.get("target_stage"),
                        "analysis_type": intent.get("analysis_type"),
                        "reasoning": intent.get("reasoning"),
                    },
                )
                return self._build_intent_result(intent)

        except Exception as e:
            print(f"  [WARN] SPD Agent failed: {e}")
            self._emit_agent_log(state, "SPD Agent parse attempt failed", level="WARN", payload={"error": str(e)})

        # --- Attempt 2: Direct Anthropic API ------------------------------------
        api_key_available = self.client is not None and os.environ.get("ANTHROPIC_API_KEY") is not None
        if api_key_available:
            try:
                print("  Trying direct Anthropic API...")
                self._emit_agent_log(state, "Attempting intent parse via direct Anthropic API")
                intent_prompt = f'{system_prompt}\n\n{agent_prompt}'
                response = self.client.messages.create(
                    model=self.model,
                    max_tokens=500,
                    messages=[{"role": "user", "content": intent_prompt}],
                )
                token_tracker.record(response, source="physical_design_graph.parse_intent")
                clean = re.sub(r"^```(?:json)?\s*", "", response.content[0].text.strip())
                clean = re.sub(r"\s*```$", "", clean)
                intent = json.loads(clean)
                print(f"  ? Intent parsed with direct Anthropic API")
                print(f"  Action type: {intent.get('action_type', 'execute')}")
                print(f"  Reasoning: {intent.get('reasoning')}")
                print(f"  Confidence: {intent.get('confidence', 0):.0%}")
                self._emit_agent_log(
                    state,
                    f"Intent parsed via direct Anthropic API: {intent.get('reasoning', '')}",
                    payload={
                        "confidence": intent.get("confidence"),
                        "action_type": intent.get("action_type"),
                        "action": intent.get("action"),
                        "stages": intent.get("stages"),
                        "target_stage": intent.get("target_stage"),
                        "analysis_type": intent.get("analysis_type"),
                        "reasoning": intent.get("reasoning"),
                    },
                )
                return self._build_intent_result(intent)

            except Exception as e:
                print(f"  [WARN] Direct API failed: {e}")
                self._emit_agent_log(state, "Direct Anthropic API parse attempt failed", level="WARN", payload={"error": str(e)})

        # --- Attempt 3: Fallback pattern matching -------------------------------
        print("  Using fallback pattern matching (no API key / all attempts failed)")
        intent = self._parse_intent_fallback(prompt)
        self._emit_agent_log(
            state,
            f"Intent parsed via fallback pattern matching: {intent.get('reasoning', 'Detected via pattern matching')}",
            level="WARN",
            payload={
                "action_type": intent.get("action_type"),
                "action": intent.get("action"),
                "stages": intent.get("stages"),
                "target_stage": intent.get("target_stage"),
                "analysis_type": intent.get("analysis_type"),
                "reasoning": intent.get("reasoning", "Detected via pattern matching"),
            },
        )
        return self._build_intent_result(intent)

    def _build_intent_result(self, intent: dict) -> dict:
        """Build the state update from parsed intent."""
        action_type = intent.get("action_type", "execute")

        # Infer action_type from action if not explicitly set
        action = intent.get("action", "run").lower()
        if action_type == "execute" or not action_type:
            if action in ("summarize", "analyze", "check", "report", "compare"):
                action_type = "analyze"
            elif action in ("status", "show", "list", "info"):
                action_type = "query"
            elif action == "off_topic":
                action_type = "off_topic"
            else:
                action_type = "execute"

        result = {
            "intent": intent,
            "action_type": action_type,
            "analysis_target": intent.get("target_stage"),
            "analysis_type": intent.get("analysis_type"),
            "execution_status": "in_progress",
        }

        # For off-topic, include the response message
        if action_type == "off_topic":
            result["off_topic_response"] = intent.get(
                "off_topic_response",
                "I'm a Physical Design flow assistant. I can help you with:\n"
                "• Running stages (synthesis, placement, routing, etc.)\n"
                "• Analyzing results and reports\n"
                "• Checking timing, area, power metrics\n"
                "• Debugging flow issues\n\n"
                "Please ask a question related to your physical design workflow."
            )
            result["execution_status"] = "completed"

        return result

    def _parse_intent_fallback(self, prompt: str) -> dict:
        """Fallback pattern-based intent parsing"""

        prompt_lower = prompt.lower()

        # Detect action type and action
        action_type = "execute"
        action = "run"
        analysis_type = None
        target_stage = None

        # Check for ANALYZE actions first
        if any(word in prompt_lower for word in ["summarize", "summary"]):
            action_type = "analyze"
            action = "summarize"
            analysis_type = "all"
        elif "analyze" in prompt_lower or "analysis" in prompt_lower:
            action_type = "analyze"
            action = "analyze"
            analysis_type = "all"
        elif "report" in prompt_lower and any(word in prompt_lower for word in ["qor", "timing", "area", "power", "result"]):
            action_type = "analyze"
            action = "report"
            analysis_type = "qor"
        elif "check" in prompt_lower and any(word in prompt_lower for word in ["timing", "drc", "result", "log"]):
            action_type = "analyze"
            action = "check"
        elif "compare" in prompt_lower:
            action_type = "analyze"
            action = "compare"

        # Check for QUERY actions
        elif "status" in prompt_lower:
            action_type = "query"
            action = "status"
        elif any(word in prompt_lower for word in ["show", "list", "info"]) and not any(word in prompt_lower for word in ["run", "execute"]):
            action_type = "query"
            action = "show"

        # EXECUTE actions
        elif "rerun" in prompt_lower or "redo" in prompt_lower:
            action = "rerun"
        elif "restart" in prompt_lower:
            action = "restart"
        elif "resume" in prompt_lower:
            action = "resume"
        elif "clean" in prompt_lower:
            action = "clean"
        elif "debug" in prompt_lower:
            action = "debug"
        else:
            action = "run"

        # Detect analysis type for analyze actions
        if action_type == "analyze":
            if "timing" in prompt_lower:
                analysis_type = "timing"
            elif "area" in prompt_lower:
                analysis_type = "area"
            elif "power" in prompt_lower:
                analysis_type = "power"
            elif "congestion" in prompt_lower:
                analysis_type = "congestion"
            elif "drc" in prompt_lower:
                analysis_type = "drc"
            elif "qor" in prompt_lower:
                analysis_type = "qor"
            elif "log" in prompt_lower:
                analysis_type = "logs"
            else:
                analysis_type = "all"

        # Detect target stage for analysis
        stages = []
        for stage in self.STAGES:
            if stage in prompt_lower:
                stages.append(stage)
                if action_type == "analyze" and not target_stage:
                    target_stage = stage

        # Handle stage aliases
        stage_name_map = {
            "synthesis": "syn",
            "placement": "place",
            "routing": "route",
            "clock tree": "cts",
        }
        for alias, stage in stage_name_map.items():
            if alias in prompt_lower and stage not in stages:
                stages.append(stage)
                if action_type == "analyze" and not target_stage:
                    target_stage = stage

        # Handle stage groups
        if not stages:
            if "all" in prompt_lower or "complete" in prompt_lower or "flow" in prompt_lower:
                stages = list(self.STAGES.keys())
            elif "pnr" in prompt_lower:
                stages = self.STAGE_GROUPS["pnr"]
            elif "signoff" in prompt_lower:
                stages = self.STAGE_GROUPS["signoff"]

        # Default stages for execute actions
        if not stages and action_type == "execute":
            stages = list(self.STAGES.keys())

        return {
            "action_type": action_type,
            "action": action,
            "stages": stages,
            "target_stage": target_stage,
            "analysis_type": analysis_type,
            "start_from": None,
            "skip_completed": True,
            "force_clean": False,
            "enable_ai": True,
            "confidence": 0.5,
            "reasoning": f"Detected via pattern matching: {action_type}/{action}",
        }

    async def _create_plan_node(self, state: FlowState) -> dict:
        """Create execution plan from intent"""

        intent = state.get("intent", {})
        stages = intent.get("stages", list(self.STAGES.keys()))
        log_prefix = self._log_prefix(state)

        print(f"\n{log_prefix}[PLAN] Creating execution plan")
        print(f"{log_prefix}  Stages: {' → '.join(stages)}")

        self._emit_lifecycle_hook(
            state,
            "started",
            {
                "message": "Flow execution started",
                "plan": stages,
                "current_stage_index": 0,
            },
        )

        return {
            "plan": stages,
            "current_stage_index": 0,
            "stages_executed": [],
            "stages_failed": [],
            "stages_skipped": [],
            "stage_results": {},
            "debug_history": {},
            "max_retries": self.max_retries,
            "error_retry_count": 0,
        }

    async def _analyze_results_node(self, state: FlowState) -> dict:
        """
        Analyze results/reports for a completed stage using Claude.

        This node handles analyze/summarize/report requests by:
        1. Finding relevant log and report files for the target stage
        2. Using Claude Agent SDK to read and analyze the files
        3. Generating a structured summary with metrics and recommendations
        """
        intent = state.get("intent", {})
        target_stage = state.get("analysis_target") or intent.get("target_stage")
        analysis_type = state.get("analysis_type") or intent.get("analysis_type", "all")
        action = intent.get("action", "summarize")
        log_prefix = self._log_prefix(state)

        print(f"\n{log_prefix}[ANALYZE] Analyzing results for stage: {target_stage or 'all'}")
        print(f"{log_prefix}  Analysis type: {analysis_type}")
        print(f"{log_prefix}  Action: {action}")

        self._emit_lifecycle_hook(
            state,
            "analysis_started",
            {
                "message": f"Starting analysis: {action} {analysis_type} for {target_stage or 'all stages'}",
                "target_stage": target_stage,
                "analysis_type": analysis_type,
                "action": action,
            },
        )
        self._emit_agent_log(
            state,
            f"Starting {action} analysis for {target_stage or 'all stages'} ({analysis_type})",
            payload={"target_stage": target_stage, "analysis_type": analysis_type},
        )

        # Get stage info and determine tool
        tool_name = "unknown"
        if target_stage:
            stage_info = self.STAGES.get(target_stage, {})
            tool_name = stage_info.get("tool", "unknown")
            try:
                tool_name, _ = self.config_manager.get_stage_tool_script(target_stage)
            except Exception:
                pass

        # Build file patterns to search based on stage and analysis type
        file_patterns = self._get_analysis_file_patterns(target_stage, tool_name, analysis_type)

        # Find actual files that exist
        files_to_analyze = []
        log_dir = self.config_manager.run_dir / "logs" if self.config_manager else Path("logs")
        report_dir = self.config_manager.run_dir / "reports" if self.config_manager else Path("reports")

        for pattern in file_patterns:
            for search_dir in [log_dir, report_dir, self.config_manager.run_dir if self.config_manager else Path(".")]:
                if search_dir.exists():
                    matched = list(search_dir.glob(pattern))
                    files_to_analyze.extend([str(f) for f in matched if f.is_file()])

        # Remove duplicates
        files_to_analyze = list(set(files_to_analyze))
        print(f"{log_prefix}  Found {len(files_to_analyze)} files to analyze")

        if not files_to_analyze:
            # No files found - return appropriate message
            result = {
                "status": "no_data",
                "summary": f"No {analysis_type} reports or logs found for stage '{target_stage or 'any'}'",
                "metrics": {},
                "issues": [],
                "recommendations": ["Run the stage first to generate results"],
                "files_analyzed": [],
            }
            self._emit_lifecycle_hook(
                state,
                "analysis_completed",
                {
                    "status": "no_data",
                    "target_stage": target_stage,
                    "message": result["summary"],
                },
            )
            return {
                "analysis_result": result,
                "analysis_files": [],
                "execution_status": "completed",
            }

        # Use Claude to analyze the files
        analysis_result = await self._perform_analysis(
            state=state,
            files=files_to_analyze,
            target_stage=target_stage,
            tool_name=tool_name,
            analysis_type=analysis_type,
            action=action,
        )

        self._emit_lifecycle_hook(
            state,
            "analysis_completed",
            {
                "status": "success",
                "target_stage": target_stage,
                "analysis_type": analysis_type,
                "summary": analysis_result.get("summary", "")[:500],  # Truncate for event
                "metrics": analysis_result.get("metrics", {}),
                "files_analyzed": len(files_to_analyze),
            },
        )

        # Emit the full analysis to the UI
        self._emit_agent_log(
            state,
            f"Analysis complete for {target_stage or 'all stages'}",
            payload={
                "type": "analysis_complete",
                "format": "markdown",
                "content": analysis_result.get("summary", ""),
                "metrics": analysis_result.get("metrics", {}),
                "issues": analysis_result.get("issues", []),
                "recommendations": analysis_result.get("recommendations", []),
            },
        )

        return {
            "analysis_result": analysis_result,
            "analysis_files": files_to_analyze,
            "execution_status": "completed",
        }

    def _get_analysis_file_patterns(
        self,
        target_stage: Optional[str],
        tool_name: str,
        analysis_type: str,
    ) -> list:
        """Get file patterns to search for based on stage, tool, and analysis type."""
        patterns = []

        # Tool-specific log patterns
        tool_patterns = {
            "genus": ["genus*.log", "genus*.rpt", "*.genus.log"],
            "dc_shell": ["dc*.log", "dc*.rpt", "*.dc.log", "compile*.log"],
            "innovus": ["innovus*.log", "innovus*.rpt", "*.innovus.log"],
            "icc2": ["icc2*.log", "icc2*.rpt", "*.icc2.log"],
            "tempus": ["tempus*.log", "tempus*.rpt", "timing*.rpt"],
            "primetime": ["pt*.log", "pt*.rpt", "timing*.rpt"],
            "calibre": ["calibre*.log", "drc*.rpt", "lvs*.rpt"],
        }

        # Analysis type specific patterns
        analysis_patterns = {
            "timing": ["*timing*.rpt", "*slack*.rpt", "*wns*.rpt", "*tns*.rpt", "*setup*.rpt", "*hold*.rpt"],
            "area": ["*area*.rpt", "*utilization*.rpt", "*cell_count*.rpt"],
            "power": ["*power*.rpt", "*leakage*.rpt", "*dynamic*.rpt"],
            "congestion": ["*congestion*.rpt", "*overflow*.rpt", "*grc*.rpt"],
            "drc": ["*drc*.rpt", "*violation*.rpt"],
            "qor": ["*qor*.rpt", "*summary*.rpt", "*metrics*.rpt"],
            "logs": ["*.log"],
            "all": ["*.log", "*.rpt"],
        }

        # Add tool-specific patterns
        if tool_name.lower() in tool_patterns:
            patterns.extend(tool_patterns[tool_name.lower()])

        # Add analysis-type patterns
        if analysis_type in analysis_patterns:
            patterns.extend(analysis_patterns[analysis_type])
        else:
            patterns.extend(analysis_patterns["all"])

        # Add stage-specific patterns
        if target_stage:
            patterns.extend([
                f"*{target_stage}*.log",
                f"*{target_stage}*.rpt",
                f"{target_stage}/*.log",
                f"{target_stage}/*.rpt",
            ])

        return list(set(patterns))

    async def _perform_analysis(
        self,
        state: FlowState,
        files: list,
        target_stage: Optional[str],
        tool_name: str,
        analysis_type: str,
        action: str,
    ) -> dict:
        """Use Claude to analyze the files and generate a summary."""
        log_prefix = self._log_prefix(state)

        # Build the analysis prompt
        stage_desc = f"stage '{target_stage}'" if target_stage else "the design flow"
        tool_desc = f" (using {tool_name})" if tool_name != "unknown" else ""

        analysis_system_prompt = f"""You are an expert VLSI Physical Design engineer analyzing results from {stage_desc}{tool_desc}.

Your task is to {action} the {analysis_type} results by:
1. Reading the provided log and report files
2. Extracting key metrics (timing, area, power, DRC counts, etc.)
3. Identifying any issues, warnings, or errors
4. Providing actionable recommendations

Focus on:
- For timing: WNS, TNS, number of violating paths, critical paths
- For area: Cell count, utilization, density
- For power: Total power, leakage, dynamic power
- For DRC: Violation counts by type, hotspots
- For QoR: Overall quality metrics, pass/fail status

Format your response as a structured analysis with clear sections."""

        analysis_prompt = f"""Analyze the following files for {stage_desc}:

Files to analyze:
{chr(10).join(f'- {f}' for f in files[:10])}  # Limit to first 10 files

Please provide:
1. **Summary**: A concise summary of the results (2-3 sentences)
2. **Key Metrics**: Important numerical values extracted
3. **Issues Found**: Any errors, warnings, or violations
4. **Recommendations**: Actionable next steps

Read each file and provide your analysis."""

        # Try using Claude Agent SDK for file reading
        try:
            from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, TextBlock

            print(f"{log_prefix}  Using Claude Agent SDK for analysis...")
            self._emit_agent_log(state, "Reading and analyzing files with Claude Agent SDK")

            options = ClaudeAgentOptions(
                model=self.model,
                system_prompt=analysis_system_prompt,
                max_turns=5,  # Allow multiple tool calls to read files
                allowed_tools=["Read", "Grep", "Glob"],
            )

            collected_text = ""
            async for message in query(prompt=analysis_prompt, options=options):
                if isinstance(message, AssistantMessage):
                    for block in message.content:
                        if isinstance(block, TextBlock):
                            collected_text += block.text
                            # Stream partial results to UI
                            self._emit_agent_log(
                                state,
                                "Analysis in progress...",
                                payload={"type": "analysis", "format": "markdown", "content": block.text},
                            )

            # Parse the analysis result
            return self._parse_analysis_response(collected_text, files)

        except ImportError:
            print(f"{log_prefix}  [WARN] Claude Agent SDK not available, using direct API")

        # Fallback: Use direct Anthropic API with file contents
        if self.client and os.environ.get("ANTHROPIC_API_KEY"):
            try:
                # Read first few files directly
                file_contents = []
                max_content_size = 50000  # Limit total content
                current_size = 0

                for file_path in files[:5]:  # Limit to 5 files
                    try:
                        with open(file_path, 'r', errors='ignore') as f:
                            content = f.read()
                            # Truncate large files
                            if len(content) > 10000:
                                content = content[:5000] + "\n...[truncated]...\n" + content[-5000:]
                            if current_size + len(content) > max_content_size:
                                break
                            file_contents.append(f"=== {file_path} ===\n{content}")
                            current_size += len(content)
                    except Exception as e:
                        print(f"{log_prefix}  [WARN] Could not read {file_path}: {e}")

                if not file_contents:
                    return {
                        "status": "error",
                        "summary": "Could not read any analysis files",
                        "metrics": {},
                        "issues": ["File read error"],
                        "recommendations": ["Check file permissions and paths"],
                        "files_analyzed": [],
                    }

                full_prompt = f"""{analysis_prompt}

File Contents:
{chr(10).join(file_contents)}"""

                response = self.client.messages.create(
                    model=self.model,
                    max_tokens=4000,
                    system=analysis_system_prompt,
                    messages=[{"role": "user", "content": full_prompt}],
                )
                token_tracker.record(response, source="physical_design_graph.analyze_results")

                analysis_text = response.content[0].text
                return self._parse_analysis_response(analysis_text, files)

            except Exception as e:
                print(f"{log_prefix}  [ERROR] Analysis failed: {e}")
                return {
                    "status": "error",
                    "summary": f"Analysis failed: {str(e)}",
                    "metrics": {},
                    "issues": [str(e)],
                    "recommendations": ["Check API key and try again"],
                    "files_analyzed": files,
                }

        # No API available - return basic file listing
        return {
            "status": "limited",
            "summary": f"Found {len(files)} files for analysis but no AI API available for detailed analysis.",
            "metrics": {},
            "issues": [],
            "recommendations": ["Configure ANTHROPIC_API_KEY for AI-powered analysis"],
            "files_analyzed": files,
            "raw_files": files,
        }

    def _parse_analysis_response(self, response_text: str, files: list) -> dict:
        """Parse Claude's analysis response into structured format."""
        result = {
            "status": "success",
            "summary": "",
            "metrics": {},
            "issues": [],
            "recommendations": [],
            "files_analyzed": files,
            "raw_response": response_text,
        }

        # Extract sections from the response
        lines = response_text.split('\n')
        current_section = "summary"
        current_content = []

        for line in lines:
            line_lower = line.lower().strip()

            # Detect section headers
            if any(header in line_lower for header in ["**summary**", "## summary", "# summary"]):
                if current_content:
                    result[current_section] = '\n'.join(current_content).strip()
                current_section = "summary"
                current_content = []
            elif any(header in line_lower for header in ["**key metrics**", "## metrics", "# metrics", "**metrics**"]):
                if current_content:
                    result[current_section] = '\n'.join(current_content).strip()
                current_section = "metrics_text"
                current_content = []
            elif any(header in line_lower for header in ["**issues**", "## issues", "# issues", "**errors**", "**warnings**"]):
                if current_content:
                    result[current_section] = '\n'.join(current_content).strip()
                current_section = "issues_text"
                current_content = []
            elif any(header in line_lower for header in ["**recommendations**", "## recommendations", "# recommendations", "**next steps**"]):
                if current_content:
                    result[current_section] = '\n'.join(current_content).strip()
                current_section = "recommendations_text"
                current_content = []
            else:
                current_content.append(line)

        # Save last section
        if current_content:
            result[current_section] = '\n'.join(current_content).strip()

        # If no sections found, use the whole response as summary
        if not result["summary"] and response_text:
            result["summary"] = response_text[:2000]

        # Extract metrics from metrics_text (simple key: value parsing)
        if "metrics_text" in result:
            metrics_text = result.pop("metrics_text", "")
            for line in metrics_text.split('\n'):
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip().strip('-*').strip()
                    value = parts[1].strip()
                    if key:
                        result["metrics"][key] = value

        # Extract issues as list
        if "issues_text" in result:
            issues_text = result.pop("issues_text", "")
            result["issues"] = [
                line.strip().strip('-*').strip()
                for line in issues_text.split('\n')
                if line.strip() and line.strip() not in ['-', '*', '•']
            ]

        # Extract recommendations as list
        if "recommendations_text" in result:
            recommendations_text = result.pop("recommendations_text", "")
            result["recommendations"] = [
                line.strip().strip('-*').strip()
                for line in recommendations_text.split('\n')
                if line.strip() and line.strip() not in ['-', '*', '•']
            ]

        return result

    async def _confirm_plan_node(self, state: FlowState) -> dict:
        """Pause for human confirmation of generated plan before stage execution."""
        require_plan_confirmation = state.get("require_plan_confirmation", True)
        if not require_plan_confirmation:
            return {
                "awaiting_plan_confirmation": False,
                "plan_approved": True,
            }

        plan = state.get("plan", [])
        intent = state.get("intent", {})
        log_prefix = self._log_prefix(state)
        resolver = state.get("hitl_resolver")

        if not callable(resolver):
            print(f"{log_prefix}[WARN] HITL plan confirmation enabled but no resolver provided; auto-approving plan")
            return {
                "awaiting_plan_confirmation": False,
                "plan_approved": True,
            }

        # Build human-readable plan description
        stage_descriptions = []
        for i, stage in enumerate(plan, 1):
            stage_info = self.STAGES.get(stage, {})
            desc = stage_info.get("description", stage)
            tool = stage_info.get("tool", "unknown")
            stage_descriptions.append(f"  {i}. {stage} ({desc}) - using {tool}")

        human_readable_plan = "\n".join(stage_descriptions)
        action = intent.get("action", "run").upper()
        reasoning = intent.get("reasoning", "")

        human_message = f"""**Execution Plan Summary**

Action: {action} {len(plan)} stage(s)
{f"Reasoning: {reasoning}" if reasoning else ""}

**Stages to Execute:**
{human_readable_plan}

Please review and confirm to proceed."""

        request_payload = self._build_hitl_request_payload(
            state,
            interaction_type="plan_confirmation",
            prompt="Please confirm the execution plan",
            message=human_message,
            options=["Approved", "Declined", "UserInput"],
            extra={
                "plan": plan,
                "current_stage_index": 0,
                "plan_size": len(plan),
                "stage_details": [
                    {"stage": s, "description": self.STAGES.get(s, {}).get("description", s), "tool": self.STAGES.get(s, {}).get("tool", "unknown")}
                    for s in plan
                ],
            },
        )

        print(f"\n{log_prefix}[HITL] Waiting for plan confirmation")
        self._emit_lifecycle_hook(state, "hitl_required", request_payload)
        latest_context = (state.get("pending_human_context") or "").strip()

        while True:
            response_payload = resolver("plan_confirmation", request_payload, state) or {}
            if not response_payload:
                await asyncio.sleep(1)
                continue

            if response_payload.get("abort_requested"):
                abort_message = response_payload.get("message") or "Abort requested during plan confirmation"
                self._emit_lifecycle_hook(
                    state,
                    "abort_requested",
                    {
                        "message": abort_message,
                        "plan": plan,
                        "current_stage_index": 0,
                    },
                )
                return {
                    "awaiting_plan_confirmation": False,
                    "plan_approved": False,
                    "execution_status": "cancelled",
                    "error_info": {
                        "category": "abort_requested",
                        "error_preview": abort_message,
                        "error": abort_message,
                    },
                }

            raw_response = str(response_payload.get("response", "")).strip()
            normalized_response = self._normalize_human_decision(raw_response)
            if not raw_response:
                await asyncio.sleep(1)
                continue

            # Build human-readable confirmation message
            additional_context = response_payload.get("additional_context", "")
            if normalized_response == "approved":
                confirm_msg = f"User approved the execution plan"
                if additional_context:
                    confirm_msg += f" with context: {additional_context}"
            elif normalized_response == "declined":
                confirm_msg = f"User declined the execution plan"
            elif normalized_response == "user_input":
                confirm_msg = f"User provided additional input: {additional_context}" if additional_context else "User requested to provide input"
            else:
                confirm_msg = f"User response: {raw_response}"

            self._emit_lifecycle_hook(
                state,
                "hitl_response",
                {
                    "response": normalized_response or raw_response,
                    "decision": (normalized_response or raw_response).capitalize() if normalized_response else raw_response,
                    "decision_status": "pending_final_decision" if normalized_response == "user_input" else ("resumed" if normalized_response == "approved" else "declined"),
                    "interaction_type": request_payload.get("interaction_type"),
                    "requested_at": request_payload.get("requested_at"),
                    "expires_at": request_payload.get("expires_at"),
                    "version": request_payload.get("version"),
                    "additional_context": additional_context,
                    "plan": plan,
                    "current_stage_index": 0,
                    "confirmation_message": confirm_msg,
                },
            )

            # Emit confirmation message to UI
            self._emit_agent_log(state, confirm_msg, payload={
                "type": "hitl_confirmation",
                "interaction_type": "plan_confirmation",
                "decision": normalized_response or raw_response,
                "additional_context": additional_context,
            })

            if normalized_response == "approved":
                print(f"{log_prefix}[HITL] Plan approved by human")
                context_to_apply = (response_payload.get("additional_context") or latest_context or "").strip()
                updated_plan = list(plan)
                updated_index = 0
                reevaluation = {"changed": False}
                if context_to_apply:
                    print(f"{log_prefix}[HITL] Applying context on approval: {context_to_apply}")
                    updated_plan, updated_index, reevaluation = self._re_evaluate_plan_with_context(
                        plan=plan,
                        current_stage_index=0,
                        context=context_to_apply,
                    )
                    print(
                        f"{log_prefix}[HITL] Re-evaluated plan changed={reevaluation.get('changed')} "
                        f"group={reevaluation.get('group_applied')}"
                    )
                    self._emit_lifecycle_hook(
                        state,
                        "plan_re_evaluated",
                        {
                            "interaction_type": "plan_confirmation",
                            "decision_status": "resumed",
                            "context": context_to_apply,
                            **reevaluation,
                        },
                    )
                return {
                    "awaiting_plan_confirmation": False,
                    "plan_approved": True,
                    "hitl_version": request_payload.get("version"),
                    "plan": updated_plan,
                    "current_stage_index": updated_index,
                    "pending_human_context": None,
                    "last_applied_human_context": context_to_apply or None,
                    "plan_confirmation_request": request_payload,
                    "plan_confirmation_response": response_payload,
                }

            if normalized_response == "declined":
                message = "Plan rejected by human"
                self._emit_lifecycle_hook(
                    state,
                    "abort_requested",
                    {
                        "message": message,
                        "plan": plan,
                        "current_stage_index": 0,
                    },
                )
                return {
                    "awaiting_plan_confirmation": False,
                    "plan_approved": False,
                    "hitl_version": request_payload.get("version"),
                    "execution_status": "cancelled",
                    "error_info": {
                        "category": "plan_rejected",
                        "error_preview": message,
                        "error": message,
                    },
                    "plan_confirmation_request": request_payload,
                    "plan_confirmation_response": response_payload,
                }

            if normalized_response == "user_input":
                context = (response_payload.get("additional_context") or "").strip()
                if context:
                    latest_context = context
                print(
                    f"{log_prefix}[HITL] UserInput received"
                    f"{': ' + context if context else ''}; awaiting final decision"
                )
                self._emit_lifecycle_hook(
                    state,
                    "hitl_required",
                    {
                        **request_payload,
                        "decision_status": "waiting_for_human",
                        "message": "UserInput received. Please submit final decision as Approved or Declined.",
                        "additional_context": context,
                    },
                )
                await asyncio.sleep(1)
                continue

            self._emit_lifecycle_hook(
                state,
                "hitl_required",
                {
                    **request_payload,
                    "decision_status": "waiting_for_human",
                    "message": "Invalid response. Expected Approved, Declined, or UserInput.",
                },
            )

            await asyncio.sleep(1)

    async def _execute_stage_node(self, state: FlowState) -> dict:
        """Execute current stage using StageExecutor"""

        current_index = state.get("current_stage_index", 0)
        plan = state.get("plan", [])
        log_prefix = self._log_prefix(state)

        if current_index >= len(plan):
            print(f"{log_prefix}[EXECUTE] All stages completed")
            return {}

        stage_name = plan[current_index]

        # Get tool and script from flow_config.yaml
        try:
            tool_name, script_name = self.config_manager.get_stage_tool_script(stage_name)
        except ValueError as e:
            stage_defaults = self.STAGES.get(stage_name, {})
            tool_name = stage_defaults.get("tool")
            script_name = stage_defaults.get("script")
            if tool_name and script_name:
                print(f"{log_prefix}[WARN] {e}; using built-in mapping for stage '{stage_name}'")
            else:
                print(f"{log_prefix}[FAIL] {e}")
                return {
                    "error_info": {"error": str(e)},
                    "stages_failed": state.get("stages_failed", []) + [stage_name],
                }

        stage_info = self.STAGES.get(stage_name, {})
        description = stage_info.get("description", stage_name)

        print(f"\n{log_prefix}[STAGE] Executing: {stage_name} (tool: {tool_name})")
        print(f"{log_prefix}  Description: {description}")

        stage_start_time = datetime.now()
        self._emit_lifecycle_hook(
            state,
            "stage_started",
            {
                "stage": stage_name,
                "tool": tool_name,
                "description": description,
                "current_stage_index": current_index,
                "plan_size": len(plan),
                "started_at": stage_start_time.isoformat(),
            },
        )

        # Check for abort before starting stage execution
        resolver = state.get("hitl_resolver")
        if callable(resolver):
            abort_check = resolver("abort_check", {"stage": stage_name}, state) or {}
            if abort_check.get("abort_requested"):
                print(f"{log_prefix}[STAGE] Abort requested, stopping execution")
                self._emit_lifecycle_hook(
                    state,
                    "abort_requested",
                    {"message": "Abort requested before stage execution", "stage": stage_name},
                )
                return {
                    "execution_status": "cancelled",
                    "error_info": {
                        "category": "abort_requested",
                        "error_preview": "Abort requested by user",
                        "error": "Abort requested by user",
                    },
                }

        # Check if stage already completed (completion marker exists)
        # If so, ask user if they want to rerun using HITL
        force_rerun = False
        marker_path = self.config_manager.get_complete_marker_path(stage_name)
        if marker_path.exists():
            print(f"{log_prefix}[STAGE] {stage_name} already completed (marker exists: {marker_path})")

            if callable(resolver):
                request_payload = self._build_hitl_request_payload(
                    state,
                    interaction_type="stage_rerun_confirmation",
                    prompt=f"Stage '{stage_name}' is already finished. Do you want to rerun?",
                    message=f"Completion marker for '{stage_name}' found at: {marker_path}",
                    options=["Approved", "Declined", "UserInput"],
                    extra={
                        "stage": stage_name,
                        "marker_path": str(marker_path),
                        "current_stage_index": current_index,
                        "plan_size": len(plan),
                    },
                )

                print(f"\n{log_prefix}[HITL] Stage already completed. Waiting for user decision...")
                self._emit_lifecycle_hook(state, "hitl_required", request_payload)

                while True:
                    response_payload = resolver("stage_rerun_confirmation", request_payload, state) or {}
                    if not response_payload:
                        await asyncio.sleep(1)
                        continue

                    # Debug: log the received response
                    print(f"{log_prefix}[DEBUG] HITL response received: {response_payload}")

                    if response_payload.get("abort_requested"):
                        abort_message = response_payload.get("message") or "Abort requested during rerun confirmation"
                        self._emit_lifecycle_hook(
                            state,
                            "abort_requested",
                            {"message": abort_message, "stage": stage_name},
                        )
                        return {
                            "execution_status": "cancelled",
                            "error_info": {
                                "category": "abort_requested",
                                "error_preview": abort_message,
                                "error": abort_message,
                            },
                        }

                    raw_response = str(response_payload.get("response", "")).strip()
                    normalized_response = self._normalize_human_decision(raw_response)
                    print(f"{log_prefix}[DEBUG] Parsed response: '{normalized_response or raw_response}'")
                    if not raw_response:
                        await asyncio.sleep(1)
                        continue

                    # Build human-readable confirmation message for stage rerun
                    additional_context = response_payload.get("additional_context", "")
                    if normalized_response == "approved":
                        confirm_msg = f"User approved rerun of stage '{stage_name}'"
                    elif normalized_response == "declined":
                        confirm_msg = f"User chose to skip stage '{stage_name}' (already completed)"
                    elif normalized_response == "user_input":
                        confirm_msg = f"User provided input for stage '{stage_name}': {additional_context}" if additional_context else f"User requested to provide input for stage '{stage_name}'"
                    else:
                        confirm_msg = f"User response for stage '{stage_name}': {raw_response}"

                    self._emit_lifecycle_hook(
                        state,
                        "hitl_response",
                        {
                            "response": normalized_response or raw_response,
                            "decision": (normalized_response or raw_response).capitalize() if normalized_response else raw_response,
                            "decision_status": "pending_final_decision" if normalized_response == "user_input" else ("resumed" if normalized_response == "approved" else "declined"),
                            "interaction_type": request_payload.get("interaction_type"),
                            "requested_at": request_payload.get("requested_at"),
                            "expires_at": request_payload.get("expires_at"),
                            "version": request_payload.get("version"),
                            "additional_context": additional_context,
                            "stage": stage_name,
                            "current_stage_index": current_index,
                            "confirmation_message": confirm_msg,
                        },
                    )

                    # Emit confirmation message to UI
                    self._emit_agent_log(state, confirm_msg, payload={
                        "type": "hitl_confirmation",
                        "interaction_type": "stage_rerun_confirmation",
                        "stage": stage_name,
                        "decision": normalized_response or raw_response,
                        "additional_context": additional_context,
                    })

                    if normalized_response == "approved":
                        print(f"{log_prefix}[HITL] User approved rerun of {stage_name}")
                        # Delete the completion marker to allow rerun
                        try:
                            marker_path.unlink()
                            print(f"{log_prefix}[OK] Deleted completion marker: {marker_path}")
                        except Exception as e:
                            print(f"{log_prefix}[WARN] Failed to delete marker: {e}")
                        force_rerun = True
                        break

                    if normalized_response == "declined":
                        print(f"{log_prefix}[HITL] User chose to skip {stage_name}")
                        stage_results = state.get("stage_results", {}).copy()
                        stage_results[stage_name] = {
                            "status": "skipped",
                            "stage": stage_name,
                            "reason": "User chose to skip (already completed)",
                            "marker_path": str(marker_path),
                        }
                        stages_executed = state.get("stages_executed", []) + [stage_name]
                        skip_end_time = datetime.now()
                        skip_duration_ms = int((skip_end_time - stage_start_time).total_seconds() * 1000)
                        self._emit_lifecycle_hook(
                            state,
                            "stage_completed",
                            {
                                "stage": stage_name,
                                "tool": tool_name,
                                "status": "skipped",
                                "reason": "User chose to skip (already completed)",
                                "current_stage_index": current_index,
                                "plan_size": len(plan),
                                "stages_executed": stages_executed,
                                "end_time": skip_end_time.isoformat(),
                                "duration_ms": skip_duration_ms,
                            },
                        )
                        return {
                            "stage_results": stage_results,
                            "stages_executed": stages_executed,
                            "current_stage_index": current_index + 1,
                            "error_info": None,
                            "error_retry_count": 0,
                        }

                    if normalized_response == "user_input":
                        context = (response_payload.get("additional_context") or "").strip()
                        self._emit_lifecycle_hook(
                            state,
                            "hitl_required",
                            {
                                **request_payload,
                                "decision_status": "waiting_for_human",
                                "message": "UserInput received. Please submit final decision as Approved or Declined.",
                                "additional_context": context,
                            },
                        )
                        await asyncio.sleep(1)
                        continue

                    self._emit_lifecycle_hook(
                        state,
                        "hitl_required",
                        {
                            **request_payload,
                            "decision_status": "waiting_for_human",
                            "message": "Invalid response. Expected Approved, Declined, or UserInput.",
                        },
                    )

                    # Unknown response, keep waiting
                    await asyncio.sleep(1)
            else:
                # No HITL resolver available, auto-skip
                print(f"{log_prefix}[WARN] No HITL resolver; auto-skipping completed stage")
                stage_results = state.get("stage_results", {}).copy()
                stage_results[stage_name] = {
                    "status": "skipped",
                    "stage": stage_name,
                    "reason": "Completion marker exists (no HITL resolver)",
                    "marker_path": str(marker_path),
                }
                stages_executed = state.get("stages_executed", []) + [stage_name]
                skip_end_time = datetime.now()
                skip_duration_ms = int((skip_end_time - stage_start_time).total_seconds() * 1000)
                self._emit_lifecycle_hook(
                    state,
                    "stage_completed",
                    {
                        "stage": stage_name,
                        "tool": tool_name,
                        "status": "skipped",
                        "reason": "Completion marker exists (no HITL resolver)",
                        "current_stage_index": current_index,
                        "plan_size": len(plan),
                        "stages_executed": stages_executed,
                        "end_time": skip_end_time.isoformat(),
                        "duration_ms": skip_duration_ms,
                    },
                )
                return {
                    "stage_results": stage_results,
                    "stages_executed": stages_executed,
                    "current_stage_index": current_index + 1,
                    "error_info": None,
                    "error_retry_count": 0,
                }

        try:
            # Set up log callback for Redis event streaming
            def stage_log_callback(message: str, level: str = "INFO", payload: dict = None):
                self._emit_agent_log(state, message, level=level, payload=payload)

            def stage_abort_checker():
                if callable(resolver):
                    return resolver("abort_check", {"stage": stage_name}, state) or {}
                return {}

            self.stage_executor.log_callback = stage_log_callback

            # Get optional tool arguments (e.g., "-stylus" for Innovus)
            tool_args = self.config_manager.get_stage_tool_args(stage_name)

            # Execute stage - scripts resolved from flow_config.yaml
            stage_result = await self.stage_executor.execute_stage(
                stage_name=stage_name,
                tool_name=tool_name,        # ← From flow_config.yaml
                tool_script=script_name,    # ← From flow_config.yaml
                tool_executable=None,       # ← Defaults to tool_name
                tool_args=tool_args,        # ← Optional args (e.g., "-stylus")
                force=force_rerun,          # ← Force rerun if user approved
                abort_checker=stage_abort_checker,
            )

            # Update results
            stage_results = state.get("stage_results", {}).copy()
            stage_results[stage_name] = stage_result

            updates = {
                "stage_results": stage_results,
                "error_info": None,
                "error_retry_count": 0,
            }

            if stage_result.get("status") == "aborted":
                abort_message = stage_result.get("error") or "Abort requested during stage execution"
                self._emit_lifecycle_hook(
                    state,
                    "abort_requested",
                    {"message": abort_message, "stage": stage_name},
                )
                updates["execution_status"] = "cancelled"
                updates["error_info"] = {
                    "category": "abort_requested",
                    "error_preview": abort_message,
                    "error": abort_message,
                    "stage_result": stage_result,
                }
                return updates

            if stage_result.get("status") == "success":
                print(f"{log_prefix}[OK] {stage_name} completed successfully")

                # Run skills-based validation if available
                validation_passed = True
                if self.validation_runner:
                    try:
                        # Set up UI callback with state context
                        def ui_callback(msg, payload):
                            self._emit_agent_log(state, msg, payload=payload)

                        self.validation_runner.ui_callback = ui_callback

                        # Emit validation started lifecycle event
                        self._emit_lifecycle_hook(
                            state,
                            "validation_started",
                            {"stage": stage_name, "tool": tool_name},
                        )

                        # Get work and log directories
                        work_dir = self.config_manager.get_stage_work_dir(stage_name)
                        log_dir = self.config_manager.get_stage_log_dir(stage_name)

                        # Run validation
                        validation_result = await self.validation_runner.validate_stage(
                            stage_name=stage_name,
                            stage_result=stage_result,
                            work_dir=work_dir,
                            log_dir=log_dir,
                        )

                        # Store validation result
                        updates["validation_results"] = state.get("validation_results", {})
                        updates["validation_results"][stage_name] = {
                            "passed": validation_result.passed,
                            "metrics": validation_result.metrics,
                            "issues": validation_result.issues,
                            "summary": validation_result.summary,
                        }

                        # Emit validation completed lifecycle event
                        self._emit_lifecycle_hook(
                            state,
                            "validation_completed",
                            {
                                "stage": stage_name,
                                "tool": tool_name,
                                "passed": validation_result.passed,
                                "metrics": validation_result.metrics,
                                "issues": validation_result.issues,
                                "summary": validation_result.summary,
                            },
                        )

                        if not validation_result.passed:
                            validation_passed = False
                            print(f"{log_prefix}[VALIDATE] {stage_name} validation FAILED")
                            updates["error_info"] = {
                                "category": "validation_failure",
                                "error_preview": f"Validation failed: {', '.join(validation_result.issues[:3])}",
                                "validation_result": {
                                    "metrics": validation_result.metrics,
                                    "issues": validation_result.issues,
                                },
                            }
                            updates["error_retry_count"] = state.get("error_retry_count", 0) + 1
                            return updates
                        else:
                            print(f"{log_prefix}[VALIDATE] {stage_name} validation PASSED")

                    except Exception as e:
                        print(f"{log_prefix}[VALIDATE] Validation error (continuing): {e}")
                        # Don't fail the stage if validation itself errors
                        validation_passed = True

                stages_executed = state.get("stages_executed", []) + [stage_name]
                updates["stages_executed"] = stages_executed
                stage_end_time = datetime.now()
                stage_duration_ms = int((stage_end_time - stage_start_time).total_seconds() * 1000)
                self._emit_lifecycle_hook(
                    state,
                    "stage_completed",
                    {
                        "stage": stage_name,
                        "tool": tool_name,
                        "current_stage_index": current_index,
                        "plan_size": len(plan),
                        "stages_executed": stages_executed,
                        "validation_passed": validation_passed,
                        "end_time": stage_end_time.isoformat(),
                        "duration_ms": stage_duration_ms,
                    },
                )
                # CRITICAL: Increment index for next stage
                updates["current_stage_index"] = current_index + 1
                # Clear retry count on success
                updates["error_retry_count"] = 0
            else:
                print(f"{log_prefix}[FAIL] {stage_name} failed: {stage_result.get('error', 'Unknown error')}")
                print(f"{log_prefix}  Log: {stage_result.get('log_file')}")
                print(f"{log_prefix}  Retry count: {state.get('error_retry_count', 0) + 1}/3")
                updates["error_info"] = {
                    "category": "execution_failure",
                    "error_preview": stage_result.get("error", "Execution failed"),
                    "stage_result": stage_result,
                }
                stage_end_time = datetime.now()
                stage_duration_ms = int((stage_end_time - stage_start_time).total_seconds() * 1000)
                self._emit_lifecycle_hook(
                    state,
                    "stage_failed",
                    {
                        "stage": stage_name,
                        "tool": tool_name,
                        "current_stage_index": current_index,
                        "plan_size": len(plan),
                        "error": stage_result.get("error", "Execution failed"),
                        "end_time": stage_end_time.isoformat(),
                        "duration_ms": stage_duration_ms,
                    },
                )
                # ✅ Increment retry count (not reset to 1)
                updates["error_retry_count"] = state.get("error_retry_count", 0) + 1

            return updates

        except Exception as e:
            print(f"{log_prefix}[FAIL] Exception in {stage_name}: {str(e)}")
            retry_count = state.get("error_retry_count", 0) + 1
            print(f"{log_prefix}  Retry count: {retry_count}/3")
            stage_end_time = datetime.now()
            stage_duration_ms = int((stage_end_time - stage_start_time).total_seconds() * 1000)
            self._emit_lifecycle_hook(
                state,
                "stage_failed",
                {
                    "stage": stage_name,
                    "tool": tool_name,
                    "current_stage_index": current_index,
                    "plan_size": len(plan),
                    "error": str(e),
                    "end_time": stage_end_time.isoformat(),
                    "duration_ms": stage_duration_ms,
                },
            )
            return {
                "error_info": {
                    "category": "exception",
                    "error_preview": str(e),
                    "error": str(e)
                },
                "error_retry_count": retry_count,
                "stages_failed": state.get("stages_failed", []) + [stage_name],
            }

    async def _debug_stage_node(self, state: FlowState) -> dict:
        """Debug failed stage using DebugAgent"""

        error_info = state.get("error_info")
        current_index = state.get("current_stage_index", 0)
        plan = state.get("plan", [])
        debug_mode = state.get("debug_mode", "interactive")
        log_prefix = self._log_prefix(state)

        if current_index >= len(plan):
            return {}

        stage_name = plan[current_index]
        run_id = state.get("run_id")

        # Get tool name for this stage
        try:
            tool_name, _ = self.config_manager.get_stage_tool_script(stage_name)
        except (ValueError, AttributeError):
            stage_defaults = self.STAGES.get(stage_name, {})
            tool_name = stage_defaults.get("tool", stage_name)

        print(f"\n{log_prefix}[DEBUG] Analyzing {stage_name} failure...")

        issue_kb_context: dict = {}
        issue_lookup = state.get("issue_kb_lookup")
        if callable(issue_lookup):
            try:
                stage_result = (error_info or {}).get("stage_result", {}) if isinstance(error_info, dict) else {}
                error_message = (
                    (stage_result.get("error") if isinstance(stage_result, dict) else None)
                    or (error_info or {}).get("error_preview")
                    or "Unknown stage failure"
                )
                lookup_payload = {
                    "stage": stage_name,
                    "error_message": error_message,
                    "project": getattr(self.config_manager, "project_name", None) if self.config_manager else None,
                    "block": getattr(self.config_manager, "block_name", None) if self.config_manager else None,
                    "run_id": run_id,
                }
                lookup_result = issue_lookup(lookup_payload) or {}
                if isinstance(lookup_result, dict):
                    issue_kb_context = lookup_result
                kb_items = issue_kb_context.get("items") if isinstance(issue_kb_context, dict) else None
                if isinstance(kb_items, list) and kb_items:
                    top_item = kb_items[0]
                    kb_msg = f"KB match found (top canonical_key={top_item.get('canonical_key')})"
                    self._emit_agent_log(
                        state,
                        kb_msg,
                        payload={
                            "stage": stage_name,
                            "run_id": run_id,
                            "kb_matches": len(kb_items),
                            "top_match": top_item,
                        },
                    )
            except Exception as kb_exc:
                self._emit_agent_log(
                    state,
                    f"Issue KB lookup skipped due to error: {kb_exc}",
                    level="WARN",
                    payload={"stage": stage_name, "run_id": run_id},
                )

        # Check for abort before starting debug
        resolver = state.get("hitl_resolver")
        if callable(resolver):
            abort_check = resolver("abort_check", {"stage": stage_name}, state) or {}
            if abort_check.get("abort_requested"):
                print(f"{log_prefix}[DEBUG] Abort requested, stopping debug")
                self._emit_lifecycle_hook(
                    state,
                    "abort_requested",
                    {"message": "Abort requested during debug", "stage": stage_name},
                )
                return {
                    "debug_result": {
                        "action": "abort",
                        "reason": "Abort requested by user",
                    },
                    "execution_status": "cancelled",
                }

        try:
            # Create log callback that emits to Redis
            def debug_log_callback(message: str, level: str = "INFO", payload: dict = None):
                self._emit_agent_log(state, message, level=level, payload=payload)

            # Create abort checker that uses hitl_resolver
            def debug_abort_checker():
                if callable(resolver):
                    return resolver("abort_check", {"stage": stage_name}, state) or {}
                return {}

            debug_result = await self.debug_agent.debug_stage(
                stage_name=stage_name,
                error_info={
                    **(error_info or {}),
                    "issue_kb_context": issue_kb_context,
                },
                mode=debug_mode,
                log_callback=debug_log_callback,
                abort_checker=debug_abort_checker,
            )

            file_edits = []
            if isinstance(debug_result, dict):
                result_payload = debug_result.get("result")
                if isinstance(result_payload, dict):
                    edits_payload = result_payload.get("file_edits")
                    if isinstance(edits_payload, list):
                        file_edits = edits_payload

            if file_edits:
                self._emit_lifecycle_hook(
                    state,
                    "file_edit",
                    {
                        "stage": stage_name,
                        "tool": tool_name,
                        "current_stage_index": current_index,
                        "plan_size": len(plan),
                        "file_edits": file_edits,
                        "message": f"Recorded {len(file_edits)} file edit(s) from debug fix application",
                    },
                )

            if isinstance(debug_result, dict) and debug_result.get("action") == "retry":
                # If this was a validation failure, we need to delete the completion marker
                # so the stage can be re-executed
                error_category = error_info.get("category") if isinstance(error_info, dict) else None
                if error_category == "validation_failure":
                    try:
                        marker_path = self.config_manager.get_complete_marker_path(stage_name)
                        if marker_path.exists():
                            marker_path.unlink()
                            print(f"{log_prefix}[DEBUG] Deleted completion marker for retry: {marker_path}")
                    except Exception as e:
                        print(f"{log_prefix}[WARN] Failed to delete completion marker: {e}")

                stage_result = (error_info or {}).get("stage_result", {}) if isinstance(error_info, dict) else {}
                error_message = (
                    (stage_result.get("error") if isinstance(stage_result, dict) else None)
                    or (error_info or {}).get("error_preview")
                    or "Execution failed"
                )
                fix_payload = debug_result.get("fix") if isinstance(debug_result.get("fix"), dict) else {}
                result_payload = debug_result.get("result") if isinstance(debug_result.get("result"), dict) else {}
                analysis_payload = debug_result.get("analysis") if isinstance(debug_result.get("analysis"), dict) else {}

                # Build debug_steps: How the agent identified the issue
                debug_steps_parts = []
                if analysis_payload.get("category"):
                    debug_steps_parts.append(f"Issue Category: {analysis_payload.get('category')}")
                if analysis_payload.get("root_cause"):
                    debug_steps_parts.append(f"Root Cause: {analysis_payload.get('root_cause')}")
                if analysis_payload.get("suggested_investigation"):
                    investigations = analysis_payload.get("suggested_investigation", [])
                    if investigations:
                        debug_steps_parts.append(f"Investigation Steps: {'; '.join(investigations)}")
                if fix_payload.get("rationale"):
                    debug_steps_parts.append(f"Fix Rationale: {fix_payload.get('rationale')}")
                debug_steps_text = "\n".join(debug_steps_parts) if debug_steps_parts else "Debug analysis completed"

                # Build resolution: Generic fix description applicable to any design with similar issue
                resolution_parts = []
                if fix_payload.get("title"):
                    resolution_parts.append(fix_payload.get("title"))
                if fix_payload.get("description"):
                    resolution_parts.append(fix_payload.get("description"))
                # Add file modifications summary for generic applicability
                modifications = fix_payload.get("modifications", [])
                if modifications:
                    mod_summary = []
                    for mod in modifications:
                        if isinstance(mod, dict):
                            op = mod.get("operation", "edit")
                            # Extract filename without full path for generic description
                            file_path = mod.get("file_path", "")
                            file_name = file_path.split("/")[-1] if file_path else "file"
                            if mod.get("new_content"):
                                # Extract the actual fix content (look for lines added)
                                content = mod.get("new_content", "")
                                # Get non-comment lines as the actual fix
                                fix_lines = [l.strip() for l in content.split("\n")
                                            if l.strip() and not l.strip().startswith("#")]
                                if fix_lines:
                                    mod_summary.append(f"In {file_name}: {'; '.join(fix_lines[:3])}")
                    if mod_summary:
                        resolution_parts.append("Applied fix: " + " | ".join(mod_summary))

                resolution_text = " - ".join(resolution_parts) if resolution_parts else "Applied debug fix and retried stage"

                # Determine issue category from analysis
                issue_category = analysis_payload.get("category", "tool")
                # Map debug agent categories to KB categories
                category_map = {
                    "timing_violation": "timing",
                    "design_rule_violation": "timing",
                    "syntax_error": "sdc",
                    "file_not_found": "rtl",
                    "configuration_error": "tool",
                    "constraint_conflict": "sdc",
                    "physical_design_error": "timing",
                    "convergence_failure": "optimization",
                    "memory_error": "tool",
                    "kb_reuse": "others",
                }
                mapped_category = category_map.get(issue_category, "others")

                # Get technology from TECH_NAME env var (set via sourceproj.env)
                technology = os.getenv("TECH_NAME", "").strip()
                if not technology:
                    # Fallback to alternative env var names
                    technology = os.getenv("TECHNOLOGY", os.getenv("TECH_NODE", "unknown")).strip()

                self._emit_lifecycle_hook(
                    state,
                    "issue_resolution_captured",
                    {
                        "stage": stage_name,
                        "tool": tool_name,
                        "current_stage_index": current_index,
                        "plan_size": len(plan),
                        "run_id": run_id,
                        "error": error_message,
                        "error_signature": error_message,
                        "summary": "Resolution captured from successful debug retry",
                        "resolution": resolution_text,
                        "debug_steps": debug_steps_text,
                        "file_edits": result_payload.get("file_edits") if isinstance(result_payload, dict) else [],
                        "issue_category": mapped_category,
                        "technology": technology,
                        "message": "Issue resolution persisted for KB reuse",
                        "fix_confidence": fix_payload.get("confidence"),
                        "analysis": analysis_payload,
                    },
                )

            # Update debug history
            debug_history = state.get("debug_history", {}).copy()
            if stage_name not in debug_history:
                debug_history[stage_name] = []

            debug_history[stage_name].append({
                "attempt": len(debug_history[stage_name]) + 1,
                "result": debug_result,
                "timestamp": datetime.now().isoformat(),
            })

            return {
                "debug_result": debug_result,
                "debug_history": debug_history,
            }

        except Exception as e:
            print(f"{log_prefix} ✗ Debug error: {str(e)}")
            return {
                "debug_result": {
                    "action": "abort",
                    "reason": f"Debug error: {str(e)}",
                }
            }

    async def _handle_result_node(self, state: FlowState) -> dict:
        """Final result processing for execute, analyze, and off-topic flows."""

        end_time = datetime.now().isoformat()
        log_prefix = self._log_prefix(state)
        action_type = state.get("action_type", "execute")

        # Handle off-topic questions (non-PD related queries)
        if action_type == "off_topic":
            off_topic_response = state.get(
                "off_topic_response",
                "I'm a Physical Design flow assistant. I can help you with:\n"
                "• Running stages (synthesis, placement, routing, etc.)\n"
                "• Analyzing results and reports\n"
                "• Checking timing, area, power metrics\n"
                "• Debugging flow issues\n\n"
                "Please ask a question related to your physical design workflow."
            )

            # Print to terminal
            print(f"\n{log_prefix}[INFO] Off-topic query detected")
            print(f"{log_prefix}  Response: {off_topic_response}")

            # Emit lifecycle event for Web UI
            self._emit_lifecycle_hook(
                state,
                "completed",
                {
                    "status": "completed",
                    "action_type": "off_topic",
                    "message": off_topic_response,
                    "end_time": end_time,
                },
            )

            # Also emit as agent_log for UI timeline display
            self._emit_agent_log(
                state,
                off_topic_response,
                level="INFO",
                payload={"type": "off_topic_response", "format": "text"},
            )

            return {
                "execution_status": "completed",
                "off_topic_response": off_topic_response,
                "end_time": end_time,
            }

        # Handle analysis results
        if action_type in ("analyze", "query"):
            analysis_result = state.get("analysis_result", {})
            analysis_target = state.get("analysis_target")
            analysis_type = state.get("analysis_type")

            status = analysis_result.get("status", "completed")
            print(f"\n{log_prefix}[RESULT] Analysis {status}")
            print(f"{log_prefix}  Target: {analysis_target or 'all'}")
            print(f"{log_prefix}  Type: {analysis_type or 'all'}")

            if analysis_result.get("summary"):
                print(f"{log_prefix}  Summary: {analysis_result['summary'][:200]}...")

            self._emit_lifecycle_hook(
                state,
                "completed",
                {
                    "status": "completed",
                    "action_type": action_type,
                    "analysis_target": analysis_target,
                    "analysis_type": analysis_type,
                    "analysis_summary": analysis_result.get("summary", ""),
                    "analysis_metrics": analysis_result.get("metrics", {}),
                    "end_time": end_time,
                },
            )

            # Print token usage summary
            token_tracker.print_summary()

            return {
                "execution_status": "completed",
                "end_time": end_time,
            }

        # Handle execution results
        stages_failed = state.get("stages_failed", [])
        stages_executed = state.get("stages_executed", [])

        status = state.get("execution_status")
        if status not in {"completed", "failed", "cancelled"}:
            status = "completed" if not stages_failed else "failed"

        print(f"\n{log_prefix}[RESULT] Flow {status}")
        print(f"{log_prefix}  Executed: {len(stages_executed)}")
        print(f"{log_prefix}  Failed: {len(stages_failed)}")

        if status == "completed":
            final_event = "completed"
        elif status == "cancelled":
            final_event = "abort_requested"
        else:
            final_event = "failed"
        self._emit_lifecycle_hook(
            state,
            final_event,
            {
                "status": status,
                "stages_executed": stages_executed,
                "stages_failed": stages_failed,
                "end_time": end_time,
            },
        )

        # Print token usage summary (internal only)
        token_tracker.print_summary()

        return {
            "execution_status": status,
            "end_time": end_time,
        }

    def _route_after_execution(self, state: FlowState) -> str:
        """
        Route after stage execution

        - If success and more stages → execute next stage
        - If success and done → handle_result
        - If failed → debug

        Note: current_stage_index is incremented by _execute_stage_node, not here
        """

        error_info = state.get("error_info")
        current_index = state.get("current_stage_index", 0)
        plan = state.get("plan", [])

        if error_info is None:
            # Success - check if more stages to execute
            if current_index < len(plan):
                # current_index already incremented by _execute_stage_node
                # Check if there are more stages after it
                return "execute_stage"
            else:
                # All stages completed
                return "handle_result"
        else:
            # Failed - go to debug
            return "debug"

    def _route_after_plan_confirmation(self, state: FlowState) -> str:
        """Route after HITL plan confirmation gate."""
        if state.get("plan_approved"):
            return "execute_stage"
        return "handle_result"

    def _route_after_debug(self, state: FlowState) -> str:
        """
        Route after debug stage

        - If retry → retry execute (same index)
        - If abort/max retries reached → handle_result

        Note: error_retry_count is incremented by _debug_stage_node, not here
        """

        debug_result = state.get("debug_result", {})
        action = debug_result.get("action", "abort")
        error_retry_count = state.get("error_retry_count", 0)
        max_retries = state.get("max_retries", self.max_retries)

        if action == "retry" and error_retry_count < max_retries:
            # Retry stage (same index, don't increment current_stage_index)
            return "execute_stage"
        else:
            # Stop retrying
            return "handle_result"

    def _initialize_components(
        self,
        project_name: str,
        user_name: str,
        block_name: str,
        rtl_tag: str,
        experiment_name: str,
    ):
        """
        Initialize configuration and execution components on-demand

        This is called during invoke() to set up ConfigManager, StageExecutor, and DebugAgent
        based on the request parameters.

        Also loads stage definitions from flow_config.yaml.

        Args:
            project_name: Project name
            user_name: User name
            block_name: Block name
            rtl_tag: RTL tag
            experiment_name: Experiment name
        """
        from ..config import create_config_manager

        print(f"\n[CONFIG] Initializing components for:")
        print(f"  Project: {project_name}")
        print(f"  User: {user_name}")
        print(f"  Block: {block_name}")
        print(f"  RTL Tag: {rtl_tag}")
        print(f"  Experiment: {experiment_name}")

        # Create ConfigManager (sources sourceproj.env and loads flow_config.yaml)
        self.config_manager = create_config_manager(
            project_name=project_name,
            user_name=user_name,
            block_name=block_name,
            rtl_tag=rtl_tag,
            run_tag=experiment_name,
        )

        # Load stages from flow_config.yaml
        configured_stages = self.config_manager.get_all_stages()
        configured_groups = self.config_manager.get_stage_groups()
        if configured_stages:
            self.STAGES = configured_stages
        else:
            print("[WARN] flow_config.yaml stages not found; using built-in default stage definitions")
        if configured_groups:
            self.STAGE_GROUPS = configured_groups

        print(f"[CONFIG] ✓ Using {len(self.STAGES)} stage definitions")

        # Create StageExecutor
        self.stage_executor = StageExecutor(self.config_manager)

        # Create DebugAgent
        self.debug_agent = DebugAgent(
            config_manager=self.config_manager,
            state_tracker=None,
            max_retry_attempts=self.max_retries,
        )

        # Create ValidationRunner for skills-based validation
        self.validation_runner = ValidationRunner(
            config_manager=self.config_manager,
            log_callback=lambda msg: print(msg),
            ui_callback=None,  # Will be set per-execution with state context
        )

        print(f"[OK] Components initialized")

    async def invoke(
        self,
        prompt: str,
        debug_mode: str = "interactive",
        user_id: Optional[str] = None,
        project_name: Optional[str] = None,
        user_name: Optional[str] = None,
        block_name: Optional[str] = None,
        rtl_tag: Optional[str] = None,
        experiment_name: Optional[str] = None,
        run_id: Optional[str] = None,
        job_id: Optional[str] = None,
        session_id: Optional[str] = None,
        lifecycle_hook: Optional[Any] = None,
        hitl_resolver: Optional[Callable[[str, dict, dict], Optional[dict]]] = None,
        issue_kb_lookup: Optional[Callable[[dict], Optional[dict]]] = None,
        require_plan_confirmation: bool = True,
    ) -> dict:
        """
        Execute flow with configuration parameters

        Configuration parameters (project_name, user_name, block_name, rtl_tag, experiment_name)
        are used to initialize ConfigManager, StageExecutor, and DebugAgent.

        Args:
            prompt: User prompt/command
            debug_mode: Debug mode ("interactive", "auto", "human-loop", "none")
            user_id: User identifier for multi-user support
            project_name: Project name for ConfigManager
            user_name: User name for ConfigManager
            block_name: Block name for ConfigManager
            rtl_tag: RTL tag for ConfigManager
            experiment_name: Experiment name for ConfigManager
            run_id: Execution identity used for lifecycle tracking
            job_id: Unique job identifier for tracking (from web UI)
            session_id: Web UI session identifier for tracking
            lifecycle_hook: Optional callback for lifecycle adapter updates
            hitl_resolver: Optional callback that returns human input/abort for HITL waits
            require_plan_confirmation: Require human confirmation before first stage execution

        Returns:
            Execution result dict with status, stages_executed, stages_failed, etc.
        """

        # Initialize components if configuration parameters provided
        if all([project_name, user_name, block_name, rtl_tag, experiment_name]):
            self._initialize_components(
                project_name=project_name,
                user_name=user_name,
                block_name=block_name,
                rtl_tag=rtl_tag,
                experiment_name=experiment_name,
            )
        elif not all([self.config_manager, self.stage_executor, self.debug_agent]):
            raise ValueError(
                "Must provide configuration parameters (project_name, user_name, block_name, "
                "rtl_tag, experiment_name) or initialize graph with existing components"
            )

        # Reset token tracker for new run
        token_tracker.reset()
        token_tracker.set_run_id(run_id or experiment_name or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}")

        # Initialize state
        state: FlowState = {
            "prompt": prompt,
            "debug_mode": debug_mode,
            "intent": None,
            "plan": [],
            "current_stage_index": 0,
            "stages_executed": [],
            "stages_failed": [],
            "stages_skipped": [],
            "stage_results": {},
            "error_info": None,
            "error_retry_count": 0,
            "max_retries": self.max_retries,
            "debug_history": {},
            "debug_result": None,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "run_id": run_id or experiment_name or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "user_id": user_id,
            "execution_status": "pending",
            "job_id": job_id,
            "session_id": session_id,
            "project": project_name,
            "block": block_name,
            "rtl_tag": rtl_tag,
            "experiment": experiment_name,
            "user_name": user_name,
            "lifecycle_hook": lifecycle_hook,
            "hitl_resolver": hitl_resolver,
            "issue_kb_lookup": issue_kb_lookup,
            "require_plan_confirmation": require_plan_confirmation,
            "awaiting_plan_confirmation": False,
            "plan_approved": False,
            "plan_confirmation_request": None,
            "plan_confirmation_response": None,
            "hitl_version": 0,
            "interaction_type": None,
            "decision_status": None,
            "pending_human_context": None,
            "last_applied_human_context": None,
        }

        # Run graph
        # (In production, would pass saver and thread_id for persistence)
        log_prefix = f"[session={session_id}][job={job_id}]" if session_id and job_id else ""
        try:
            result = await self.graph.ainvoke(state)
            return result
        except Exception as e:
            print(f"{log_prefix} ✗ Graph execution error: {str(e)}")
            self._emit_lifecycle_hook(
                state,
                "failed",
                {
                    "status": "failed",
                    "error": str(e),
                    "stages_executed": state.get("stages_executed", []),
                    "stages_failed": state.get("stages_failed", []),
                },
            )
            return {
                "status": "failed",
                "error": str(e),
                "stages_executed": state.get("stages_executed", []),
                "stages_failed": state.get("stages_failed", []),
                "job_id": job_id,
                "session_id": session_id,
            }

    def get_graph(self):
        """Get compiled graph (for visualization, testing)"""
        return self.graph
