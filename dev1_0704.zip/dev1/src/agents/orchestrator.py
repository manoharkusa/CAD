#!/usr/bin/env python3
"""
OrchestratorAgent - Orchestrates physical design flow execution

Uses Claude Agent SDK for intelligent NLP intent parsing and decision making.

Responsibilities:
1. Parse natural language prompts (Claude Agent SDK)
2. Understand user intent (with fallback pattern matching)
3. Create execution plans
4. Orchestrate stage execution
5. Handle dependencies and errors
6. Track progress and state
"""

import asyncio
import json
import io
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from enum import Enum

# Ensure output is not buffered for real-time logging
import functools
_print = print
print = functools.partial(_print, flush=True)

# Configure UTF-8 encoding for stdout
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

try:
    from claude_agent_sdk import query, ClaudeAgentOptions
except ImportError:
    print("[WARN] Claude Agent SDK not installed. Using fallback pattern matching.")
    query = None
    ClaudeAgentOptions = None

from ..config import ConfigManager
from ..executor import StageExecutor
from ..config.runtime_config import get_claude_model


class StageStatus(Enum):
    """Stage execution status"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class OrchestratorAgent:
    """
    Main orchestrator agent using Claude Agent SDK for intelligent orchestration

    Architecture:
    - Claude Agent SDK: Intelligent NLP intent parsing (with fallback pattern matching)
    - Intent → Execution plan (dependency resolution)
    - Plan → Stage execution via StageExecutor
    - Execution → Progress tracking and error handling

    Flow:
    1. User prompt → Claude Agent SDK intent parsing
    2. Intent → Create execution plan (with stage dependencies)
    3. Plan → Execute stages sequentially
    4. On failure → Trigger DebugAgent (if enabled)
    5. Result → Return execution summary
    """

    # Define all stages and their dependencies
    STAGES = {
        "syn": {
            "tool": "genus",
            "script": "tool_scripts/genus_syn.tcl",
            "depends_on": [],
            "description": "Synthesis with Genus",
        },
        "init_design": {
            "tool": "innovus",
            "script": "tool_scripts/design_init.tcl",
            "depends_on": ["syn"],
            "description": "PnR Init Design",
        },
        "floorplan": {
            "tool": "innovus",
            "script": "tool_scripts/floorplan.tcl",
            "depends_on": ["init_design"],
            "description": "PnR Floorplan",
        },
        "place": {
            "tool": "innovus",
            "script": "tool_scripts/place.tcl",
            "depends_on": ["floorplan"],
            "description": "PnR Place",
        },
        "cts": {
            "tool": "innovus",
            "script": "tool_scripts/cts.tcl",
            "depends_on": ["place"],
            "description": "PnR CTS",
        },
        "post_cts": {
            "tool": "innovus",
            "script": "tool_scripts/post_cts.tcl",
            "depends_on": ["cts"],
            "description": "PnR Post CTS",
        },
        "route": {
            "tool": "innovus",
            "script": "tool_scripts/route.tcl",
            "depends_on": ["post_cts"],
            "description": "PnR Route",
        },
        "postroute": {
            "tool": "innovus",
            "script": "tool_scripts/post_route.tcl",
            "depends_on": ["route"],
            "description": "PnR Post Route",
        },
        "chip_finish": {
            "tool": "innovus",
            "script": "tool_scripts/chip_finish.tcl",
            "depends_on": ["postroute"],
            "description": "PnR Chip Finish",
        },
        "qrc": {
            "tool": "quantus",
            "script": "tool_scripts/qrc/qrc.cmd",
            "depends_on": ["chip_finish"],
            "description": "RC Extraction",
        },
        "sta": {
            "tool": "tempus",
            "script": "tool_scripts/tempus/tempus.tcl",
            "depends_on": ["chip_finish", "qrc"],
            "description": "Static Timing Analysis",
        },
        "pv": {
            "tool": "calibre",
            "script": "tool_scripts/pv/pv_runset.tcl",
            "depends_on": ["chip_finish"],
            "description": "Physical Verification",
        },
        "lec": {
            "tool": "lec",
            "script": "tool_scripts/lec/lec.tcl",
            "depends_on": ["chip_finish"],
            "description": "Logical Equivalence Check",
        },
    }

    # Stage groupings
    STAGE_GROUPS = {
        "pnr": [
            "init_design",
            "floorplan",
            "place",
            "cts",
            "post_cts",
            "route",
            "postroute",
            "chip_finish",
        ],
        "signoff": ["qrc", "sta", "pv", "lec"],
        "flow": ["syn"] + ["init_design", "floorplan", "place", "cts", "post_cts", "route", "postroute", "chip_finish"],
    }

    def __init__(
        self,
        config_manager: ConfigManager,
        stage_executor: StageExecutor,
        state_tracker=None,
    ):
        """
        Initialize OrchestratorAgent

        Args:
            config_manager: ConfigManager for YAML file paths
            stage_executor: StageExecutor for running stages
            state_tracker: Optional StateTracker for state persistence
        """
        self.config_manager = config_manager
        self.stage_executor = stage_executor
        self.state_tracker = state_tracker

        # Claude Agent SDK available
        self.use_claude_sdk = query is not None

        # Execution state
        self.stage_status = {}  # {stage_name: Status}
        self.execution_history = []
        self.current_plan = []

        # DebugAgent (injected from main.py)
        self.debug_agent = None

    async def process_prompt(self, prompt: str, debug_mode: str = "interactive") -> Dict[str, Any]:
        """
        Main entry point: Process natural language prompt

        Args:
            prompt: User's natural language command
            debug_mode: "auto" | "interactive" | "human-loop"

        Returns:
            Execution result dictionary
        """
        print(f"\n[PROMPT] {prompt}")
        print("=" * 70)

        # Step 1: Parse intent
        intent = await self._parse_intent(prompt)
        print(f"\n[INTENT] {intent['reasoning']}")
        print(f"[CONFIDENCE] {intent['confidence']:.0%}")

        # Step 2: Create execution plan
        plan = self._create_execution_plan(intent)
        print(f"\n[PLAN] {' -> '.join(plan)}")

        # Step 3: Execute plan
        result = await self._execute_plan(plan, debug_mode)

        return result

    async def _parse_intent(self, prompt: str) -> Dict[str, Any]:
        """
        Use Claude Agent SDK to understand user intent (with fallback)

        Returns dict with:
        - action: run | rerun | restart | check | clean | etc.
        - stages: which stages to execute
        - start_from: which stage to start from
        - skip_completed: whether to skip completed stages
        - confidence: confidence in parsing (0-1)
        - reasoning: explanation of intent
        """
        intent_prompt = f"""
You are a physical design flow orchestrator. Analyze the user's intent and extract:

1. **Action**: What the user wants to do
   - "run": Execute stages from the beginning
   - "rerun": Re-execute all specified stages (clear completion markers)
   - "restart": Restart from a specific stage (clean everything before it)
   - "check": Check current status
   - "clean": Clean all outputs
   - "resume": Continue from where it stopped
   - "debug": Run with debugging

2. **Stages**: Which stages to execute
   - Specific stages: "syn place route"
   - Groups: "pnr" (all place/route), "signoff" (sta/pv/lec)
   - All: "flow", "all"
   - Default: current action defaults

3. **Start From**: Which stage to start from (if restarting/resuming)
   - Only applicable for restart/resume actions
   - Example: "restart from place" means: clean pnr, start from place

4. **Options**:
   - skip_completed: Should skip already completed stages
   - force_clean: Force clean before running
   - enable_ai: Enable AI-assisted debugging

Available stages:
- Synthesis: syn
- PnR: init_design, floorplan, place, cts, post_cts, route, postroute, chip_finish
- Post-design: qrc, sta, pv, lec
- Groups: pnr (all PnR), signoff (qrc+sta+pv+lec), flow (syn+pnr+signoff)

User prompt: "{prompt}"

Respond in JSON format only:
{{
    "action": "run|rerun|restart|check|clean|resume|debug",
    "stages": ["stage1", "stage2"],
    "start_from": "stage_name or null",
    "skip_completed": true/false,
    "force_clean": true/false,
    "enable_ai": true/false,
    "confidence": 0.95,
    "reasoning": "brief explanation of what user wants"
}}
"""

        # Try Claude Agent SDK first
        if self.use_claude_sdk and ClaudeAgentOptions is not None:
            try:
                # Configure Claude Agent SDK for simple text generation
                # with permission_mode to bypass tool prompts
                options = ClaudeAgentOptions(
                    model=get_claude_model(),
                    permission_mode="bypassPermissions"
                )

                # Query with Claude Agent SDK with options
                text = ""
                message_count = 0
                async for message in query(prompt=intent_prompt, options=options):
                    message_count += 1
                    message_type = type(message).__name__

                    # Debug: Print message type only
                    # (Detailed debugging was used to understand structure)
                    # print(f"  Message {message_count}: {message_type}")

                    # Extract text from AssistantMessage or ResultMessage
                    if message_type == "AssistantMessage":
                        if hasattr(message, 'content') and message.content:
                            # AssistantMessage.content is a list of TextBlock objects
                            if isinstance(message.content, list):
                                for block in message.content:
                                    # TextBlock objects have .text attribute
                                    if hasattr(block, 'text') and block.text:
                                        block_text = block.text
                                        # Remove markdown code block markers if present
                                        if block_text.startswith("```"):
                                            # Remove opening ```json or similar
                                            lines = block_text.split('\n')
                                            lines = [l for l in lines if not l.startswith("```")]
                                            block_text = '\n'.join(lines)
                                        text += block_text
                                    elif isinstance(block, dict) and 'text' in block:
                                        text += block['text']
                    elif message_type == "ResultMessage":
                        if hasattr(message, 'output') and message.output:
                            text += str(message.output)
                        elif hasattr(message, 'text') and message.text:
                            text += message.text
                    elif message_type == "SystemMessage":
                        # Skip system messages
                        pass

                if message_count == 0:
                    print(f"[WARN] Claude Agent SDK returned no messages")

                # Parse JSON
                text = text.strip()
                if text:
                    intent = json.loads(text)
                    print(f"[INTENT] Using Claude Agent SDK")
                    return intent
                else:
                    print(f"[WARN] Claude Agent SDK returned empty response")
            except json.JSONDecodeError as e:
                print(f"[WARN] Claude Agent SDK intent parsing failed (JSON): {e}")
                # Fall through to fallback
            except Exception as e:
                print(f"[WARN] Claude Agent SDK intent parsing failed: {e}")
                # Fall through to fallback

        # Fallback to pattern matching
        return self._parse_intent_fallback(prompt)

    def _parse_intent_fallback(self, prompt: str) -> Dict[str, Any]:
        """Fallback pattern-based intent parsing"""
        prompt_lower = prompt.lower()

        # Detect action
        if "rerun" in prompt_lower or "redo" in prompt_lower:
            action = "rerun"
        elif "restart" in prompt_lower or "from" in prompt_lower:
            action = "restart"
        elif "resume" in prompt_lower:
            action = "resume"
        elif "check" in prompt_lower or "status" in prompt_lower:
            action = "check"
        elif "clean" in prompt_lower or "remove" in prompt_lower:
            action = "clean"
        elif "debug" in prompt_lower:
            action = "debug"
        else:
            action = "run"

        # Detect scope
        stages = []
        if "all" in prompt_lower or "complete" in prompt_lower or "flow" in prompt_lower:
            stages = list(self.STAGES.keys())
        elif "pnr" in prompt_lower:
            stages = self.STAGE_GROUPS["pnr"]
        elif "signoff" in prompt_lower:
            stages = self.STAGE_GROUPS["signoff"]
        else:
            # Look for individual stage names
            for stage_name in self.STAGES.keys():
                if stage_name in prompt_lower:
                    stages.append(stage_name)
            if not stages:
                stages = ["syn"]  # default

        # Detect start stage
        start_from = None
        for stage_name in self.STAGES.keys():
            if f"from {stage_name}" in prompt_lower:
                start_from = stage_name
                break

        return {
            "action": action,
            "stages": stages,
            "start_from": start_from,
            "skip_completed": action != "rerun",
            "force_clean": action == "restart",
            "enable_ai": "ai" in prompt_lower or "auto" in prompt_lower,
            "confidence": 0.7,
            "reasoning": "Fallback pattern matching",
        }

    def _create_execution_plan(self, intent: Dict[str, Any]) -> List[str]:
        """
        Create execution plan based on intent

        Handles:
        - Dependencies between stages
        - Skip completed stages
        - Start from specific stage
        - Clean operations
        """
        action = intent.get("action", "run")
        stages = intent.get("stages", [])
        start_from = intent.get("start_from")
        skip_completed = intent.get("skip_completed", True)
        force_clean = intent.get("force_clean", False)

        plan = []

        # Handle special actions
        if action == "check":
            return ["_check_status"]

        if action == "clean":
            return ["_clean_all"]

        # For restart action, add clean step
        if action == "restart" and force_clean and start_from:
            plan.append(f"_clean_from:{start_from}")

        # For rerun, add setup step
        if action == "rerun":
            plan.append("_clear_completion_markers")

        # Filter stages based on start_from
        if start_from:
            stage_list = list(self.STAGES.keys())
            try:
                start_idx = stage_list.index(start_from)
                stages = [s for s in stage_list[start_idx:] if s in stages]
            except ValueError:
                pass

        # Add stages with dependency resolution
        # Note: Working directories are pre-created by external setup script
        added = set()

        for stage in stages:
            if stage not in added:
                self._add_stage_with_deps(plan, stage, added, skip_completed)

        return plan

    def _add_stage_with_deps(self, plan: List[str], stage: str, added: set, skip_completed: bool):
        """Recursively add stage with its dependencies"""
        if stage not in self.STAGES or stage in added:
            return

        stage_info = self.STAGES[stage]

        # Add dependencies first
        for dep in stage_info.get("depends_on", []):
            if dep not in added:
                self._add_stage_with_deps(plan, dep, added, skip_completed)

        # Check if should skip
        if skip_completed and self.stage_status.get(stage) == StageStatus.COMPLETED.value:
            plan.append(f"_skip:{stage}")
            added.add(stage)
            return

        # Add the stage
        plan.append(stage)
        added.add(stage)

    async def _execute_plan(self, plan: List[str], debug_mode: str) -> Dict[str, Any]:
        """Execute the planned stages"""
        print(f"\n[EXECUTION] Starting execution plan...")
        print(f"[DEBUG MODE] {debug_mode}")
        print("=" * 70)

        start_time = datetime.now()
        execution_result = {
            "status": "completed",
            "stages_executed": [],
            "stages_failed": [],
            "stages_skipped": [],
            "start_time": start_time.isoformat(),
        }

        # Note: Working directories are pre-created by external setup script
        # Execute plan
        for step in plan:
            # Handle special steps
            if step.startswith("_"):
                await self._handle_special_step(step)
                continue

            # Execute stage with retry loop for debugging
            max_retries = 3
            stage_succeeded = False

            for attempt in range(max_retries):
                print(f"\n[STAGE] Executing: {step} (attempt {attempt + 1}/{max_retries})")
                self.stage_status[step] = StageStatus.IN_PROGRESS.value

                try:
                    stage_info = self.STAGES[step]
                    result = await self.stage_executor.execute_stage(
                        stage_name=step,
                        tool_name=stage_info["tool"],
                        tool_script=stage_info["script"],
                        tool_executable=stage_info["tool"],
                    )

                    if result["status"] == "success":
                        print(f"[OK] {step} completed successfully")
                        self.stage_status[step] = StageStatus.COMPLETED.value
                        execution_result["stages_executed"].append(step)
                        stage_succeeded = True
                        break
                    else:
                        print(f"[FAIL] {step} failed (attempt {attempt + 1}/{max_retries})")
                        self.stage_status[step] = StageStatus.FAILED.value

                        # Trigger DebugAgent on failure
                        if self.debug_agent and debug_mode != "none":
                            debug_result = await self.debug_agent.debug_stage(
                                stage_name=step,
                                error_info=result,
                                mode=debug_mode,
                            )

                            if debug_result.get("action") == "retry":
                                # Fix applied, retry stage
                                print(f"[DEBUG] Fix applied, retrying {step}...")
                                continue
                            elif debug_result.get("action") == "human_intervention":
                                # Human needed, stop execution
                                print(f"[DEBUG] Human intervention needed")
                                execution_result["stages_failed"].append(step)
                                stage_succeeded = False
                                break
                            else:  # abort
                                # Stop execution
                                print(f"[DEBUG] Debug aborted")
                                execution_result["stages_failed"].append(step)
                                stage_succeeded = False
                                break
                        else:
                            # No debugging, fail immediately
                            execution_result["stages_failed"].append(step)
                            stage_succeeded = False
                            break

                except Exception as e:
                    print(f"[FAIL] Exception in {step}: {str(e)}")
                    self.stage_status[step] = StageStatus.FAILED.value
                    execution_result["stages_failed"].append(step)
                    stage_succeeded = False
                    break

            # If stage failed after all retries, stop execution
            if not stage_succeeded:
                break

        # Update final status
        if execution_result["stages_failed"]:
            execution_result["status"] = "failed"
        else:
            execution_result["status"] = "completed"

        execution_result["end_time"] = datetime.now().isoformat()
        execution_result["duration"] = (
            datetime.fromisoformat(execution_result["end_time"])
            - datetime.fromisoformat(execution_result["start_time"])
        ).total_seconds()

        self.execution_history.append(execution_result)

        return execution_result

    async def _handle_special_step(self, step: str):
        """Handle special steps like setup, clean, skip"""
        if step == "_setup":
            print("[SETUP] Directories ready")

        elif step == "_check_status":
            print("\n[STATUS] Current execution status:")
            print("=" * 70)
            for stage_name, status in self.stage_status.items():
                symbol = {
                    "completed": "[OK]",
                    "failed": "[X]",
                    "in_progress": "[*]",
                    "pending": "[-]",
                }.get(status, "[?]")
                print(f"  {symbol} {stage_name:20s} {status}")
            print("=" * 70)

        elif step == "_clean_all":
            print("[CLEAN] Cleaning all run directories")
            # Would clean directories here
            self.stage_status = {}

        elif step == "_clear_completion_markers":
            print("[SETUP] Clearing completion markers for rerun")
            # Would clear markers here

        elif step.startswith("_skip:"):
            stage = step.split(":")[-1]
            print(f"[SKIP] {stage} already completed, skipping")
            self.stage_status[stage] = StageStatus.SKIPPED.value

        elif step.startswith("_clean_from:"):
            stage = step.split(":")[-1]
            print(f"[CLEAN] Cleaning from {stage}")

    def get_status(self) -> Dict[str, Any]:
        """Get current execution status"""
        return {
            "stage_status": self.stage_status,
            "execution_history": self.execution_history,
        }

    def get_stage_log(self, stage_name: str) -> Optional[str]:
        """Get log content for a stage"""
        return self.stage_executor.get_stage_log(stage_name)
