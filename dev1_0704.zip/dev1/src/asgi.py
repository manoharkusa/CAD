"""ASGI entrypoint for running dev1 API with uvicorn."""

from __future__ import annotations

import os

from .main import create_app


def _env(name: str, default: str) -> str:
    value = os.getenv(name, default)
    return value.strip() if isinstance(value, str) else default


app = create_app(
    project_name=_env("PROJECT_NAME", "demo_project"),
    user_name=_env("USER_NAME", "demo_user"),
    block_name=_env("BLOCK_NAME", "demo_block"),
    rtl_tag=_env("RTL_TAG", "demo_rtl"),
    run_tag=_env("RUN_TAG", "demo_run"),
)
