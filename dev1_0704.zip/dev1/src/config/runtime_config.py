"""Runtime infrastructure configuration for lifecycle adapters."""

from __future__ import annotations

import os
import socket
import json
from dataclasses import dataclass
from typing import Dict


# Default Claude model for Agent SDK and direct API calls
DEFAULT_CLAUDE_MODEL = "claude-sonnet-4-20250514"


def get_claude_model() -> str:
    """Get the Claude model from environment variable or use default.

    Environment variable: CLAUDE_MODEL
    Default: claude-sonnet-4-20250514

    Examples:
        - claude-sonnet-4-20250514 (Sonnet 4 - fast, cost-effective)
        - claude-opus-4-20250514 (Opus 4 - most capable)
        - claude-3-5-sonnet-20241022 (Sonnet 3.5)
        - claude-3-opus-20240229 (Opus 3)
    """
    return os.getenv("CLAUDE_MODEL", DEFAULT_CLAUDE_MODEL)


@dataclass(frozen=True)
class RuntimeConfig:
    postgres_uri: str
    redis_url: str
    queue_backend: str
    redis_queue_key: str
    redis_stream_key: str
    redis_stream_group: str
    redis_stream_consumer: str
    redis_stream_claim_idle_ms: int
    redis_stream_claim_count: int
    max_active_runs: int
    active_runs_key: str
    active_runs_class_prefix: str
    admission_defer_seconds: int
    max_active_runs_per_class: Dict[str, int]
    max_queue_attempts: int
    max_admission_defers: int
    redis_dlq_key: str
    redis_ops_metrics_key: str

    @classmethod
    def from_env(cls) -> "RuntimeConfig":
        postgres_user = os.getenv("POSTGRES_USER", "postgres")
        postgres_password = os.getenv("POSTGRES_PASSWORD", "password")
        postgres_host = os.getenv("POSTGRES_HOST", "localhost")
        postgres_port = int(os.getenv("POSTGRES_PORT", 5432))
        postgres_db = os.getenv("POSTGRES_DB", "synthesis_agent")

        default_postgres_uri = (
            f"postgresql+psycopg2://{postgres_user}:{postgres_password}@"
            f"{postgres_host}:{postgres_port}/{postgres_db}"
        )

        redis_host = os.getenv("REDIS_HOST", "localhost")
        redis_port = int(os.getenv("REDIS_PORT", 6379))
        redis_db = int(os.getenv("REDIS_DB", 0))
        redis_password = os.getenv("REDIS_PASSWORD")
        default_redis_url = (
            f"redis://{'' if not redis_password else f':{redis_password}@'}"
            f"{redis_host}:{redis_port}/{redis_db}"
        )

        queue_backend = os.getenv("JOB_QUEUE_BACKEND", "list").strip().lower()
        if queue_backend not in {"list", "stream"}:
            queue_backend = "list"

        consumer_base = os.getenv("REDIS_STREAM_CONSUMER", "worker").strip() or "worker"
        stream_consumer_default = f"{consumer_base}-{socket.gethostname()}-{os.getpid()}"

        class_quota_raw = os.getenv("MAX_ACTIVE_RUNS_PER_CLASS", "{}")
        try:
            class_quota_json = json.loads(class_quota_raw) if class_quota_raw else {}
        except Exception:
            class_quota_json = {}
        max_active_runs_per_class = {
            str(k): max(0, int(v))
            for k, v in (class_quota_json.items() if isinstance(class_quota_json, dict) else [])
        }

        return cls(
            postgres_uri=os.getenv("POSTGRES_URI", default_postgres_uri),
            redis_url=os.getenv("REDIS_URL", default_redis_url),
            queue_backend=queue_backend,
            redis_queue_key=os.getenv("REDIS_QUEUE_KEY", "jobs:queue"),
            redis_stream_key=os.getenv("REDIS_STREAM_KEY", "jobs:stream"),
            redis_stream_group=os.getenv("REDIS_STREAM_GROUP", "lifecycle-workers"),
            redis_stream_consumer=stream_consumer_default,
            redis_stream_claim_idle_ms=max(1000, int(os.getenv("REDIS_STREAM_CLAIM_IDLE_MS", "60000"))),
            redis_stream_claim_count=max(1, int(os.getenv("REDIS_STREAM_CLAIM_COUNT", "5"))),
            max_active_runs=max(0, int(os.getenv("MAX_ACTIVE_RUNS", "0"))),
            active_runs_key=os.getenv("REDIS_ACTIVE_RUNS_KEY", "jobs:active_runs"),
            active_runs_class_prefix=os.getenv("REDIS_ACTIVE_RUNS_CLASS_PREFIX", "jobs:active_runs:class"),
            admission_defer_seconds=max(0, int(os.getenv("ADMISSION_DEFER_SECONDS", "2"))),
            max_active_runs_per_class=max_active_runs_per_class,
            max_queue_attempts=max(1, int(os.getenv("MAX_QUEUE_ATTEMPTS", "3"))),
            max_admission_defers=max(1, int(os.getenv("MAX_ADMISSION_DEFERS", "20"))),
            redis_dlq_key=os.getenv("REDIS_DLQ_KEY", "jobs:dlq"),
            redis_ops_metrics_key=os.getenv("REDIS_OPS_METRICS_KEY", "jobs:ops:metrics"),
        )
