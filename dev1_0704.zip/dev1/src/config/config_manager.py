#!/usr/bin/env python3
"""
ConfigManager - Configuration and environment management

Responsibilities:
1. Source sourceproj.env for environment variables
2. Load flow_config.yaml for stage definitions
3. Manage paths (run directory, work dirs, log dirs)
4. Provide tool script paths from ENV_SCRIPTS
"""

import os
import shutil
import subprocess
import yaml
from pathlib import Path
from typing import Dict, Optional, Tuple


class ConfigManager:
    """
    Configuration manager that:
    - Sources sourceproj.env for environment variables
    - Loads flow_config.yaml for stage-to-tool mappings
    - Manages directory paths
    """

    def __init__(
        self,
        project_name: str,
        user_name: str,
        block_name: str,
        rtl_tag: str,
        run_tag: str,
        proj_root: str | None = None,
    ):
        """
        Initialize ConfigManager

        Args:
            project_name: Project name (e.g., "semicon_19-02")
            user_name: User name (e.g., "bharath")
            block_name: Block name (e.g., "aes_cipher_top")
            rtl_tag: RTL tag (e.g., "bronze_v2")
            run_tag: Run/experiment tag (e.g., "run2")
            proj_root: Project root directory (default: /proj5/projects)
        """
        self.proj_root = proj_root or os.environ.get("PD_PROJECTS_ROOT", "/proj5/projects")
        self.project_name = project_name
        self.user_name = user_name
        self.block_name = block_name
        self.rtl_tag = rtl_tag
        self.run_tag = run_tag

        # Build run directory path
        self.run_dir = Path(
            f"{self.proj_root}/{project_name}/pd/users/{user_name}/"
            f"{block_name}/{rtl_tag}/{run_tag}"
        )

        # Environment file paths
        self.env_file = self.run_dir / "sourceproj.env"

        # Source sourceproj.env to load environment variables
        self._source_env_file()

        # Get tools root from ENV_SCRIPTS
        env_scripts_value = os.environ.get("ENV_SCRIPTS", "")
        self.tools_root = Path(env_scripts_value) if env_scripts_value else Path("")

        print(f"[CONFIG] ENV_SCRIPTS from environment: '{env_scripts_value}'")
        print(f"[CONFIG] tools_root Path object: {self.tools_root}")

        if env_scripts_value and self.tools_root.exists():
            print(f"[CONFIG] ✓ Tools root verified: {self.tools_root}")
        elif not env_scripts_value:
            print(f"[WARN] ⚠️ ENV_SCRIPTS not set in environment!")
            print(f"[WARN]    Check that sourceproj.env contains ENV_SCRIPTS variable")
        else:
            print(f"[WARN] ⚠️ ENV_SCRIPTS path does not exist: {self.tools_root}")
            print(f"[WARN]    Tools scripts will not be found")

        # Flow config file locations (priority order):
        # 1. Base config: {ENV_SCRIPTS}/flow_config.yaml (global defaults)
        # 2. Local override: {BLOCK_INPUTS}/flow_config.yaml (block-level overrides)
        self.flow_config_file_base = self.tools_root / "flow_config.yaml" if self.tools_root else None

        block_inputs = os.environ.get("BLOCK_INPUTS", "")
        self.block_inputs_dir = Path(block_inputs) if block_inputs else None
        self.flow_config_file_local = self.block_inputs_dir / "flow_config.yaml" if self.block_inputs_dir else None

        if self.block_inputs_dir:
            print(f"[CONFIG] BLOCK_INPUTS: {self.block_inputs_dir}")
        else:
            print(f"[WARN] BLOCK_INPUTS not set in environment")

        # Load flow configuration from YAML (with merge support)
        self.flow_config = self._load_flow_config()

    def _source_env_file(self) -> None:
        """Source sourceproj.env file to load all environment variables

        Handles both bash and tcsh format files:
        - Detects file format from shebang or content
        - Variable expansion and substitution
        - Comments (# or set)
        - Shell logic and conditional statements
        """
        if not self.env_file.exists():
            print(f"[WARN] Environment file not found: {self.env_file}")
            return

        print(f"[CONFIG] Sourcing environment file: {self.env_file}")

        try:
            # Read first line to detect shell format
            with open(self.env_file, 'r') as f:
                first_line = f.readline().strip()

            is_tcsh = 'tcsh' in first_line or 'csh' in first_line

            print(f"[CONFIG] Detected format: {'tcsh' if is_tcsh else 'bash'}")

            if os.name != "posix":
                print("[CONFIG] Non-POSIX environment detected; using fallback env parser")
                self._source_env_file_fallback()
                return

            if is_tcsh:
                # Use tcsh to source the file
                if shutil.which("tcsh") is None:
                    print("[WARN] tcsh not available; using fallback env parser")
                    self._source_env_file_fallback()
                    return
                cmd = f"tcsh -c 'source {self.env_file} && env'"
                executable = "/bin/tcsh"
            else:
                # Use bash to source the file
                if shutil.which("bash") is None:
                    print("[WARN] bash not available; using fallback env parser")
                    self._source_env_file_fallback()
                    return
                cmd = f"source {self.env_file} && env"
                executable = "/bin/bash"

            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                executable=executable,
            )

            if result.returncode != 0:
                print(f"[ERROR] Failed to source {self.env_file}")
                print(f"[ERROR] stderr: {result.stderr}")
                print("[WARN] Falling back to direct env parsing")
                self._source_env_file_fallback()
                return

            # Parse the environment variables
            sourced_env = {}
            for line in result.stdout.strip().split('\n'):
                if '=' in line:
                    key, value = line.split('=', 1)
                    sourced_env[key] = value

            # Set all sourced variables in os.environ
            os.environ.update(sourced_env)

            print(f"[CONFIG] ✓ Sourced {len(sourced_env)} environment variables")

            # Show important variables
            important_vars = [
                "ENV_SCRIPTS",
                "PROJ_NAME",
                "PD_PROJECTS_ROOT",
                "BLOCK_NAME",
                "RTL_TAG",
                "EXP_NAME",
            ]

            for var in important_vars:
                value = os.environ.get(var)
                if value:
                    print(f"[CONFIG]   {var}: {value}")

        except Exception as e:
            print(f"[ERROR] Exception while sourcing environment file: {e}")
            print("[WARN] Falling back to direct env parsing")
            self._source_env_file_fallback()

    def _source_env_file_fallback(self) -> None:
        """Parse shell-style env file directly for cross-platform compatibility."""
        sourced_count = 0

        with open(self.env_file, "r", encoding="utf-8") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line or line.startswith("#"):
                    continue

                if line.startswith("export "):
                    line = line[len("export "):].strip()
                elif line.startswith("setenv "):
                    parts = line.split(maxsplit=2)
                    if len(parts) == 3:
                        key, value = parts[1], parts[2]
                        value = value.strip().strip('"').strip("'")
                        if key and key not in os.environ:
                            os.environ[key] = value
                            sourced_count += 1
                    continue

                if "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if not key:
                    continue

                if key not in os.environ:
                    os.environ[key] = value
                    sourced_count += 1

        print(f"[CONFIG] ✓ Fallback parser loaded {sourced_count} environment variables")

    def _load_flow_config(self) -> Dict:
        """Load flow configuration from flow_config.yaml

        Priority order:
        1. Base config from {ENV_SCRIPTS}/flow_config.yaml (global defaults)
        2. Local overrides from {BLOCK_INPUTS}/flow_config.yaml (block-level)

        Local config is deep-merged with base config, allowing
        block-specific overrides while inheriting global defaults.
        """
        config = {}

        # Step 1: Load base config from ENV_SCRIPTS (global defaults)
        if self.flow_config_file_base and self.flow_config_file_base.exists():
            print(f"[CONFIG] Loading base flow config: {self.flow_config_file_base}")
            try:
                with open(self.flow_config_file_base, 'r') as f:
                    config = yaml.safe_load(f) or {}
                stages_count = len(config.get('stages', {}))
                print(f"[CONFIG] ✓ Loaded {stages_count} stages from ENV_SCRIPTS")
            except Exception as e:
                print(f"[ERROR] Failed to load base flow_config.yaml: {e}")
        else:
            print(f"[WARN] Base flow config not found: {self.flow_config_file_base}")

        # Step 2: Load and merge local overrides from BLOCK_INPUTS (if exists)
        if self.flow_config_file_local and self.flow_config_file_local.exists():
            print(f"[CONFIG] Loading local overrides: {self.flow_config_file_local}")
            try:
                with open(self.flow_config_file_local, 'r') as f:
                    local_config = yaml.safe_load(f) or {}

                # Deep merge local config into base config
                config = self._deep_merge(config, local_config)
                print(f"[CONFIG] ✓ Merged local overrides from BLOCK_INPUTS")

            except Exception as e:
                print(f"[WARN] Failed to load BLOCK_INPUTS flow_config.yaml: {e}")
        else:
            print(f"[CONFIG] No BLOCK_INPUTS overrides found (using ENV_SCRIPTS config only)")

        if not config:
            print(f"[WARN] No flow configuration loaded!")

        return config

    def _deep_merge(self, base: Dict, override: Dict) -> Dict:
        """Deep merge override dict into base dict

        - Dictionaries are recursively merged
        - Lists and other values are replaced
        - Override values take precedence

        Args:
            base: Base dictionary
            override: Override dictionary

        Returns:
            Merged dictionary
        """
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                # Recursively merge nested dicts
                result[key] = self._deep_merge(result[key], value)
            else:
                # Replace value
                result[key] = value

        return result

    def get_stage_tool_script(self, stage_name: str) -> Tuple[str, str]:
        """Get tool and script name for a stage from flow_config.yaml

        Args:
            stage_name: e.g., "syn", "place"

        Returns:
            Tuple of (tool_name, script_name)
            Example: ("genus", "syn.tcl")
        """
        stages = self.flow_config.get("stages", {})
        stage_info = stages.get(stage_name)

        if not stage_info:
            raise ValueError(f"Stage '{stage_name}' not found in flow_config.yaml")

        tool = stage_info.get("tool")
        script = stage_info.get("script")

        if not tool or not script:
            raise ValueError(
                f"Stage '{stage_name}' missing tool or script in flow_config.yaml"
            )

        return tool, script

    def get_stage_tool_args(self, stage_name: str) -> Optional[str]:
        """Get tool arguments for a stage from flow_config.yaml

        Args:
            stage_name: e.g., "place", "route"

        Returns:
            Tool arguments string (e.g., "-stylus") or None
        """
        stages = self.flow_config.get("stages", {})
        stage_info = stages.get(stage_name, {})
        return stage_info.get("tool_args")

    def get_tool_script_path(self, tool_name: str, script_name: str) -> Path:
        """Get path to TCL script from ENV_SCRIPTS

        Args:
            tool_name: e.g., "genus", "innovus"
            script_name: e.g., "syn.tcl", "place.tcl" (already includes extension)

        Returns:
            Full path: ENV_SCRIPTS/{tool_name}/{script_name}
            Example: /proj5/projects/semicon_19-02/tech/tools/genus/syn.tcl
        """
        # Use script_name as-is (already has extension from flow_config.yaml)
        script_path = self.tools_root / tool_name / script_name

        print(f"[CONFIG] Constructing script path:")
        print(f"[CONFIG]   tools_root: {self.tools_root}")
        print(f"[CONFIG]   tool_name: {tool_name}")
        print(f"[CONFIG]   script_name: {script_name}")
        print(f"[CONFIG]   → Full path: {script_path}")
        print(f"[CONFIG]   → Path exists: {script_path.exists()}")

        return script_path

    def get_stage_work_dir(self, stage_name: str) -> Path:
        """Get work directory for a stage, accounting for stage_groups and dir_name mappings

        Supports:
        - Stage groups with base_dir (e.g., pnr/init, pnr/place)
        - Custom dir_name mappings (e.g., init_design → init)

        Returns:
            {run_dir}/[base_dir/]{dir_name}/work
            Examples:
            - syn → {run_dir}/syn/work (no group)
            - init_design → {run_dir}/pnr/init/work (group with base_dir and dir_name)
            - place → {run_dir}/pnr/place/work (group with base_dir, standard name)
        """
        stages = self.flow_config.get("stages", {})
        stage_info = stages.get(stage_name, {})
        groups = self.flow_config.get("stage_groups", {})

        # Get directory name (stage may have custom dir_name)
        dir_name = stage_info.get("dir_name", stage_name)

        # Check if stage belongs to a group with base_dir
        stage_group = stage_info.get("stage_group")
        if stage_group and stage_group in groups:
            group_config = groups[stage_group]
            base_dir = group_config.get("base_dir")
            if base_dir:
                work_dir = self.run_dir / base_dir / dir_name / "work"
                print(f"[CONFIG] Work dir for '{stage_name}': {base_dir}/{dir_name}/work")
                return work_dir

        # Default: stage at run_root/{dir_name}/work
        work_dir = self.run_dir / dir_name / "work"
        print(f"[CONFIG] Work dir for '{stage_name}': {dir_name}/work")
        return work_dir

    def get_stage_log_dir(self, stage_name: str) -> Path:
        """Get log directory for a stage, accounting for stage_groups and dir_name mappings

        Supports:
        - Stage groups with base_dir (e.g., pnr/init, pnr/place)
        - Custom dir_name mappings (e.g., init_design → init)

        Returns:
            {run_dir}/[base_dir/]{dir_name}/logs
            Examples:
            - syn → {run_dir}/syn/logs (no group)
            - init_design → {run_dir}/pnr/init/logs (group with base_dir and dir_name)
            - place → {run_dir}/pnr/place/logs (group with base_dir, standard name)
        """
        stages = self.flow_config.get("stages", {})
        stage_info = stages.get(stage_name, {})
        groups = self.flow_config.get("stage_groups", {})

        # Get directory name (stage may have custom dir_name)
        dir_name = stage_info.get("dir_name", stage_name)

        # Check if stage belongs to a group with base_dir
        stage_group = stage_info.get("stage_group")
        if stage_group and stage_group in groups:
            group_config = groups[stage_group]
            base_dir = group_config.get("base_dir")
            if base_dir:
                log_dir = self.run_dir / base_dir / dir_name / "logs"
                print(f"[CONFIG] Log dir for '{stage_name}': {base_dir}/{dir_name}/logs")
                return log_dir

        # Default: stage at run_root/{dir_name}/logs
        log_dir = self.run_dir / dir_name / "logs"
        print(f"[CONFIG] Log dir for '{stage_name}': {dir_name}/logs")
        return log_dir

    def get_env_file_path(self) -> Path:
        """Get path to sourceproj.env file

        Returns:
            Path to sourceproj.env
        """
        return self.env_file

    def get_all_stages(self) -> Dict:
        """Get all stages from flow_config.yaml

        Returns:
            Dictionary of stage configurations
        """
        return self.flow_config.get("stages", {})

    def get_stage_groups(self) -> Dict:
        """Get stage groups from flow_config.yaml

        Returns:
            Dictionary of stage groups (e.g., pnr, signoff)
        """
        return self.flow_config.get("stage_groups", {})

    def get_env_var(self, key: str, default: str = None) -> str:
        """Get environment variable (from sourced sourceproj.env)

        Args:
            key: Environment variable name
            default: Default value if not found

        Returns:
            Environment variable value or default
        """
        return os.environ.get(key, default)

    def get_all_env_vars(self) -> Dict[str, str]:
        """Get all environment variables

        Returns:
            Dictionary of all environment variables
        """
        return dict(os.environ)

    def get_slurm_config(self, stage_name: str) -> Dict:
        """Get SLURM configuration for a stage

        Merges stage-specific config with global defaults.

        Returns:
            Dict with keys: enabled, partition, cpus_per_task, mem, srun_path
        """
        # Get global defaults
        defaults = self.flow_config.get("slurm_defaults", {})
        slurm_config = {
            "enabled": defaults.get("enabled", False),
            "partition": defaults.get("partition", "normal"),
            "cpus_per_task": defaults.get("cpus_per_task", 2),
            "mem": defaults.get("mem", "4G"),
            "srun_path": defaults.get("srun_path", "srun"),
        }

        # Override with stage-specific config
        stages = self.flow_config.get("stages", {})
        stage_info = stages.get(stage_name, {})
        stage_slurm = stage_info.get("slurm", {})

        if stage_slurm:
            slurm_config.update(stage_slurm)

        return slurm_config

    def get_post_processing_config(self) -> Dict:
        """Get post-processing configuration

        Returns:
            Dict with keys: enabled, script
        """
        config = self.flow_config.get("post_processing", {})

        # Expand {env_scripts} placeholder in script path
        script = config.get("script", "")
        if "{env_scripts}" in script:
            env_scripts = self.get_env_var("ENV_SCRIPTS", "")
            script = script.replace("{env_scripts}", env_scripts)

        return {
            "enabled": config.get("enabled", False),
            "script": script,
        }

    def get_complete_marker_path(self, stage_name: str) -> Path:
        """Get path to completion marker file for a stage

        Returns:
            Path to marker file in work directory
        """
        stages = self.flow_config.get("stages", {})
        stage_info = stages.get(stage_name, {})
        marker_name = stage_info.get("complete_marker", f"{stage_name}_complete")

        work_dir = self.get_stage_work_dir(stage_name)
        return work_dir / marker_name

    def get_run_dir(self) -> Path:
        """Get run directory

        Returns:
            {proj_root}/{project}/pd/users/{user}/{block}/{rtl_tag}/{run_tag}
        """
        return self.run_dir


def create_config_manager(
    project_name: str,
    user_name: str,
    block_name: str,
    rtl_tag: str,
    run_tag: str,
    proj_root: str | None = None,
) -> ConfigManager:
    """Factory function to create ConfigManager

    Args:
        project_name: Project name
        user_name: User name
        block_name: Block name
        rtl_tag: RTL tag
        run_tag: Run/experiment tag
        proj_root: Project root directory

    Returns:
        Initialized ConfigManager instance
    """
    return ConfigManager(
        project_name=project_name,
        user_name=user_name,
        block_name=block_name,
        rtl_tag=rtl_tag,
        run_tag=run_tag,
        proj_root=proj_root,
    )
