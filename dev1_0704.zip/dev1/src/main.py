#!/usr/bin/env python3
"""
Main entry point for Physical Design Flow API server

Assumes:
- Working directory structure created by external setup scripts
- YAML files managed by external configuration system
- TCL scripts handle yaml_config_reader.tcl loading

Usage:
    python src/main.py --project <project> --user <user> --block <block> --rtl-tag <rtl_tag> --run-tag <run_tag> [--host 0.0.0.0] [--port 8000]

Example:
    python src/main.py --project aes_cipher --user bharath --block aes_cipher_top --rtl-tag bronze_v1 --run-tag run_001
"""

import argparse
import asyncio
import uuid
import os
from pathlib import Path
from datetime import datetime
import json

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks, Query, WebSocket, WebSocketDisconnect
import redis.asyncio as aioredis

from .tracker.langgraph_saver import get_saver, create_thread_id, get_config_for_thread
from .agents.physical_design_graph import PhysicalDesignGraph
from .config.env_loader import load_env_file
from .infra import FeatureFlags, initialize_lifecycle_runtime
from .infra.db import SessionLocal
from .infra.lifecycle_utils import (
    derive_checkpoint_nodes,
    lifecycle_status_for_event,
    message_for_event,
    normalize_optional_uuid,
    safe_int,
    safe_str,
)
from .infra.mappers import make_identity
from .infra.repositories import IssueKnowledgeRepository, SqlAlchemyJobRepository, DesignRunRepository
from pydantic import BaseModel, Field, model_validator
from typing import Optional, List


def generate_job_id() -> str:
    """Generate a unique job ID for tracking"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    short_uuid = uuid.uuid4().hex[:8]
    return f"job_{timestamp}_{short_uuid}"


def _normalize_human_decision(value: str) -> Optional[str]:
    normalized = (value or "").strip().lower().replace("-", "_").replace(" ", "_")
    if normalized in {"approved", "approve", "yes", "y", "ok", "continue", "rerun", "run", "execute"}:
        return "Approved"
    if normalized in {"declined", "decline", "reject", "rejected", "no", "n", "skip", "cancel", "abort", "stop"}:
        return "Declined"
    if normalized in {"userinput", "user_input", "context", "comment", "need_context", "more_info"}:
        return "UserInput"
    return None


# ============================================================================
# Request/Response Models
# ============================================================================

class ExecuteRequest(BaseModel):
    """Request to execute flow"""
    prompt: str
    session_id: str  # Required: from web UI for tracking
    debug_mode: str = "interactive"
    user_name: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    rtl_tag: Optional[str] = None
    experiment_name: Optional[str] = None


class ExecuteAckResponse(BaseModel):
    """Immediate acknowledgment response with job_id"""
    job_id: str  # Unique job identifier for tracking
    session_id: str  # Echo back session_id from request
    status: str  # "accepted" - job has been queued
    message: str


class ExecuteResponse(BaseModel):
    """Response from flow execution"""
    job_id: str  # Unique job identifier for tracking
    session_id: str  # Echo back session_id from request
    thread_id: Optional[str] = None
    experiment_name: Optional[str] = None
    status: str
    stages_executed: List[str]
    stages_failed: List[str]
    duration: float
    start_time: str
    end_time: Optional[str]


class JobStatusResponse(BaseModel):
    """Response for job status query"""
    job_id: str
    session_id: str
    status: str  # "running", "completed", "failed"
    current_stage: Optional[str] = None
    stages_executed: List[str] = []
    stages_failed: List[str] = []
    progress_percent: float = 0.0
    start_time: str
    end_time: Optional[str] = None
    duration: Optional[float] = None
    error: Optional[str] = None


class LifecycleJobCreateRequest(BaseModel):
    prompt: Optional[str] = None
    user_name: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    rtl_tag: Optional[str] = None
    experiment_name: Optional[str] = None
    debug_mode: str = "interactive"
    script_path: Optional[str] = None
    instructions_path: Optional[str] = None
    allowed_paths: List[str] = Field(default_factory=list)
    max_retries: int = 3
    max_iterations: int = 5
    require_plan_confirmation: bool = True
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    # NOTE: Reserved for future per-class admission policy.
    # resource_class: Optional[str] = None

    @model_validator(mode="after")
    def ensure_prompt(self) -> "LifecycleJobCreateRequest":
        if self.prompt:
            return self
        if self.script_path:
            self.prompt = f"run syn for {self.script_path}"
            return self
        raise ValueError("Either 'prompt' or 'script_path' must be provided")


class LifecycleJobCreateResponse(BaseModel):
    job_id: str
    run_id: str
    status: str
    phase: str


class LifecycleJobStatusResponse(BaseModel):
    job_id: str
    run_id: Optional[str] = None
    status: str
    phase: str
    iteration: Optional[int] = None
    current_tool: Optional[str] = None
    progress_message: Optional[str] = None


class HumanInputRequest(BaseModel):
    response: str
    additional_context: Optional[str] = None


class HumanInputResponse(BaseModel):
    job_id: str
    status: str
    phase: str
    interaction_type: str
    decision: str
    decision_status: str
    version: Optional[int] = None
    requested_at: Optional[str] = None
    expires_at: Optional[str] = None


class AbortResponse(BaseModel):
    job_id: str
    status: str
    phase: str
    message: str


class IssueKBSearchRequest(BaseModel):
    text_query: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    stage: Optional[str] = None
    issue_category: Optional[str] = None
    tool: Optional[str] = None
    technology: Optional[str] = None
    session_id: Optional[str] = None
    limit: int = 20


class IssueKBHybridSearchRequest(BaseModel):
    text_query: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    stage: Optional[str] = None
    issue_category: Optional[str] = None
    tool: Optional[str] = None
    technology: Optional[str] = None
    session_id: Optional[str] = None
    limit: int = 20


class IssueKBDuplicateCheckRequest(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    error_message: Optional[str] = None
    error_signature: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    stage: str
    issue_category: Optional[str] = "others"
    tool: Optional[str] = None
    technology: Optional[str] = "others"
    limit: int = 10


class IssueKBSemanticReindexRequest(BaseModel):
    limit: int = 500


class IssueKBSemanticSearchRequest(BaseModel):
    text_query: str
    project: Optional[str] = None
    block: Optional[str] = None
    stage: Optional[str] = None
    session_id: Optional[str] = None
    limit: int = 10


class JobLogItem(BaseModel):
    job_id: str
    kind: str
    seq: int
    ts_ms: int
    source: str
    level: str
    message: str
    payload: dict


class JobLogsResponse(BaseModel):
    job_id: str
    count: int
    items: List[JobLogItem]


class JobHistoryItem(BaseModel):
    job_id: str
    kind: str
    seq: int
    ts_ms: int
    source: str
    level: str
    message: str
    payload: dict
    event_type: Optional[str] = None
    status: Optional[str] = None
    phase: Optional[str] = None


class JobHistoryResponse(BaseModel):
    job_id: str
    count: int
    items: List[JobHistoryItem]


# In-memory job store (for production, use Redis or database)
job_store: dict = {}


# ============================================================================
# App Creation
# ============================================================================

def create_app(
    project_name: str,
    user_name: str,
    block_name: str,
    rtl_tag: str,
    run_tag: str,
) -> FastAPI:
    """
    Create and configure the FastAPI application

    Minimal initialization - routes user queries to appropriate project/user/block
    All path creation and state management happens on-demand based on user prompt

    Args:
        project_name: Default project name
        user_name: Default user name
        block_name: Default block name
        rtl_tag: Default RTL tag
        run_tag: Default run tag

    Returns:
        Configured FastAPI application
    """

    load_env_file()

    print(f"\n[SERVER] Initializing Physical Design Flow Server")
    print(f"  Project: {project_name}")
    print(f"  User: {user_name}")
    print(f"  Block: {block_name}")
    print(f"  RTL Tag: {rtl_tag}")
    print(f"  Run Tag: {run_tag}")

    # Initialize Redis checkpointer for multi-user support
    print(f"\n[REDIS] Initializing Redis checkpointer...")
    try:
        redis_host = os.getenv("REDIS_HOST", "localhost")
        redis_port = int(os.getenv("REDIS_PORT", "6379"))
        redis_db = int(os.getenv("REDIS_DB", "0"))
        saver = get_saver(
            backend="redis",
            redis_host=redis_host,
            redis_port=redis_port,
            redis_db=redis_db,
        )
        print(f"[OK] Redis checkpointer ready")
    except Exception as e:
        print(f"[WARN] Redis not available: {e}")
        saver = None

    # Create FastAPI application with minimal setup
    print(f"\n[START] Creating FastAPI application...")
    app = FastAPI(
        title="Physical Design Flow API",
        description="Multi-user physical design flow orchestration",
        version="2.0.0",
    )

    # Store configuration for routing (fallback defaults only)
    # In multi-user mode, client should always provide these parameters
    app.state.default_project = project_name
    app.state.default_user = user_name
    app.state.default_block = block_name
    app.state.default_rtl_tag = rtl_tag
    app.state.default_run_tag = run_tag
    app.state.saver = saver
    initialize_lifecycle_runtime(app)

    # Mark whether we're in multi-user mode
    # (client should provide all params per request)
    app.state.is_multi_user = True  # Assume multi-user by default

    # Initialize PhysicalDesignGraph for flow execution
    print(f"\n[GRAPH] Initializing PhysicalDesignGraph...")
    try:
        # PhysicalDesignGraph initializes its own components on-demand during invoke()
        # No need to pass ConfigManager, StageExecutor, or DebugAgent to constructor
        graph = PhysicalDesignGraph(max_retries=3)

        app.state.graph = graph

        print(f"[OK] PhysicalDesignGraph ready (components initialized on-demand)")
    except Exception as e:
        print(f"[WARN] Failed to initialize PhysicalDesignGraph: {e}")
        app.state.graph = None

    # Health check endpoint
    @app.get("/health")
    async def health():
        return {
            "status": "healthy",
            "service": "Physical Design Flow API",
            "redis": "available" if saver else "unavailable",
        }

    # Info endpoint
    @app.get("/info")
    async def info():
        return {
            "service": "Physical Design Flow API",
            "version": "2.0.0",
            "mode": "multi-user",
            "default_parameters": {
                "project": project_name,
                "user": user_name,
                "block": block_name,
                "rtl_tag": rtl_tag,
                "run_tag": run_tag,
            },
            "multi_user_note": "For proper user isolation, provide all parameters (user_name, project, block, rtl_tag, experiment_name) in every request",
            "redis_checkpointer": "available" if saver else "unavailable",
        }

    @app.get("/jobs/ops-metrics")
    async def get_ops_metrics():
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")
        if not flags.use_redis_job_state or app.state.job_state_store is None:
            raise HTTPException(status_code=503, detail="Redis lifecycle state store unavailable")
        return app.state.job_state_store.get_ops_metrics()

    @app.post("/issues/kb/search")
    async def search_issue_kb(request: IssueKBSearchRequest):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            items = issue_kb_repository.search_issues(
                text_query=request.text_query,
                project=request.project,
                block=request.block,
                stage=request.stage,
                issue_category=request.issue_category,
                tool=request.tool,
                technology=request.technology,
                session_id=request.session_id,
                limit=request.limit,
            )
            return {
                "count": len(items),
                "items": items,
            }
        finally:
            session.close()

    @app.post("/issues/kb/hybrid/search")
    async def hybrid_search_issue_kb(request: IssueKBHybridSearchRequest):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            return issue_kb_repository.hybrid_search_issues(
                text_query=request.text_query,
                project=request.project,
                block=request.block,
                stage=request.stage,
                issue_category=request.issue_category,
                tool=request.tool,
                technology=request.technology,
                session_id=request.session_id,
                limit=request.limit,
            )
        finally:
            session.close()

    @app.post("/issues/kb/check-duplicate")
    async def check_issue_duplicate(request: IssueKBDuplicateCheckRequest):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            return issue_kb_repository.find_duplicate_candidates(
                payload=request.model_dump(),
                limit=request.limit,
            )
        finally:
            session.close()

    @app.get("/issues/kb/stats")
    async def issue_kb_stats():
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            return issue_kb_repository.get_issue_stats()
        finally:
            session.close()

    @app.get("/issues/kb/taxonomy")
    async def issue_kb_taxonomy():
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            return issue_kb_repository.get_taxonomy()
        finally:
            session.close()

    @app.get("/issues/kb/semantic/{issue_id}")
    async def get_issue_semantic_document(issue_id: str):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            semantic_doc = issue_kb_repository.get_semantic_document(issue_id=issue_id)
            if semantic_doc is None:
                raise HTTPException(status_code=404, detail="Issue semantic document not found")
            return semantic_doc
        finally:
            session.close()

    @app.post("/issues/kb/semantic/reindex")
    async def rebuild_issue_semantic_index(request: IssueKBSemanticReindexRequest):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            return issue_kb_repository.rebuild_semantic_index(limit=request.limit)
        finally:
            session.close()

    @app.post("/issues/kb/semantic/search")
    async def semantic_search_issue_kb(request: IssueKBSemanticSearchRequest):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Issue KB unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            issue_kb_repository = IssueKnowledgeRepository(session)
            return issue_kb_repository.semantic_search_issues(
                text_query=request.text_query,
                project=request.project,
                block=request.block,
                stage=request.stage,
                session_id=request.session_id,
                limit=request.limit,
            )
        finally:
            session.close()

    # =========================================================================
    # Stage Progress API - For Web UI
    # =========================================================================

    class StageProgressQueryRequest(BaseModel):
        """Request model for stage progress query."""
        session_id: Optional[str] = None
        job_id: Optional[str] = None
        user_name: Optional[str] = None
        project_name: Optional[str] = None
        block_name: Optional[str] = None
        rtl_tag: Optional[str] = None
        experiment_name: Optional[str] = None
        status: Optional[str] = None  # pending, inprogress, completed, failed, cancelled, skipped
        limit: int = 100
        offset: int = 0

    class BlockProgressRequest(BaseModel):
        """Request model for block progress summary."""
        project_name: str
        block_name: str
        rtl_tag: Optional[str] = None

    @app.post("/stage-progress/query")
    async def query_stage_progress(request: StageProgressQueryRequest):
        """
        Query stage progress with filters for Web UI.

        Supports filtering by session_id, job_id, user_name, project_name,
        block_name, rtl_tag, experiment_name, and status.
        """
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Stage progress unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            design_run_repo = DesignRunRepository(session)
            job_id_uuid = None
            if request.job_id:
                try:
                    job_id_uuid = uuid.UUID(request.job_id)
                except ValueError:
                    raise HTTPException(status_code=400, detail=f"Invalid job_id format: {request.job_id}")

            results = design_run_repo.query_stage_progress(
                session_id=request.session_id,
                job_id=job_id_uuid,
                user_name=request.user_name,
                project_name=request.project_name,
                block_name=request.block_name,
                rtl_tag=request.rtl_tag,
                experiment_name=request.experiment_name,
                status=request.status,
                limit=request.limit,
                offset=request.offset,
            )
            return {"results": results, "count": len(results)}
        finally:
            session.close()

    @app.post("/stage-progress/block-summary")
    async def get_block_progress_summary(request: BlockProgressRequest):
        """
        Get progress summary for a block - useful for Web UI dashboard.

        Returns latest run info, stage-by-stage status, and status counts.
        """
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Stage progress unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            design_run_repo = DesignRunRepository(session)
            summary = design_run_repo.get_block_progress_summary(
                project_name=request.project_name,
                block_name=request.block_name,
                rtl_tag=request.rtl_tag,
            )
            return summary
        finally:
            session.close()

    @app.get("/stage-progress/session/{session_id}")
    async def get_session_stage_progress(session_id: str, limit: int = 100):
        """
        Get all stage progress for a specific session.

        Quick endpoint for Web UI to fetch progress by session.
        """
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Stage progress unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            design_run_repo = DesignRunRepository(session)
            results = design_run_repo.query_stage_progress(
                session_id=session_id,
                limit=limit,
            )
            return {"session_id": session_id, "results": results, "count": len(results)}
        finally:
            session.close()

    @app.get("/stage-progress/job/{job_id}")
    async def get_job_stage_progress(job_id: str, limit: int = 100):
        """
        Get all stage progress for a specific job.

        Quick endpoint for Web UI to fetch progress by job ID.
        """
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_postgres_job_repo:
            raise HTTPException(status_code=503, detail="Stage progress unavailable: Postgres repository disabled")

        session = SessionLocal()
        try:
            try:
                job_id_uuid = uuid.UUID(job_id)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid job_id format: {job_id}")

            design_run_repo = DesignRunRepository(session)
            results = design_run_repo.query_stage_progress(
                job_id=job_id_uuid,
                limit=limit,
            )
            return {"job_id": job_id, "results": results, "count": len(results)}
        finally:
            session.close()

    def lifecycle_bridge(event_type: str, payload: dict, state: dict):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            return

        job_id = state.get("job_id") or payload.get("job_id")
        if not job_id:
            return

        if event_type == "agent_log":
            if app.state.job_event_publisher is not None:
                app.state.job_event_publisher.publish_job_log(
                    job_id,
                    message=safe_str(payload.get("message")) or "Agent log",
                    payload=payload,
                    source=safe_str(payload.get("source")) or "SPD_Agent",
                    level=safe_str(payload.get("level")) or "INFO",
                )
            return

        status, phase = lifecycle_status_for_event(event_type, payload)
        current_tool = payload.get("tool") or payload.get("stage")  # Prefer tool, fallback to stage
        run_id = safe_str(state.get("run_id") or payload.get("run_id"))
        progress_message = payload.get("message") or message_for_event(event_type, payload)
        iteration = safe_int(payload.get("current_stage_index"))
        if iteration is not None:
            iteration += 1

        state_snapshot = {
            "job_id": job_id,
            "run_id": run_id,
            "status": status,
            "phase": phase,
            "iteration": iteration,
            "current_tool": current_tool,
            "current_stage": safe_str(payload.get("stage")),
            "progress_message": progress_message,
            "stages_executed": payload.get("stages_executed", state.get("stages_executed", [])),
            "stages_failed": payload.get("stages_failed", state.get("stages_failed", [])),
            "end_time": payload.get("end_time"),
            "decision_status": safe_str(payload.get("decision_status")),
            "interaction_type": safe_str(payload.get("interaction_type")),
            "hitl_version": safe_int(payload.get("version")),
            "requested_at": safe_str(payload.get("requested_at")),
            "expires_at": safe_str(payload.get("expires_at")),
        }

        checkpoint_current_node, checkpoint_next_node = derive_checkpoint_nodes(event_type, payload, state)
        state_snapshot["current_node"] = checkpoint_current_node
        state_snapshot["next_node"] = checkpoint_next_node

        if flags.use_redis_job_state and app.state.job_state_store is not None:
            current_state = app.state.job_state_store.get_job_state(job_id) or {}
            merged_state = {
                **current_state,
                **state_snapshot,
            }
            app.state.job_state_store.set_job_state(job_id, merged_state)
            state_snapshot = merged_state

        if flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                issue_kb_repository = IssueKnowledgeRepository(session)

                def _extract_file_change_payloads() -> list[dict]:
                    extracted: list[dict] = []
                    file_edits = payload.get("file_edits")
                    if isinstance(file_edits, list):
                        for edit in file_edits:
                            if isinstance(edit, dict) and safe_str(edit.get("file_path")):
                                extracted.append(edit)

                    if safe_str(payload.get("file_path")):
                        extracted.append(payload)

                    details = payload.get("details")
                    if isinstance(details, dict) and safe_str(details.get("file_path")):
                        extracted.append(details)

                    return extracted

                repository.update_job_status(
                    job_id=job_id,
                    status=status,
                    phase=phase,
                    current_tool=safe_str(current_tool),
                    completed_at=safe_str(payload.get("end_time")) if status in {"SUCCESS", "FAILED", "CANCELLED"} else None,
                )
                repository.add_history(
                    job_id=job_id,
                    payload={
                        "sequence_num": iteration if iteration is not None else 0,
                        "action_type": event_type,
                        "tool_name": safe_str(current_tool),
                        "input_params": payload,
                        "output_result": {
                            "status": status,
                            "phase": phase,
                            "message": progress_message,
                        },
                        "duration_ms": safe_int(payload.get("duration_ms")),
                        "error_message": safe_str(payload.get("error")),
                    },
                )
                stage = safe_str(payload.get("stage"))
                if stage and event_type in {"stage_started", "stage_completed", "stage_failed"}:
                    stage_status_map = {
                        "stage_started": "running",
                        "stage_completed": "pass",
                        "stage_failed": "fail",
                    }
                    repository.add_stage_record(
                        job_id=job_id,
                        payload={
                            "run_id": run_id,
                            "stage": stage,
                            "tool": safe_str(current_tool),
                            "stage_order": iteration,
                            "status": stage_status_map.get(event_type, "running"),
                            "summary": safe_str(payload.get("summary") or payload.get("reason") or progress_message),
                            "error_details": safe_str(payload.get("error")),
                            "started_at": safe_str(payload.get("started_at")) if event_type == "stage_started" else None,
                            "ended_at": safe_str(payload.get("end_time")) if event_type in {"stage_completed", "stage_failed"} else None,
                            "duration_ms": safe_int(payload.get("duration_ms")),
                            "metadata": {
                                "event_type": event_type,
                                "payload": payload,
                            },
                        },
                    )

                for file_change in _extract_file_change_payloads():
                    repository.add_file_change(
                        job_id=job_id,
                        payload={
                            "run_id": run_id,
                            "stage": safe_str(file_change.get("stage") or payload.get("stage")),
                            "file_path": safe_str(file_change.get("file_path")),
                            "change_type": safe_str(file_change.get("change_type") or file_change.get("edit_type") or "edit"),
                            "tool_name": safe_str(file_change.get("tool_name") or current_tool),
                            "before_hash": safe_str(file_change.get("before_hash")),
                            "after_hash": safe_str(file_change.get("after_hash")),
                            "diff_excerpt": safe_str(file_change.get("diff_excerpt") or file_change.get("diff")),
                            "happened_at": safe_str(file_change.get("timestamp") or payload.get("timestamp")),
                            "metadata": {
                                "event_type": event_type,
                                "payload": file_change,
                            },
                        },
                    )

                repository.save_checkpoint(
                    job_id=job_id,
                    state=state_snapshot,
                    current_node=checkpoint_current_node,
                    next_node=checkpoint_next_node,
                )
                if event_type == "hitl_required":
                    requested_at = safe_str(payload.get("requested_at")) or datetime.utcnow().isoformat()
                    repository.add_human_interaction(
                        job_id=job_id,
                        prompt=safe_str(payload.get("prompt")) or "Human confirmation required",
                        options=payload.get("options") or ["Approved", "Declined", "UserInput"],
                        response=None,
                        interaction_type=safe_str(payload.get("interaction_type")) or "generic",
                        decision=None,
                        additional_context=None,
                        decision_status=safe_str(payload.get("decision_status")) or "waiting_for_human",
                        requested_at=requested_at,
                        expires_at=safe_str(payload.get("expires_at")),
                        version=safe_int(payload.get("version")),
                        interaction_metadata={
                            "payload": payload,
                            "source": "lifecycle_bridge",
                        },
                    )
                if event_type in {"stage_failed", "failed"}:
                    error_message = safe_str(payload.get("error")) or progress_message
                    stage = safe_str(payload.get("stage"))
                    repository.add_error_log(
                        job_id=job_id,
                        error_type=event_type,
                        error_message=error_message,
                        stage=stage,
                        tool=safe_str(current_tool),
                        context={
                            "payload": payload,
                            "status": status,
                            "phase": phase,
                            "current_tool": safe_str(current_tool),
                            "stage": stage,
                        },
                    )

                # When an issue is resolved, update the error_log
                if event_type == "issue_resolution_captured":
                    stage = safe_str(payload.get("stage"))
                    resolution = safe_str(payload.get("resolution")) or safe_str(payload.get("summary"))
                    repository.resolve_error_log(
                        job_id=job_id,
                        stage=stage,
                        resolution=resolution,
                        error_type="resolved",
                        tool=safe_str(current_tool),
                    )

                if event_type in {"stage_failed", "failed", "issue_resolution_captured"}:
                    error_message = safe_str(payload.get("error")) or progress_message
                    # Get proper tool name from payload (not falling back to stage)
                    tool_name = safe_str(payload.get("tool")) or safe_str(current_tool)
                    stage_name = safe_str(payload.get("stage")) or phase

                    # Get technology from TECH_NAME env var (set via sourceproj.env)
                    technology = safe_str(payload.get("technology"))
                    if not technology or technology == "others":
                        technology = IssueKnowledgeRepository.get_technology_from_env()

                    # Get or classify issue category
                    issue_category = safe_str(payload.get("issue_category"))
                    if not issue_category or issue_category == "others":
                        issue_category = IssueKnowledgeRepository.classify_issue_from_error(
                            error_message, stage_name
                        )

                    # Generate descriptive title instead of generic "stage failure"
                    title = IssueKnowledgeRepository.generate_descriptive_title(
                        stage=stage_name,
                        tool=tool_name,
                        error_message=error_message,
                        issue_category=issue_category,
                    )

                    issue_kb_repository.upsert_issue(
                        job_id=job_id,
                        payload={
                            "run_id": run_id,
                            "session_id": safe_str(state.get("session_id") or payload.get("session_id")),
                            "title": title,
                            "description": error_message,
                            "error_message": error_message,
                            "error_signature": safe_str(payload.get("error_signature") or payload.get("error")),
                            "tool": tool_name,
                            "technology": technology,
                            "issue_category": issue_category,
                            "stage": stage_name,
                            "summary": progress_message,
                            "debug_steps": safe_str(payload.get("debug_steps")),
                            "resolution": safe_str(payload.get("resolution")),
                            "metadata": {
                                "event_type": event_type,
                                "phase": phase,
                                "status": status,
                                "payload": payload,
                            },
                        },
                    )

                # Track stage progress in design_runs/stage_progress tables
                design_run_repo = DesignRunRepository(session)
                dr_project = safe_str(state.get("project") or payload.get("project"))
                dr_block = safe_str(state.get("block") or payload.get("block"))
                dr_rtl_tag = safe_str(state.get("rtl_tag") or payload.get("rtl_tag"))
                dr_experiment = safe_str(state.get("experiment") or payload.get("experiment") or run_id)

                if dr_project and dr_block and dr_rtl_tag and dr_experiment:
                    try:
                        if event_type == "started":
                            # Create design run and initialize stage progress for all planned stages
                            plan = payload.get("plan") or state.get("plan") or []
                            acquired, design_run, holder_info = design_run_repo.try_acquire_lock(
                                project=dr_project,
                                block=dr_block,
                                rtl_tag=dr_rtl_tag,
                                experiment=dr_experiment,
                                job_id=uuid.UUID(job_id) if job_id else None,
                                session_id=safe_str(state.get("session_id")),
                                user_name=safe_str(state.get("user_name") or state.get("user_id")),
                                plan=plan,
                            )
                            if acquired and design_run:
                                # Get denormalized fields for Web UI
                                dr_session_id = safe_str(state.get("session_id"))
                                dr_job_id = uuid.UUID(job_id) if job_id else None
                                dr_user_name = safe_str(state.get("user_name") or state.get("user_id"))

                                # Create stage progress entries for all stages in plan
                                for idx, stage_name in enumerate(plan):
                                    design_run_repo.create_stage_progress(
                                        run_id=design_run.run_id,
                                        stage_name=stage_name,
                                        stage_index=idx,
                                        # Denormalized fields for Web UI
                                        session_id=dr_session_id,
                                        job_id=dr_job_id,
                                        user_name=dr_user_name,
                                        project_name=dr_project,
                                        block_name=dr_block,
                                        rtl_tag=dr_rtl_tag,
                                        experiment_name=dr_experiment,
                                    )
                                session.commit()
                                # Store design run_id in state for later updates
                                state_snapshot["design_run_id"] = str(design_run.run_id)

                        elif event_type == "stage_started":
                            stage = safe_str(payload.get("stage"))
                            design_run = design_run_repo.get_running_design(
                                dr_project, dr_block, dr_rtl_tag, dr_experiment
                            )
                            if design_run and stage:
                                design_run_repo.update_stage_progress(
                                    run_id=design_run.run_id,
                                    stage_name=stage,
                                    status="inprogress",
                                    tool_name=safe_str(payload.get("tool") or current_tool),
                                    start_time=datetime.utcnow(),
                                    progress_percent=0,
                                    # Ensure denormalized fields are set
                                    session_id=safe_str(state.get("session_id")),
                                    job_id=uuid.UUID(job_id) if job_id else None,
                                    user_name=safe_str(state.get("user_name") or state.get("user_id")),
                                    project_name=dr_project,
                                    block_name=dr_block,
                                    rtl_tag=dr_rtl_tag,
                                    experiment_name=dr_experiment,
                                )
                                design_run_repo.update_progress(
                                    run_id=design_run.run_id,
                                    current_stage=stage,
                                    current_stage_index=safe_int(payload.get("current_stage_index")),
                                )
                                session.commit()

                        elif event_type == "stage_completed":
                            stage = safe_str(payload.get("stage"))
                            design_run = design_run_repo.get_running_design(
                                dr_project, dr_block, dr_rtl_tag, dr_experiment
                            )
                            if design_run and stage:
                                design_run_repo.update_stage_progress(
                                    run_id=design_run.run_id,
                                    stage_name=stage,
                                    status="completed",
                                    tool_name=safe_str(payload.get("tool") or current_tool),
                                    end_time=datetime.utcnow(),
                                    progress_percent=100,
                                )
                                stages_completed = list(design_run.stages_completed or [])
                                if stage not in stages_completed:
                                    stages_completed.append(stage)
                                plan_size = safe_int(payload.get("plan_size")) or design_run.total_stages or 1
                                progress_pct = int((len(stages_completed) / plan_size) * 100)
                                design_run_repo.update_progress(
                                    run_id=design_run.run_id,
                                    stages_completed=stages_completed,
                                    progress_percent=progress_pct,
                                )
                                session.commit()

                        elif event_type == "stage_failed":
                            stage = safe_str(payload.get("stage"))
                            design_run = design_run_repo.get_running_design(
                                dr_project, dr_block, dr_rtl_tag, dr_experiment
                            )
                            if design_run and stage:
                                design_run_repo.update_stage_progress(
                                    run_id=design_run.run_id,
                                    stage_name=stage,
                                    status="failed",
                                    tool_name=safe_str(payload.get("tool") or current_tool),
                                    end_time=datetime.utcnow(),
                                    error_message=safe_str(payload.get("error")),
                                    error_category=safe_str(payload.get("error_category")),
                                )
                                stages_failed = list(design_run.stages_failed or [])
                                if stage not in stages_failed:
                                    stages_failed.append(stage)
                                design_run_repo.update_progress(
                                    run_id=design_run.run_id,
                                    stages_failed=stages_failed,
                                )
                                session.commit()

                        elif event_type == "validation_completed":
                            stage = safe_str(payload.get("stage"))
                            design_run = design_run_repo.get_running_design(
                                dr_project, dr_block, dr_rtl_tag, dr_experiment
                            )
                            if design_run and stage:
                                passed = payload.get("passed", False)
                                design_run_repo.update_stage_progress(
                                    run_id=design_run.run_id,
                                    stage_name=stage,
                                    tool_name=safe_str(payload.get("tool") or current_tool),
                                    validation_status="passed" if passed else "failed",
                                    validation_metrics=payload.get("metrics"),
                                    validation_issues=payload.get("issues"),
                                )
                                # Update design run validation_results
                                validation_results = dict(design_run.validation_results or {})
                                validation_results[stage] = {
                                    "passed": passed,
                                    "metrics": payload.get("metrics"),
                                    "issues": payload.get("issues"),
                                    "summary": payload.get("summary"),
                                }
                                design_run_repo.update_progress(
                                    run_id=design_run.run_id,
                                    validation_results=validation_results,
                                )
                                session.commit()

                        elif event_type in {"completed", "failed", "abort_requested"}:
                            design_run = design_run_repo.get_running_design(
                                dr_project, dr_block, dr_rtl_tag, dr_experiment
                            )
                            if design_run:
                                final_status = "completed" if event_type == "completed" else (
                                    "cancelled" if event_type == "abort_requested" else "failed"
                                )
                                design_run_repo.release_lock(design_run.run_id, final_status)
                                session.commit()

                    except Exception as dr_exc:
                        print(f"[WARN] DesignRunRepository stage progress update failed: {dr_exc}")
                        session.rollback()

            finally:
                session.close()

        if app.state.job_event_publisher is not None:
            if event_type == "hitl_required":
                app.state.job_event_publisher.publish_hitl_required(job_id)
            app.state.job_event_publisher.publish_job_event(
                job_id,
                {
                    "event_type": event_type,
                    "status": status,
                    "phase": phase,
                    "message": progress_message,
                    "run_id": run_id,
                    "payload": payload,
                },
            )

    def build_issue_kb_lookup(*, project: str, block: str, session_id: Optional[str], log_prefix: str):
        def lookup_issue_kb(lookup_payload: dict) -> Optional[dict]:
            flags: FeatureFlags = app.state.feature_flags
            if not flags.use_postgres_job_repo:
                return None

            session = SessionLocal()
            try:
                issue_repo = IssueKnowledgeRepository(session)
                items = issue_repo.search_issues(
                    text_query=safe_str(lookup_payload.get("error_message")),
                    project=project,
                    block=block,
                    stage=safe_str(lookup_payload.get("stage")),
                    session_id=session_id,
                    limit=5,
                    include_internal=True,
                )
                return {"count": len(items), "items": items}
            except Exception as exc:
                print(f"{log_prefix}[WARN] Issue KB lookup failed: {exc}")
                return None
            finally:
                session.close()

        return lookup_issue_kb

    @app.post("/jobs", response_model=LifecycleJobCreateResponse, status_code=202)
    async def create_job_compat(payload: LifecycleJobCreateRequest):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        identity = make_identity(session_id=payload.session_id)

        req_user_name = payload.user_name or user_name
        proj = payload.project or project_name
        blk = payload.block or block_name
        rtl = payload.rtl_tag or rtl_tag
        exp = payload.experiment_name or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        prompt = payload.prompt or f"run syn for {payload.script_path or 'default design'}"
        script_path = payload.script_path or payload.instructions_path or "langgraph_request"

        # Resolve user_id: prefer explicit user_id, else use user_name directly
        resolved_user_id = payload.user_id or req_user_name

        if flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                repository.create_job(
                    job_id=identity.job_id,
                    user_id=resolved_user_id,
                    session_id=identity.session_id,
                    run_id=identity.run_id,
                    config_payload={
                        **payload.model_dump(),
                        "script_path": script_path,
                    },
                )
            finally:
                session.close()

        state = {
            "job_id": identity.job_id,
            "run_id": identity.run_id,
            "user_id": resolved_user_id,
            "session_id": identity.session_id,
            "status": "PENDING",
            "phase": "QUEUED",
            "iteration": 0,
            "current_tool": None,
            "progress_message": "Job accepted",
            "max_retries": payload.max_retries,
            "max_iterations": payload.max_iterations,
            "script_path": payload.script_path,
            "instructions_path": payload.instructions_path,
            "allowed_paths": payload.allowed_paths,
            "prompt": prompt,
            "user_name": req_user_name,
            "project": proj,
            "block": blk,
            "rtl_tag": rtl,
            "experiment_name": exp,
            "debug_mode": payload.debug_mode,
            "require_plan_confirmation": payload.require_plan_confirmation,
            # "resource_class": safe_str(payload.resource_class) or None,
        }

        if flags.use_redis_job_state and app.state.job_state_store is not None:
            app.state.job_state_store.enqueue_job_with_state(
                identity.job_id,
                state,
                {
                    "job_id": identity.job_id,
                    "run_id": identity.run_id,
                    "config": {
                        "run_id": identity.run_id,
                        "prompt": prompt,
                        "session_id": identity.session_id,
                        "user_name": req_user_name,
                        "project": proj,
                        "block": blk,
                        "rtl_tag": rtl,
                        "experiment_name": exp,
                        "debug_mode": payload.debug_mode,
                        "require_plan_confirmation": payload.require_plan_confirmation,
                        # "resource_class": safe_str(payload.resource_class) or None,
                        "max_retries": payload.max_retries,
                        "max_iterations": payload.max_iterations,
                        "script_path": payload.script_path,
                        "instructions_path": payload.instructions_path,
                        "allowed_paths": payload.allowed_paths,
                    },
                },
            )

            if app.state.job_event_publisher is not None:
                app.state.job_event_publisher.publish_job_event(
                    identity.job_id,
                    {
                        "event_type": "queued",
                        "status": "PENDING",
                        "phase": "QUEUED",
                        "run_id": identity.run_id,
                        "message": "Job accepted and queued for worker execution",
                    },
                )

        return LifecycleJobCreateResponse(job_id=identity.job_id, run_id=identity.run_id or "", status="PENDING", phase="QUEUED")

    @app.get("/jobs/{job_id}/job_status", response_model=LifecycleJobStatusResponse)
    async def get_job_status_compat(job_id: str):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        if flags.use_redis_job_state and app.state.job_state_store is not None:
            redis_state = app.state.job_state_store.get_job_state(job_id)
            if redis_state:
                return LifecycleJobStatusResponse(
                    job_id=job_id,
                    run_id=safe_str(redis_state.get("run_id")),
                    status=str(redis_state.get("status", "UNKNOWN")),
                    phase=str(redis_state.get("phase", "UNKNOWN")),
                    iteration=safe_int(redis_state.get("iteration")),
                    current_tool=safe_str(redis_state.get("current_tool")),
                    progress_message=safe_str(redis_state.get("progress_message")),
                )

        if flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                job = repository.get_job(job_id)
            finally:
                session.close()

            if job:
                return LifecycleJobStatusResponse(
                    job_id=job_id,
                    run_id=safe_str(job.get("run_id")),
                    status=str(job.get("status", "UNKNOWN")),
                    phase=str(job.get("phase", "UNKNOWN")),
                    iteration=None,
                    current_tool=safe_str(job.get("current_tool")),
                    progress_message=None,
                )

        raise HTTPException(status_code=404, detail="Job not found")

    @app.post("/jobs/{job_id}/human-input", response_model=HumanInputResponse)
    async def post_human_input(job_id: str, payload: HumanInputRequest):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        canonical_response = _normalize_human_decision(payload.response)
        if canonical_response is None:
            raise HTTPException(
                status_code=422,
                detail="Invalid response. Expected one of: 'Approved', 'Declined', or 'UserInput'.",
            )
        if canonical_response == "UserInput" and not (payload.additional_context or "").strip():
            raise HTTPException(
                status_code=422,
                detail="'UserInput' requires additional_context with comment/details.",
            )

        interaction_type = "generic"
        version: Optional[int] = None
        requested_at: Optional[str] = None
        expires_at: Optional[str] = None
        decision_status = "pending_final_decision" if canonical_response == "UserInput" else (
            "resumed" if canonical_response == "Approved" else "declined"
        )
        context_value = (payload.additional_context or "").strip() or None

        normalized_payload = {
            "response": canonical_response,
            "decision": canonical_response,
            "decision_status": decision_status,
            "additional_context": context_value,
        }

        current_state: dict = {"job_id": job_id}
        if flags.use_redis_job_state and app.state.job_state_store is not None:
            current_state = app.state.job_state_store.get_job_state(job_id) or {"job_id": job_id}
            interaction_type = safe_str(current_state.get("interaction_type")) or "generic"
            version = safe_int(current_state.get("hitl_version"))
            requested_at = safe_str(current_state.get("requested_at"))
            expires_at = safe_str(current_state.get("expires_at"))
            if canonical_response in {"Approved", "Declined"} and not context_value:
                context_value = safe_str(current_state.get("pending_human_context"))
            current_phase = safe_str(current_state.get("phase"))
            if current_phase and current_phase != "WAITING_FOR_HUMAN":
                raise HTTPException(status_code=409, detail=f"Job is not waiting for human input (phase={current_phase}).")
        normalized_payload["additional_context"] = context_value
        normalized_payload["interaction_type"] = interaction_type
        normalized_payload["version"] = version
        normalized_payload["requested_at"] = requested_at
        normalized_payload["expires_at"] = expires_at

        if flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                if not repository.get_job(job_id):
                    raise HTTPException(status_code=404, detail="Job not found")
                resolved = repository.resolve_latest_pending_interaction(
                    job_id=job_id,
                    decision=canonical_response,
                    additional_context=context_value,
                    decision_status=decision_status,
                    interaction_type=interaction_type,
                    version=version,
                )
                if resolved is None:
                    repository.add_human_interaction(
                        job_id=job_id,
                        prompt="HITL response",
                        options=["Approved", "Declined", "UserInput"],
                        response=canonical_response,
                        interaction_type=interaction_type,
                        decision=canonical_response,
                        additional_context=context_value,
                        decision_status=decision_status,
                        requested_at=requested_at,
                        expires_at=expires_at,
                        version=version,
                        interaction_metadata={"source": "api.human-input.fallback"},
                    )
            finally:
                session.close()

        if flags.use_redis_job_state and app.state.job_state_store is not None:
            app.state.job_state_store.clear_hitl_responses(job_id)
            app.state.job_state_store.push_hitl_response(job_id, normalized_payload)
            if canonical_response == "Approved":
                current_state["progress_message"] = "Human input received: Approved"
                current_state["phase"] = "RESUMED"
                current_state["last_applied_human_context"] = context_value
                current_state["pending_human_context"] = None
            elif canonical_response == "Declined":
                current_state["progress_message"] = "Human input received: Declined"
                current_state["phase"] = "DECLINED"
                current_state["last_applied_human_context"] = context_value
                current_state["pending_human_context"] = None
            else:
                current_state["progress_message"] = "Human input received: context added; awaiting final decision"
                current_state["phase"] = "WAITING_FOR_HUMAN"
                current_state["pending_human_context"] = context_value
            current_state["decision_status"] = decision_status
            current_state["decision"] = canonical_response
            current_state["additional_context"] = context_value
            current_state["interaction_type"] = interaction_type
            current_state["requested_at"] = requested_at
            current_state["expires_at"] = expires_at
            current_state["hitl_version"] = version
            app.state.job_state_store.set_job_state(job_id, current_state)

        if app.state.job_event_publisher is not None:
            app.state.job_event_publisher.publish_hitl_response(job_id)
            app.state.job_event_publisher.publish_job_event(
                job_id,
                {
                    "event_type": "hitl_response",
                    "status": "IN_PROGRESS",
                    "phase": "WAITING_FOR_HUMAN" if canonical_response == "UserInput" else ("RESUMED" if canonical_response == "Approved" else "DECLINED"),
                    "message": f"Human input received: {canonical_response}",
                    "payload": {
                        **normalized_payload,
                        "interaction_type": interaction_type,
                        "version": version,
                        "requested_at": requested_at,
                        "expires_at": expires_at,
                    },
                },
            )

        status = await get_job_status_compat(job_id)
        return HumanInputResponse(
            job_id=job_id,
            status=status.status,
            phase=status.phase,
            interaction_type=interaction_type,
            decision=canonical_response,
            decision_status=decision_status,
            version=version,
            requested_at=requested_at,
            expires_at=expires_at,
        )

    @app.post("/jobs/{job_id}/abort", response_model=AbortResponse, status_code=202)
    async def abort_job(job_id: str):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        found = False
        if flags.use_postgres_job_repo:
            session = SessionLocal()
            try:
                repository = SqlAlchemyJobRepository(session)
                if repository.get_job(job_id):
                    found = True
                    repository.update_job_status(job_id=job_id, status="CANCELLED", phase="ABORT_REQUESTED")
            finally:
                session.close()

        if flags.use_redis_job_state and app.state.job_state_store is not None:
            app.state.job_state_store.set_abort_flag(job_id)
            current = app.state.job_state_store.get_job_state(job_id)
            if current:
                found = True
                current["status"] = "CANCELLED"
                current["phase"] = "ABORT_REQUESTED"
                current["progress_message"] = "Abort requested"
                app.state.job_state_store.set_job_state(job_id, current)

        if not found:
            raise HTTPException(status_code=404, detail="Job not found")

        if app.state.job_event_publisher is not None:
            app.state.job_event_publisher.publish_abort(job_id)
            app.state.job_event_publisher.publish_job_event(
                job_id,
                {
                    "event_type": "abort_requested",
                    "status": "CANCELLED",
                    "phase": "ABORT_REQUESTED",
                    "message": "Abort requested; worker will cancel shortly.",
                },
            )

        return AbortResponse(
            job_id=job_id,
            status="CANCELLED",
            phase="ABORT_REQUESTED",
            message="Abort requested; worker will cancel shortly.",
        )

    @app.get("/job_state")
    async def get_full_job_state(job_id: str = Query(..., description="Job ID to fetch full state for")):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api or app.state.job_state_store is None:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        state = app.state.job_state_store.get_job_state(job_id)
        if not state:
            raise HTTPException(status_code=404, detail="Job not found")

        try:
            hitl_list = app.state.job_state_store.client.lrange(f"job:{job_id}:hitl_response", 0, 0)
            if hitl_list:
                state["hitl_response"] = json.loads(hitl_list[0])
            else:
                state["hitl_response"] = None
        except Exception:
            state["hitl_response"] = None

        return state

    @app.get("/jobs/{job_id}/logs", response_model=JobLogsResponse)
    async def get_job_logs(
        job_id: str,
        limit: int = Query(100, ge=1, le=500, description="Max number of log entries to return"),
        before_seq: Optional[int] = Query(None, ge=1, description="Return logs with seq strictly less than this value"),
    ):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        publisher = app.state.job_event_publisher
        if publisher is None:
            raise HTTPException(status_code=404, detail="Job log publisher unavailable")

        items = publisher.get_job_logs(job_id, limit=limit, before_seq=before_seq)
        return JobLogsResponse(job_id=job_id, count=len(items), items=items)

    @app.get("/jobs/{job_id}/history", response_model=JobHistoryResponse)
    async def get_job_history(
        job_id: str,
        limit: int = Query(100, ge=1, le=500, description="Max number of merged timeline entries to return"),
        before_seq: Optional[int] = Query(None, ge=1, description="Return items with seq strictly less than this value"),
    ):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            raise HTTPException(status_code=404, detail="Lifecycle API disabled")

        publisher = app.state.job_event_publisher
        if publisher is None:
            raise HTTPException(status_code=404, detail="Job history publisher unavailable")

        items = publisher.get_job_timeline(job_id, limit=limit, before_seq=before_seq)
        return JobHistoryResponse(job_id=job_id, count=len(items), items=items)

    @app.websocket("/ws/jobs/{job_id}")
    async def job_events_ws(websocket: WebSocket, job_id: str):
        flags: FeatureFlags = app.state.feature_flags
        if not flags.use_job_lifecycle_api:
            await websocket.close(code=1008, reason="Lifecycle API disabled")
            return

        await websocket.accept()
        include_logs = str(websocket.query_params.get("include_logs", "false")).lower() in {"1", "true", "yes", "on"}
        runtime = app.state.runtime_config
        client = aioredis.from_url(runtime.redis_url, decode_responses=True)
        pubsub = client.pubsub()
        channels = [f"jobs:{job_id}:events"]
        if include_logs:
            channels.append(f"jobs:{job_id}:logs")
        await pubsub.subscribe(*channels)

        await websocket.send_json({"type": "connected", "job_id": job_id, "include_logs": include_logs})

        try:
            async for message in pubsub.listen():
                if message.get("type") != "message":
                    continue
                data = message.get("data")
                await websocket.send_text(data)
        except WebSocketDisconnect:
            pass
        finally:
            try:
                await pubsub.unsubscribe(*channels)
                await pubsub.close()
                await client.aclose()
            except Exception:
                pass

    # Execute flow endpoint
    @app.post("/flow/execute", response_model=ExecuteResponse)
    async def execute_flow(request: ExecuteRequest):
        """Execute design flow based on user prompt"""
        # Generate job_id immediately for tracking
        job_id = generate_job_id()
        session_id = request.session_id

        # Log prefix for all messages
        log_prefix = f"[session={session_id}][job={job_id}]"

        try:
            print(f"\n{log_prefix} === New Request Received ===")

            # For multi-user mode: require all parameters to be provided
            # This ensures proper isolation per user/project/block/experiment
            if app.state.is_multi_user:
                missing_params = []
                if not request.user_name:
                    missing_params.append("user_name")
                if not request.project:
                    missing_params.append("project")
                if not request.block:
                    missing_params.append("block")
                if not request.rtl_tag:
                    missing_params.append("rtl_tag")
                if not request.experiment_name:
                    missing_params.append("experiment_name")

                if missing_params:
                    print(f"{log_prefix}[WARN] Missing multi-user parameters: {', '.join(missing_params)}")
                    print(f"{log_prefix}[INFO] Using defaults: user={user_name}, project={project_name}, block={block_name}")

            # Use provided values or defaults
            req_user_name = request.user_name or user_name
            proj = request.project or project_name
            blk = request.block or block_name
            rtl = request.rtl_tag or rtl_tag
            exp = request.experiment_name or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

            # Create thread ID for multi-user isolation
            thread_id = create_thread_id(req_user_name, blk, exp)

            print(f"{log_prefix}[EXECUTE] User: {req_user_name}, Project: {proj}, Block: {blk}, Experiment: {exp}")
            print(f"{log_prefix}[EXECUTE] Thread ID: {thread_id}")
            print(f"{log_prefix}[EXECUTE] Prompt: {request.prompt}")

            start_time = datetime.now().isoformat()

            # Check if PhysicalDesignGraph is available
            if not app.state.graph:
                print(f"{log_prefix}[WARN] PhysicalDesignGraph not available, returning pending")
                return ExecuteResponse(
                    job_id=job_id,
                    session_id=session_id,
                    thread_id=thread_id,
                    experiment_name=exp,
                    status="pending",
                    stages_executed=[],
                    stages_failed=[],
                    duration=0.0,
                    start_time=start_time,
                    end_time=None,
                )

            # Execute flow via PhysicalDesignGraph
            # Pass all configuration parameters for on-demand component initialization
            print(f"{log_prefix}[EXECUTE] Invoking PhysicalDesignGraph...")
            issue_kb_lookup = build_issue_kb_lookup(project=proj, block=blk, session_id=session_id, log_prefix=log_prefix)
            result = await app.state.graph.invoke(
                prompt=request.prompt,
                debug_mode=request.debug_mode,
                project_name=proj,
                user_name=req_user_name,
                block_name=blk,
                rtl_tag=rtl,
                experiment_name=exp,
                job_id=job_id,
                session_id=session_id,
                lifecycle_hook=lifecycle_bridge,
                issue_kb_lookup=issue_kb_lookup,
            )

            end_time = datetime.now().isoformat()
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

            print(f"{log_prefix}[EXECUTE] Result: {result}")
            print(f"{log_prefix}[EXECUTE] Completed in {duration:.2f}s")

            return ExecuteResponse(
                job_id=job_id,
                session_id=session_id,
                thread_id=thread_id,
                experiment_name=exp,
                status=result.get("execution_status", "completed"),
                stages_executed=result.get("stages_executed", []),
                stages_failed=result.get("stages_failed", []),
                duration=duration,
                start_time=start_time,
                end_time=end_time,
            )

        except Exception as e:
            print(f"{log_prefix}[ERROR] {str(e)}")
            import traceback
            traceback.print_exc()
            raise HTTPException(status_code=500, detail=f"{log_prefix} {str(e)}")

    # Background task for async execution
    async def run_flow_background(
        job_id: str,
        session_id: str,
        prompt: str,
        debug_mode: str,
        req_user_name: str,
        proj: str,
        blk: str,
        rtl: str,
        exp: str,
        thread_id: str,
    ):
        """Background task to execute flow"""
        log_prefix = f"[session={session_id}][job={job_id}]"
        start_time = datetime.now().isoformat()

        # Update job store with running status
        job_store[job_id]["status"] = "running"
        job_store[job_id]["start_time"] = start_time

        try:
            print(f"{log_prefix}[BACKGROUND] Starting flow execution...")

            issue_kb_lookup = build_issue_kb_lookup(project=proj, block=blk, session_id=session_id, log_prefix=log_prefix)
            result = await app.state.graph.invoke(
                prompt=prompt,
                debug_mode=debug_mode,
                project_name=proj,
                user_name=req_user_name,
                block_name=blk,
                rtl_tag=rtl,
                experiment_name=exp,
                job_id=job_id,
                session_id=session_id,
                lifecycle_hook=lifecycle_bridge,
                issue_kb_lookup=issue_kb_lookup,
            )

            end_time = datetime.now().isoformat()
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()

            # Update job store with result
            job_store[job_id].update({
                "status": result.get("execution_status", "completed"),
                "stages_executed": result.get("stages_executed", []),
                "stages_failed": result.get("stages_failed", []),
                "end_time": end_time,
                "duration": duration,
                "result": result,
            })

            print(f"{log_prefix}[BACKGROUND] Completed in {duration:.2f}s")

        except Exception as e:
            end_time = datetime.now().isoformat()
            duration = (datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)).total_seconds()
            job_store[job_id].update({
                "status": "failed",
                "error": str(e),
                "end_time": end_time,
                "duration": duration,
            })
            print(f"{log_prefix}[BACKGROUND][ERROR] {str(e)}")

    # Async execute endpoint - returns immediately with job_id
    @app.post("/flow/execute-async", response_model=ExecuteAckResponse)
    async def execute_flow_async(request: ExecuteRequest, background_tasks: BackgroundTasks):
        """
        Execute flow asynchronously - returns job_id immediately.

        Use GET /flow/job/{job_id} to check status.
        """
        # Generate job_id immediately
        job_id = generate_job_id()
        session_id = request.session_id
        log_prefix = f"[session={session_id}][job={job_id}]"

        print(f"\n{log_prefix} === Async Request Received ===")

        # Resolve parameters
        req_user_name = request.user_name or user_name
        proj = request.project or project_name
        blk = request.block or block_name
        rtl = request.rtl_tag or rtl_tag
        exp = request.experiment_name or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        thread_id = create_thread_id(req_user_name, blk, exp)

        print(f"{log_prefix}[ASYNC] User: {req_user_name}, Project: {proj}, Block: {blk}")
        print(f"{log_prefix}[ASYNC] Thread ID: {thread_id}")
        print(f"{log_prefix}[ASYNC] Prompt: {request.prompt}")

        # Initialize job in store
        job_store[job_id] = {
            "job_id": job_id,
            "session_id": session_id,
            "thread_id": thread_id,
            "experiment_name": exp,
            "status": "accepted",
            "stages_executed": [],
            "stages_failed": [],
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "duration": None,
            "error": None,
            "prompt": request.prompt,
            "user_name": req_user_name,
            "project": proj,
            "block": blk,
        }

        # Check if graph is available
        if not app.state.graph:
            job_store[job_id]["status"] = "failed"
            job_store[job_id]["error"] = "PhysicalDesignGraph not available"
            return ExecuteAckResponse(
                job_id=job_id,
                session_id=session_id,
                status="failed",
                message="PhysicalDesignGraph not available",
            )

        # Schedule background execution
        background_tasks.add_task(
            run_flow_background,
            job_id=job_id,
            session_id=session_id,
            prompt=request.prompt,
            debug_mode=request.debug_mode,
            req_user_name=req_user_name,
            proj=proj,
            blk=blk,
            rtl=rtl,
            exp=exp,
            thread_id=thread_id,
        )

        print(f"{log_prefix}[ASYNC] Job queued for background execution")

        # Return immediately with job_id
        return ExecuteAckResponse(
            job_id=job_id,
            session_id=session_id,
            status="accepted",
            message="Job accepted and queued for execution. Use GET /flow/job/{job_id} to check status.",
        )

    # Job status endpoint
    @app.get("/flow/job/{job_id}", response_model=JobStatusResponse)
    async def get_job_status(job_id: str):
        """Get status of a running or completed job"""
        if job_id not in job_store:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

        job = job_store[job_id]

        # Calculate progress
        total_stages = len(job.get("stages_executed", [])) + len(job.get("stages_failed", []))
        progress = 0.0
        if job.get("status") == "completed":
            progress = 100.0
        elif job.get("status") == "running" and total_stages > 0:
            # Estimate progress based on typical flow (13 stages)
            progress = min((total_stages / 13) * 100, 99.0)

        return JobStatusResponse(
            job_id=job_id,
            session_id=job.get("session_id", ""),
            status=job.get("status", "unknown"),
            current_stage=job.get("current_stage"),
            stages_executed=job.get("stages_executed", []),
            stages_failed=job.get("stages_failed", []),
            progress_percent=progress,
            start_time=job.get("start_time", ""),
            end_time=job.get("end_time"),
            duration=job.get("duration"),
            error=job.get("error"),
        )

    # List all jobs for a session
    @app.get("/flow/jobs")
    async def list_jobs(session_id: Optional[str] = None):
        """List all jobs, optionally filtered by session_id"""
        if session_id:
            jobs = [j for j in job_store.values() if j.get("session_id") == session_id]
        else:
            jobs = list(job_store.values())

        return {
            "total": len(jobs),
            "jobs": [
                {
                    "job_id": j.get("job_id"),
                    "session_id": j.get("session_id"),
                    "status": j.get("status"),
                    "start_time": j.get("start_time"),
                    "prompt": j.get("prompt", "")[:50] + "..." if len(j.get("prompt", "")) > 50 else j.get("prompt", ""),
                }
                for j in jobs
            ]
        }

    print(f"[OK] FastAPI application created")
    print(f"[OK] /flow/execute endpoint ready (sync)")
    print(f"[OK] /flow/execute-async endpoint ready (async - returns job_id immediately)")
    print(f"[OK] /flow/job/{{job_id}} endpoint ready (check job status)")
    print(f"[OK] Server ready to route user queries")

    return app


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Physical Design Flow API Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  python src/main.py --project aes_cipher --user bharath --block aes_cipher_top --rtl-tag bronze_v1 --run-tag run_001

  # Custom host/port
  python src/main.py --project aes_cipher --user bharath --block aes_cipher_top --rtl-tag bronze_v1 --run-tag run_001 --host 0.0.0.0 --port 8080

  # Local development (default)
  python src/main.py --project aes_cipher --user bharath --block aes_cipher_top --rtl-tag bronze_v1 --run-tag run_001 --host 127.0.0.1 --port 8000
        """,
    )

    parser.add_argument(
        "--project",
        required=True,
        help="Project name (e.g., aes_cipher)",
    )
    parser.add_argument(
        "--user",
        required=True,
        help="User name (e.g., bharath)",
    )
    parser.add_argument(
        "--block",
        required=True,
        help="Block name (e.g., aes_cipher_top)",
    )
    parser.add_argument(
        "--rtl-tag",
        required=True,
        help="RTL tag (e.g., bronze_v1)",
    )
    parser.add_argument(
        "--run-tag",
        required=True,
        help="Run tag (e.g., run_001)",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind to (default: 8000)",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload on file changes (development only)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of worker processes (default: 1)",
    )

    args = parser.parse_args()

    # Create application
    app = create_app(
        project_name=args.project,
        user_name=args.user,
        block_name=args.block,
        rtl_tag=args.rtl_tag,
        run_tag=args.run_tag,
    )

    # Start server
    print(f"\n{'='*70}")
    print(f"[SERVER] Starting Physical Design Flow API Server")
    print(f"{'='*70}")
    print(f"Host: {args.host}")
    print(f"Port: {args.port}")
    print(f"Reload: {args.reload}")
    print(f"Workers: {args.workers}")
    print(f"\n[DOCS] API Documentation:")
    print(f"  Swagger UI: http://{args.host}:{args.port}/docs")
    print(f"  ReDoc: http://{args.host}:{args.port}/redoc")
    print(f"  OpenAPI JSON: http://{args.host}:{args.port}/openapi.json")
    print(f"\n[CONN] WebSocket Connection:")
    print(f"  ws://{args.host}:{args.port}/flow/ws")
    print(f"{'='*70}\n")

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers,
    )


if __name__ == "__main__":
    main()
