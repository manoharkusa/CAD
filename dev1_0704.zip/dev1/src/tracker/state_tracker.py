#!/usr/bin/env python3
"""
StateTracker - Manages execution state persistence and querying

Responsibilities:
1. Track stage execution status
2. Persist state to JSON
3. Query and retrieve state
4. Handle concurrent updates
"""

import json
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict, field


@dataclass
class StageExecution:
    """Record of a single stage execution"""
    stage_name: str
    status: str  # pending, in_progress, completed, failed, skipped
    tool: str
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    duration: float = 0.0
    return_code: Optional[int] = None
    log_file: Optional[str] = None
    error: Optional[str] = None
    metrics: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionRecord:
    """Complete record of a flow execution"""
    run_id: str
    run_tag: str
    block_name: str
    rtl_tag: str
    status: str  # pending, in_progress, completed, failed
    start_time: str
    end_time: Optional[str] = None
    duration: float = 0.0
    stages: Dict[str, StageExecution] = field(default_factory=dict)
    current_stage: Optional[str] = None
    debug_mode: str = "interactive"
    enable_ai: bool = False


class StateTracker:
    """
    Manages execution state with JSON persistence

    State persisted as JSON for:
    - Web UI queries
    - Flow resumption
    - Debugging and analysis
    """

    def __init__(self, run_dir: Path, run_tag: str, block_name: str, rtl_tag: str):
        """
        Initialize StateTracker

        Args:
            run_dir: Run directory path
            run_tag: Run identifier
            block_name: Block name
            rtl_tag: RTL tag
        """
        self.run_dir = Path(run_dir)
        self.run_tag = run_tag
        self.block_name = block_name
        self.rtl_tag = rtl_tag

        # State file location
        self.state_file = self.run_dir / ".flow_state.json"
        self.history_dir = self.run_dir / ".history"
        self.history_dir.mkdir(parents=True, exist_ok=True)

        # In-memory state
        self.current_execution: Optional[ExecutionRecord] = None
        self.lock = asyncio.Lock()

        # Load existing state
        self._load_state()

    def _load_state(self):
        """Load state from JSON file if exists"""
        if not self.state_file.exists():
            self._init_state()
            return

        try:
            with open(self.state_file, "r") as f:
                data = json.load(f)
                self._from_dict(data)
        except Exception as e:
            print(f"⚠ Error loading state: {e}, initializing fresh")
            self._init_state()

    def _init_state(self):
        """Initialize fresh state"""
        self.current_execution = ExecutionRecord(
            run_id=f"{self.block_name}_{self.rtl_tag}_{self.run_tag}",
            run_tag=self.run_tag,
            block_name=self.block_name,
            rtl_tag=self.rtl_tag,
            status="pending",
            start_time=datetime.now().isoformat(),
        )
        self._save_state()

    def _save_state(self):
        """Save current state to JSON file"""
        try:
            data = self._to_dict()
            with open(self.state_file, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"✗ Error saving state: {e}")

    def _to_dict(self) -> Dict[str, Any]:
        """Convert state to dictionary"""
        if not self.current_execution:
            return {}

        return {
            "run_id": self.current_execution.run_id,
            "run_tag": self.current_execution.run_tag,
            "block_name": self.current_execution.block_name,
            "rtl_tag": self.current_execution.rtl_tag,
            "status": self.current_execution.status,
            "start_time": self.current_execution.start_time,
            "end_time": self.current_execution.end_time,
            "duration": self.current_execution.duration,
            "current_stage": self.current_execution.current_stage,
            "debug_mode": self.current_execution.debug_mode,
            "enable_ai": self.current_execution.enable_ai,
            "stages": {
                name: asdict(stage)
                for name, stage in self.current_execution.stages.items()
            },
        }

    def _from_dict(self, data: Dict[str, Any]):
        """Load state from dictionary"""
        stages = {}
        for stage_name, stage_data in data.get("stages", {}).items():
            stages[stage_name] = StageExecution(
                stage_name=stage_data["stage_name"],
                status=stage_data["status"],
                tool=stage_data["tool"],
                start_time=stage_data.get("start_time"),
                end_time=stage_data.get("end_time"),
                duration=stage_data.get("duration", 0.0),
                return_code=stage_data.get("return_code"),
                log_file=stage_data.get("log_file"),
                error=stage_data.get("error"),
                metrics=stage_data.get("metrics", {}),
            )

        self.current_execution = ExecutionRecord(
            run_id=data.get("run_id", ""),
            run_tag=data.get("run_tag", ""),
            block_name=data.get("block_name", ""),
            rtl_tag=data.get("rtl_tag", ""),
            status=data.get("status", "pending"),
            start_time=data.get("start_time", ""),
            end_time=data.get("end_time"),
            duration=data.get("duration", 0.0),
            current_stage=data.get("current_stage"),
            debug_mode=data.get("debug_mode", "interactive"),
            enable_ai=data.get("enable_ai", False),
            stages=stages,
        )

    async def start_execution(self, debug_mode: str = "interactive", enable_ai: bool = False):
        """Start a new execution"""
        async with self.lock:
            self.current_execution = ExecutionRecord(
                run_id=f"{self.block_name}_{self.rtl_tag}_{self.run_tag}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                run_tag=self.run_tag,
                block_name=self.block_name,
                rtl_tag=self.rtl_tag,
                status="in_progress",
                start_time=datetime.now().isoformat(),
                debug_mode=debug_mode,
                enable_ai=enable_ai,
            )
            self._save_state()

    async def update_stage_status(
        self,
        stage_name: str,
        status: str,
        tool: str = "",
        **kwargs
    ):
        """Update stage status"""
        async with self.lock:
            if not self.current_execution:
                return

            if stage_name not in self.current_execution.stages:
                self.current_execution.stages[stage_name] = StageExecution(
                    stage_name=stage_name,
                    status=status,
                    tool=tool,
                )
            else:
                stage = self.current_execution.stages[stage_name]
                stage.status = status
                stage.tool = tool

            # Update with additional kwargs
            stage = self.current_execution.stages[stage_name]
            if "start_time" in kwargs:
                stage.start_time = kwargs["start_time"]
            if "end_time" in kwargs:
                stage.end_time = kwargs["end_time"]
            if "duration" in kwargs:
                stage.duration = kwargs["duration"]
            if "return_code" in kwargs:
                stage.return_code = kwargs["return_code"]
            if "log_file" in kwargs:
                stage.log_file = kwargs["log_file"]
            if "error" in kwargs:
                stage.error = kwargs["error"]
            if "metrics" in kwargs:
                stage.metrics = kwargs["metrics"]

            # Update current stage and flow status
            self.current_execution.current_stage = stage_name

            # Update overall status
            if status == "failed":
                self.current_execution.status = "failed"
            elif status == "in_progress":
                self.current_execution.status = "in_progress"

            self._save_state()

    async def complete_execution(self, overall_status: str = "completed"):
        """Mark execution as complete"""
        async with self.lock:
            if not self.current_execution:
                return

            self.current_execution.status = overall_status
            self.current_execution.end_time = datetime.now().isoformat()
            self.current_execution.duration = (
                datetime.fromisoformat(self.current_execution.end_time)
                - datetime.fromisoformat(self.current_execution.start_time)
            ).total_seconds()

            # Save to history
            self._save_to_history()

            # Save current state
            self._save_state()

    def _save_to_history(self):
        """Save execution record to history"""
        if not self.current_execution:
            return

        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            history_file = self.history_dir / f"execution_{timestamp}.json"
            with open(history_file, "w") as f:
                json.dump(self._to_dict(), f, indent=2)
        except Exception as e:
            print(f"⚠ Error saving to history: {e}")

    def get_state(self) -> Dict[str, Any]:
        """Get current state"""
        if not self.current_execution:
            return {}
        return self._to_dict()

    def get_stage_status(self, stage_name: str) -> Optional[str]:
        """Get status of a specific stage"""
        if not self.current_execution:
            return None
        stage = self.current_execution.stages.get(stage_name)
        return stage.status if stage else None

    def get_all_stages(self) -> Dict[str, str]:
        """Get status of all stages"""
        if not self.current_execution:
            return {}
        return {name: stage.status for name, stage in self.current_execution.stages.items()}

    def get_execution_history(self) -> List[Dict[str, Any]]:
        """Get list of past executions"""
        history = []
        try:
            for history_file in sorted(self.history_dir.glob("execution_*.json")):
                with open(history_file, "r") as f:
                    history.append(json.load(f))
        except Exception as e:
            print(f"⚠ Error reading history: {e}")
        return history

    def get_stage_log_path(self, stage_name: str) -> Optional[Path]:
        """Get log file path for a stage"""
        if not self.current_execution:
            return None
        stage = self.current_execution.stages.get(stage_name)
        if stage and stage.log_file:
            return Path(stage.log_file)
        return None

    async def record_debug_attempt(
        self,
        stage_name: str,
        attempt_number: int,
        error_category: str,
        fix_applied: bool,
        outcome: str,
    ):
        """
        Record a debug attempt for a stage

        Args:
            stage_name: Name of the stage being debugged
            attempt_number: Debug attempt number
            error_category: Error category detected
            fix_applied: Whether a fix was applied
            outcome: Outcome of the attempt ("success", "failed", "skipped")
        """
        async with self.lock:
            if not self.current_execution:
                return

            stage = self.current_execution.stages.get(stage_name)
            if not stage:
                return

            # Add debug info to metrics
            if "debug_attempts" not in stage.metrics:
                stage.metrics["debug_attempts"] = []

            stage.metrics["debug_attempts"].append({
                "attempt": attempt_number,
                "category": error_category,
                "fix_applied": fix_applied,
                "outcome": outcome,
                "timestamp": datetime.now().isoformat(),
            })

            self._save_state()

    def print_summary(self):
        """Print state summary"""
        if not self.current_execution:
            print("No execution state")
            return

        print("\n[STATE SUMMARY]")
        print("=" * 70)
        print(f"Run ID: {self.current_execution.run_id}")
        print(f"Status: {self.current_execution.status}")
        print(f"Started: {self.current_execution.start_time}")
        if self.current_execution.end_time:
            print(f"Ended: {self.current_execution.end_time}")
            print(f"Duration: {self.current_execution.duration:.1f}s")
        print(f"Current Stage: {self.current_execution.current_stage}")
        print(f"Debug Mode: {self.current_execution.debug_mode}")
        print(f"\nStages ({len(self.current_execution.stages)}):")
        for stage_name, stage in self.current_execution.stages.items():
            symbol = {
                "completed": "✓",
                "failed": "✗",
                "in_progress": "⟳",
                "skipped": "○",
            }.get(stage.status, "-")
            print(f"  {symbol} {stage_name:20s} {stage.status}")
        print("=" * 70)
