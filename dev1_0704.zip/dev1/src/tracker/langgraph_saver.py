#!/usr/bin/env python3
"""
LangGraph Saver Wrapper - Redis/Postgres backends only.
"""

import json
import importlib
from datetime import datetime
from typing import Optional, Dict, Any

try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False


class RedisSaverCompat:
    def __init__(self, redis_host: str = "localhost", redis_port: int = 6379, redis_db: int = 0):
        if not REDIS_AVAILABLE:
            raise RuntimeError("redis not installed. Run: pip install redis")

        try:
            self.redis_client = redis.Redis(
                host=redis_host,
                port=redis_port,
                db=redis_db,
                decode_responses=True,
                socket_connect_timeout=5,
            )
            self.redis_client.ping()
            print(f"✓ Connected to Redis at {redis_host}:{redis_port}")
        except Exception as e:
            raise RuntimeError(f"Failed to connect to Redis: {e}")

    def put(
        self,
        config: Dict[str, Any],
        values: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        try:
            thread_id = config.get("configurable", {}).get("thread_id")
            if not thread_id:
                return None

            checkpoint_id = f"ckpt_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            checkpoint_data = {
                "checkpoint_id": checkpoint_id,
                "timestamp": datetime.now().isoformat(),
                "data": json.dumps(values),
                "metadata": json.dumps(metadata or {}),
            }

            key = f"checkpoint:{thread_id}"
            self.redis_client.hset(key, checkpoint_id, json.dumps(checkpoint_data))
            self.redis_client.sadd("threads", thread_id)
            self.redis_client.expire(key, 30 * 24 * 60 * 60)
            return checkpoint_id
        except Exception as e:
            print(f"⚠ Error saving checkpoint: {e}")
            return None

    def get(self, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            thread_id = config.get("configurable", {}).get("thread_id")
            if not thread_id:
                return None

            key = f"checkpoint:{thread_id}"
            checkpoints = self.redis_client.hgetall(key)
            if not checkpoints:
                return None

            latest = max([json.loads(cp) for cp in checkpoints.values()], key=lambda x: x["timestamp"])
            return {
                "checkpoint_id": latest["checkpoint_id"],
                "timestamp": latest["timestamp"],
                "channel_values": json.loads(latest["data"]),
                "metadata": json.loads(latest["metadata"]),
            }
        except Exception as e:
            print(f"⚠ Error retrieving checkpoint: {e}")
            return None

    def get_all_threads(self) -> list:
        try:
            return list(self.redis_client.smembers("threads"))
        except Exception as e:
            print(f"⚠ Error retrieving threads: {e}")
            return []

    def delete_thread(self, thread_id: str) -> bool:
        try:
            key = f"checkpoint:{thread_id}"
            self.redis_client.delete(key)
            self.redis_client.srem("threads", thread_id)
            return True
        except Exception as e:
            print(f"⚠ Error deleting thread: {e}")
            return False

    async def aget(self, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        return self.get(config)

    async def aput(
        self,
        config: Dict[str, Any],
        values: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        return self.put(config, values, metadata)

    async def adelete_thread(self, config: Dict[str, Any]) -> bool:
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            return False
        return self.delete_thread(thread_id)

    async def aget_all_threads(self) -> list:
        return self.get_all_threads()


class PostgresSaverCompat:
    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self._init_db()

    def _init_db(self):
        try:
            import psycopg2

            conn = psycopg2.connect(self.connection_string)
            cursor = conn.cursor()
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS checkpoints (
                    thread_id TEXT NOT NULL,
                    checkpoint_id TEXT NOT NULL,
                    checkpoint_ns TEXT,
                    node TEXT,
                    timestamp TEXT,
                    data JSONB NOT NULL,
                    metadata JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (thread_id, checkpoint_id)
                )
                """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_thread_id
                ON checkpoints(thread_id, created_at DESC)
                """
            )
            conn.commit()
            conn.close()
        except ImportError:
            print("⚠ psycopg2 not installed. Install with: pip install psycopg2-binary")
        except Exception as e:
            print(f"⚠ Error initializing PostgreSQL: {e}")

    def put(self, config: Dict[str, Any], values: Dict[str, Any], metadata: Optional[Dict[str, Any]] = None) -> Optional[str]:
        raise NotImplementedError("Install langgraph PostgreSQL checkpointer support")

    def get(self, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        raise NotImplementedError("Install langgraph PostgreSQL checkpointer support")


def get_saver(
    backend: str = "redis",
    connection_string: Optional[str] = None,
    redis_host: str = "localhost",
    redis_port: int = 6379,
    redis_db: int = 0,
):
    if backend == "redis":
        return RedisSaverCompat(redis_host=redis_host, redis_port=redis_port, redis_db=redis_db)
    if backend == "postgres":
        if not connection_string:
            raise ValueError("connection_string required for PostgreSQL")
        return PostgresSaverCompat(connection_string)
    raise ValueError(f"Unknown backend: {backend}. Use 'redis' or 'postgres'")


class LangGraphSaverCompat:
    def __new__(
        cls,
        backend: str = "redis",
        connection_string: Optional[str] = None,
    ):
        try:
            if backend == "postgres":
                postgres_module = importlib.import_module("langgraph.checkpoint.postgres")
                PostgresSaver = getattr(postgres_module, "PostgresSaver")
                if not connection_string:
                    raise ValueError("connection_string required")
                return PostgresSaver(connection_string)
            if backend == "redis":
                return RedisSaverCompat()
        except ImportError:
            if backend == "postgres":
                return PostgresSaverCompat(connection_string or "")
            if backend == "redis":
                return RedisSaverCompat()
        raise ValueError(f"Unknown backend: {backend}. Use 'redis' or 'postgres'")


def create_thread_id(
    user_id: Optional[str] = None,
    block_name: Optional[str] = None,
    run_id: Optional[str] = None,
) -> str:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    if block_name and run_id:
        return f"u={user_id or 'user'}__b={block_name}__r={run_id}__t={timestamp}"

    if user_id:
        return f"{user_id}_run_{timestamp}"

    return f"run_{timestamp}"


def get_config_for_thread(thread_id: str) -> Dict[str, Any]:
    return {"configurable": {"thread_id": thread_id}}


def create_thread_id_for_experiment(user_id: str, block_name: str, experiment_name: str) -> str:
    return create_thread_id(user_id=user_id, block_name=block_name, run_id=experiment_name)


def parse_thread_id(thread_id: str) -> Dict[str, Optional[str]]:
    if thread_id.startswith("u=") and "__" in thread_id:
        pieces = {}
        for chunk in thread_id.split("__"):
            if "=" in chunk:
                key, value = chunk.split("=", 1)
                pieces[key] = value
        return {
            "user_id": pieces.get("u"),
            "block": pieces.get("b"),
            "experiment": pieces.get("r"),
            "timestamp": pieces.get("t"),
        }

    if "_run_" in thread_id:
        user_part, timestamp_part = thread_id.split("_run_", 1)
        return {
            "user_id": user_part or None,
            "block": None,
            "experiment": None,
            "timestamp": timestamp_part or None,
        }

    if thread_id.startswith("run_"):
        return {
            "user_id": None,
            "block": None,
            "experiment": None,
            "timestamp": thread_id.replace("run_", "", 1) or None,
        }

    return {
        "user_id": None,
        "block": None,
        "experiment": None,
        "timestamp": None,
    }


def get_user_threads_for_experiment(saver, user_id: str, block_name: str, experiment_name: str) -> list:
    if not hasattr(saver, "get_all_threads"):
        return []

    matches = []
    for thread_id in saver.get_all_threads():
        parsed = parse_thread_id(thread_id)
        if (
            parsed.get("user_id") == user_id
            and parsed.get("block") == block_name
            and parsed.get("experiment") == experiment_name
        ):
            matches.append(thread_id)
    return matches


class CheckpointBrowser:
    def __init__(self, saver):
        self.saver = saver

    def list_threads(self) -> list[str]:
        if hasattr(self.saver, "get_all_threads"):
            return self.saver.get_all_threads()
        return []

    def list_checkpoints(self, thread_id: str) -> list[Dict[str, Any]]:
        if hasattr(self.saver, "get_all"):
            return self.saver.get_all(thread_id)
        return []

    def show_checkpoint(self, thread_id: str, checkpoint_id: Optional[str] = None):
        checkpoints = self.list_checkpoints(thread_id)
        if not checkpoints:
            print(f"No checkpoints found for thread: {thread_id}")
            return

        if checkpoint_id:
            for ckpt in checkpoints:
                if ckpt["checkpoint_id"] == checkpoint_id:
                    print(f"Checkpoint: {ckpt['checkpoint_id']}")
                    print(f"Node: {ckpt['node']}")
                    print(f"Timestamp: {ckpt['timestamp']}")
                    print("State:")
                    print(json.dumps(ckpt["data"], indent=2))
                    return
            print(f"Checkpoint not found: {checkpoint_id}")
            return

        latest = checkpoints[-1]
        print(f"Latest Checkpoint: {latest['checkpoint_id']}")
        print(f"Node: {latest['node']}")
        print(f"Timestamp: {latest['timestamp']}")
        print("State:")
        print(json.dumps(latest["data"], indent=2))

    def show_thread_summary(self, thread_id: str):
        checkpoints = self.list_checkpoints(thread_id)
        if not checkpoints:
            print(f"No checkpoints for thread: {thread_id}")
            return

        print(f"\nThread: {thread_id}")
        print(f"Total Checkpoints: {len(checkpoints)}")
        print("\nExecution Timeline:")
        print("-" * 60)
        for i, ckpt in enumerate(checkpoints, 1):
            node = ckpt.get("node", "unknown")
            timestamp = ckpt.get("timestamp", "unknown")
            print(f"  {i}. {node:20s} {timestamp}")
        print("-" * 60)
