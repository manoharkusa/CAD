#!/usr/bin/env python3
"""
StageExecutor - Executes EDA tool stages with environment sourcing

Responsibilities:
1. Check if stage already completed (skip if marker exists)
2. Source sourceproj.env before running tools
3. Wrap tool execution with SLURM (srun) if configured
4. Execute TCL scripts with sourced environment
5. Run post-processing script after successful execution
6. Create completion marker file
7. Capture logs and results
"""

import asyncio
import os
import signal
from pathlib import Path
from typing import Dict, Any, Optional, Callable
import functools

# Ensure output is not buffered for real-time logging
_print = print
print = functools.partial(_print, flush=True)

from ..config.config_manager import ConfigManager


class StageExecutor:
    """
    Executes EDA tool stages with environment sourcing

    Features:
    - Skip if completion marker exists
    - SLURM integration (srun wrapper)
    - Sources sourceproj.env before running tools
    - Post-processing via unified post_stage.py
    - Creates completion marker on success
    - Logs output to log directory
    """

    def __init__(self, config_manager: ConfigManager, log_callback=None):
        """
        Initialize StageExecutor

        Args:
            config_manager: ConfigManager instance for path and env management
            log_callback: Optional callback for emitting logs to Redis
                          Signature: callback(message, level="INFO", payload=None)
        """
        self.config_manager = config_manager
        self.run_dir = config_manager.get_run_dir()
        self.log_callback = log_callback

    def _emit_log(self, message: str, level: str = "INFO", payload: Dict[str, Any] = None) -> None:
        """Emit log to both stdout and Redis via callback."""
        print(message)
        if self.log_callback:
            try:
                self.log_callback(message, level=level, payload=payload or {})
            except Exception as e:
                print(f"[WARN] log_callback failed: {e}")

    def _rotate_log_file(self, log_file: Path, stage_name: str, log_dir: Path) -> None:
        """
        Rotate existing log file before retry.

        Renames existing log file to <stage>_iter<N>.log where N is the next
        available iteration number.

        Args:
            log_file: Path to the current log file
            stage_name: Name of the stage
            log_dir: Directory containing log files
        """
        if not log_file.exists():
            return

        # Find the next available iteration number
        iter_num = 1
        while True:
            iter_log = log_dir / f"{stage_name}_iter{iter_num}.log"
            if not iter_log.exists():
                break
            iter_num += 1

        # Rename the existing log file
        try:
            log_file.rename(iter_log)
            print(f"[RETRY] Renamed existing log: {log_file.name} -> {iter_log.name}")
            self._emit_log(
                f"Renamed previous log to {iter_log.name} for retry",
                level="INFO",
                payload={
                    "stage": stage_name,
                    "previous_log": str(log_file),
                    "archived_log": str(iter_log),
                    "iteration": iter_num,
                },
            )
        except Exception as e:
            print(f"[WARN] Failed to rotate log file: {e}")

    async def execute_stage(
        self,
        stage_name: str,
        tool_name: str,
        tool_script: str,
        tool_executable: str = None,
        tool_args: str = None,
        force: bool = False,
        abort_checker: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a TCL script from ENV_SCRIPTS

        Execution flow:
        1. Check if stage already completed (skip if marker exists)
        2. Build command with SLURM wrapper if configured
        3. Execute tool with environment sourcing
        4. Run post-processing script
        5. Create completion marker on success

        Args:
            stage_name: Name of stage (syn, place, route, etc.)
            tool_name: Tool name from flow_config.yaml (genus, innovus, etc.)
            tool_script: Script name from flow_config.yaml (syn.tcl, place.tcl, etc.)
            tool_executable: Optional override for executable (defaults to tool_name)
            tool_args: Optional arguments to pass to tool (e.g., "-stylus" for Innovus)
            force: If True, run even if completion marker exists

        Returns:
            Dictionary with execution result
        """

        # ============================================================
        # Step 1: Check completion marker
        # ============================================================
        marker_path = self.config_manager.get_complete_marker_path(stage_name)
        if marker_path.exists() and not force:
            print(f"[SKIP] {stage_name} already completed (marker exists: {marker_path})")
            return {
                "status": "skipped",
                "stage": stage_name,
                "reason": "Completion marker exists",
                "marker_path": str(marker_path),
            }

        # ============================================================
        # Step 2: Get paths and validate
        # ============================================================
        script_path = self.config_manager.get_tool_script_path(
            tool_name=tool_name,
            script_name=tool_script
        )

        work_dir = self.config_manager.get_stage_work_dir(stage_name)
        log_dir = self.config_manager.get_stage_log_dir(stage_name)
        env_file = self.config_manager.get_env_file_path()

        print(f"\n[VALIDATE] Checking stage prerequisites:")
        print(f"[VALIDATE]   Script: {script_path}")
        print(f"[VALIDATE]     → Exists: {script_path.exists()}")
        print(f"[VALIDATE]   Work dir: {work_dir}")
        print(f"[VALIDATE]     → Exists: {work_dir.exists()}")
        print(f"[VALIDATE]   Log dir: {log_dir}")
        print(f"[VALIDATE]     → Exists: {log_dir.exists()}")
        print(f"[VALIDATE]   Env file: {env_file}")
        print(f"[VALIDATE]     → Exists: {env_file.exists()}")

        if not work_dir.exists():
            raise FileNotFoundError(f"Work directory does not exist: {work_dir}")
        if not log_dir.exists():
            raise FileNotFoundError(f"Log directory does not exist: {log_dir}")
        if not script_path.exists():
            raise FileNotFoundError(f"Tool script not found: {script_path}")
        if not env_file.exists():
            raise FileNotFoundError(f"Environment file not found: {env_file}")

        # ============================================================
        # Step 3: Determine executor and shell
        # ============================================================
        executor = tool_executable or tool_name
        log_file = log_dir / f"{stage_name}.log"

        # If log file exists (retry scenario), rename it with iteration number
        if log_file.exists():
            self._rotate_log_file(log_file, stage_name, log_dir)

        # Detect environment file format (bash vs tcsh)
        is_tcsh = False
        try:
            with open(env_file, 'r') as f:
                first_line = f.readline().strip()
                is_tcsh = 'tcsh' in first_line or 'csh' in first_line
        except Exception as e:
            print(f"[WARN] Could not detect env file format: {e}")

        shell_executable = "/bin/tcsh" if is_tcsh else "/bin/bash"
        print(f"  Shell: {'tcsh' if is_tcsh else 'bash'} (detected from {env_file.name})")

        # ============================================================
        # Step 4: Get SLURM configuration
        # ============================================================
        slurm_config = self.config_manager.get_slurm_config(stage_name)
        use_slurm = slurm_config.get("enabled", False)

        if use_slurm:
            self._emit_log(
                f"[SLURM] Submitting {stage_name} to SLURM cluster",
                payload={
                    "stage": stage_name,
                    "slurm_enabled": True,
                    "partition": slurm_config['partition'],
                    "cpus_per_task": slurm_config['cpus_per_task'],
                    "mem": slurm_config['mem'],
                },
            )
            print(f"  Partition: {slurm_config['partition']}")
            print(f"  CPUs: {slurm_config['cpus_per_task']}")
            print(f"  Memory: {slurm_config['mem']}")

        # ============================================================
        # Step 5: Build and execute command
        # ============================================================
        print(f"  Tool: {tool_name}")
        print(f"  Script: {script_path}")
        print(f"  Working dir: {work_dir}")
        print(f"  Env file: {env_file}")

        script_path_str = str(script_path)
        log_file_str = str(log_file)

        # Build tool command with optional SLURM wrapper
        # Include tool_args if provided (e.g., "-stylus" for Innovus)
        tool_args_str = f" {tool_args}" if tool_args else ""
        slurm_job_name = None
        if use_slurm:
            srun_path = slurm_config.get("srun_path", "srun")
            partition = slurm_config["partition"]
            cpus = slurm_config["cpus_per_task"]
            mem = slurm_config["mem"]
            slurm_job_name = f"{stage_name}_{self.config_manager.block_name}"
            tool_cmd = (
                f'{srun_path} --verbose -p {partition} '
                f'--cpus-per-task={cpus} --mem={mem} '
                f'--job-name={slurm_job_name} '
                f'{executor}{tool_args_str} -files "{script_path_str}" -abort_on_error'
            )
        else:
            tool_cmd = f'{executor}{tool_args_str} -files "{script_path_str}" -abort_on_error'

        # Build full command with environment sourcing
        if is_tcsh:
            cmd = (
                f"tcsh -c 'source {str(env_file)} && "
                f"{tool_cmd} | tee {log_file_str}'"
            )
        else:
            cmd = (
                f"source {str(env_file)} && "
                f"{tool_cmd} | tee {log_file_str}"
            )

        print(f"  Executor: {executor}")
        print(f"  Command: {cmd}")

        # Execute the tool
        result = await self._run_tool(
            cmd=cmd,
            work_dir=work_dir,
            log_file=log_file,
            stage_name=stage_name,
            shell_executable=shell_executable,
            use_slurm=use_slurm,
            slurm_config=slurm_config if use_slurm else None,
            slurm_job_name=slurm_job_name,
                abort_checker=abort_checker,
        )

        # ============================================================
        # Step 6: Run post-processing if successful
        # ============================================================
        if result.get("status") == "success":
            post_config = self.config_manager.get_post_processing_config()
            if post_config.get("enabled") and post_config.get("script"):
                print(f"[POST] Running post-processing for {stage_name}...")
                post_result = await self._run_post_processing(
                    stage_name=stage_name,
                    script_path=post_config["script"],
                    work_dir=work_dir,
                    log_dir=log_dir,
                )
                result["post_processing"] = post_result

            # Create completion marker
            try:
                marker_path.touch()
                print(f"[OK] Created completion marker: {marker_path}")
                result["marker_path"] = str(marker_path)
            except Exception as e:
                print(f"[WARN] Failed to create completion marker: {e}")

        return result

    async def _run_tool(
        self,
        cmd: str,
        work_dir: Path,
        log_file: Path,
        stage_name: str,
        shell_executable: str = "/bin/bash",
        use_slurm: bool = False,
        slurm_config: Dict[str, Any] = None,
        slurm_job_name: str = None,
        abort_checker: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Run tool subprocess with shell command

        Sources sourceproj.env before running tool
        All environment variables available to TCL scripts

        Args:
            cmd: Shell command string (with source and pipe)
            work_dir: Working directory for execution
            log_file: Path to log file
            stage_name: Stage name for logging
            shell_executable: Shell to use (/bin/bash or /bin/tcsh)
            use_slurm: Whether SLURM is enabled
            slurm_config: SLURM configuration dict
            slurm_job_name: SLURM job name

        Returns:
            Dictionary with execution result
        """
        import re

        # UI_MSG Protocol for TCL puts statements to stream to UI
        # Usage in TCL: source $env(ENV_SCRIPTS)/common/ui_common_procs.tcl
        #               ui_info "Reading netlist..."
        #               ui_warn "Clock constraint missing"
        #               ui_error "Timing violation detected"
        #               ui_progress 50 "Optimization in progress"
        # Format: UI_MSG <LEVEL> <message>
        UI_MSG_PREFIX = "UI_MSG "

        try:
            print(f"\n[EXEC] Running {stage_name}...")
            print(f"  Sourcing environment in {shell_executable}...")

            # Create subprocess with shell=True to handle pipes and source command
            subprocess_kwargs = {
                "cwd": str(work_dir),
                "stdout": asyncio.subprocess.PIPE,
                "stderr": asyncio.subprocess.PIPE,
                "env": os.environ.copy(),
                "executable": shell_executable,
            }

            if os.name != "nt" and hasattr(os, "setsid"):
                subprocess_kwargs["preexec_fn"] = os.setsid

            process = await asyncio.create_subprocess_shell(cmd, **subprocess_kwargs)

            slurm_job_id = None
            stderr_lines = []

            # Read stdout and stderr concurrently with real-time streaming
            async def read_stream(stream, is_stderr=False):
                nonlocal slurm_job_id
                lines = []
                while True:
                    line = await stream.readline()
                    if not line:
                        break
                    decoded_line = line.decode('utf-8', errors='ignore').rstrip()
                    lines.append(decoded_line)

                    if is_stderr:
                        # Check for SLURM job ID in stderr
                        if use_slurm and 'srun: job' in decoded_line:
                            job_id_match = re.search(r'srun: job (\d+)', decoded_line)
                            if job_id_match:
                                slurm_job_id = job_id_match.group(1)
                                self._emit_log(
                                    f"[SLURM] Job {slurm_job_id} running for {stage_name}",
                                    payload={
                                        "stage": stage_name,
                                        "slurm_job_id": slurm_job_id,
                                        "slurm_job_name": slurm_job_name,
                                        "partition": slurm_config.get("partition") if slurm_config else None,
                                        "cpus_per_task": slurm_config.get("cpus_per_task") if slurm_config else None,
                                        "mem": slurm_config.get("mem") if slurm_config else None,
                                    },
                                )
                    else:
                        # Check for UI_MSG prefix in stdout (TCL ui_* procs)
                        if decoded_line.startswith(UI_MSG_PREFIX):
                            # Parse: "UI_MSG <LEVEL> <message>"
                            content = decoded_line[len(UI_MSG_PREFIX):]
                            parts = content.split(" ", 1)
                            level = parts[0] if parts else "INFO"
                            msg = parts[1] if len(parts) > 1 else ""

                            # Handle PROGRESS level specially (extract percentage)
                            payload = {
                                "stage": stage_name,
                                "source": "tcl_script",
                                "level": level,
                                "slurm_job_id": slurm_job_id,
                            }

                            if level == "PROGRESS":
                                # Format: PROGRESS <percent> <message>
                                progress_parts = msg.split(" ", 1)
                                if progress_parts:
                                    try:
                                        payload["percent"] = int(progress_parts[0])
                                        msg = progress_parts[1] if len(progress_parts) > 1 else ""
                                    except ValueError:
                                        pass
                            elif level == "METRIC":
                                # Format: METRIC <name> <value>
                                metric_parts = msg.split(" ", 1)
                                if len(metric_parts) >= 2:
                                    payload["metric_name"] = metric_parts[0]
                                    payload["metric_value"] = metric_parts[1]
                            elif level == "STAGE_START":
                                payload["stage_event"] = "start"
                                payload["stage_name"] = msg
                            elif level == "STAGE_END":
                                # Format: STAGE_END <name> <status>
                                end_parts = msg.split(" ", 1)
                                payload["stage_event"] = "end"
                                payload["stage_name"] = end_parts[0] if end_parts else ""
                                payload["stage_status"] = end_parts[1] if len(end_parts) > 1 else "unknown"

                            self._emit_log(
                                f"[{stage_name}] {msg}",
                                level=level if level in ["INFO", "WARN", "ERROR"] else "INFO",
                                payload=payload,
                            )
                return lines

            async def terminate_process_tree() -> None:
                if process.returncode is not None:
                    return

                try:
                    if os.name != "nt" and hasattr(os, "killpg"):
                        os.killpg(process.pid, signal.SIGTERM)
                    else:
                        process.terminate()
                except ProcessLookupError:
                    return
                except Exception as terminate_error:
                    print(f"[WARN] Failed to terminate {stage_name} process cleanly: {terminate_error}")

                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                    return
                except asyncio.TimeoutError:
                    pass

                if process.returncode is None:
                    try:
                        if os.name != "nt" and hasattr(os, "killpg"):
                            os.killpg(process.pid, signal.SIGKILL)
                        else:
                            process.kill()
                    except ProcessLookupError:
                        return
                    except Exception as kill_error:
                        print(f"[WARN] Failed to kill {stage_name} process tree: {kill_error}")

                await process.wait()

            # Run with timeout
            try:
                stdout_task = asyncio.create_task(read_stream(process.stdout, is_stderr=False))
                stderr_task = asyncio.create_task(read_stream(process.stderr, is_stderr=True))

                timeout_seconds = 3600
                loop = asyncio.get_running_loop()
                started_at = loop.time()
                abort_message = None

                while process.returncode is None:
                    if callable(abort_checker):
                        try:
                            abort_status = abort_checker() or {}
                        except Exception as abort_error:
                            print(f"[WARN] abort_checker error for {stage_name}: {abort_error}")
                            abort_status = {}

                        if abort_status.get("abort_requested"):
                            abort_message = abort_status.get("message") or "Abort requested during stage execution"
                            self._emit_log(
                                f"[ABORT] {stage_name} interrupted: {abort_message}",
                                level="WARN",
                                payload={"stage": stage_name, "abort_requested": True, "message": abort_message},
                            )
                            await terminate_process_tree()
                            break

                    if loop.time() - started_at > timeout_seconds:
                        await terminate_process_tree()
                        raise asyncio.TimeoutError()

                    await asyncio.sleep(1)

                await process.wait()

                stdout_lines = await stdout_task
                stderr_lines = await stderr_task

                if abort_message:
                    return {
                        "status": "aborted",
                        "stage": stage_name,
                        "error": abort_message,
                        "log_file": str(log_file),
                        "slurm_job_id": slurm_job_id,
                    }

            except asyncio.TimeoutError:
                await terminate_process_tree()
                print(f"[FAIL] {stage_name} execution timeout exceeded")
                return {
                    "status": "failed",
                    "stage": stage_name,
                    "error": "Execution timeout exceeded",
                    "log_file": str(log_file),
                    "slurm_job_id": slurm_job_id,
                }

            # Write stderr to log if present
            if stderr_lines:
                with open(log_file, 'a') as f:
                    f.write(f"\n=== STDERR ===\n")
                    f.write('\n'.join(stderr_lines))

            # Determine success/failure
            if process.returncode == 0:
                print(f"[OK] {stage_name} completed successfully")
                print(f"  Log: {log_file}")
                result = {
                    "status": "success",
                    "stage": stage_name,
                    "return_code": 0,
                    "log_file": str(log_file),
                }
                if slurm_job_id:
                    result["slurm_job_id"] = slurm_job_id
                return result
            else:
                # Try to get error from stderr first
                if stderr_lines:
                    error_msg = '\n'.join(stderr_lines[-10:])
                else:
                    # If stderr is empty, try to extract error from log file
                    error_msg = self._extract_error_from_log(log_file, process.returncode)

                print(f"[FAIL] {stage_name} failed with return code {process.returncode}")
                print(f"  Error: {error_msg[:200]}")
                print(f"  Log: {log_file}")

                result = {
                    "status": "failed",
                    "stage": stage_name,
                    "return_code": process.returncode,
                    "log_file": str(log_file),
                    "error": error_msg[:500],
                }
                if slurm_job_id:
                    result["slurm_job_id"] = slurm_job_id
                return result

        except Exception as e:
            print(f"[FAIL] Exception executing {stage_name}: {e}")
            return {
                "status": "failed",
                "stage": stage_name,
                "error": str(e),
                "log_file": str(log_file),
            }

    async def _run_post_processing(
        self,
        stage_name: str,
        script_path: str,
        work_dir: Path,
        log_dir: Path,
    ) -> Dict[str, Any]:
        """
        Run post-processing Python script after stage completion

        Args:
            stage_name: Name of the completed stage
            script_path: Path to post-processing script
            work_dir: Stage work directory
            log_dir: Stage log directory

        Returns:
            Dictionary with post-processing result
        """
        try:
            post_log = log_dir / f"{stage_name}_post.log"

            # Get required arguments from config_manager
            run_dir = self.config_manager.get_run_dir()
            # stage_dir is parent of work_dir (accounts for stage_group like pnr/)
            stage_dir = work_dir.parent  # e.g., run_dir/syn or run_dir/pnr/floorplan
            project = self.config_manager.project_name
            block_name = self.config_manager.block_name
            rtl_tag = self.config_manager.rtl_tag
            exp_name = self.config_manager.run_tag  # run_tag is the experiment name
            env_scripts = self.config_manager.get_env_var("ENV_SCRIPTS", "")

            # Build command to run post-processing script with all required args
            cmd = (
                f"python3 {script_path} "
                f"--stage {stage_name} "
                f"--stage-dir {stage_dir} "
                f"--run-dir {run_dir} "
                f"--project {project} "
                f"--block-name {block_name} "
                f"--rtl-tag {rtl_tag} "
                f"--exp-name {exp_name} "
                f"--env-scripts {env_scripts} "
                f"--status success"
            )

            print(f"[POST] Command: {cmd}")

            process = await asyncio.create_subprocess_shell(
                cmd,
                cwd=str(work_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=os.environ.copy(),
            )

            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=300  # 5 minute timeout for post-processing
            )

            # Write output to log
            with open(post_log, 'w') as f:
                f.write(stdout.decode('utf-8', errors='ignore'))
                if stderr:
                    f.write(f"\n=== STDERR ===\n")
                    f.write(stderr.decode('utf-8', errors='ignore'))

            if process.returncode == 0:
                print(f"[POST] Post-processing completed successfully")
                return {
                    "status": "success",
                    "log_file": str(post_log),
                }
            else:
                print(f"[POST] Post-processing failed with return code {process.returncode}")
                return {
                    "status": "failed",
                    "return_code": process.returncode,
                    "log_file": str(post_log),
                }

        except asyncio.TimeoutError:
            print(f"[POST] Post-processing timeout")
            return {
                "status": "failed",
                "error": "Post-processing timeout",
            }
        except Exception as e:
            print(f"[POST] Post-processing error: {e}")
            return {
                "status": "failed",
                "error": str(e),
            }

    def _extract_error_from_log(self, log_file: Path, return_code: int) -> str:
        """
        Extract error information from log file when stderr is empty.

        Looks for specific error patterns in EDA tool logs:
        - ERROR (case insensitive)
        - Error at start of line
        - File not found
        - invalid command name
        - Encountered problems processing file

        Args:
            log_file: Path to the log file
            return_code: Process return code

        Returns:
            Error message string
        """
        import re

        try:
            if not log_file.exists():
                return f"Stage failed with return code {return_code} (no log file)"

            with open(log_file, 'r', errors='ignore') as f:
                lines = f.readlines()

            if not lines:
                return f"Stage failed with return code {return_code} (empty log file)"

            # Specific error patterns to look for
            error_patterns = [
                (r'ERROR', re.IGNORECASE),           # ERROR anywhere (case insensitive)
                (r'^Error', 0),                       # Error at start of line
                (r'File not found', re.IGNORECASE),  # File not found
                (r'invalid command name', re.IGNORECASE),  # TCL error
                (r'Encountered problems processing file', re.IGNORECASE),  # Processing error
            ]

            # Collect error lines
            error_lines = []
            for line in lines:
                line_stripped = line.strip()
                for pattern, flags in error_patterns:
                    if re.search(pattern, line_stripped, flags):
                        error_lines.append(line_stripped)
                        break

            if error_lines:
                # Deduplicate while preserving order
                seen = set()
                unique_errors = []
                for line in error_lines:
                    if line and line not in seen:
                        seen.add(line)
                        unique_errors.append(line)
                return '\n'.join(unique_errors[-10:])  # Last 10 unique error lines

            # Fallback: return last 5 non-empty lines
            last_lines = [l.strip() for l in lines[-20:] if l.strip()][-5:]
            if last_lines:
                return f"Stage failed (return code {return_code}):\n" + '\n'.join(last_lines)

            return f"Stage failed with return code {return_code}"

        except Exception as e:
            return f"Stage failed with return code {return_code} (error reading log: {e})"
