"""Skills-based validation using Claude Agent SDK with YAML frontmatter.

This module provides stage validation after successful execution using
tool-specific skill files with YAML frontmatter for metadata.
"""

from __future__ import annotations

import json
import re
import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.infra.token_tracker import token_tracker
from src.config.runtime_config import get_claude_model


@dataclass
class ValidationResult:
    """Result of stage validation."""

    stage: str
    tool: str
    passed: bool
    metrics: Dict[str, Any] = field(default_factory=dict)
    issues: List[str] = field(default_factory=list)
    checks_passed: List[str] = field(default_factory=list)
    recommendation: str = ""
    summary: str = ""  # Formatted markdown summary for UI


class ValidationRunner:
    """Run validation using Claude Agent SDK with tool-specific skills.

    Skills are loaded from markdown files with YAML frontmatter that defines
    metadata like stage name, tool, and description. The system automatically
    finds the correct skill based on stage and tool.
    """

    # Map stage names to skill file lookup
    STAGE_ALIASES = {
        "synthesis": "syn",
        "placement": "place",
        "clock_tree": "cts",
        "routing": "route",
        "physical_verification": "pv",
    }

    def __init__(
        self,
        config_manager,
        log_callback: Optional[Callable[[str], None]] = None,
        ui_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    ):
        """Initialize the validation runner.

        Args:
            config_manager: Configuration manager for stage configs
            log_callback: Callback for logging messages
            ui_callback: Callback for sending messages to web UI
        """
        self.config_manager = config_manager
        self.log_callback = log_callback
        self.ui_callback = ui_callback
        self.skills_dir = Path(__file__).parent.parent.parent / "skills" / "validation"
        self._skill_cache: Dict[str, Path] = {}

    def _emit_log(self, msg: str) -> None:
        """Emit log message."""
        if self.log_callback:
            self.log_callback(msg)
        else:
            print(msg)

    def _emit_ui_log(self, msg: str, payload: Optional[Dict[str, Any]] = None) -> None:
        """Send message to web UI."""
        if self.ui_callback:
            self.ui_callback(msg, payload or {})

    def _format_tool_call(self, tool_name: str, tool_input: Dict[str, Any]) -> str:
        """Format tool call for human-readable display."""
        if tool_name == "Read":
            file_path = tool_input.get("file_path", "unknown")
            return f"Reading {file_path}"
        elif tool_name == "Grep":
            pattern = tool_input.get("pattern", "")
            path = tool_input.get("path", ".")
            return f"Searching for '{pattern}' in {path}"
        elif tool_name == "Glob":
            pattern = tool_input.get("pattern", "")
            path = tool_input.get("path", ".")
            return f"Finding files matching '{pattern}' in {path}"
        elif tool_name == "Bash":
            command = tool_input.get("command", "")
            if len(command) > 80:
                command = command[:77] + "..."
            return f"Running: {command}"
        else:
            return f"Calling {tool_name}"

    def _parse_skill_file(self, path: Path) -> Tuple[Optional[Dict[str, Any]], str]:
        """Parse YAML frontmatter and content from skill file.

        Args:
            path: Path to the skill file

        Returns:
            Tuple of (metadata dict, body content string)
        """
        try:
            content = path.read_text()
        except Exception as e:
            self._emit_log(f"[VALIDATE] Error reading skill file {path}: {e}")
            return None, ""

        # Extract YAML frontmatter between --- markers
        match = re.match(r"^---\n(.*?)\n---\n(.*)$", content, re.DOTALL)
        if not match:
            return None, content

        try:
            metadata = yaml.safe_load(match.group(1))
            body = match.group(2).strip()
            return metadata, body
        except yaml.YAMLError as e:
            self._emit_log(f"[VALIDATE] Error parsing YAML in {path}: {e}")
            return None, content

    def _load_skills_index(self) -> Dict[str, Path]:
        """Build index of skills by (stage:tool) key from frontmatter.

        Returns:
            Dict mapping "stage:tool" keys to skill file paths
        """
        if self._skill_cache:
            return self._skill_cache

        if not self.skills_dir.exists():
            self._emit_log(f"[VALIDATE] Skills directory not found: {self.skills_dir}")
            return {}

        for skill_file in self.skills_dir.glob("*.skill.md"):
            meta, _ = self._parse_skill_file(skill_file)
            if meta:
                stage = meta.get("stage", "")
                tool = meta.get("tool", "")
                if stage and tool:
                    key = f"{stage}:{tool}"
                    self._skill_cache[key] = skill_file
                    self._emit_log(f"[VALIDATE] Indexed skill: {key} -> {skill_file.name}")

        return self._skill_cache

    def _find_skill(
        self, stage: str, tool: str
    ) -> Optional[Tuple[Dict[str, Any], str]]:
        """Find skill file matching stage and tool.

        Args:
            stage: Stage name (e.g., "syn", "place")
            tool: Tool name (e.g., "genus", "dc_shell")

        Returns:
            Tuple of (metadata, body) if found, None otherwise
        """
        index = self._load_skills_index()

        # Normalize stage name
        stage_normalized = self.STAGE_ALIASES.get(stage.lower(), stage.lower())
        tool_normalized = tool.lower().replace("-", "_")

        # Try exact match
        key = f"{stage_normalized}:{tool_normalized}"
        if key in index:
            return self._parse_skill_file(index[key])

        # Try stage with any tool (fallback)
        for k, path in index.items():
            if k.startswith(f"{stage_normalized}:"):
                self._emit_log(f"[VALIDATE] Using fallback skill {path.name} for {stage}/{tool}")
                return self._parse_skill_file(path)

        return None

    def _detect_tool(self, stage_name: str) -> str:
        """Detect tool from stage configuration.

        Args:
            stage_name: Name of the stage

        Returns:
            Tool name (lowercase)
        """
        try:
            # get_stage_tool_script returns (tool_name, script_name)
            tool, _ = self.config_manager.get_stage_tool_script(stage_name)
            return tool.lower().replace("-", "_")
        except Exception:
            return "unknown"

    def _format_summary(
        self, result: ValidationResult, metadata: Dict[str, Any]
    ) -> str:
        """Format validation result as markdown summary for UI.

        Args:
            result: Validation result
            metadata: Skill metadata

        Returns:
            Formatted markdown string
        """
        status = "PASSED" if result.passed else "FAILED"
        status_icon = "✓" if result.passed else "✗"

        lines = [
            f"## Validation Summary: {result.stage} ({result.tool})",
            "",
            f"**Status**: {status} {status_icon}",
            "",
        ]

        # Metrics table
        if result.metrics:
            lines.extend([
                "### Metrics",
                "| Metric | Value |",
                "|--------|-------|",
            ])
            for key, value in result.metrics.items():
                lines.append(f"| {key} | {value} |")
            lines.append("")

        # Checks
        if result.checks_passed or result.issues:
            lines.append("### Checks")
            for check in result.checks_passed:
                lines.append(f"- ✓ {check}")
            for issue in result.issues:
                lines.append(f"- ✗ {issue}")
            lines.append("")

        # Recommendation
        if result.recommendation:
            lines.extend([
                "### Recommendation",
                result.recommendation,
            ])

        return "\n".join(lines)

    def _parse_response(
        self, response: str, stage: str, tool: str
    ) -> ValidationResult:
        """Parse Claude's JSON response into ValidationResult.

        Args:
            response: Raw response text from Claude
            stage: Stage name
            tool: Tool name

        Returns:
            ValidationResult parsed from response
        """
        # Look for JSON block in response
        json_match = re.search(r"```json\s*(.*?)\s*```", response, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group(1))
                return ValidationResult(
                    stage=stage,
                    tool=tool,
                    passed=data.get("passed", False),
                    metrics=data.get("metrics", {}),
                    issues=data.get("issues", []),
                    checks_passed=data.get("checks_passed", []),
                    recommendation=data.get("recommendation", ""),
                )
            except json.JSONDecodeError:
                pass

        # Fallback: infer from keywords
        passed = "passed" in response.lower() and "failed" not in response.lower()
        return ValidationResult(
            stage=stage,
            tool=tool,
            passed=passed,
            issues=["Could not parse structured response"] if not passed else [],
        )

    async def validate_stage(
        self,
        stage_name: str,
        stage_result: Dict[str, Any],
        work_dir: Path,
        log_dir: Path,
    ) -> ValidationResult:
        """Validate a completed stage using tool-specific skills.

        Args:
            stage_name: Name of the stage to validate
            stage_result: Result dict from stage execution
            work_dir: Stage working directory
            log_dir: Stage log directory

        Returns:
            ValidationResult with pass/fail status, metrics, and summary
        """
        # Import here to avoid circular imports and allow graceful degradation
        try:
            from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, ResultMessage
        except ImportError:
            ResultMessage = None
            self._emit_log("[VALIDATE] Claude Agent SDK not available, skipping validation")
            return ValidationResult(
                stage=stage_name,
                tool="unknown",
                passed=True,
                recommendation="Validation skipped (SDK not available)",
            )

        # Detect tool
        tool = self._detect_tool(stage_name)
        self._emit_log(f"[VALIDATE] Stage: {stage_name}, Tool: {tool}")

        # Find matching skill
        skill = self._find_skill(stage_name, tool)
        if not skill:
            self._emit_log(f"[VALIDATE] No validation skill found for {stage_name}/{tool}")
            return ValidationResult(
                stage=stage_name,
                tool=tool,
                passed=True,
                recommendation="No validation skill defined for this stage/tool",
            )

        metadata, instructions = skill
        skill_name = metadata.get("name", "unknown")
        self._emit_log(f"[VALIDATE] Using skill: {skill_name}")

        # Notify UI: validation starting
        self._emit_ui_log(
            f"Starting validation for {stage_name} ({tool})",
            {
                "stage": stage_name,
                "tool": tool,
                "type": "validation_started",
                "skill": skill_name,
            },
        )

        # Build prompt for Claude
        prompt = f"""Validate the **{stage_name}** stage (tool: {tool}).

**Directories**:
- Work Directory: {work_dir}
- Log Directory: {log_dir}

**Stage Execution Result**:
```json
{json.dumps(stage_result, indent=2, default=str)}
```

**Validation Instructions**:
{instructions}

**Your Task**:
1. **Use Grep tool** (NOT Read) to search for specific patterns in log files and reports
   - Log files can be 10K+ lines - DO NOT read entire files
   - Grep for error patterns, success indicators, and metrics
   - Only use Read for small files (<100 lines) or specific line context
2. Apply the validation checks specified in the instructions
3. Extract the metrics mentioned using Grep patterns
4. Determine if the stage passed or failed based on the criteria

**Return your result as JSON**:
```json
{{
    "passed": true or false,
    "metrics": {{"wns": -0.05, "area": 12345, ...}},
    "checks_passed": ["Log file exists", "No errors found", ...],
    "issues": ["WNS below threshold", ...],
    "recommendation": "Proceed to next stage" or "Fix timing violations"
}}
```
"""

        response_text = ""
        try:
            async for message in query(
                prompt=prompt,
                options=ClaudeAgentOptions(
                    model=get_claude_model(),
                    allowed_tools=["Read", "Grep", "Glob"],
                    permission_mode="default",
                ),
            ):
                if AssistantMessage and isinstance(message, AssistantMessage):
                    for block in message.content:
                        if hasattr(block, "text"):
                            response_text += block.text
                            # Stream progress to UI
                            self._emit_ui_log(
                                block.text,
                                {
                                    "stage": stage_name,
                                    "type": "validation_progress",
                                },
                            )
                        elif hasattr(block, "name"):
                            # Tool call - format for human-readable display
                            tool_name = block.name
                            tool_input = getattr(block, "input", {}) or {}
                            tool_detail = self._format_tool_call(tool_name, tool_input)
                            self._emit_log(f"[VALIDATE] {tool_detail}")
                            self._emit_ui_log(
                                tool_detail,
                                {
                                    "stage": stage_name,
                                    "type": "validation_tool",
                                    "tool": tool_name,
                                },
                            )
                # Track token usage from ResultMessage (usage is a dict in Python SDK)
                if ResultMessage and isinstance(message, ResultMessage):
                    usage = getattr(message, "usage", None) or {}

                    if isinstance(usage, dict):
                        # Extract cache tokens
                        cache_read = usage.get("cache_read_input_tokens", 0)
                        cache_creation = usage.get("cache_creation_input_tokens", 0)
                        base_input = usage.get("input_tokens", 0)
                        # Calculate total input tokens (including cache tokens)
                        input_tokens = base_input + cache_creation + cache_read
                        output_tokens = usage.get("output_tokens", 0)
                    else:
                        input_tokens = getattr(usage, "input_tokens", 0)
                        output_tokens = getattr(usage, "output_tokens", 0)
                        cache_read = 0
                        cache_creation = 0

                    # Get cost and turns
                    total_cost = getattr(message, "total_cost_usd", None) or 0.0
                    num_turns = getattr(message, "num_turns", None) or 0

                    # Always record if we have any data (tokens, cost, or turns)
                    if input_tokens or output_tokens or total_cost or num_turns:
                        token_tracker.record_manual(
                            input_tokens=input_tokens,
                            output_tokens=output_tokens,
                            source=f"validation_runner.{stage_name}",
                            model=getattr(message, "model", "claude-agent-sdk"),
                            cost_usd=total_cost,
                            num_turns=num_turns,
                            cache_read_tokens=cache_read,
                            cache_creation_tokens=cache_creation,
                        )

        except Exception as e:
            self._emit_log(f"[VALIDATE] Error during validation: {e}")
            result = ValidationResult(
                stage=stage_name,
                tool=tool,
                passed=False,
                issues=[f"Validation error: {str(e)}"],
                recommendation="Check validation setup and try again",
            )
            result.summary = self._format_summary(result, metadata)
            return result

        # Parse response
        result = self._parse_response(response_text, stage_name, tool)

        # Format summary
        result.summary = self._format_summary(result, metadata)

        # Send complete summary to UI
        self._emit_ui_log(
            result.summary,
            {
                "stage": stage_name,
                "tool": tool,
                "type": "validation_summary",
                "passed": result.passed,
                "metrics": result.metrics,
            },
        )

        self._emit_log(
            f"[VALIDATE] {stage_name} validation {'PASSED' if result.passed else 'FAILED'}"
        )

        return result
