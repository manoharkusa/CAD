# Concurrency Workflow (Business + Engineering View)

## 1) What changed (simple)

Before:
- One queue path behaved effectively sequentially under load.
- No strong guardrails for deferred jobs, retries, or stuck pending stream messages.

After:
- Multiple workers process jobs in parallel from Redis Streams.
- Every job has `job_id` + `run_id` and is tracked end-to-end.
- Admission policy controls start rate by capacity/quotas.
- Deferred and failing jobs are bounded (retry + DLQ).
- Stuck pending stream messages are reclaimed with `XAUTOCLAIM`.
- Runtime counters are exposed via `/jobs/ops-metrics`.

---

## 2) Identity and policy model

- `job_id`: request identity (API/business tracking)
- `run_id`: execution identity (worker/HITL/runtime tracking)
- `session_id`: trace context only (not scheduling key)
- `design_key = project:block:rtl_tag`: analytics/grouping key only

### Scope policy meaning (current)

Scope policy now means: **resource admission policy**, not design-key exclusivity.

Admission evaluates:
1. Global active run cap (`MAX_ACTIVE_RUNS`)
2. Backoff/defer/retry safety bounds

> Current decision: per-class concurrency cap is temporarily disabled pending business confirmation.

---

## 3) End-to-end request lifecycle (implemented)

```mermaid
flowchart TD
    U[UI / Client] --> A[POST /jobs]
    A --> I[Generate job_id + run_id]
    I --> S[Persist initial state<br/>Redis + Postgres]
    S --> Q[XADD jobs:stream]

    Q --> W1[Worker-1]
    Q --> W2[Worker-2]
    Q --> W3[Worker-N]

    subgraph ADM[Admission Control]
      G{Global slot available?}
    end

    W1 --> G
    W2 --> G
    W3 --> G
    G -- no --> D[Defer + requeue]
    G -- yes --> R[Run admitted]

    D --> L1{Defer limit reached?}
    L1 -- no --> Q
    L1 -- yes --> DLQ[Route to DLQ]

    R --> H[HITL bound to job_id + run_id]
    H --> E[Execute workflow stages]
    E --> OK{Success?}
    OK -- yes --> ACK[XACK + release slots]
    OK -- no --> RETRY{Retry attempts left?}
    RETRY -- yes --> Q
    RETRY -- no --> DLQ
```

---

## 4) Crash recovery flow (implemented)

```mermaid
sequenceDiagram
    participant RW as Redis Stream
    participant W1 as Worker-A (dies)
    participant W2 as Worker-B (healthy)

    RW->>W1: Deliver message (pending in group)
    Note over W1: Crash before ACK

    W2->>RW: XREADGROUP (new messages)
    RW-->>W2: none/new limited
    W2->>RW: XAUTOCLAIM(min_idle_time)
    RW-->>W2: stale pending message claimed
    W2->>W2: Process recovered message
    W2->>RW: XACK
```

---

## 5) Phase-by-phase implementation status

### Phase 1 — Identity and persistence ✅
- Added `run_id` generation and propagation.
- Persisted in API flow, Redis state, Postgres job records, worker context.

### Phase 2 — Queue + multi-worker concurrency ✅
- Added queue backend config (`list`/`stream`).
- Enabled Redis Streams consumer-group worker flow.
- Scaled worker model via Docker Compose.

### Phase 3 — Admission + reliability controls ✅
- Global concurrency gate.
- Per-class quota enforcement intentionally disabled for now.
- Bounded defer and bounded retries.
- DLQ routing for limit-exceeded cases.
- Pending message recovery with `XAUTOCLAIM`.

### Phase 4 — Operational visibility ✅
- Added counters for admit/defer/retry/dlq/recovery.
- Added queue/dead-letter depth and pending counts.
- Exposed endpoint: `GET /jobs/ops-metrics`.

---

## 6) What the business team should remember

1. The system is now parallel, not sequential.
2. Load is controlled by policy (not by blocking same design key).
3. Failures do not loop forever (bounded retries + DLQ).
4. Worker crashes are recoverable (pending reclaim).
5. Health can be observed via a single metrics endpoint.

---

## 7) Quick validation commands

- Scale workers:
  - `docker compose -f docker-compose.dev1.yml up -d --build --scale worker=3`
- Check services:
  - `docker compose -f docker-compose.dev1.yml ps`
- Watch worker behavior:
  - `docker compose -f docker-compose.dev1.yml logs -f worker`
- Fetch ops counters:
  - `GET /jobs/ops-metrics`

Key counters to present:
- `admitted_total`
- `admission_deferred_total`
- `queue_retry_total`
- `dlq_routed_total`
- `pending_recovered_total`