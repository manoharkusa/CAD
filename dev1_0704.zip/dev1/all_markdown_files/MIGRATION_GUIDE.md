# Flow Config Migration Guide

## Problem Identified

Your actual directory structure has a mismatch:

```
flow_config.yaml expects:          Actual disk structure:
{run_dir}/init_design/work/        {run_dir}/pnr/init/work/
{run_dir}/place/work/              {run_dir}/pnr/place/work/
{run_dir}/route/work/              {run_dir}/pnr/route/work/
etc.                               etc.
```

## Solution

Update `flow_config.yaml` to include:
1. **`stage_group`** field in each stage → Maps stage to its group (pnr, signoff, etc.)
2. **`dir_name`** field in each stage → Maps config name to actual directory name (init_design → init)
3. **`base_dir`** in stage_groups → Parent directory for grouped stages (pnr/)

## Required Changes to `/proj5/projects/semicon_19-02/pd/users/bharath/aes_cipher_top/bronze_v2/run2/flow_config.yaml`

### Step 1: Update PnR stages with stage_group and dir_name

**For `init_design` stage (line 12-16):**
```yaml
  init_design:
    tool: innovus
    script: init_design.tcl
    timeout: 1800
    description: Design initialization
    stage_group: pnr        # ← ADD THIS
    dir_name: init          # ← ADD THIS (maps to pnr/init/)
```

**For `floorplan` stage:**
```yaml
  floorplan:
    tool: innovus
    script: floorplan.tcl
    timeout: 1800
    description: Floorplanning
    stage_group: pnr        # ← ADD THIS
    dir_name: floorplan     # ← ADD THIS
```

**For `place`, `cts`, `post_cts`, `route`, `postroute`, `chip_finish`:**
```yaml
    stage_group: pnr        # ← ADD THIS to each
    # dir_name not needed if it matches stage name
```

### Step 2: Update stage_groups with base_dir

**For `pnr` group (replace lines 86-94):**
```yaml
  pnr:
    base_dir: pnr           # ← ADD THIS
    stages:
      - init_design
      - floorplan
      - place
      - cts
      - post_cts
      - route
      - postroute
      - chip_finish
```

**For `signoff` group (lines 96-100):**
```yaml
  signoff:
    # No base_dir - stages are at run_root
    stages:
      - qrc
      - sta
      - pv
      - lec
```

### Step 3: Full Updated File

A complete example is provided at: `flow_config.yaml.updated`

You can:
```bash
# Option A: View the updated template
cat flow_config.yaml.updated

# Option B: Back up current and use updated
cp flow_config.yaml flow_config.yaml.backup
cp flow_config.yaml.updated flow_config.yaml
```

## Directory Resolution Logic

After these changes, ConfigManager will resolve paths as:

```
Stage: init_design
  - Has stage_group: pnr
  - Has dir_name: init
  - pnr group has base_dir: pnr
  → Work dir: {run_dir}/pnr/init/work ✓

Stage: place
  - Has stage_group: pnr
  - No dir_name (uses stage name)
  - pnr group has base_dir: pnr
  → Work dir: {run_dir}/pnr/place/work ✓

Stage: syn
  - No stage_group
  - No dir_name (uses stage name)
  → Work dir: {run_dir}/syn/work ✓

Stage: qrc
  - No stage_group
  - No dir_name (uses stage name)
  → Work dir: {run_dir}/qrc/work ✓
```

## Verification

After updating, the debug output should show:
```
[CONFIG] Work dir for 'init_design': pnr/init/work
[CONFIG] Work dir for 'place': pnr/place/work
[CONFIG] Work dir for 'syn': syn/work
[VALIDATE] Script: /proj5/REL/env_scripts/projects/semicon_19-02/latest/tools_scripts/genus/genus_syn.tcl
[VALIDATE]   → Exists: True
[VALIDATE] Work dir: /proj5/projects/semicon_19-02/pd/users/bharath/aes_cipher_top/bronze_v2/run2/pnr/init/work
[VALIDATE]   → Exists: True
```

## Summary

The updated ConfigManager now:
1. ✅ Reads `stage_group` from each stage definition
2. ✅ Reads `dir_name` for custom directory name mappings
3. ✅ Reads `base_dir` from stage group definitions
4. ✅ Combines these to construct the correct work/log directory paths
5. ✅ Prints debug info for path resolution
6. ✅ Handles tcsh and bash environment files
7. ✅ Properly sources ENV_SCRIPTS for script path resolution

Everything should now work correctly! 🎉
