# Testing Guide: DebugAgent & LangGraph

Complete guide to test the implementation right now.

---

## Quick Start (5 minutes)

### 1. Verify Syntax

```bash
# Check all Python files compile
python3 -m py_compile src/agents/debug_agent.py
python3 -m py_compile src/agents/physical_design_graph.py
python3 -m py_compile src/tracker/langgraph_saver.py

# Should output: (no errors)
```

### 2. Verify Imports

```bash
# Test imports work
python3 << 'EOF'
from src.agents.debug_agent import DebugAgent
from src.agents.physical_design_graph import PhysicalDesignGraph
from src.tracker.langgraph_saver import get_saver, create_thread_id

print("✅ All imports successful")
EOF
```

### 3. Check Integration

```bash
# Verify DebugAgent is exported
python3 << 'EOF'
from src.agents import DebugAgent, OrchestratorAgent

print("✅ DebugAgent exported from agents module")
print(f"DebugAgent: {DebugAgent}")
print(f"OrchestratorAgent: {OrchestratorAgent}")
EOF
```

---

## Unit Tests

### Test 1: DebugAgent Instantiation

```bash
python3 << 'EOF'
import asyncio
from pathlib import Path
from src.config import create_config_manager
from src.executor import StageExecutor
from src.agents.debug_agent import DebugAgent
from src.tracker import StateTracker

async def test_debug_agent_creation():
    """Test DebugAgent can be instantiated"""

    # Setup
    config_manager = create_config_manager(
        project_name="test",
        user_name="bharath",
        block_name="test_block",
        rtl_tag="v1",
        run_tag="run_001",
    )

    state_tracker = StateTracker(
        run_dir=Path("."),
        run_tag="run_001",
        block_name="test_block",
        rtl_tag="v1",
    )

    # Test
    debug_agent = DebugAgent(
        config_manager=config_manager,
        state_tracker=state_tracker,
        max_retry_attempts=3,
    )

    # Verify
    assert debug_agent is not None
    assert debug_agent.max_retry_attempts == 3
    assert debug_agent.model == "claude-opus-4.5"

    print("✅ DebugAgent instantiation test PASSED")

asyncio.run(test_debug_agent_creation())
EOF
```

### Test 2: File Safety Check

```bash
python3 << 'EOF'
from src.agents.debug_agent import DebugAgent
from src.config import create_config_manager
from src.tracker import StateTracker
from pathlib import Path

# Setup
config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
state = StateTracker(Path("."), "run_001", "test_block", "v1")
debug_agent = DebugAgent(config, state)

# Test editable files
editable_files = [
    "block_scripts/block.yaml",
    "block_inputs/constraints.sdc",
    "block_inputs/script.tcl",
    "block_inputs/mem_list.txt",
]

for file in editable_files:
    assert debug_agent._is_file_editable(file), f"{file} should be editable"
    print(f"✅ {file} is editable")

# Test non-editable files
non_editable = [
    "tool_scripts/genus_syn.tcl",
    "tech_scripts/library.tcl",
]

for file in non_editable:
    assert not debug_agent._is_file_editable(file), f"{file} should NOT be editable"
    print(f"✅ {file} correctly blocked")

print("\n✅ File safety test PASSED")
EOF
```

### Test 3: Error Analysis Fallback

```bash
python3 << 'EOF'
from src.agents.debug_agent import DebugAgent
from src.config import create_config_manager
from src.tracker import StateTracker
from pathlib import Path

# Setup
config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
state = StateTracker(Path("."), "run_001", "test_block", "v1")
debug_agent = DebugAgent(config, state)

# Test fallback analysis (when Claude unavailable)
error_context = {
    "stage_name": "syn",
    "return_code": 1,
    "error_preview": "ERROR: Setup violation of 25ps at clk→D",
    "log_file": None,
}

analysis = debug_agent._fallback_error_analysis(error_context)

assert analysis.category == "timing_violation"
assert analysis.fixable == True
assert analysis.confidence > 0

print(f"✅ Error category: {analysis.category}")
print(f"✅ Fixable: {analysis.fixable}")
print(f"✅ Confidence: {analysis.confidence}")
print("\n✅ Fallback analysis test PASSED")
EOF
```

### Test 4: Backup & Rollback

```bash
python3 << 'EOF'
from pathlib import Path
import tempfile
from src.agents.debug_agent import DebugAgent
from src.config import create_config_manager
from src.tracker import StateTracker

# Setup with temp directory
config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
state = StateTracker(Path("."), "run_001", "test_block", "v1")
debug_agent = DebugAgent(config, state)

# Create test file
with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
    f.write("test: content\n")
    test_file = Path(f.name)

try:
    # Test backup
    original_content = test_file.read_text()
    backup_path = debug_agent._create_backup(test_file)

    assert backup_path.exists()
    assert backup_path.read_text() == original_content
    print(f"✅ Backup created: {backup_path}")

    # Test rollback
    test_file.write_text("modified content\n")
    backups = {str(test_file): str(backup_path)}

    import asyncio
    asyncio.run(debug_agent._rollback_modifications(backups))

    assert test_file.read_text() == original_content
    print(f"✅ Rollback successful")

finally:
    test_file.unlink()
    backup_path.unlink()

print("\n✅ Backup & rollback test PASSED")
EOF
```

---

## Integration Tests

### Test 5: PhysicalDesignGraph Instantiation

```bash
python3 << 'EOF'
import asyncio
from pathlib import Path
from src.config import create_config_manager
from src.executor import StageExecutor
from src.agents.debug_agent import DebugAgent
from src.agents.physical_design_graph import PhysicalDesignGraph
from src.tracker import StateTracker

async def test_graph_creation():
    """Test PhysicalDesignGraph instantiation"""

    config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
    executor = StageExecutor(config)
    state_tracker = StateTracker(Path("."), "run_001", "test_block", "v1")
    debug_agent = DebugAgent(config, state_tracker)

    # Test graph creation
    graph = PhysicalDesignGraph(
        config_manager=config,
        stage_executor=executor,
        debug_agent=debug_agent,
        max_retries=3,
    )

    assert graph is not None
    assert graph.graph is not None

    print("✅ PhysicalDesignGraph created successfully")
    print(f"✅ Graph object: {graph.graph}")

asyncio.run(test_graph_creation())
EOF
```

### Test 6: LangGraph Saver (SQLite)

```bash
python3 << 'EOF'
from pathlib import Path
from src.tracker.langgraph_saver import get_saver, create_thread_id

# Create saver
saver = get_saver(backend="sqlite", db_path=".langgraph_test.db")

try:
    # Test thread ID creation
    thread1 = create_thread_id("user1")
    thread2 = create_thread_id("user2")

    print(f"✅ Thread 1: {thread1}")
    print(f"✅ Thread 2: {thread2}")

    # Test checkpoint save
    config1 = {"configurable": {"thread_id": thread1}}
    state1 = {
        "prompt": "run synthesis",
        "stages_executed": ["syn"],
        "execution_status": "in_progress",
    }

    checkpoint_id = saver.put(config1, state1, metadata={"node": "parse_intent"})
    print(f"✅ Checkpoint saved: {checkpoint_id}")

    # Test checkpoint retrieval
    retrieved = saver.get(config1)
    assert retrieved is not None
    assert retrieved["stages_executed"] == ["syn"]
    print(f"✅ Checkpoint retrieved successfully")

    # Test thread isolation
    config2 = {"configurable": {"thread_id": thread2}}
    state2 = {
        "prompt": "run place",
        "stages_executed": ["place"],
        "execution_status": "running",
    }

    saver.put(config2, state2, metadata={"node": "execute_stage"})

    # Verify isolation
    check1 = saver.get(config1)
    check2 = saver.get(config2)

    assert check1["stages_executed"] == ["syn"]
    assert check2["stages_executed"] == ["place"]
    print(f"✅ Thread isolation verified")

finally:
    # Cleanup
    Path(".langgraph_test.db").unlink(missing_ok=True)

print("\n✅ LangGraph Saver test PASSED")
EOF
```

---

## Manual Testing

### Test 7: Start Server and Verify DebugAgent

```bash
# Terminal 1: Start server
python src/main.py --project test --user bharath --block test_block \
  --rtl-tag v1 --run-tag run_001

# Expected output:
# ✓ ConfigManager initialized
# ✓ StateTracker initialized
# ✓ StageExecutor initialized
# ✓ OrchestratorAgent initialized
# ✓ DebugAgent initialized        ← NEW
# ✓ DebugAgent integrated with OrchestratorAgent  ← NEW
# ✓ FastAPI application created
```

### Test 8: Trigger Debug Flow

```bash
# Terminal 2: Make request
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis",
    "debug_mode": "auto"
  }'

# Expected output:
# {
#   "status": "completed" or "failed",
#   "stages_executed": [...],
#   "stages_failed": [...]
# }
```

### Test 9: Check Debug Artifacts

```bash
# Check backups were created (if stage failed)
ls -la .debug_backups/

# Check state file contains debug_attempts
cat .flow_state.json | grep "debug_attempts"

# Expected:
# {
#   "debug_attempts": [
#     {
#       "attempt": 1,
#       "category": "timing_violation",
#       "fix_applied": true,
#       "outcome": "success",
#       "timestamp": "2024-01-15T10:30:45"
#     }
#   ]
# }
```

---

## Error Simulation Tests

### Test 10: Simulate Timing Violation

```bash
# Create a test error scenario
python3 << 'EOF'
from src.agents.debug_agent import DebugAgent
from src.config import create_config_manager
from src.tracker import StateTracker
from pathlib import Path

config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
state = StateTracker(Path("."), "run_001", "test_block", "v1")
debug_agent = DebugAgent(config, state)

# Simulate error
error_info = {
    "status": "failed",
    "return_code": 1,
    "error_preview": "ERROR: Setup violation of 50ps at clk→D\nERROR: Hold violation of 25ps",
    "log_file": None,
}

# Test analysis
analysis = debug_agent._fallback_error_analysis(error_info)

print(f"Category: {analysis.category}")
print(f"Root cause: {analysis.root_cause}")
print(f"Fixable: {analysis.fixable}")
print(f"Confidence: {analysis.confidence}")

assert analysis.category == "timing_violation"
assert analysis.fixable == True

print("\n✅ Timing violation simulation PASSED")
EOF
```

### Test 11: Simulate File Not Found

```bash
python3 << 'EOF'
from src.agents.debug_agent import DebugAgent
from src.config import create_config_manager
from src.tracker import StateTracker
from pathlib import Path

config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
state = StateTracker(Path("."), "run_001", "test_block", "v1")
debug_agent = DebugAgent(config, state)

# Simulate error
error_info = {
    "status": "failed",
    "return_code": 1,
    "error_preview": "ERROR: Cannot find file: inputs/missing.sdc\nNo such file or directory",
    "log_file": None,
}

# Test analysis
analysis = debug_agent._fallback_error_analysis(error_info)

print(f"Category: {analysis.category}")
print(f"Fixable: {analysis.fixable}")

assert analysis.category == "file_not_found"
assert analysis.fixable == True

print("\n✅ File not found simulation PASSED")
EOF
```

---

## Test Suite (Run All at Once)

```bash
# Create test_all.py
cat > test_all.py << 'EOF'
"""
Complete test suite for DebugAgent and LangGraph
Run: python test_all.py
"""

import asyncio
import sys
from pathlib import Path

# Test 1: Imports
print("=" * 60)
print("TEST 1: Imports")
print("=" * 60)
try:
    from src.agents.debug_agent import DebugAgent
    from src.agents.physical_design_graph import PhysicalDesignGraph
    from src.tracker.langgraph_saver import get_saver, create_thread_id
    from src.agents import DebugAgent, OrchestratorAgent
    print("✅ All imports successful\n")
except Exception as e:
    print(f"❌ Import failed: {e}\n")
    sys.exit(1)

# Test 2: DebugAgent Creation
print("=" * 60)
print("TEST 2: DebugAgent Creation")
print("=" * 60)
try:
    from src.config import create_config_manager
    from src.tracker import StateTracker

    config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
    state = StateTracker(Path("."), "run_001", "test_block", "v1")
    debug_agent = DebugAgent(config, state, max_retry_attempts=3)

    assert debug_agent is not None
    print("✅ DebugAgent created successfully\n")
except Exception as e:
    print(f"❌ DebugAgent creation failed: {e}\n")
    sys.exit(1)

# Test 3: File Safety
print("=" * 60)
print("TEST 3: File Safety Checks")
print("=" * 60)
try:
    assert debug_agent._is_file_editable("block_scripts/block.yaml")
    assert debug_agent._is_file_editable("block_inputs/constraints.sdc")
    assert not debug_agent._is_file_editable("tool_scripts/genus_syn.tcl")
    print("✅ File safety checks passed\n")
except Exception as e:
    print(f"❌ File safety check failed: {e}\n")
    sys.exit(1)

# Test 4: Error Analysis
print("=" * 60)
print("TEST 4: Error Analysis (Fallback)")
print("=" * 60)
try:
    error_context = {
        "stage_name": "syn",
        "return_code": 1,
        "error_preview": "ERROR: Setup violation of 25ps",
        "log_file": None,
    }
    analysis = debug_agent._fallback_error_analysis(error_context)
    assert analysis.category == "timing_violation"
    print(f"✅ Error category: {analysis.category}")
    print(f"✅ Fixable: {analysis.fixable}\n")
except Exception as e:
    print(f"❌ Error analysis failed: {e}\n")
    sys.exit(1)

# Test 5: PhysicalDesignGraph
print("=" * 60)
print("TEST 5: PhysicalDesignGraph Creation")
print("=" * 60)
try:
    from src.executor import StageExecutor

    executor = StageExecutor(config)
    graph = PhysicalDesignGraph(config, executor, debug_agent, max_retries=3)

    assert graph is not None
    assert graph.graph is not None
    print("✅ PhysicalDesignGraph created successfully\n")
except Exception as e:
    print(f"❌ PhysicalDesignGraph creation failed: {e}\n")
    sys.exit(1)

# Test 6: LangGraph Saver
print("=" * 60)
print("TEST 6: LangGraph Saver (SQLite)")
print("=" * 60)
try:
    saver = get_saver(backend="sqlite", db_path=".test_langgraph.db")

    thread1 = create_thread_id("user1")
    config1 = {"configurable": {"thread_id": thread1}}
    state1 = {"prompt": "test", "stages_executed": ["syn"]}

    checkpoint = saver.put(config1, state1)
    retrieved = saver.get(config1)

    assert checkpoint is not None
    assert retrieved is not None
    assert retrieved["stages_executed"] == ["syn"]

    Path(".test_langgraph.db").unlink(missing_ok=True)
    print("✅ LangGraph Saver working correctly\n")
except Exception as e:
    print(f"❌ LangGraph Saver test failed: {e}\n")
    Path(".test_langgraph.db").unlink(missing_ok=True)
    sys.exit(1)

print("=" * 60)
print("✅ ALL TESTS PASSED")
print("=" * 60)
EOF

# Run tests
python test_all.py
```

---

## Performance Testing

### Test 12: Measure Debug Agent Speed

```bash
python3 << 'EOF'
import asyncio
import time
from src.agents.debug_agent import DebugAgent
from src.config import create_config_manager
from src.tracker import StateTracker
from pathlib import Path

async def test_performance():
    config = create_config_manager("test", "bharath", "test_block", "v1", "run_001")
    state = StateTracker(Path("."), "run_001", "test_block", "v1")
    debug_agent = DebugAgent(config, state)

    error_context = {
        "stage_name": "syn",
        "return_code": 1,
        "error_preview": "ERROR: Setup violation",
        "log_file": None,
    }

    # Measure fallback analysis
    start = time.time()
    for _ in range(100):
        analysis = debug_agent._fallback_error_analysis(error_context)
    end = time.time()

    avg_time = (end - start) / 100 * 1000  # ms
    print(f"✅ Fallback analysis: {avg_time:.2f}ms per call")
    print(f"✅ 1000 calls would take: {avg_time * 10:.1f} seconds")

asyncio.run(test_performance())
EOF
```

---

## Debugging Commands

### View Current State

```bash
# See latest state
cat .flow_state.json | python -m json.tool

# See debug attempts
cat .flow_state.json | python -m json.tool | grep -A 20 "debug_attempts"

# See backups
ls -lah .debug_backups/

# See LangGraph checkpoints
ls -lah .langgraph/
sqlite3 .langgraph/checkpoints.db "SELECT thread_id, checkpoint_id FROM checkpoints LIMIT 10;"
```

### Enable Debug Logging

```python
# Add to any test to see detailed output
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger("DebugAgent")
logger.debug("Starting debug test...")
```

---

## Test Checklist

- [ ] **Syntax**: All files compile
- [ ] **Imports**: All modules import successfully
- [ ] **DebugAgent Creation**: Can instantiate with config
- [ ] **File Safety**: Editable/non-editable files properly classified
- [ ] **Error Analysis**: Fallback analysis works
- [ ] **Backup/Rollback**: Creates and restores backups
- [ ] **PhysicalDesignGraph**: Graph instantiates correctly
- [ ] **LangGraph Saver**: Can save/retrieve checkpoints
- [ ] **Thread Isolation**: Different threads don't interfere
- [ ] **Server Start**: API starts without errors
- [ ] **DebugAgent Integration**: DebugAgent initialized in main
- [ ] **Error Simulation**: Can test various error types
- [ ] **Performance**: Fallback analysis fast enough

---

## Troubleshooting

### If imports fail:
```bash
# Check Python path
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
python test_all.py
```

### If Claude unavailable:
```bash
# Fallback should kick in automatically
# Check debug output:
ERROR: Claude call failed: ...
INFO: Using fallback error analysis
```

### If LangGraph not installed:
```bash
# Current system still works without LangGraph
# Install when ready:
pip install langgraph
```

---

## Next Steps

1. **Run test_all.py** to verify everything works
2. **Start server** and check initialization messages
3. **Monitor artifacts** (.debug_backups/, .flow_state.json)
4. **Test error scenarios** if stages fail
5. **Check performance** with fallback analysis
6. **Review logs** to understand behavior

All tests should pass! Report any failures with error messages.
