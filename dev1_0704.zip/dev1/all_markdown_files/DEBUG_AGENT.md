# DebugAgent - Intelligent Debugging Engine

## Overview

DebugAgent is an intelligent debugging system for the physical design flow that:

1. **Analyzes stage failures** using Claude AI to understand root causes
2. **Generates context-aware fix suggestions** for editable configuration and constraint files
3. **Applies fixes automatically** with comprehensive safety mechanisms
4. **Supports three debug modes** for different execution contexts (auto, interactive, human-loop)
5. **Tracks debug history** for learning and analysis

The system integrates seamlessly with OrchestratorAgent's execution loop, providing intelligent error recovery without requiring manual intervention.

## Architecture

### System Components

```
┌─────────────────────────────────────────────────────────┐
│                 OrchestratorAgent                        │
│  - Parses NLP prompts and creates execution plans       │
│  - Executes stages with retry loop                      │
│  - Handles debug mode (auto/interactive/human-loop)     │
└──────────────┬──────────────────────────────────────────┘
               │ Calls on stage failure
               ↓
┌─────────────────────────────────────────────────────────┐
│                   DebugAgent                            │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Error Analysis (Claude AI)                      │   │
│  │  - Load and analyze log files                   │   │
│  │  - Categorize errors                            │   │
│  │  - Identify root causes                         │   │
│  │  - Assess fixability                            │   │
│  └─────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Fix Generation (Claude AI)                      │   │
│  │  - Generate 1-3 fix suggestions                 │   │
│  │  - Provide confidence and risk assessment       │   │
│  │  - Include exact file modifications             │   │
│  └─────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Fix Application (Safety Mechanisms)             │   │
│  │  - Validate editable files only                 │   │
│  │  - Create automatic backups                     │   │
│  │  - Apply modifications                          │   │
│  │  - Validate syntax                              │   │
│  │  - Rollback on failure                          │   │
│  └─────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────┐   │
│  │ History & State Tracking (StateTracker)         │   │
│  │  - Record all debug attempts                    │   │
│  │  - Track outcomes and metrics                   │   │
│  │  - Persist to JSON for analysis                 │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
               │ Returns action (retry/abort/human_intervention)
               ↓
        OrchestratorAgent decides: retry stage or stop
```

### Error Analysis Process

1. **Collect Context**
   - Stage name, tool, return code
   - Error preview from executor
   - Full log file path

2. **Load Log File** (on-demand)
   - Read last 500 lines (size-limited)
   - Extract error-related sections
   - Limit to 10KB for Claude prompt

3. **Analyze with Claude**
   - Send log + context to Claude
   - Request JSON response with error category, root cause, fixability
   - Fall back to pattern matching if Claude fails

4. **Categorize Error**
   - `timing_violation`: Setup/hold time violations
   - `design_rule_violation`: Max transition, capacitance, fanout
   - `syntax_error`: TCL/SDC/YAML syntax issues
   - `file_not_found`: Missing input files
   - `memory_error`: Out of memory, license issues
   - `convergence_failure`: Optimization not converging
   - `configuration_error`: Wrong settings/parameters
   - `constraint_conflict`: Conflicting constraints
   - `physical_design_error`: Placement, routing issues
   - `other`: Unknown/unclassified

### Fix Generation Process

1. **Load Current Configuration**
   - Read `block_scripts/block.yaml`
   - List available SDC and TCL files
   - Include in prompt for context

2. **Generate with Claude**
   - Request 1-3 fixes ordered by confidence
   - Include rationale and risk assessment
   - Provide exact file modifications
   - Only target editable files

3. **Structure Each Fix**
   ```
   {
       "title": "Fix name",
       "description": "What it does",
       "rationale": "Why it works",
       "risk_level": "low|medium|high",
       "confidence": 0.85,
       "estimated_impact": "Expected result",
       "modifications": [
           {
               "file_path": "path/to/file",
               "operation": "edit|append|create",
               "old_content": "for edit",
               "new_content": "for edit"
           }
       ]
   }
   ```

## Safety Mechanisms

### File Protection

- **Whitelist**: Only these file paths can be modified:
  - `block_scripts/block.yaml`
  - `block_inputs/*.sdc`
  - `block_inputs/*.tcl`
  - `block_inputs/mem_list.txt`

- **Blacklist**: These are read-only:
  - `tool_scripts/**/*`
  - `tech_scripts/**/*`

All modification attempts are validated against these lists before execution.

### Backup System

Before any file modification:
1. Create timestamped backup: `.debug_backups/<filename>.<YYYYMMDD_HHMMSS>.bak`
2. Store original content
3. Enable rollback on failure

Automatic cleanup: Old backups older than 7 days are archived.

### Syntax Validation

After modifications, files are validated:

- **YAML files**: `yaml.safe_load()` validation
- **TCL files**: Check balanced braces and brackets
- **Other files**: Pass through (assume valid)

Validation failure triggers automatic rollback from backups.

### Automatic Rollback

On any error during modification:
1. Stop modification process immediately
2. Restore all modified files from backups
3. Clean up temporary changes
4. Report error and skip to next fix attempt

### Retry Limits

Default: 3 retry attempts per stage
- Prevents infinite debug loops
- Configurable in DebugAgent constructor
- Each attempt is recorded with outcome

## Debug Modes

### Auto Mode

**Use Case**: Known error patterns, low-risk fixes, production runs

**Behavior**:
1. Analyze error
2. Generate fixes
3. **Automatically apply** highest-confidence, low-risk fix
4. Return to OrchestratorAgent for retry

**Conditions**:
- Only applies fixes with confidence ≥ 0.8 AND risk_level = "low"
- Falls back to human_intervention if no suitable fix

**Example Flow**:
```
Stage fails with timing violation
  ↓
DebugAgent analyzes: timing_violation (confidence: 0.95)
  ↓
Generates fixes:
  1. Increase timing margin in SDC (confidence: 0.95, risk: low)
  2. Adjust tool settings (confidence: 0.60, risk: medium)
  ↓
Applies fix #1 automatically
  ↓
Returns "retry" to OrchestratorAgent
  ↓
OrchestratorAgent retries stage
```

### Interactive Mode

**Use Case**: Development, learning, user oversight

**Behavior**:
1. Analyze error
2. Generate fixes
3. Present all options to user
4. Wait for user selection
5. Apply selected fix
6. Return to OrchestratorAgent for retry

**User Interface** (would show):
```
Error Analysis:
  Category: timing_violation
  Root Cause: Setup time violated by 50ps
  Confidence: 95%

Available Fixes:
  1. Increase timing margin in SDC
     - Confidence: 95%, Risk: low
     - Modifies: block_inputs/constraints.sdc

  2. Adjust clock period
     - Confidence: 60%, Risk: medium
     - Modifies: block_scripts/block.yaml

Select fix (or skip): _
```

**Current Implementation**: For now, applies best fix (same as auto mode)

### Human-Loop Mode

**Use Case**: Production designs, critical path changes, manual validation

**Behavior**:
1. Analyze error
2. Generate fixes
3. Present comprehensive analysis
4. Show suggested fixes for reference **only**
5. **Wait for engineer to manually fix**
6. Engineer confirms fix is complete
7. Return "retry" to OrchestratorAgent

**What Engineer Sees**:
```
ERROR ANALYSIS
==============
Category: timing_violation
Root Cause: Setup time violated by 50ps at clk→D path
Confidence: 95%
Fixable: Yes (by modifying timing constraints)

SUGGESTED FIXES (reference only - apply manually):

1. Increase Setup Margin
   Modify block_inputs/constraints.sdc:
   - Change: set_setup_margin 0.1
   - To: set_setup_margin 0.15

2. Loosen Clock
   Modify block_scripts/block.yaml:
   - Change: clock_period_ns: 4.0
   - To: clock_period_ns: 4.5

NEXT STEPS:
1. Review error logs in run/logs/
2. Make necessary changes
3. Confirm fix is complete
4. System will retry stage automatically
```

**Current Implementation**: Returns "human_intervention" (shows analysis)

## Error Recovery Examples

### Example 1: Timing Violation (Auto Mode)

```python
# Stage fails with setup/hold violation
error_info = {
    "status": "failed",
    "return_code": 1,
    "error_preview": "ERROR: Setup violation of 25ps at clk→D",
    "log_file": "run/logs/sta.log"
}

# DebugAgent processes:
analysis = await debug_agent._analyze_error(error_context)
# category: "timing_violation"
# confidence: 0.95
# fixable: true

fixes = await debug_agent._generate_fix_suggestions(error_context, analysis)
# Fix 1: Increase margin in SDC (confidence: 0.95, risk: "low")
# Fix 2: Loosen constraint (confidence: 0.60, risk: "medium")

result = await debug_agent._apply_fix(fixes[0])
# Modifies: block_inputs/constraints.sdc
# Adds 0.1ns margin
# Status: applied

return {"action": "retry", ...}
# OrchestratorAgent retries stage
```

### Example 2: File Not Found (Human Intervention)

```python
# Stage fails with file not found
error_info = {
    "status": "failed",
    "return_code": 1,
    "error_preview": "ERROR: Cannot find file: inputs/missing.sdc",
    "log_file": "run/logs/syn.log"
}

# DebugAgent processes:
analysis = await debug_agent._analyze_error(error_context)
# category: "file_not_found"
# confidence: 0.90
# fixable: false  # Cannot auto-create SDC files

# No fixes generated for file_not_found when confidence > 0.8

return {
    "action": "human_intervention",
    "reason": "Cannot automatically generate missing SDC file",
    "analysis": {...}
}
# Engineer must create/provide missing file
# User confirms in interactive mode
# OrchestratorAgent retries
```

### Example 3: Design Rule Violation (Interactive Mode)

```python
# Stage fails with max transition violation
error_info = {
    "status": "failed",
    "return_code": 1,
    "error_preview": "ERROR: Max transition 0.8ns violated (limit: 0.5ns)",
    "log_file": "run/logs/postroute.log"
}

# DebugAgent processes:
analysis = await debug_agent._analyze_error(error_context)
# category: "design_rule_violation"
# confidence: 0.85
# fixable: true

fixes = await debug_agent._generate_fix_suggestions(error_context, analysis)
# Fix 1: Add buffers to long nets (confidence: 0.80, risk: "low")
# Fix 2: Increase pin capacitance limits (confidence: 0.50, risk: "medium")

# User sees options and selects Fix 1
result = await debug_agent._apply_fix(fixes[0])
# Modifies: block_inputs/buffer_strategy.tcl
# Adds buffer sizing rules
# Status: applied

return {"action": "retry", ...}
```

## Integration with OrchestratorAgent

### Execution Flow

```python
for step in plan:
    # Execute stage
    result = await stage_executor.execute_stage(...)

    if result["status"] == "success":
        # Mark completed
        execution_result["stages_executed"].append(step)
        break

    else:
        # Stage failed
        if debug_agent and debug_mode != "none":
            debug_result = await debug_agent.debug_stage(
                stage_name=step,
                error_info=result,
                mode=debug_mode,
            )

            if debug_result["action"] == "retry":
                # Try again with fix
                continue  # Retry loop iteration

            elif debug_result["action"] == "human_intervention":
                # Stop, wait for engineer
                execution_result["stages_failed"].append(step)
                break

            else:  # abort
                # Stop execution
                execution_result["stages_failed"].append(step)
                break
        else:
            # No debug agent, fail immediately
            execution_result["stages_failed"].append(step)
            break
```

### Return Values

**retry**
```json
{
    "action": "retry",
    "fix": { ... },
    "result": { ... }
}
```
→ OrchestratorAgent retries the stage

**human_intervention**
```json
{
    "action": "human_intervention",
    "reason": "Cannot auto-fix",
    "analysis": { ... },
    "suggestions": [ ... ]
}
```
→ OrchestratorAgent stops, waits for manual fix

**abort**
```json
{
    "action": "abort",
    "reason": "Max retries exceeded"
}
```
→ OrchestratorAgent stops execution

## State Tracking

### Debug Attempts in StateTracker

Each debug attempt is recorded in `.flow_state.json`:

```json
{
  "stages": {
    "syn": {
      "metrics": {
        "debug_attempts": [
          {
            "attempt": 1,
            "category": "timing_violation",
            "fix_applied": true,
            "outcome": "success",
            "timestamp": "2024-01-15T10:30:45.123456"
          }
        ]
      }
    }
  }
}
```

### Access Debug History

```python
# From StateTracker
state = state_tracker.get_state()
debug_attempts = state["stages"]["syn"]["metrics"]["debug_attempts"]

# From DebugAgent history
attempts = debug_agent.debug_history["syn"]
for attempt in attempts:
    print(f"Attempt {attempt.attempt_number}: {attempt.outcome}")
```

### Debug Artifacts

```
run_dir/
  .debug_backups/
    block.yaml.20240115_103045.bak
    constraints.sdc.20240115_103045.bak
  .history/
    execution_20240115_103045.json
  .flow_state.json (contains debug_attempts)
```

## Usage Examples

### Basic Auto-Debugging

```python
from src.agents import OrchestratorAgent, DebugAgent
from src.config import create_config_manager
from src.tracker import StateTracker
from src.executor import StageExecutor

# Initialize components
config_manager = create_config_manager(...)
state_tracker = StateTracker(...)
stage_executor = StageExecutor(config_manager)

# Create agents
orchestrator = OrchestratorAgent(config_manager, stage_executor, state_tracker)
debug_agent = DebugAgent(config_manager, state_tracker)

# Inject DebugAgent
orchestrator.debug_agent = debug_agent

# Run with auto-debugging
result = await orchestrator.process_prompt(
    "run synthesis",
    debug_mode="auto"
)

# Check result
if result["status"] == "completed":
    print("✓ Execution succeeded with auto-fixes")
elif result["status"] == "failed":
    print("✗ Execution failed, manual intervention needed")
```

### Interactive Debugging

```python
# Run with interactive mode
result = await orchestrator.process_prompt(
    "run place and route",
    debug_mode="interactive"
)

# When stage fails:
# 1. Error analysis shown
# 2. Fix options presented
# 3. User selects fix
# 4. Applied and retried
```

### Human-Loop Debugging

```python
# Run with human-loop mode
result = await orchestrator.process_prompt(
    "run full flow",
    debug_mode="human-loop"
)

# When stage fails:
# 1. Error analysis shown
# 2. Suggested fixes shown (for reference)
# 3. Engineer manually fixes files
# 4. Engineer confirms fix
# 5. Stage retried automatically
```

### Manual Debug Invocation

```python
# Manually trigger debug on a failed stage
error_info = {
    "status": "failed",
    "return_code": 1,
    "error_preview": "ERROR: ...",
    "log_file": "run/logs/syn.log"
}

debug_result = await debug_agent.debug_stage(
    stage_name="syn",
    error_info=error_info,
    mode="auto"
)

if debug_result["action"] == "retry":
    # Retry the stage
    pass
```

## Troubleshooting

### Issue: DebugAgent not initialized

**Symptom**: `AttributeError: 'OrchestratorAgent' object has no attribute 'debug_agent'`

**Solution**: Ensure DebugAgent is initialized and injected in main.py:
```python
debug_agent = DebugAgent(config_manager, state_tracker)
orchestrator_agent.debug_agent = debug_agent
```

### Issue: Fixes not applied

**Symptom**: Debug returns "human_intervention" but no fix was generated

**Solution**:
- Check Claude API availability
- Review error category and fixability assessment
- Ensure editable files exist and are readable
- Check debug_agent logs for error details

### Issue: Rollback failed

**Symptom**: Modifications partially applied, backup rollback unsuccessful

**Solution**:
1. Check backup file exists: `.debug_backups/`
2. Verify file permissions
3. Manually restore from backup if needed
4. Check disk space for backup creation

### Issue: Max retries exceeded

**Symptom**: Stage fails after 3 attempts, no more retries

**Solution**:
- Issue may require human intervention (try human-loop mode)
- Review all suggested fixes manually
- Check if problem is actually fixable by configuration changes
- May require RTL or tool script modifications (not supported)

### Issue: File validation failed

**Symptom**: "YAML validation failed" or "TCL syntax error"

**Solution**:
1. Check original file syntax: `yaml.safe_load()` for YAML
2. Review Claude-generated modifications
3. Check for unmatched braces in TCL
4. File rollback automatically triggered

## Implementation Details

### Error Analysis Prompt

Claude is asked to analyze:
- Error category (from defined list)
- Root cause analysis
- Confidence in analysis (0-1)
- Fixability assessment
- Suggested investigation steps
- Relevant log sections

### Fix Generation Prompt

Claude is asked to generate:
- 1-3 fix suggestions ordered by confidence
- Title and description for each
- Rationale explaining why it works
- Risk level assessment
- Exact file modifications needed
- Estimated impact

### File Safety Checks

Before any modification:
```python
def _is_file_editable(file_path: str) -> bool:
    # Check against whitelist
    # Check not in blacklist
    # Return True/False
```

### Modification Operations

- **edit**: Replace old_content with new_content
- **append**: Add content to end of file
- **create**: Create new file with content

All operations include backup and rollback capability.

## Performance Characteristics

### Response Times

- Error analysis: ~1-2 seconds (Claude API call)
- Fix generation: ~2-3 seconds (Claude API call)
- Fix application: ~100-500ms (file I/O)
- Rollback: ~50-200ms (file restore)

### Resource Usage

- Memory: ~50MB per debug session
- Disk: ~1-5MB per backup set
- Claude API: 2 calls per debug attempt (analysis + fixes)

### Limits

- Log file size: Limited to 10KB in prompt
- Max retries: Configurable, default 3
- Max fixes per error: 3 suggestions
- Backup retention: 7 days (auto-cleaned)

## Future Enhancements

1. **Learning System**: Track which fixes work best for which errors
2. **Constraint Solver**: Use Z3/SMT solver for timing constraint generation
3. **Pattern Recognition**: Build corpus of common errors and fixes
4. **Rollout Strategy**: Gradually increase confidence thresholds
5. **Cost Optimization**: Merge similar fixes to reduce Claude API calls
6. **Enhanced UI**: Real-time fix preview before application

## Contributing

When adding new error categories:
1. Add to `ErrorCategory` enum in `debug_agent.py`
2. Update Claude prompts with category description
3. Add fallback pattern matching in `_fallback_error_analysis()`
4. Test with real error logs

When adding new editable paths:
1. Update `EDITABLE_PATTERNS` list
2. Update `READONLY_PATTERNS` blacklist
3. Test file safety checks
4. Document in this guide
