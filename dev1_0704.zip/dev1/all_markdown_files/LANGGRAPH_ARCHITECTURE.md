# LangGraph Architecture for Multi-User Physical Design Flow

## Overview

This document describes the migration from custom StateTracker to LangGraph-based orchestration, enabling multi-user support with automatic state persistence, isolation, and crash recovery.

## Why LangGraph for Multi-User?

### Current Limitations (StateTracker)
- ❌ Single `.flow_state.json` file (race conditions with concurrent flows)
- ❌ No thread safety (multiple users overwrite each other's state)
- ❌ Manual state saving (can lose state on crash)
- ❌ No built-in recovery mechanism
- ❌ Linear execution model (hard to extend)

### LangGraph Advantages
- ✅ Built-in multi-threading support (each flow = separate thread)
- ✅ Automatic checkpointing after each node
- ✅ Database-backed persistence (thread-safe)
- ✅ Automatic crash recovery (resume from last checkpoint)
- ✅ Declarative graph model (easier to extend)
- ✅ Production-grade state management

---

## Architecture

### System Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    API / FastAPI Endpoints                  │
│  POST /flow/execute - Start new flow (returns thread_id)    │
│  GET /flow/status/{thread_id} - Get flow status             │
│  POST /flow/resume/{thread_id} - Resume after human input   │
└────────────┬────────────────────────────────────────────────┘
             │ (thread_id per user/flow)
             ↓
┌─────────────────────────────────────────────────────────────┐
│          PhysicalDesignGraph (LangGraph StateGraph)          │
├─────────────────────────────────────────────────────────────┤
│  NODES:                                                     │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 1. parse_intent_node                                 │  │
│  │    - Input: prompt                                   │  │
│  │    - Output: intent dict                             │  │
│  │    - Uses: Claude for NLP parsing                    │  │
│  └──────────────────────────────────────────────────────┘  │
│                           ↓                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 2. create_plan_node                                  │  │
│  │    - Input: intent                                   │  │
│  │    - Output: plan (list of stages)                   │  │
│  │    - Uses: Intent to stage mapping                   │  │
│  └──────────────────────────────────────────────────────┘  │
│                           ↓                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 3. execute_stage_node (LOOPED)                       │  │
│  │    - Input: current stage from plan                  │  │
│  │    - Output: execution result                        │  │
│  │    - Uses: StageExecutor (unchanged)                 │  │
│  └──────────────────────────────────────────────────────┘  │
│                           ↓ (conditional)                   │
│              ┌────────────┴────────────┐                    │
│              ↓                         ↓                    │
│          SUCCESS              FAILED (retry loop)           │
│              │                         │                    │
│              ↓                         ↓                    │
│          (Next Stage)    ┌──────────────────────────────┐  │
│              │           │ 4. debug_stage_node          │  │
│              │           │    - Input: error_info       │  │
│              │           │    - Output: debug_result    │  │
│              │           │    - Uses: DebugAgent        │  │
│              │           │      (unchanged)             │  │
│              │           └──────────────────────────────┘  │
│              │                         ↓ (conditional)      │
│              │            ┌────────────┴────────────────┐  │
│              │            ↓            ↓         ↓      ↓  │
│              │          RETRY    HUMAN_INT   ABORT   ???   │
│              │            │            │       │          │
│              │            └────────────┴───────┘          │
│              │                    ↓                        │
│              │            (Route back to execute           │
│              │            or wait for human input)         │
│              │                                             │
│              └──────────────┬──────────────────────────┘   │
│                             ↓                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 5. handle_result_node                                │  │
│  │    - Input: all stage results                        │  │
│  │    - Output: final result                            │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  EDGES (Routing):                                           │
│  - parse_intent → create_plan                              │
│  - create_plan → execute_stage (first)                     │
│  - execute_stage → [debug/next/end] (conditional)          │
│  - debug_stage → [execute/wait/end] (conditional)          │
│  - execute_stage → handle_result (when done)               │
│                                                             │
│  STATE (Automatic Checkpointing):                           │
│  - After each node execution                               │
│  - Persistent in LangGraph Saver                           │
│  - Recoverable after crash                                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
             ↓ (Saver: SqliteSaver / PostgresSaver)
┌─────────────────────────────────────────────────────────────┐
│              Persistence Layer (Thread-Safe)                │
├─────────────────────────────────────────────────────────────┤
│  Option A: SQLiteSaver (local development)                 │
│  - File: .langgraph/checkpoints.db                         │
│  - Each thread_id = separate flow                          │
│  - Auto-isolated by thread_id                              │
│                                                             │
│  Option B: PostgresSaver (production)                      │
│  - Host: postgres://db_server                              │
│  - Each thread_id = separate row                           │
│  - Multi-process safe                                      │
│                                                             │
│  Checkpoint Structure:                                      │
│  {                                                          │
│    "thread_id": "user_123_flow_001",                        │
│    "node": "execute_stage",                                │
│    "state": {...},                                          │
│    "timestamp": "2024-01-15T10:30:45"                       │
│  }                                                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
             ↓ (Shared components - unchanged)
┌─────────────────────────────────────────────────────────────┐
│                    Shared Components                        │
├─────────────────────────────────────────────────────────────┤
│  ✅ DebugAgent (unchanged)                                  │
│  ✅ StageExecutor (unchanged)                               │
│  ✅ ConfigManager (unchanged)                               │
│  ✅ STAGES definitions (unchanged)                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## State Model

### FlowState TypedDict

```python
from typing import TypedDict, Optional, Any

class FlowState(TypedDict):
    # Input
    prompt: str
    debug_mode: str  # "auto" | "interactive" | "human-loop"

    # Parsed intent
    intent: Optional[dict]  # {action, stages, start_from, ...}

    # Execution plan
    plan: list[str]  # ["syn", "place", "route", ...]
    current_stage_index: int  # 0, 1, 2, ...

    # Results
    stages_executed: list[str]
    stages_failed: list[str]
    stages_skipped: list[str]
    stage_results: dict[str, dict]  # {stage: {status, return_code, ...}}

    # Error handling
    error_info: Optional[dict]  # Last error details
    error_retry_count: int  # Per-stage retry counter

    # Debug
    debug_history: dict[str, list]  # {stage: [attempts]}
    debug_result: Optional[dict]  # Last debug result

    # Metadata
    start_time: str  # ISO timestamp
    run_id: str
    user_id: Optional[str]  # For multi-user tracking
    execution_status: str  # "pending" | "in_progress" | "completed" | "failed"
```

### State Initialization

```python
def init_state(prompt: str, debug_mode: str, user_id: Optional[str] = None) -> FlowState:
    return {
        "prompt": prompt,
        "debug_mode": debug_mode,
        "intent": None,
        "plan": [],
        "current_stage_index": 0,
        "stages_executed": [],
        "stages_failed": [],
        "stages_skipped": [],
        "stage_results": {},
        "error_info": None,
        "error_retry_count": 0,
        "debug_history": {},
        "debug_result": None,
        "start_time": datetime.now().isoformat(),
        "run_id": f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "user_id": user_id,
        "execution_status": "pending",
    }
```

---

## Graph Nodes

### 1. parse_intent_node

```python
async def parse_intent_node(state: FlowState) -> dict:
    """
    Parse natural language prompt into execution intent

    Input: prompt (e.g., "run synthesis and place")
    Output: Updated state with intent
    """
    prompt = state["prompt"]

    # Use Claude for NLP parsing (same as OrchestratorAgent)
    intent = await parse_intent(prompt)  # Claude or fallback

    return {
        "intent": intent,
        "execution_status": "in_progress",
    }
```

### 2. create_plan_node

```python
async def create_plan_node(state: FlowState) -> dict:
    """
    Convert intent into execution plan

    Input: intent
    Output: Updated state with plan and stage_index=0
    """
    intent = state["intent"]

    # Create execution plan from intent
    # (same logic as OrchestratorAgent._create_execution_plan)
    plan = create_execution_plan(intent)

    return {
        "plan": plan,
        "current_stage_index": 0,
    }
```

### 3. execute_stage_node

```python
async def execute_stage_node(state: FlowState) -> dict:
    """
    Execute current stage

    Input: plan[current_stage_index]
    Output: Updated state with execution result
    """
    current_stage_index = state["current_stage_index"]
    plan = state["plan"]

    if current_stage_index >= len(plan):
        return {}  # All stages done

    stage_name = plan[current_stage_index]
    stage_info = STAGES[stage_name]

    # Execute stage (same as OrchestratorAgent)
    result = await stage_executor.execute_stage(
        stage_name=stage_name,
        tool_name=stage_info["tool"],
        tool_script=stage_info["script"],
        tool_executable=stage_info["tool"],
    )

    # Update state
    stage_results = state["stage_results"].copy()
    stage_results[stage_name] = result

    updates = {
        "stage_results": stage_results,
        "error_info": None,
        "error_retry_count": 0,
    }

    if result["status"] == "success":
        stages_executed = state["stages_executed"] + [stage_name]
        updates["stages_executed"] = stages_executed
    else:
        updates["error_info"] = result
        updates["error_retry_count"] = 1

    return updates
```

### 4. debug_stage_node

```python
async def debug_stage_node(state: FlowState) -> dict:
    """
    Debug failed stage using DebugAgent

    Input: error_info, debug_mode
    Output: Updated state with debug_result
    """
    error_info = state["error_info"]
    stage_index = state["current_stage_index"]
    stage_name = state["plan"][stage_index]
    debug_mode = state["debug_mode"]

    # Call DebugAgent (unchanged)
    debug_result = await debug_agent.debug_stage(
        stage_name=stage_name,
        error_info=error_info,
        mode=debug_mode,
    )

    # Update debug history
    debug_history = state["debug_history"].copy()
    if stage_name not in debug_history:
        debug_history[stage_name] = []

    debug_history[stage_name].append({
        "attempt": len(debug_history[stage_name]) + 1,
        "result": debug_result,
        "timestamp": datetime.now().isoformat(),
    })

    return {
        "debug_result": debug_result,
        "debug_history": debug_history,
    }
```

### 5. handle_result_node

```python
async def handle_result_node(state: FlowState) -> dict:
    """
    Final processing and result generation

    Input: All execution data
    Output: Final result dict
    """
    return {
        "execution_status": "completed" if not state["stages_failed"] else "failed",
    }
```

---

## Conditional Edges (Routers)

### Router 1: After execute_stage

```python
def route_after_execution(state: FlowState) -> str:
    """
    Decide: debug → execute (retry) → next stage → end?
    """
    error_info = state["error_info"]
    current_index = state["current_stage_index"]
    plan = state["plan"]

    if error_info is None:
        # Success - move to next stage
        if current_index + 1 < len(plan):
            # Update index and continue loop
            state["current_stage_index"] += 1
            return "execute_stage"
        else:
            # All stages completed
            return "handle_result"
    else:
        # Failed - debug
        return "debug_stage"
```

### Router 2: After debug_stage

```python
def route_after_debug(state: FlowState) -> str:
    """
    Decide: retry → abort → human_intervention?
    """
    debug_result = state["debug_result"]
    action = debug_result.get("action")

    if action == "retry":
        # Retry current stage
        return "execute_stage"
    elif action == "human_intervention":
        # Wait for human (handled by API)
        return "wait_for_human"
    else:  # abort
        # Stop execution
        return "handle_result"
```

---

## Persistence Layer

### SqliteSaver (Development)

```python
from langgraph.checkpoint.sqlite import SqliteSaver

# Create saver for local development
saver = SqliteSaver(
    db_path=".langgraph/checkpoints.db"
)

# Automatically creates:
# - Database: .langgraph/checkpoints.db
# - Tables: checkpoints, versions
# - Each thread_id = isolated flow
```

### PostgresSaver (Production)

```python
from langgraph.checkpoint.postgres import PostgresSaver

# Create saver for production
saver = PostgresSaver(
    connection_string="postgresql://user:pass@db_server:5432/langgraph"
)

# Automatically handles:
# - Connection pooling
# - Thread-safe operations
# - Concurrent flows
```

### Checkpoint Structure

```json
{
  "thread_id": "user_123_flow_20240115_103045",
  "parent_ts": null,
  "checkpoint_ns": "PhysicalDesignGraph",
  "checkpoint_id": "1234567890",
  "ts_created": "2024-01-15T10:30:45.123456",
  "checkpoint": {
    "prompt": "run synthesis",
    "intent": {...},
    "plan": ["syn", "place", "route"],
    "current_stage_index": 1,
    "stages_executed": ["syn"],
    "stages_failed": [],
    "stage_results": {...},
    "debug_history": {...}
  },
  "metadata": {
    "node": "execute_stage",
    "user_id": "user_123"
  }
}
```

---

## Multi-User Flow Isolation

### Thread ID Management

```python
# Each flow = unique thread_id
# Format: {user_id}_{run_id}_{timestamp}

thread_id = f"{user_id}_run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

# Example:
# "bharath_run_20240115_103045"
# "alice_run_20240115_103050"
# "bob_run_20240115_103055"
```

### Database Isolation

```
LangGraph Checkpoints DB:
├── Thread 1: bharath_run_20240115_103045
│   ├── Checkpoint 1: parse_intent
│   ├── Checkpoint 2: create_plan
│   ├── Checkpoint 3: execute_stage
│   └── Checkpoint 4: debug_stage
├── Thread 2: alice_run_20240115_103050
│   ├── Checkpoint 1: parse_intent
│   ├── Checkpoint 2: create_plan
│   └── Checkpoint 3: execute_stage
└── Thread 3: bob_run_20240115_103055
    ├── Checkpoint 1: parse_intent
    └── Checkpoint 2: create_plan

Each thread completely isolated, no conflicts!
```

### API Integration

```python
@app.post("/flow/execute")
async def execute_flow(
    prompt: str,
    debug_mode: str = "auto",
    user_id: Optional[str] = None,
):
    """
    Start new flow for user
    """
    # Generate thread_id
    thread_id = f"{user_id}_run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    # Initialize state
    state = init_state(prompt, debug_mode, user_id)

    # Invoke graph (runs in background)
    config = {"configurable": {"thread_id": thread_id}}

    # Stream or async invoke
    result = await graph.ainvoke(state, config)

    return {
        "thread_id": thread_id,
        "status": "started",
        "result": result
    }
```

---

## Crash Recovery

### Automatic Resume

```python
# If server crashes mid-execution:

1. User requests status: GET /flow/status/thread_id
2. System queries checkpoint: saver.get(thread_id)
3. LangGraph finds last checkpoint
4. User can resume: POST /flow/resume/thread_id

# Result:
- Flow continues from where it crashed
- No lost work
- User data persisted automatically
```

### Example

```python
# Flow was executing stage "place" when server crashed

# Before crash:
Thread: "bharath_run_001"
Checkpoints:
  1. parse_intent (completed)
  2. create_plan (completed)
  3. execute_stage[syn] (completed)
  4. execute_stage[place] (IN PROGRESS)

# After crash recovery:
GET /flow/status/bharath_run_001
→ Returns: "place" in progress (partial state)

POST /flow/resume/bharath_run_001
→ Resumes from "place" stage
→ No re-execution of syn
```

---

## Comparison: StateTracker vs LangGraph

| Feature | StateTracker | LangGraph |
|---------|--------------|-----------|
| **State Storage** | JSON file | SQLite/Postgres |
| **Multi-user** | ❌ Race conditions | ✅ Thread-safe |
| **Concurrent flows** | ❌ File locking | ✅ Isolated threads |
| **Persistence** | Manual save calls | Automatic checkpoint |
| **Crash recovery** | ❌ Manual | ✅ Automatic resume |
| **Type safety** | Dynamic dict | TypedDict validated |
| **Visualization** | None | `graph.draw_mermaid()` |
| **Setup** | ~150 lines | ~600 lines but cleaner |
| **Testing** | Hard (state mutation) | Easy (pure nodes) |
| **Production ready** | ⚠️ Limited | ✅ Production grade |

---

## Migration Path

### Phase 1: Build PhysicalDesignGraph
- Keep StateTracker (backward compatible)
- New graph-based orchestration runs in parallel
- Test with real flows

### Phase 2: Migrate API Routes
- Switch API endpoints to use LangGraph graph
- Update thread_id handling
- Maintain backward compatibility

### Phase 3: Deprecate StateTracker
- Remove StateTracker usage
- Update tests
- Archive old code

### Phase 4: Add Advanced Features
- Dashboard with graph visualization
- Multi-flow dashboard (status of all user flows)
- Advanced checkpoint browser
- Flow replay capability

---

## Dependencies

```python
# New requirements.txt additions:
langgraph>=0.0.30
# Or from pyproject.toml:
langgraph = "^0.0.30"

# Already have:
anthropic  # For Claude calls (no change)
fastapi    # For API (no change)
uvicorn    # For server (no change)
pyyaml     # For config (no change)
```

---

## Benefits Summary

✅ **Multi-user support**: Each flow isolated by thread_id
✅ **Automatic persistence**: Checkpoint after each node
✅ **Crash recovery**: Resume from last checkpoint
✅ **Type safety**: TypedDict for state validation
✅ **Testable**: Pure node functions
✅ **Visualizable**: `graph.draw_mermaid_png()`
✅ **Scalable**: Database-backed (supports 1000s of concurrent flows)
✅ **Production ready**: Battle-tested LangGraph framework

---

## Next Steps

1. ✅ Design architecture (this document)
2. → Create PhysicalDesignGraph (~600 lines)
3. → Update persistence layer
4. → Migrate API routes
5. → Create migration guide
6. → Deploy and validate

