# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Python-based Physical Design Flow Orchestration System for semiconductor chip design. It provides an AI-powered REST API server that orchestrates EDA tool workflows (synthesis, place & route, signoff) using natural language prompts.

**Tech Stack**: Python 3.10+, FastAPI, LangGraph (multi-user orchestration), Claude Agent SDK, SQLite3

## Commands

### Run the Server

```bash
python3.10 -m src.main \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001 \
  --host 0.0.0.0 \
  --port 8000
```

### Run Tests

```bash
# Syntax validation
python3.10 test_syntax.py

# Core logic tests
python3.10 test_core_logic.py

# Quick import check
python3.10 test_quick.py

# LangGraph-specific tests
python3.10 test_langgraph_only.py

# Multi-user tests
python3.10 tests/test_multi_user.py

# Issue tracking tests
python3.10 test_issue_tracking.py
```

### Verify Imports

```bash
python3.10 -m py_compile src/agents/debug_agent.py
python3.10 -m py_compile src/agents/physical_design_graph.py
```

### API Testing

```bash
curl http://localhost:8000/health
curl http://localhost:8000/info
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "run synthesis", "debug_mode": "interactive"}'
```

## Architecture

```
HTTP Request (POST /flow/execute)
    |
    v
FastAPI Layer (src/api/flow_api.py)
    |
    v
LangGraph StateGraph (src/agents/physical_design_graph.py)
    |-- parse_intent_node: NLP intent extraction
    |-- create_plan_node: Stage planning
    |-- execute_stage_node: Tool execution via StageExecutor
    |-- debug_stage_node: AI error analysis via DebugAgent
    |-- handle_result_node: Result aggregation
    |
    v
Claude Agent SDK (src/agents/unified_agent.py)
    |-- Skills: Domain knowledge from skills/*.md files
    |-- Tools: Read, Edit, Glob, Bash
```

### Key Components

- **src/main.py**: FastAPI server entry point with CLI arguments
- **src/agents/physical_design_graph.py**: LangGraph orchestrator for multi-user flow execution
- **src/agents/debug_agent.py**: Error analysis and fix generation using Claude
- **src/agents/unified_agent.py**: Claude Agent SDK integration with 8 execution contexts
- **src/config/config_manager.py**: YAML configuration and path resolution
- **src/executor/stage_executor.py**: Subprocess execution for EDA tools
- **src/tracker/langgraph_saver.py**: Redis/SQLite checkpointer for state persistence
- **src/issues/**: Issue tracking system with SQLite backend

### Configuration Files

- **flow_config.yaml**: Defines 13 physical design stages (syn, place, route, sta, pv, lec, etc.)
- **sourceproj.env**: EDA environment variables and tool paths

### Skill System

Domain knowledge is stored in modular markdown files under `skills/`:
- `synthesis_skills.md`: Synthesis optimization and debugging
- `pnr_skills.md`: Place & route analysis
- `debug_skills.md`: Error diagnosis knowledge
- `knowledge_skills.md`: EDA tool commands

### Multi-User Isolation

Thread ID format: `{user_id}_{block}_{experiment}_{timestamp}`

State is persisted via LangGraph checkpointing (Redis or SQLite) for crash recovery.

## API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/flow/execute` | Execute flow with natural language |
| GET | `/flow/status` | Current execution status |
| GET | `/flow/stages` | Available stages |
| GET | `/flow/history` | Execution history |
| GET | `/flow/logs/{stage}` | Stage log content |
| WebSocket | `/flow/ws` | Real-time updates |
| POST | `/issues/create` | Create issue |
| GET | `/issues/list` | List issues |
| POST | `/issues/suggest-fixes` | Get fix suggestions |

## Execution Contexts

| Context | Purpose |
|---------|---------|
| EXECUTE_SYNTHESIS | Run synthesis |
| EXECUTE_PNR | Place & route |
| EXECUTE_STA | Static timing analysis |
| DEBUG_TIMING | Fix timing issues |
| DEBUG_LINKING | Fix linking errors |
| DEBUG_CONVERGENCE | Fix convergence issues |
| DEBUG_DRV | Fix design rule violations |
| ANALYZE_ERROR | Analyze errors |
