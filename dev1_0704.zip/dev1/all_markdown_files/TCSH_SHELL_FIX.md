# tcsh Environment File Fix (Option B)

## Problem

The `sourceproj.env` file uses tcsh syntax (`setenv`, `source`), but the execution shell was bash. This caused:

```
setenv: command not found  (50+ times)
→ All environment variables failed to load
→ RTL_FILELIST undefined
→ genus_syn.tcl: can't read "env(RTL_FILELIST)"
→ Synthesis fails
```

## Solution: Auto-Detect Shell Format & Use Appropriate Shell

### Implementation

**File:** `src/executor/stage_executor.py`

#### 1. Detect Environment File Format
```python
# Detect environment file format (bash vs tcsh)
is_tcsh = False
try:
    with open(env_file, 'r') as f:
        first_line = f.readline().strip()
        is_tcsh = 'tcsh' in first_line or 'csh' in first_line
except Exception as e:
    print(f"[WARN] Could not detect env file format: {e}")
```

#### 2. Build Command with Correct Shell
**For tcsh files:**
```bash
tcsh -c 'source /path/to/sourceproj.env && genus -files /path/to/script.tcl -abort_on_error | tee log'
```
- Entire command runs in tcsh context
- `setenv` commands work correctly
- All variables available to genus process

**For bash files:**
```bash
source /path/to/sourceproj.env && genus -files /path/to/script.tcl -abort_on_error | tee log
```
- Standard bash execution
- `export` commands work correctly

#### 3. Execute with Correct Shell Executable
```python
process = await asyncio.create_subprocess_shell(
    cmd,
    cwd=str(work_dir),
    stdout=asyncio.subprocess.PIPE,
    stderr=asyncio.subprocess.PIPE,
    env=os.environ.copy(),
    executable=shell_executable,  # /bin/bash or /bin/tcsh
)
```

### Debug Output

When the fix is active, you'll see:

```
[EXEC] Running syn...
  Sourcing environment in /bin/tcsh...
  Shell: tcsh (detected tcsh format in sourceproj.env)
  Command: tcsh -c 'source /proj5/.../sourceproj.env && genus -files /proj5/.../genus_syn.tcl -abort_on_error | tee /proj5/.../syn.log'

[OK] syn completed successfully
  Log: /proj5/.../syn.log
```

## How This Works

### Before (Broken)
```
Python Process (bash)
  ↓
create_subprocess_shell with executable=/bin/bash
  ↓
Bash tries to interpret: source sourceproj.env
  ↓
Bash encounters: setenv BLOCK_NAME aes_cipher_top
  ↓
❌ setenv: command not found
  ↓
Environment variables undefined
  ↓
genus_syn.tcl crashes with RTL_FILELIST missing
```

### After (Fixed)
```
Python Process
  ↓
Detects: sourceproj.env starts with #!/bin/tcsh
  ↓
Builds: tcsh -c 'source sourceproj.env && genus ...'
  ↓
create_subprocess_shell with executable=/bin/tcsh
  ↓
tcsh sources the file correctly
  ↓
✅ All setenv commands work
  ↓
Environment variables set in tcsh context
  ↓
genus launches with all variables available
  ↓
genus_syn.tcl reads $env(RTL_FILELIST) successfully
```

## Compatibility

This fix handles:

| Scenario | File Format | Shell | Result |
|----------|------------|-------|--------|
| Standard project | `#!/bin/tcsh` + `setenv` | tcsh | ✅ Works |
| Bash-based project | `#!/bin/bash` + `export` | bash | ✅ Works |
| Auto-detect failure | Unknown | bash (default) | ⚠️ Falls back to bash |

## Testing

Run synthesis with debug output enabled:

```bash
# Check logs for shell detection
tail -n 100 /proj5/projects/semicon_19-02/pd/users/bharath/aes_cipher_top/bronze_v2/run2/syn/logs/syn.log

# Verify environment variables are set
grep "setenv: command not found" /path/to/syn.log
# Should return: empty (no errors)

# Verify tool ran
grep "Success" /path/to/syn.log
# Should show successful completion
```

## No Code Changes Required

✅ ConfigManager already detects tcsh format (for env sourcing in Python)
✅ StageExecutor now detects tcsh format (for subprocess execution)
✅ Both use appropriate shell automatically
✅ No user configuration needed - auto-detects from shebang

This is a transparent, automatic fix that handles both tcsh and bash environment files without any manual intervention.
