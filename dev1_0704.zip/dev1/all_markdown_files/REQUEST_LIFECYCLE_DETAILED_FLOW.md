# Dev1 Incoming Request Lifecycle (Detailed)

This document explains how an incoming lifecycle/API request moves through `dev1` end-to-end: API layer, Redis, PostgreSQL, LangGraph state transitions, and HITL handling.

## 1) Runtime bootstrap (before first request)

When the API process starts (`dev1/src/main.py`):

1. `load_env_file()` loads `dev1/.env` (without overriding already-set env vars).
2. `initialize_lifecycle_runtime()` initializes:
   - feature flags from env (`USE_JOB_LIFECYCLE_API`, `USE_POSTGRES_JOB_REPO`, `USE_REDIS_JOB_STATE`)
   - runtime endpoints (`POSTGRES_URI`, `REDIS_URL`)
3. If Postgres flag is enabled, lifecycle schema is auto-created (`Base.metadata.create_all`).
4. If Redis flag is enabled, these adapters are created:
   - `RedisJobStateStore`
   - `RedisJobEventPublisher`

## 2) Lifecycle request path: `POST /jobs`

Endpoint: `dev1/src/main.py` (`create_job_compat`)

### Request in
Typical payload:
- `script_path`
- `instructions_path`
- `allowed_paths`
- `max_retries`
- `max_iterations`
- optional `user_id`, `session_id`

### Internal processing
1. Generate identity (`job_id`, `session_id`) via `make_identity()`.
2. If Postgres enabled:
   - insert row in `jobs`
   - insert config row in `job_configurations`
3. Build initial lifecycle state object:
   - `status=PENDING`, `phase=QUEUED`, `iteration=0`, etc.
4. If Redis enabled:
   - write hash `job:{job_id}:state`
   - enqueue payload to list `jobs:queue`
5. Publish lifecycle event on Redis pub/sub channel:
   - `jobs:{job_id}:events` payload: `queued`

### Response out
- HTTP `202`
- `{ job_id, status: "PENDING", phase: "QUEUED" }`

## 3) Status query path: `GET /jobs/{job_id}/job_status`

Resolution order:
1. Read Redis hash `job:{job_id}:state` first (preferred live state).
2. If missing, fallback to Postgres `jobs` table.
3. Return normalized status/phase tuple to caller.

## 4) HITL response path: `POST /jobs/{job_id}/human-input`

1. Validate job exists (via Postgres when enabled).
2. Persist human interaction row in Postgres (`human_interactions`).
3. Push response to Redis list `job:{job_id}:hitl_response`.
4. Update Redis state hash message to `Human input received`.
5. Publish pub/sub events:
   - `jobs:{job_id}:hitl_response`
   - `jobs:{job_id}:events` with `event_type=hitl_response`

## 5) Abort path: `POST /jobs/{job_id}/abort`

1. Update Postgres lifecycle row to:
   - `status=CANCELLED`, `phase=ABORT_REQUESTED`
2. Set Redis abort flag key:
   - `job:{job_id}:abort = 1`
3. Update Redis state hash with cancelled/abort-requested values.
4. Publish pub/sub abort events:
   - `jobs:{job_id}:abort`
   - `jobs:{job_id}:events` with `event_type=abort_requested`

## 6) Full state path: `GET /job_state?job_id=...`

1. Read Redis hash `job:{job_id}:state`.
2. Optionally read most recent HITL payload from list `job:{job_id}:hitl_response`.
3. Return merged state JSON to caller.

## 7) WebSocket event stream: `WS /ws/jobs/{job_id}`

1. Client connects to websocket endpoint.
2. Server subscribes to Redis channel `jobs:{job_id}:events`.
3. Every published lifecycle event is forwarded to the websocket client.

## 8) Graph execution flow (`/flow/execute`) and lifecycle bridge

For full graph-driven execution, `main.py` calls:
- `PhysicalDesignGraph.invoke(..., lifecycle_hook=lifecycle_bridge)`

Inside `PhysicalDesignGraph`, these hook events are emitted:
- `started`
- `stage_started`
- `stage_completed`
- `stage_failed`
- `completed` or `failed`

`lifecycle_bridge(...)` in `main.py` maps each event to:
- Redis hash updates (`job:{job_id}:state`)
- Postgres `jobs` status updates
- Redis pub/sub `jobs:{job_id}:events`

Event-to-status mapping lives in `dev1/src/infra/lifecycle_utils.py`.

## 9) LangGraph FlowState transitions (core state mutation)

`FlowState` fields evolve in this sequence:

1. **Initialize invoke state**
   - `execution_status=pending`
   - `plan=[]`
   - `current_stage_index=0`
   - `stages_executed=[]`, `stages_failed=[]`
2. **`parse_intent` node**
   - fills `intent`
   - sets `execution_status=in_progress`
3. **`create_plan` node**
   - populates `plan`
   - resets stage/result/debug tracking containers
   - emits `started`
4. **`execute_stage` node**
   - emits `stage_started`
   - on success: appends stage to `stages_executed`, increments `current_stage_index`, emits `stage_completed`
   - on failure: sets `error_info`, increments `error_retry_count`, emits `stage_failed`
5. **`debug_stage` node** (only after failures)
   - writes `debug_result`
   - appends attempt record into `debug_history[stage]`
6. **`handle_result` node**
   - sets `execution_status=completed|failed`
   - sets `end_time`
   - emits `completed|failed`

## 10) What gets logged where

### API process logs (stdout)
- Request receipt, stage transitions, errors, lifecycle route activity.

### Redis
- Queue: `jobs:queue`
- State: `job:{job_id}:state` (hash)
- HITL list: `job:{job_id}:hitl_response`
- Abort flag: `job:{job_id}:abort`
- Event channel: `jobs:{job_id}:events`

### PostgreSQL
- Lifecycle state: `jobs`
- Input config: `job_configurations`
- HITL history: `human_interactions`
- Optional execution/error/checkpoint tables for advanced flows

## 11) Proof-run evidence (latest run)

Validated with `job_id=39299d06-d4b2-45be-ba57-738d08e4313a`:
- API flow succeeded from `PENDING/QUEUED` → `CANCELLED/ABORT_REQUESTED`
- Postgres row present in `jobs`
- Redis hash present at `job:{job_id}:state`
- Redis HITL payload present at `job:{job_id}:hitl_response`
- Redis abort flag present at `job:{job_id}:abort`
