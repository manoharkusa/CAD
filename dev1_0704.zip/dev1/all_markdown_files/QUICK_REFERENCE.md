# Quick Reference Guide

## File Dependency Graph

```
User Request
    ↓
main.py (Server startup)
    ├─ Reads command-line args
    ├─ Creates FastAPI app
    └─ Mounts flow_api.py routes
         ↓
flow_api.py (HTTP endpoints)
    ├─ POST /flow/execute
    │   ├─ Parses request
    │   ├─ Creates config_manager.py instance
    │   └─ Calls physical_design_graph.py
    │
    ├─ GET /flow/status
    └─ POST /flow/resume
         ↓
physical_design_graph.py (5-node orchestrator)
    ├─ parse_intent_node → intent
    ├─ create_plan_node → plan
    ├─ execute_stage_node → StageExecutor
    │   └─ Uses config_manager.py for paths
    ├─ [If error] debug_stage_node → debug_agent.py
    └─ handle_result_node → return result
         ↓
config_manager.py (Path resolution)
    ├─ Source sourceproj.env
    ├─ Load flow_config.yaml
    └─ Resolve all paths
         ↓
stage_executor.py (Tool execution)
    ├─ Detect env format (tcsh/bash)
    ├─ Build shell command
    └─ Execute subprocess
         ↓
Tool (Genus/Innovus/Calibre)
    ├─ Reads environment variables
    ├─ Runs TCL script
    └─ Generates outputs

langgraph_saver.py (Checkpointing)
    └─ Saves/retrieves state by thread_id
```

---

## File Quick Look

### 🔧 Core Files (Must Learn)

| File | Lines | Time | Key Function |
|------|-------|------|--------------|
| `config_manager.py` | ~300 | 40min | `create_config_manager()`, `get_stage_work_dir()`, `get_tool_script_path()` |
| `stage_executor.py` | ~250 | 40min | `execute_stage()`, `_run_tool()` |
| `physical_design_graph.py` | ~700 | 90min | `_parse_intent_node()`, `_execute_stage_node()`, `invoke()` |

### 📡 API Files

| File | Lines | Time | Key Function |
|------|-------|------|--------------|
| `flow_api.py` | ~150 | 30min | `execute_flow()`, `get_flow_status()` |
| `main.py` | ~150 | 20min | `create_app()`, `main()` |

### 🐛 Support Files

| File | Lines | Time | Key Function |
|------|-------|------|--------------|
| `debug_agent.py` | ~200 | 30min | `analyze_error()` |
| `langgraph_saver.py` | ~400 | 20min | `get_saver()`, `create_thread_id()` |

---

## Key Code Snippets to Understand

### 1. ConfigManager: Path Resolution
```python
# Get script path
tool, script = config.get_stage_tool_script("syn")
# Returns: ("genus", "genus_syn.tcl")

script_path = config.get_tool_script_path(tool, script)
# Returns: /proj5/REL/env_scripts/.../genus/genus_syn.tcl

# Get work directory (with stage_group support)
work_dir = config.get_stage_work_dir("place")
# Returns: /proj5/.../run2/pnr/place/work  (stage_group=pnr)
```

**Why important:** Every tool execution depends on these paths being correct.

---

### 2. StageExecutor: Command Building
```python
# Detect format
is_tcsh = 'tcsh' in first_line

# Build command based on format
if is_tcsh:
    cmd = "tcsh -c 'source env && tool -files script'"
else:
    cmd = "source env && tool -files script"

# Execute
process = await asyncio.create_subprocess_shell(
    cmd,
    cwd=work_dir,
    executable=shell_executable
)
```

**Why important:** This is how tools actually run. Understanding this is critical.

---

### 3. PhysicalDesignGraph: State Flow
```python
# FlowState starts empty
state = {
    "user_id": "bharath",
    "prompt": "run synthesis",
    "plan": [],
    "stages_executed": [],
    "error_info": None,
}

# parse_intent_node updates it
state["intent"] = {...}

# create_plan_node updates it
state["plan"] = ["syn", "place"]

# execute_stage_node loops through plan
for i in range(len(plan)):
    state["current_stage_index"] = i
    # Execute stage[i]
    state["stages_executed"].append(stage)
    state["current_stage_index"] += 1  # CRITICAL!
```

**Why important:** Understanding state transitions is key to debugging.

---

### 4. Routing Logic: How Errors Are Handled
```python
# After execute_stage
if error_info is None:
    # Success - continue
    return "execute_stage"  # or "handle_result"
else:
    # Error - debug
    return "debug_stage"

# After debug_stage
if suggested_fix and retry_count < max:
    return "execute_stage"  # Retry
else:
    return "handle_result"  # Give up
```

**Why important:** This determines whether flows succeed or fail.

---

## Common Patterns

### Pattern: Async Tool Execution
```python
async def execute_stage(...):
    # Non-blocking execution
    process = await asyncio.create_subprocess_shell(...)
    stdout, stderr = await process.communicate()
    return {"status": "success" if return_code == 0 else "failed"}

# Called as:
result = await executor.execute_stage(...)
```

### Pattern: State Updates
```python
# Node receives state, returns updates
async def node(state: FlowState) -> Dict[str, Any]:
    # Read from state
    current_value = state.get("field")

    # Calculate new value
    new_value = ...

    # Return updates (merged into state)
    return {"field": new_value}
```

### Pattern: Error Handling
```python
try:
    result = await execute_stage(...)
    if result["status"] == "failed":
        return {
            "error_info": {"error": result["error"]},
            "stages_failed": [...] + [stage_name]
        }
except Exception as e:
    return {
        "error_info": {"error": str(e)},
        "execution_status": "failed"
    }
```

---

## Debugging Checklist

When something goes wrong, check in this order:

### ✓ Checklist for Path Issues
- [ ] Does sourceproj.env exist at run_dir?
- [ ] Is sourceproj.env format detected correctly (tcsh/bash)?
- [ ] Is ENV_SCRIPTS set in sourceproj.env?
- [ ] Does ENV_SCRIPTS directory exist?
- [ ] Does script exist at {ENV_SCRIPTS}/{tool}/{script}?
- [ ] Is stage_group + base_dir correct in flow_config.yaml?

### ✓ Checklist for Execution Issues
- [ ] Do work_dir and log_dir exist?
- [ ] Can the shell (tcsh/bash) be found?
- [ ] Is the tool executable available?
- [ ] Are all environment variables set?
- [ ] Does the TCL script have correct syntax?

### ✓ Checklist for State Issues
- [ ] Is FlowState being updated correctly?
- [ ] Is current_stage_index incremented after success?
- [ ] Is error_retry_count incremented on retry?
- [ ] Are stages_executed and stages_failed correct?

### ✓ Checklist for Multi-User Issues
- [ ] Is thread_id unique per user+run?
- [ ] Are checkpoints isolated by thread_id?
- [ ] Are work directories different per user?
- [ ] Are log files different per user?

---

## Common Errors & Solutions

### Error: "Tool script not found: genus/genus_syn.tcl"

**Root cause:** ENV_SCRIPTS not set or path wrong

**Check:**
1. Is sourceproj.env being sourced?
2. Does sourceproj.env have ENV_SCRIPTS?
3. Does ENV_SCRIPTS path exist?

**Fix:**
```python
# In config_manager.py
print(f"ENV_SCRIPTS: {os.environ.get('ENV_SCRIPTS')}")
print(f"tools_root: {self.tools_root}")
```

---

### Error: "can't read env(RTL_FILELIST)"

**Root cause:** sourceproj.env not being sourced correctly

**Check:**
1. Is it tcsh or bash format?
2. Is env format detection working?

**Fix:**
```python
# In stage_executor.py
print(f"Is tcsh: {is_tcsh}")
print(f"Shell executable: {shell_executable}")
```

---

### Error: Synthesis runs infinitely (200 times)

**Root cause:** current_stage_index not incrementing

**Check:**
```python
# In physical_design_graph.py
# After execute_stage success, must increment:
updates["current_stage_index"] = current_index + 1
```

---

## Learning Path by Role

### If you're a **Backend Developer:**
1. Start: `config_manager.py`
2. Then: `stage_executor.py`
3. Then: `physical_design_graph.py`
4. Then: `flow_api.py`

### If you're a **DevOps/Sys Admin:**
1. Start: `main.py`
2. Then: `flow_api.py`
3. Then: `langgraph_saver.py`
4. Optional: Others

### If you're a **Hardware Designer:**
1. Start: Understanding the tools (Genus, Innovus)
2. Then: `config_manager.py` (understand paths)
3. Then: `stage_executor.py` (understand execution)
4. Then: `flow_config.yaml` (understand stage definitions)

---

## Time Investment ROI

| Knowledge | Time | Usefulness |
|-----------|------|------------|
| ConfigManager paths | 10 min | 🌟🌟🌟🌟🌟 (Most debugging issues) |
| StageExecutor execution | 15 min | 🌟🌟🌟🌟🌟 (Understanding tool runs) |
| PhysicalDesignGraph logic | 30 min | 🌟🌟🌟🌟 (Overall flow) |
| Error recovery | 10 min | 🌟🌟🌟🌟 (Reliability) |
| API endpoints | 10 min | 🌟🌟🌟 (Using the system) |
| Total | 75 min | 🌟🌟🌟🌟🌟 (Complete understanding) |

---

## Resources

- **Study Guide (Markdown):** `STUDY_GUIDE.md`
- **Study Guide (HTML):** `study_guide.html`
- **Script Learning Plan:** `SCRIPT_LEARNING_PLAN.md`
- **Setup Guide:** `SETUP_GUIDE.md`
- **Migration Guide:** `MIGRATION_GUIDE.md`

---

## Quick Start for Modifications

### Want to add a new stage?
1. Read: `flow_config.yaml` section in SETUP_GUIDE
2. Add stage to `flow_config.yaml`
3. Done! (ConfigManager handles everything)

### Want to change directory structure?
1. Read: `config_manager.py` (get_stage_work_dir)
2. Modify stage_group or base_dir in `flow_config.yaml`
3. Done!

### Want to support a new tool?
1. Create TCL script in `{ENV_SCRIPTS}/{tool_name}/script.tcl`
2. Add to `flow_config.yaml`
3. Done! (StageExecutor auto-handles)

### Want to change error recovery?
1. Read: `physical_design_graph.py` (_route_after_debug)
2. Modify retry logic
3. Update `debug_agent.py` if needed

---

## Pro Tips

1. **Always print intermediate values** when debugging
2. **Use thread_id as trace ID** for multi-user debugging
3. **Check paths early** - most issues are path-related
4. **Understand async/await** - key to everything
5. **TypedDict is your friend** - shows all state fields

Good luck! 🚀
