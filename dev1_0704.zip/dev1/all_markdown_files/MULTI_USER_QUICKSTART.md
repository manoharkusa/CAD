# Multi-User Server - Quick Start Guide

## What Changed

The API now supports **multiple concurrent users** with complete flow isolation:

- ✅ Each flow gets a unique `thread_id`
- ✅ State automatically checkpointed to SQLite
- ✅ Users don't interfere with each other
- ✅ Flows can be resumed from checkpoints
- ✅ 100% backward compatible with existing code

## Server Startup (Same as Before)

```bash
python src/main.py \
  --project aes_cipher \
  --user default \
  --block aes_top \
  --rtl-tag v1.0 \
  --run-tag initial
```

Server now prints:
```
[CHECKPOINTER] Initializing LangGraph checkpointer...
[OK] LangGraph checkpointer initialized
  Database: /path/to/project/.flow_checkpoints.db
[OK] Multi-user mode enabled
```

## Basic Usage

### 1. Execute Flow (Now with user_id)

```bash
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "project": "aes_cipher",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "run_id": "run_001"
  }'
```

**Response:**
```json
{
  "thread_id": "alice_run_20260216_143022",
  "run_id": "run_001",
  "status": "in_progress",
  "stages_executed": [],
  "stages_failed": [],
  "start_time": "2026-02-16T14:30:22.123456"
}
```

💡 **Key**: Save the `thread_id` - you'll need it to check status and resume

### 2. Check Status

```bash
# Check status of specific thread
curl "http://localhost:8000/flow/status?thread_id=alice_run_20260216_143022"
```

**Response:**
```json
{
  "thread_id": "alice_run_20260216_143022",
  "run_id": "run_001",
  "status": "in_progress",
  "current_stage": "place",
  "stages": {
    "syn": "completed",
    "init_design": "completed",
    "floorplan": "completed",
    "place": "in_progress"
  },
  "progress_percent": 33,
  "start_time": "2026-02-16T14:30:22.123456"
}
```

### 3. Resume from Checkpoint

```bash
# If flow was interrupted, resume it
curl -X POST "http://localhost:8000/thread/alice_run_20260216_143022/resume"
```

**Response:**
```json
{
  "thread_id": "alice_run_20260216_143022",
  "status": "completed",
  "stages_executed": ["syn", "place", "route"],
  "stages_failed": []
}
```

### 4. Get Complete History

```bash
curl "http://localhost:8000/thread/alice_run_20260216_143022/history"
```

**Response:**
```json
{
  "thread_id": "alice_run_20260216_143022",
  "state": {
    "prompt": "run synthesis",
    "user_id": "alice",
    "stages_executed": ["syn", "place", "route"],
    "stage_results": {
      "syn": {
        "status": "success",
        "iterations": 2,
        "final_output": "Synthesis completed"
      }
    }
  },
  "checkpoint_id": "ckpt_20260216_143555_654321"
}
```

## Multi-User Concurrent Execution

Multiple users can run flows simultaneously without interference:

```bash
# Terminal 1: Alice's flow
curl -X POST http://localhost:8000/flow/execute \
  -d '{"prompt": "run synthesis", "user_id": "alice"}' &

# Terminal 2: Bob's flow (at the same time)
curl -X POST http://localhost:8000/flow/execute \
  -d '{"prompt": "run pnr", "user_id": "bob"}' &

# Terminal 3: Check both are running
curl http://localhost:8000/threads
```

Each user's flow:
- Gets unique `thread_id`
- Has isolated checkpoints
- Doesn't affect others' flows
- Can be resumed independently

## Common Operations

### List All Threads

```bash
curl http://localhost:8000/threads
```

### List Threads for Specific User

```bash
curl "http://localhost:8000/threads?user_id=alice"
```

### Delete a Thread

```bash
curl -X DELETE "http://localhost:8000/thread/alice_run_20260216_143022"
```

Response:
```json
{
  "message": "Thread alice_run_20260216_143022 deleted"
}
```

## Backward Compatibility

**Old code still works** - omit `user_id` to use legacy mode:

```bash
# This still works (uses OrchestratorAgent)
curl -X POST http://localhost:8000/flow/execute \
  -d '{"prompt": "run synthesis"}'

# Response includes thread_id: null (legacy mode)
{
  "thread_id": null,
  "run_id": "",
  "status": "completed"
}
```

## Testing Multi-User Concurrency

```python
import asyncio
import aiohttp

async def test_concurrent_users():
    """Test 3 users running flows concurrently"""
    users = ["alice", "bob", "charlie"]

    async with aiohttp.ClientSession() as session:
        tasks = [
            session.post(
                "http://localhost:8000/flow/execute",
                json={
                    "prompt": f"run synthesis for {user}",
                    "user_id": user
                }
            )
            for user in users
        ]

        responses = await asyncio.gather(*tasks)
        thread_ids = [
            (await r.json())["thread_id"]
            for r in responses
        ]

        print(f"✓ Started {len(thread_ids)} concurrent flows:")
        for user, tid in zip(users, thread_ids):
            print(f"  {user}: {tid}")

# Run the test
asyncio.run(test_concurrent_users())
```

## Monitoring Checkpoint Database

The checkpoint database is stored at:
```
.flow_checkpoints.db
```

View database stats:
```bash
# Check file size
ls -lh .flow_checkpoints.db

# Count checkpoints per thread
sqlite3 .flow_checkpoints.db "SELECT thread_id, COUNT(*) as checkpoints FROM checkpoints GROUP BY thread_id"

# List all threads
sqlite3 .flow_checkpoints.db "SELECT DISTINCT thread_id FROM checkpoints ORDER BY thread_id"

# Get latest checkpoint for a thread
sqlite3 .flow_checkpoints.db "SELECT checkpoint_id, timestamp FROM checkpoints WHERE thread_id='alice_run_...' ORDER BY created_at DESC LIMIT 1"
```

## Error Handling

### Thread Not Found

```bash
curl http://localhost:8000/flow/status?thread_id=invalid_thread_id
```

**Response (404):**
```json
{
  "detail": "Thread invalid_thread_id not found"
}
```

### Multi-User Mode Disabled

```bash
curl http://localhost:8000/thread/thread_id/history
```

If checkpointer didn't initialize:
```json
{
  "detail": "Multi-user mode not enabled"
}
```

## Production Deployment

### SQLite (Current - Good for ~100 Users)

Default configuration. Database stored locally:
```
.flow_checkpoints.db
```

**Pros**: No setup, good for testing/small deployments
**Cons**: Limited concurrency

### PostgreSQL (Recommended - For 1000+ Users)

```python
# In src/main.py, change:
saver = get_saver(
    backend="postgres",
    connection_string="postgresql://user:pass@localhost/flow_db"
)
```

**Pros**: High concurrency, enterprise-ready
**Cons**: Requires PostgreSQL database

## Performance Tips

1. **Use thread_id for lookups**: Always pass `?thread_id=...` for status/history
2. **Batch operations**: Use `/threads` endpoint to get all thread_ids at once
3. **Clean old threads**: Delete completed threads to keep database lean
4. **Monitor checkpoint growth**: Check database file size regularly

## Troubleshooting

### "Multi-user mode not enabled"

**Problem**: Checkpointer didn't initialize

**Solution**:
```bash
# Check database permissions
ls -la .flow_checkpoints.db

# Check for initialization errors
python src/main.py ... 2>&1 | grep -i error

# Verify saver works
python -c "from src.tracker.langgraph_saver import get_saver; s = get_saver(); print('✓ OK')"
```

### Slow Status Queries

**Problem**: Many threads in database, queries slow

**Solution**:
```bash
# Delete old/completed threads
curl -X DELETE http://localhost:8000/thread/old_thread_id

# Or rebuild database index
sqlite3 .flow_checkpoints.db "REINDEX idx_thread_id"
```

### Connection Errors

**Problem**: SQLite database locked

**Solution**:
```bash
# Check for stuck processes
lsof .flow_checkpoints.db

# Or move to PostgreSQL for better concurrency
```

## Next Steps

✅ **Start using multi-user mode**: Add `user_id` to all `/flow/execute` requests
✅ **Monitor checkpoints**: Keep database clean and healthy
✅ **Plan for scale**: When reaching 100+ users, consider PostgreSQL
✅ **Add authentication**: Integrate with JWT/OAuth to tie users to requests

## Support

For issues or questions:
1. Check database: `sqlite3 .flow_checkpoints.db "SELECT COUNT(*) FROM checkpoints"`
2. Review logs: Look for `[CHECKPOINTER]` and `[API]` lines
3. Test manually: `curl http://localhost:8000/health`
4. Run tests: `pytest tests/test_multi_user.py -v`
