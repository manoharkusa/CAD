# Experiment Name Parameter - API Clarification

## Overview

Renamed `run_id` parameter to `experiment_name` throughout the API for clarity and accuracy.

## Why This Change

The parameter represents **experiment names selected from the UI dropdown**, not generic "run IDs". The UI structure is:

```
Dropdowns:
  ├── Project → project_name
  ├── User → user_id
  ├── Block → block_name
  ├── RTL Tag → rtl_tag
  └── Experiment → experiment_name  ✓ This is what was called run_id
```

Directory structure:
```
/proj/{project_name}/pd/users/{user_name}/{block_name}/{rtl_tag}/{experiment_name}/
                                                        ↓
                                              Experiment directory
```

## API Changes

### ExecuteRequest Model

**Before**:
```python
class ExecuteRequest(BaseModel):
    prompt: str
    user_id: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    rtl_tag: Optional[str] = None
    run_id: Optional[str] = None  # ← Was this
```

**After**:
```python
class ExecuteRequest(BaseModel):
    prompt: str
    # UI Metadata (selected from dropdowns)
    user_id: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    rtl_tag: Optional[str] = None
    experiment_name: Optional[str] = None  # ← Now this
```

### ExecuteResponse Model

**Before**:
```python
class ExecuteResponse(BaseModel):
    thread_id: Optional[str] = None
    run_id: str  # ← Was this
    status: str
    # ...
```

**After**:
```python
class ExecuteResponse(BaseModel):
    thread_id: Optional[str] = None
    experiment_name: Optional[str] = None  # ← Now this (echoes back the experiment)
    status: str
    # ...
```

## Curl Examples

### Execute Experiment

**Before**:
```bash
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "run_id": "expr_001"
  }'
```

**After**:
```bash
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "project": "aes_cipher",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "experiment_name": "expr_001"
  }'
```

### Response

**Before**:
```json
{
  "thread_id": "alice_aes_top_expr_001_20260216_143022",
  "run_id": "expr_001",
  "status": "in_progress"
}
```

**After**:
```json
{
  "thread_id": "alice_aes_top_expr_001_20260216_143022",
  "experiment_name": "expr_001",
  "status": "in_progress"
}
```

## Internal Implementation

### Thread ID Format

**Unchanged** (uses experiment_name internally):
```
{user_id}_{block_name}_{experiment_name}_{timestamp}

Examples:
  alice_aes_top_expr_001_20260216_143022
  alice_aes_top_expr_002_20260216_143100
  alice_sha_top_baseline_20260216_144000
```

### FlowState

**Internal field** (unchanged for backward compatibility):
```python
class FlowState(TypedDict):
    # ...
    run_id: str  # Internal: maps to experiment_name from UI
    # ...
```

This allows the graph nodes to continue using `run_id` internally without changes.

## Usage Patterns

### Multiple Experiments on Same Block

```bash
# Experiment 1: Baseline
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "experiment_name": "baseline"
  }'

# Experiment 2: Optimized
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis with optimizations",
    "user_id": "alice",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "experiment_name": "opt_v1"
  }'

# Experiment 3: Alternative approach
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis with different strategy",
    "user_id": "alice",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "experiment_name": "strategy_b"
  }'
```

Each gets unique thread_id:
- `alice_aes_top_baseline_20260216_143022`
- `alice_aes_top_opt_v1_20260216_143100`
- `alice_aes_top_strategy_b_20260216_143200`

### Same Experiment, Run Again

```bash
# First run of experiment
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "block": "aes_top",
    "experiment_name": "expr_001"
  }'
# Result: alice_aes_top_expr_001_20260216_143022

# Run same experiment again
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "block": "aes_top",
    "experiment_name": "expr_001"
  }'
# Result: alice_aes_top_expr_001_20260216_143100 (new timestamp)
```

Each run gets unique thread_id with different timestamp.

## Backward Compatibility

### Internal Usage

- Graph nodes continue to use `run_id` internally
- No changes needed in PhysicalDesignGraph
- Checkpointer uses thread_id (based on experiment_name)

### Legacy Single-User Mode

- Response includes `experiment_name: None` when not provided
- No breaking changes to existing code

## Naming Conventions

Since `experiment_name` comes from UI dropdown, examples include:

```
expr_001, expr_002, expr_003      # Sequential experiments
baseline, opt_v1, opt_v2           # Optimization versions
synthesis_v1, synthesis_v2         # Version tracking
timing_opt, area_opt               # Optimization goals
cmos_40nm, cmos_28nm               # Technology variants
run_001, run_002, run_003          # Manual run numbering
pr_baseline, pr_optimized          # Pre-route variations
```

## Thread ID Parsing

To extract experiment_name from thread_id:

```python
from src.tracker.langgraph_saver import parse_thread_id

thread_id = "alice_aes_top_expr_001_20260216_143022"
info = parse_thread_id(thread_id)

print(info["experiment"])  # "expr_001"
```

## Database Representation

### Checkpoint Table

```sql
CREATE TABLE checkpoints (
    thread_id TEXT NOT NULL,
    -- Examples:
    -- alice_aes_top_expr_001_20260216_143022
    -- alice_aes_top_expr_002_20260216_143100
    -- alice_sha_top_baseline_20260216_144000
    ...
);
```

### Query Experiments

```bash
# List all experiments for alice on aes_top
sqlite3 .flow_checkpoints.db "
  SELECT DISTINCT thread_id FROM checkpoints
  WHERE thread_id LIKE 'alice_aes_top_%'
"

# Count checkpoints per experiment
sqlite3 .flow_checkpoints.db "
  SELECT thread_id, COUNT(*) as checkpoints FROM checkpoints
  WHERE thread_id LIKE 'alice_aes_top_%'
  GROUP BY thread_id
"
```

## Summary

✅ **Clarity**: Parameter now clearly represents experiment selection from UI
✅ **Consistency**: Matches directory structure `/.../{experiment_name}/`
✅ **Compatibility**: Internal implementation unchanged (uses run_id)
✅ **Functionality**: No behavioral changes, just naming
✅ **Testing**: All tests updated to use experiment_name

**Files Updated**:
- ✅ src/api/flow_api.py - ExecuteRequest, ExecuteResponse, endpoints
- ✅ src/tracker/langgraph_saver.py - Function parameters (already support)
- ✅ tests/test_multi_user.py - Test cases
- ✅ Documentation files

**API Version**: Same (backward compatible at field level)
**Status**: Ready for UI integration
