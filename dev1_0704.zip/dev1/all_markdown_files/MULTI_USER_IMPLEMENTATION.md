# Multi-User Server Implementation - Complete Guide

## Overview

This document outlines the complete implementation of multi-user support for the Physical Design Flow API server. The implementation leverages:

- **PhysicalDesignGraph**: Stateless LangGraph-based orchestration (already exists)
- **LangGraph Checkpointer**: SQLite-based state persistence with thread isolation
- **Thread ID Tracking**: Unique identifier per user/flow for complete isolation
- **Async/Await**: Proper async support for concurrent flows

## Implementation Status

✅ **Completed**:
1. Updated API request/response models to include `thread_id`
2. Enhanced `/flow/execute` endpoint with dual-mode support (legacy + multi-user)
3. Updated `/flow/status` endpoint with thread_id parameter
4. Added thread management endpoints (`/threads`, `/thread/{id}/...`)
5. Initialized LangGraph checkpointer in `main.py`
6. Added async methods to SqliteSaverCompat
7. Created comprehensive tests

## Architecture

### Single-User Mode (Legacy - Backward Compatible)

```
HTTP Request → /flow/execute → OrchestratorAgent (global) → StateTracker (file-based)
                                    ↓
                            Single user state
```

### Multi-User Mode (New - Recommended)

```
HTTP Request (user_id) → /flow/execute → PhysicalDesignGraph (stateless) → LangGraph Checkpointer
                              ↓                    ↓                              ↓
                         thread_id created    thread_id passed        Isolated per thread_id
                              ↓                    ↓                              ↓
                         Unique flow ID      State param stored         SQLite DB
```

## API Changes

### 1. ExecuteRequest - Now Accepts Multi-User Parameters

```python
class ExecuteRequest(BaseModel):
    # Existing
    prompt: str
    debug_mode: str = "interactive"
    enable_ai: bool = False

    # NEW: Multi-user parameters
    user_id: Optional[str] = None
    project: Optional[str] = None
    block: Optional[str] = None
    rtl_tag: Optional[str] = None
    run_id: Optional[str] = None
```

### 2. ExecuteResponse - Now Returns thread_id

```python
class ExecuteResponse(BaseModel):
    thread_id: Optional[str] = None  # NEW
    run_id: str
    status: str
    stages_executed: List[str]
    stages_failed: List[str]
    duration: float
    start_time: str
    end_time: Optional[str]
```

### 3. /flow/execute Endpoint - Dual Mode

```python
@app.post("/flow/execute", response_model=ExecuteResponse)
async def execute_flow(request: ExecuteRequest) -> ExecuteResponse:
    # Checks if multi-user components available
    if physical_design_graph and saver:
        # NEW: Multi-user mode
        thread_id = create_thread_id(request.user_id)
        result = await graph.ainvoke(state, config)
        return ExecuteResponse(thread_id=thread_id, ...)
    else:
        # LEGACY: Single-user mode
        result = await orchestrator.process_prompt(...)
        return ExecuteResponse(thread_id=None, ...)
```

### 4. /flow/status Endpoint - Optional thread_id

```python
@app.get("/flow/status")
async def get_status(thread_id: Optional[str] = None):
    if thread_id and saver:
        # Multi-user: Get checkpoint for specific thread
        checkpoint = await saver.aget(config)
    else:
        # Legacy: Get global state
        state = state_tracker.get_state()
```

### 5. New Thread Management Endpoints

```python
# List all threads (optionally filtered by user_id)
GET /threads?user_id=alice

# Get status of specific thread
GET /flow/status?thread_id=alice_run_20260216_123456

# Get complete history of thread
GET /thread/{thread_id}/history

# Resume execution from checkpoint
POST /thread/{thread_id}/resume

# Delete thread and checkpoint
DELETE /thread/{thread_id}
```

## Database Schema

SQLite database stored at: `.flow_checkpoints.db` (in project root)

```sql
CREATE TABLE checkpoints (
    thread_id TEXT NOT NULL,
    checkpoint_id TEXT NOT NULL,
    checkpoint_ns TEXT,
    parent_id TEXT,
    node TEXT,
    timestamp TEXT,
    data TEXT NOT NULL,
    metadata TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (thread_id, checkpoint_id)
);

CREATE INDEX idx_thread_id
    ON checkpoints(thread_id, created_at DESC);
```

## Thread ID Format

Thread IDs follow this pattern:

```
{user_id}_run_{YYYYMMDD}_{HHMMSS}

Examples:
- alice_run_20260216_123456
- bob_run_20260216_123457
- anonymous_run_20260216_123458
```

Benefits:
- ✅ Unique per user/flow combination
- ✅ Sortable by timestamp
- ✅ Human-readable for debugging
- ✅ Supports querying by user_id prefix

## Config Manager Strategy

The ConfigManager is created per-request from UI parameters:

```python
# In /flow/execute endpoint
config_manager = create_config_manager(
    project_name=request.project,
    user_name=request.user_id,
    block_name=request.block,
    rtl_tag=request.rtl_tag,
    run_tag=request.run_id,
)
```

This allows:
- ✅ Multiple users with different blocks simultaneously
- ✅ No global state coupling
- ✅ Fresh configuration per flow
- ✅ Complete isolation

## FlowState Enhancement

FlowState now includes user/run tracking:

```python
class FlowState(TypedDict):
    # User/run configuration
    user_id: str                    # NEW: For multi-user tracking
    run_id: str
    project: Optional[str]          # NEW: From UI
    block: Optional[str]            # NEW: From UI
    rtl_tag: Optional[str]          # NEW: From UI

    # Existing fields
    prompt: str
    debug_mode: str
    intent: Optional[dict]
    plan: list[str]
    stages_executed: list[str]
    stages_failed: list[str]
    # ... etc
```

## Usage Examples

### 1. Execute Flow for User (Multi-User)

```bash
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "project": "aes_cipher",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "run_id": "run_001",
    "debug_mode": "interactive"
  }'

Response:
{
  "thread_id": "alice_run_20260216_123456",
  "run_id": "run_001",
  "status": "in_progress",
  "stages_executed": [],
  "stages_failed": []
}
```

### 2. Check Status of Specific Thread

```bash
curl http://localhost:8000/flow/status?thread_id=alice_run_20260216_123456

Response:
{
  "thread_id": "alice_run_20260216_123456",
  "run_id": "run_001",
  "status": "in_progress",
  "stages": {
    "syn": "completed",
    "place": "in_progress"
  },
  "progress_percent": 33
}
```

### 3. Resume from Checkpoint

```bash
curl -X POST http://localhost:8000/thread/alice_run_20260216_123456/resume

Response:
{
  "thread_id": "alice_run_20260216_123456",
  "status": "completed",
  "stages_executed": ["syn", "place", "route"]
}
```

### 4. List All Threads for User

```bash
curl http://localhost:8000/threads?user_id=alice

Response:
{
  "threads": [
    "alice_run_20260216_123456",
    "alice_run_20260216_134500",
    "alice_run_20260216_150000"
  ]
}
```

## Server Startup

The server now initializes with multi-user support:

```bash
python src/main.py \
  --project aes_cipher \
  --user default \
  --block aes_top \
  --rtl-tag v1.0 \
  --run-tag initial

# Output:
[CONFIG] Initializing ConfigManager...
[OK] ConfigManager initialized
[STATE] Initializing StateTracker...
[OK] StateTracker initialized
[EXEC] Initializing StageExecutor...
[OK] StageExecutor initialized
[AGENT] Initializing OrchestratorAgent...
[OK] OrchestratorAgent initialized
[LANGGRAPH] Initializing PhysicalDesignGraph...
[OK] PhysicalDesignGraph initialized
[CHECKPOINTER] Initializing LangGraph checkpointer...
[OK] LangGraph checkpointer initialized
  Database: /path/to/project/.flow_checkpoints.db
[OK] FastAPI application created
[OK] Multi-user mode enabled
```

## Backward Compatibility

The implementation maintains 100% backward compatibility:

- ✅ **Legacy endpoints still work**: `/flow/execute` without `user_id` works as before
- ✅ **Single-user mode**: Requests without `user_id` use OrchestratorAgent
- ✅ **Optional thread_id**: Responses include `thread_id: null` in legacy mode
- ✅ **No breaking changes**: Existing clients continue to work

## Testing

Run the comprehensive test suite:

```bash
# Install test dependencies
pip install pytest pytest-asyncio

# Run multi-user tests
pytest tests/test_multi_user.py -v

# Run specific test
pytest tests/test_multi_user.py::TestMultiUserSupport::test_checkpoint_isolation -v
```

Test coverage includes:
- ✅ Thread ID generation and uniqueness
- ✅ Checkpoint isolation per thread
- ✅ Concurrent flow execution
- ✅ Resume from checkpoint
- ✅ Thread deletion
- ✅ Async operations

## Performance Considerations

### SQLite (Current)
- ✅ Good for development and testing
- ✅ Up to ~100 concurrent users
- ✅ No external dependencies
- ⚠️ Single writer at a time (but async-safe)

### PostgreSQL (Future Upgrade)
```python
# When ready to scale to 1000+ users:
saver = get_saver(
    backend="postgres",
    connection_string="postgresql://user:pass@host/db"
)
```

- ✅ Supports concurrent writes
- ✅ Handles 1000+ concurrent users
- ✅ Better for production deployments
- ✅ Connection pooling available

## Monitoring and Debugging

### 1. View Active Threads

```bash
# List all threads
curl http://localhost:8000/threads

# List threads for specific user
curl http://localhost:8000/threads?user_id=alice
```

### 2. Inspect Checkpoint State

```bash
# Get full state of a thread
curl http://localhost:8000/thread/alice_run_20260216_123456/history

# Response includes:
{
  "thread_id": "alice_run_20260216_123456",
  "state": {
    "prompt": "run synthesis",
    "stages_executed": ["syn"],
    "current_stage_index": 1,
    "stage_results": { ... }
  },
  "checkpoint_id": "ckpt_20260216_123500_123456"
}
```

### 3. Debug with CheckpointBrowser

```python
from src.tracker.langgraph_saver import get_saver, CheckpointBrowser

saver = get_saver(".flow_checkpoints.db")
browser = CheckpointBrowser(saver)

# Show thread summary
browser.show_thread_summary("alice_run_20260216_123456")

# Show specific checkpoint
browser.show_checkpoint("alice_run_20260216_123456")
```

## Migration Path for Existing Code

### Before (Single-User)

```python
# Client
curl -X POST http://localhost:8000/flow/execute \
  -d '{"prompt": "run synthesis"}'

# Server started with specific user/block
python src/main.py --user alice --block aes_top --rtl-tag v1
```

### After (Multi-User - Recommended)

```python
# Client sends user_id per request
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "block": "aes_top",
    "rtl_tag": "v1"
  }'

# Server started with default/shared settings
python src/main.py --user default --block default --rtl-tag default
```

## Configuration Options

### Environment Variables

```bash
# Checkpoint database location (default: .flow_checkpoints.db in project root)
export FLOW_CHECKPOINT_DB=/path/to/checkpoints.db

# Debug mode
export FLOW_DEBUG=1

# Async timeout (seconds)
export FLOW_TIMEOUT=300
```

### Code Configuration

```python
# In src/main.py or custom initialization
saver = get_saver(
    backend="sqlite",  # or "postgres"
    db_path="/custom/path/checkpoints.db"
)

# ... or for production
saver = get_saver(
    backend="postgres",
    connection_string="postgresql://user:pass@localhost/flow_db"
)
```

## Troubleshooting

### Issue: "Multi-user mode not enabled"

**Cause**: Checkpointer failed to initialize or PhysicalDesignGraph not loaded

**Solution**:
```bash
# Check database permissions
ls -la .flow_checkpoints.db

# Check logs for initialization errors
python src/main.py ... 2>&1 | grep -i "error\|warn"

# Manually test saver
python -c "from src.tracker.langgraph_saver import get_saver; s = get_saver(); print('OK')"
```

### Issue: "Thread {id} not found"

**Cause**: Thread ID typo or checkpoint not yet saved

**Solution**:
```bash
# List available threads
curl http://localhost:8000/threads

# Check if flow is still running
curl http://localhost:8000/flow/status?thread_id=<id>
```

### Issue: Database locked

**Cause**: Multiple writers accessing SQLite simultaneously

**Solution**:
- ✅ Use PostgreSQL for production (better concurrency)
- ✅ Increase SQLite timeout in configuration
- ✅ Ensure proper connection cleanup

## Future Enhancements

### 1. User Authentication

```python
# Integrate with JWT/OAuth
from fastapi.security import HTTPBearer

security = HTTPBearer()

@app.post("/flow/execute")
async def execute_flow(
    request: ExecuteRequest,
    token: str = Depends(security)
):
    user_id = verify_token(token)  # Extract from JWT
    # ... rest of endpoint
```

### 2. Rate Limiting

```python
from slowapi import Limiter

limiter = Limiter(key_func=get_remote_address)

@app.post("/flow/execute")
@limiter.limit("10/minute")
async def execute_flow(request: ExecuteRequest):
    # Limited to 10 requests/minute per IP
```

### 3. WebSocket Real-Time Updates

```python
@app.websocket("/flow/stream/{thread_id}")
async def stream_flow(websocket: WebSocket, thread_id: str):
    await websocket.accept()
    config = get_config_for_thread(thread_id)

    async for update in graph.astream(None, config):
        await websocket.send_json(update)
```

### 4. Metrics and Monitoring

```python
# Prometheus metrics
from prometheus_client import Counter, Gauge

flows_started = Counter("flows_started_total", "Total flows started")
active_flows = Gauge("active_flows", "Currently active flows")
```

## Summary

The multi-user server implementation provides:

✅ **Complete isolation**: Each user/flow gets unique thread_id
✅ **Persistence**: Automatic checkpointing to SQLite
✅ **Concurrency**: Multiple users can run flows simultaneously
✅ **Backward compatibility**: Legacy single-user mode still works
✅ **Scalability**: Easy upgrade path to PostgreSQL
✅ **Debugging**: Full history and checkpoint inspection
✅ **Production-ready**: Comprehensive error handling and testing

The foundation is in place for scaling from single-user to enterprise multi-user deployments.
