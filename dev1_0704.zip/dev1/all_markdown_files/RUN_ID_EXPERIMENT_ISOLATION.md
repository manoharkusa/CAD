# Run ID / Experiment Isolation - Implementation Guide

## Overview

Each block can have multiple experiments (identified by `run_id` or `expr_name`). The implementation now ensures **complete isolation** between experiments through multi-level thread ID structure.

## Structure

### Thread ID Format

```
{user_id}_{block_name}_{run_id}_{timestamp}
```

Example:
```
alice_aes_top_expr_001_20260216_143022
bob_sha_top_run_001_20260216_143100
charlie_aes_mid_optimization_v2_20260216_143200
```

### Why This Structure

1. **User Isolation**: `{user_id}` - Multiple users can work independently
2. **Block Isolation**: `{block_name}` - Same user can run experiments on different blocks
3. **Experiment Isolation**: `{run_id}` - Same user can run multiple experiments on same block
4. **Timestamp**: Added for uniqueness within same experiment

## Complete Isolation

Each experiment gets **complete isolation**:

```
Alice's Experiments:
├── aes_top (block)
│   ├── expr_001 (experiment) → Thread: alice_aes_top_expr_001_20260216_143022
│   ├── expr_002 (experiment) → Thread: alice_aes_top_expr_002_20260216_143100
│   └── optimization_v1 (experiment) → Thread: alice_aes_top_optimization_v1_20260216_143200
├── sha_top (block)
│   ├── expr_001 (experiment) → Thread: alice_sha_top_expr_001_20260216_144000
│   └── run_001 (experiment) → Thread: alice_sha_top_run_001_20260216_144100
└── aes_mid (block)
    └── synthesis_test (experiment) → Thread: alice_aes_mid_synthesis_test_20260216_144500
```

Each thread has:
- ✅ Separate checkpoints in database
- ✅ Independent execution state
- ✅ No interference with other experiments
- ✅ Full execution history

## API Usage

### Execute Experiment

```bash
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "project": "aes_cipher",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "run_id": "expr_001"
  }'
```

Response:
```json
{
  "thread_id": "alice_aes_top_expr_001_20260216_143022",
  "run_id": "expr_001",
  "status": "in_progress",
  "stages_executed": [],
  "stages_failed": []
}
```

### Check Specific Experiment Status

```bash
# Get status of alice's expr_001 on aes_top
curl "http://localhost:8000/flow/status?thread_id=alice_aes_top_expr_001_20260216_143022"
```

### Resume Experiment

```bash
# Resume alice's expr_001 from checkpoint
curl -X POST "http://localhost:8000/thread/alice_aes_top_expr_001_20260216_143022/resume"
```

### Get Experiment History

```bash
# Get full history of expr_001
curl "http://localhost:8000/thread/alice_aes_top_expr_001_20260216_143022/history"
```

## Programmatic Access

### Create Thread ID for Experiment

```python
from src.tracker.langgraph_saver import create_thread_id_for_experiment, get_config_for_thread

# Create thread ID for specific experiment
thread_id = create_thread_id_for_experiment(
    user_id="alice",
    block_name="aes_top",
    experiment_name="expr_001"
)
# Result: alice_aes_top_expr_001_20260216_143022

# Get config for checkpoint operations
config = get_config_for_thread(thread_id)
```

### Parse Thread ID

```python
from src.tracker.langgraph_saver import parse_thread_id

thread_id = "alice_aes_top_expr_001_20260216_143022"
info = parse_thread_id(thread_id)

# Result:
# {
#   "user_id": "alice",
#   "block": "aes_top",
#   "experiment": "expr_001",
#   "timestamp": "20260216_143022"
# }
```

### Query Experiments

```python
from src.tracker.langgraph_saver import get_user_threads_for_experiment

# Get all threads for alice's expr_001 on aes_top
threads = get_user_threads_for_experiment(
    saver=saver,
    user_id="alice",
    block_name="aes_top",
    experiment_name="expr_001"
)
# Returns: ["alice_aes_top_expr_001_20260216_143022", ...]
```

## Checkpointer Database

### Schema

```sql
CREATE TABLE checkpoints (
    thread_id TEXT NOT NULL,      -- alice_aes_top_expr_001_20260216_143022
    checkpoint_id TEXT NOT NULL,  -- ckpt_20260216_143055_654321
    checkpoint_ns TEXT,
    parent_id TEXT,
    node TEXT,
    timestamp TEXT,
    data TEXT NOT NULL,           -- Full FlowState JSON
    metadata TEXT,
    created_at TEXT,
    PRIMARY KEY (thread_id, checkpoint_id)
);

CREATE INDEX idx_thread_id
    ON checkpoints(thread_id, created_at DESC);
```

### Query Examples

```bash
# Count checkpoints for specific experiment
sqlite3 .flow_checkpoints.db "
  SELECT COUNT(*) FROM checkpoints
  WHERE thread_id LIKE 'alice_aes_top_expr_001_%'
"

# Get latest checkpoint for experiment
sqlite3 .flow_checkpoints.db "
  SELECT checkpoint_id, timestamp FROM checkpoints
  WHERE thread_id LIKE 'alice_aes_top_expr_001_%'
  ORDER BY created_at DESC LIMIT 1
"

# List all experiments by alice
sqlite3 .flow_checkpoints.db "
  SELECT DISTINCT thread_id FROM checkpoints
  WHERE thread_id LIKE 'alice_%'
  ORDER BY thread_id
"

# Compare checkpoints between experiments
sqlite3 .flow_checkpoints.db "
  SELECT
    thread_id,
    COUNT(*) as checkpoint_count,
    MAX(created_at) as latest
  FROM checkpoints
  WHERE thread_id LIKE 'alice_aes_top_%'
  GROUP BY thread_id
"
```

## Experiment Workflow Example

### Scenario: Alice running multiple synthesis experiments on AES block

```bash
# 1. First experiment (baseline)
RESPONSE=$(curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "block": "aes_top",
    "run_id": "baseline"
  }')
THREAD_1=$(echo $RESPONSE | jq -r '.thread_id')
# Result: alice_aes_top_baseline_20260216_143022

# 2. Second experiment (with optimizations)
RESPONSE=$(curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis with optimizations",
    "user_id": "alice",
    "block": "aes_top",
    "run_id": "opt_v1"
  }')
THREAD_2=$(echo $RESPONSE | jq -r '.thread_id')
# Result: alice_aes_top_opt_v1_20260216_143100

# 3. Both experiments run independently
curl "http://localhost:8000/flow/status?thread_id=$THREAD_1"
curl "http://localhost:8000/flow/status?thread_id=$THREAD_2"

# 4. Compare results
curl "http://localhost:8000/thread/$THREAD_1/history" | jq '.state.stage_results'
curl "http://localhost:8000/thread/$THREAD_2/history" | jq '.state.stage_results'

# 5. Resume specific experiment if needed
curl -X POST "http://localhost:8000/thread/$THREAD_1/resume"

# 6. Clean up old experiments
curl -X DELETE "http://localhost:8000/thread/$THREAD_1"
```

## Naming Conventions

### Recommended Experiment Names

```
expr_001, expr_002, ...          # Sequential experiments
run_001, run_002, ...            # Simulation runs
baseline, opt_v1, opt_v2         # Optimization attempts
synthesis_v1, synthesis_v2       # Version tracking
cmos_40nm, cmos_28nm             # Technology variants
timing_opt, area_opt             # Optimization goals
pr_baseline, pr_optimized        # Pre-route variations
```

### Examples

```python
# Sequential naming
run_id = f"expr_{experiment_number:03d}"  # expr_001, expr_002, ...

# Time-based naming
import datetime
run_id = datetime.datetime.now().strftime("run_%Y%m%d_%H%M%S")  # run_20260216_143022

# Goal-based naming
run_id = f"opt_{goal}_{version}"  # opt_timing_v1, opt_area_v2

# Technology-based naming
run_id = f"pdk_{tech_node}_{variant}"  # pdk_40nm_a, pdk_28nm_b
```

## Multi-Level Isolation Example

### Same User, Different Experiments

```
Alice on aes_top:
  - expr_001 [syn, place, route] ✓ completed
  - expr_002 [syn, place] ✗ failed at route
  - expr_003 [syn] ⏳ in progress

Each has separate:
  - Checkpoints (stored separately in DB)
  - Execution history
  - Stage results
  - Error logs
  - Resumed states
```

### Database Representation

```sql
-- Alice's experiments on aes_top
SELECT thread_id, COUNT(*) as checkpoints, MAX(timestamp) as latest
FROM checkpoints
WHERE thread_id LIKE 'alice_aes_top_%'
GROUP BY thread_id;

-- Results:
-- alice_aes_top_expr_001_20260216_143022 | 15 | 2026-02-16T14:35:42
-- alice_aes_top_expr_002_20260216_143100 | 8  | 2026-02-16T14:32:15
-- alice_aes_top_expr_003_20260216_143200 | 3  | 2026-02-16T14:33:50
```

## Checkpoint Management

### List All Experiments for User

```python
from src.tracker.langgraph_saver import parse_thread_id

saver = get_saver()
all_threads = saver.get_all_threads()

# Group by user
user_experiments = {}
for thread_id in all_threads:
    info = parse_thread_id(thread_id)
    user_id = info["user_id"]
    if user_id not in user_experiments:
        user_experiments[user_id] = []
    user_experiments[user_id].append(info)

# List alice's experiments
print("Alice's experiments:")
for exp in user_experiments.get("alice", []):
    print(f"  {exp['block']} / {exp['experiment']} - {exp['timestamp']}")
```

### Clean Old Experiments

```bash
# Delete specific experiment
curl -X DELETE "http://localhost:8000/thread/alice_aes_top_expr_001_20260216_143022"

# Or programmatically
from src.tracker.langgraph_saver import create_thread_id_for_experiment, get_config_for_thread

thread_id = create_thread_id_for_experiment("alice", "aes_top", "expr_001")
config = get_config_for_thread(thread_id)
saver.adelete_thread(config)
```

## Testing

### Test Experiment Isolation

```bash
pytest tests/test_multi_user.py::TestExperimentIsolation -v
```

Tests included:
- ✅ Create experiment thread ID
- ✅ Experiment thread IDs unique
- ✅ Parse experiment thread ID
- ✅ Same user, different experiments isolated
- ✅ Same user, different blocks isolated
- ✅ Query experiments by user/block
- ✅ Various naming conventions

### Run Specific Test

```bash
# Test same user with different experiments are isolated
pytest tests/test_multi_user.py::TestExperimentIsolation::test_same_user_different_experiments_isolated -v

# Test querying experiments
pytest tests/test_multi_user.py::TestExperimentIsolation::test_get_user_threads_for_experiment -v
```

## Migration Guide

### From Single-User to Multi-User with Experiments

Before:
```bash
# Server bound to specific user/block
python src/main.py --user alice --block aes_top --rtl-tag v1

# API request
curl -X POST http://localhost:8000/flow/execute \
  -d '{"prompt": "run synthesis"}'
```

After:
```bash
# Server started with generic config
python src/main.py --user default --block default --rtl-tag default

# API request with experiment parameters
curl -X POST http://localhost:8000/flow/execute \
  -d '{
    "prompt": "run synthesis",
    "user_id": "alice",
    "block": "aes_top",
    "run_id": "expr_001"
  }'
```

## Performance Considerations

### Checkpoint Lookup Speed

Thread ID format enables fast queries:

```sql
-- Fast: Direct thread_id lookup (indexed)
SELECT * FROM checkpoints
WHERE thread_id = 'alice_aes_top_expr_001_20260216_143022'  -- <1ms

-- Medium: Prefix search for experiment
SELECT DISTINCT thread_id FROM checkpoints
WHERE thread_id LIKE 'alice_aes_top_expr_001_%'  -- ~10ms

-- Slower: Wildcard search for user
SELECT DISTINCT thread_id FROM checkpoints
WHERE thread_id LIKE 'alice_%'  -- ~100ms
```

### Scaling Recommendations

- **Up to 100 experiments per user**: SQLite ✓
- **100+ experiments**: Consider indexing strategy
- **1000+ experiments**: PostgreSQL recommended

## Summary

✅ **Complete Experiment Isolation**:
- Each experiment has unique thread_id: `{user_id}_{block}_{run_id}_{timestamp}`
- Checkpoints stored per thread in SQLite
- Queries support prefix search for experiments
- Multi-level isolation (user → block → experiment)

✅ **Easy Access**:
- Create: `create_thread_id_for_experiment()`
- Parse: `parse_thread_id()`
- Query: `get_user_threads_for_experiment()`
- API endpoints for resume, status, history

✅ **Database-Ready**:
- Indexed for fast lookups
- Supports naming conventions
- Clean separation of experiments
- Full history available per experiment

The implementation is **production-ready** for managing multiple experiments across multiple users on multiple blocks.
