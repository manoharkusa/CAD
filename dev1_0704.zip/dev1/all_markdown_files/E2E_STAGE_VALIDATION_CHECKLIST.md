# Dev1 End-to-End Stage Validation Checklist

Use this checklist to validate behavior at each request/stage transition in real end-to-end testing.

## A) Stack and configuration readiness

### A1. Bring up services
```powershell
docker compose -f dev1/docker-compose.dev1.yml up -d --build
docker compose -f dev1/docker-compose.dev1.yml ps
```

Verify:
- `dev1_api`, `dev1_postgres`, `dev1_redis` are `healthy`.
- `dev1_worker` is `Up` (separate queue consumer for LangGraph execution).
- API docs reachable at `http://127.0.0.1:8000/docs`.

### A2. Validate runtime env inside API container
```powershell
docker exec dev1_api env | Select-String "USE_JOB_LIFECYCLE_API|POSTGRES_HOST|POSTGRES_URI|REDIS_HOST|REDIS_URL|PROJ_ROOT|ENV_SCRIPTS"
```

Verify:
- lifecycle flags are `true`
- `POSTGRES_HOST=postgres`
- `REDIS_HOST=redis`
- `POSTGRES_URI` points to `@postgres:5432`

---

## B) Request lifecycle validation (`/jobs` APIs)

### B1. Create job
```powershell
$payload = @{ session_id='c52b9040-1d9b-4788-bd19-5e4c317748bd'; prompt='run syn'; user_name='admin1'; project='saraswathi'; block='block2'; rtl_tag='demo_rtl'; experiment_name='run2'; max_retries=3; max_iterations=5 } | ConvertTo-Json
$job = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/jobs' -Method Post -Body $payload -ContentType 'application/json'
$jobId = $job.job_id
$job
```

Verify API response:
- HTTP `202`
- `status=PENDING`
- `phase=QUEUED`
- non-empty `job_id`

### B2. Verify Postgres persistence
```powershell
docker exec dev1_postgres psql -U postgres -d synthesis_agent -c "select job_id,status,phase,current_tool,updated_at from jobs where job_id = '$jobId';"
```

Verify:
- row exists for `job_id`
- initial or updated lifecycle state is present

### B3. Verify Redis state/queue
```powershell
docker exec dev1_redis redis-cli HGETALL "job:$jobId:state"
docker exec dev1_redis redis-cli LLEN jobs:queue
```

Verify state hash includes:
- `status`, `phase`, `script_path`, `max_retries`, `max_iterations`

### B4. Verify status endpoint
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8000/jobs/$jobId/job_status" -Method Get | ConvertTo-Json -Depth 5
```

Verify:
- status/phase match Redis/Postgres state

---

## C) HITL and abort validation

### C1. Submit HITL input
```powershell
$hitl = @{ response='approved'; additional_context='e2e-check' } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/jobs/$jobId/human-input" -Method Post -Body $hitl -ContentType 'application/json' | ConvertTo-Json -Depth 5
```

Verify:
- endpoint returns current status/phase
- Postgres has interaction row
- Redis list has payload

```powershell
docker exec dev1_redis redis-cli LRANGE "job:$jobId:hitl_response" 0 -1
```

### C2. Abort request
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8000/jobs/$jobId/abort" -Method Post | ConvertTo-Json -Depth 5
Invoke-RestMethod -Uri "http://127.0.0.1:8000/jobs/$jobId/job_status" -Method Get | ConvertTo-Json -Depth 5
```

Verify:
- status transitions to `CANCELLED`
- phase transitions to `ABORT_REQUESTED`

Redis checks:
```powershell
docker exec dev1_redis redis-cli GET "job:$jobId:abort"
docker exec dev1_redis redis-cli HGETALL "job:$jobId:state"
```

---

## D) Full-state and eventing validation

### D1. Full state endpoint
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8000/job_state?job_id=$jobId" -Method Get | ConvertTo-Json -Depth 6
```

Verify:
- includes merged state plus latest `hitl_response`

### D2. WebSocket event stream
Connect to:
- `ws://127.0.0.1:8000/ws/jobs/{job_id}`

Verify events appear for:
- queued
- hitl_response
- abort_requested
- stage events if graph-driven execution path is triggered

---

## E) Graph-state lifecycle validation (`/flow/execute` path)

This validates LangGraph node-to-node progression and lifecycle bridge events.

Expected progression:
1. `parse_intent`
2. `create_plan` (emits `started`)
3. `execute_stage` loop (emits `stage_started`, `stage_completed` or `stage_failed`)
4. `debug_stage` (on failures)
5. `handle_result` (emits `completed` or `failed`)

Verify via:
- API logs: `docker compose -f dev1/docker-compose.dev1.yml logs api --tail 300`
- Worker logs (recommended for node-by-node execution): `docker compose -f dev1/docker-compose.dev1.yml logs worker --tail 300`
- Redis state hash changes over time (`status`, `phase`, `iteration`, `current_tool`)
- Postgres `jobs` row updates (`status`, `phase`, `current_tool`, `updated_at`, `completed_at`)

---

## F) Automated regression gates

Run after E2E lifecycle checks:

```powershell
./.venv/Scripts/python.exe dev1/tests/test_syntax.py
./.venv/Scripts/python.exe -m pytest dev1/tests/test_multi_user.py -q
./.venv/Scripts/python.exe dev1/tests/test_issue_tracking.py
```

Pass criteria:
- syntax script: all targeted files compile
- multi-user suite: all tests pass
- issue-tracking script: all tests pass (non-blocking lock warnings can appear in script output)

---

## G) Failure probes (recommended)

1. Disable Redis flag (`USE_REDIS_JOB_STATE=false`) and re-run `/jobs` flow.
   - Verify fallback behavior via Postgres status endpoint still works.
2. Disable Postgres flag (`USE_POSTGRES_JOB_REPO=false`) and re-run `/jobs` flow.
   - Verify Redis-only lifecycle still works.
3. Temporarily point Postgres/Redis host to invalid value.
   - Verify startup warns clearly and health/status behavior is explicit.

---

## H) Cleanup

```powershell
docker compose -f dev1/docker-compose.dev1.yml down
# or include -v to reset data
docker compose -f dev1/docker-compose.dev1.yml down -v
```
