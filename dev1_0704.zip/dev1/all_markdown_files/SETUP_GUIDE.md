# Setup Guide - Environment Sourcing & Flow Configuration

## ✅ Implementation Complete

All changes have been successfully implemented to support:
1. **Environment sourcing** from sourceproj.env before running tools
2. **Flow configuration** from flow_config.yaml for stage→tool/script mappings

---

## Configuration Files Required

### 1. sourceproj.env
**Location:** `{run_dir}/sourceproj.env`

**Example:**
```bash
PROJECT_NAME="semicon_19-02"
USER_NAME="bharath"
BLOCK_NAME="aes_cipher_top"
RTL_TAG="bronze_v2"
RUN_TAG="run2"

# CRITICAL: Central tool scripts location
ENV_SCRIPTS="/proj5/projects/semicon_19-02/tech/tools"

# Paths for TCL scripts
TECH_LIB="/proj5/projects/semicon_19-02/tech/lib"
REF_LIBS="/proj5/projects/semicon_19-02/tech/cells"

# Design files
RTL_DIR="/proj5/projects/semicon_19-02/rtl"
RTL_FILES="${RTL_DIR}/*.v"
TOP_MODULE="aes_cipher_top"
```

**Purpose:** All environment variables sourced using bash before running tools. TCL scripts can access via `$::env(VAR_NAME)`

---

### 2. flow_config.yaml
**Location:** `{run_dir}/flow_config.yaml`

**Example:**
```yaml
stages:
  syn:
    tool: genus
    script: syn.tcl
    timeout: 3600
    description: Synthesis using Genus

  place:
    tool: innovus
    script: place.tcl
    timeout: 3600
    description: Placement using Innovus

  route:
    tool: innovus
    script: route.tcl
    timeout: 3600
    description: Routing using Innovus

stage_groups:
  pnr:
    - place
    - route
  flow:
    - syn
    - place
    - route
```

**Purpose:** Maps stages to tool/script files in ENV_SCRIPTS/{tool}/{script}.tcl

---

## Execution Flow

```
sourceproj.env sourced
    ↓ (all env vars loaded)
ConfigManager initialized
    ↓
flow_config.yaml loaded
    ↓
_execute_stage_node() called
    ↓
get_stage_tool_script(stage_name)
    ↓ (returns tool, script from YAML)
StageExecutor.execute_stage()
    ↓
Command: source {ENV_FILE} && {tool} -files {script} -abort_on_error | tee {log}
    ↓ (in work directory, with bash, all env vars available)
TCL script executes
    ↓ (can access $::env(VAR_NAME))
Output logged and captured
```

---

## Directory Structure

```
/proj5/projects/semicon_19-02/
├── tech/tools/                          ← ENV_SCRIPTS (central, shared)
│   ├── genus/
│   │   └── syn.tcl
│   ├── innovus/
│   │   ├── place.tcl
│   │   └── route.tcl
│   └── ...
│
└── pd/users/bharath/aes_cipher_top/bronze_v2/run2/  ← run_dir
    ├── sourceproj.env                   ← Sourced before tools
    ├── flow_config.yaml                 ← Stage mappings
    ├── syn/
    │   ├── work/                        ← Execution here
    │   └── logs/
    ├── place/
    │   ├── work/
    │   └── logs/
    └── route/
        ├── work/
        └── logs/
```

---

## TCL Script Example

```tcl
#!/usr/bin/tclsh

puts "=========================================="
puts "Synthesis - Genus"
puts "=========================================="

# Access environment variables (sourced automatically)
set project $::env(PROJECT_NAME)
set user $::env(USER_NAME)
set rtl_files $::env(RTL_FILES)
set tech_lib $::env(TECH_LIB)
set top_module $::env(TOP_MODULE)

puts "Project: $project"
puts "User: $user"
puts "RTL Files: $rtl_files"
puts "Tech Lib: $tech_lib"
puts "Top Module: $top_module"

# Use variables in tool commands
read_hdl -v2001 $rtl_files
set_top $top_module
read_libs $tech_lib

# Compile
syn_gen -effort high

# Generate reports
report_qor > ../reports/qor.rpt

puts "=========================================="
puts "Done!"
puts "=========================================="
```

---

## Server Execution

```bash
python3 src/main.py \
  --project semicon_19-02 \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v2 \
  --run-tag run2 \
  --host 0.0.0.0 \
  --port 8080
```

---

## API Request Example

```bash
curl -X POST http://localhost:8080/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis and place",
    "user_id": "bharath",
    "project": "semicon_19-02",
    "block": "aes_cipher_top",
    "rtl_tag": "bronze_v2",
    "experiment_name": "run2"
  }'
```

---

## Expected Output

```
[CONFIG] Sourcing environment file: /.../run2/sourceproj.env
[CONFIG] ✓ Sourced 30 environment variables
[CONFIG]   ENV_SCRIPTS: /proj5/projects/semicon_19-02/tech/tools
[CONFIG] Loading flow configuration: /.../run2/flow_config.yaml
[CONFIG] ✓ Loaded 13 stages from flow_config.yaml

[STAGE] Executing: syn
  Description: Synthesis using Genus
  Tool: genus
  Script: /proj5/projects/semicon_19-02/tech/tools/genus/syn.tcl
  Env file: /.../run2/sourceproj.env
  Command: source /.../run2/sourceproj.env && genus -files /proj5/.../genus/syn.tcl -abort_on_error | tee /.../logs/syn.log

[EXEC] Running syn...
  Sourcing environment...

[OK] syn completed successfully
  Log: /.../logs/syn.log
```

---

## Key Points

✅ **Environment sourcing** happens before EVERY tool execution
✅ **All TCL scripts** have access to all sourced environment variables
✅ **Stage configuration** is flexible and per-experiment
✅ **Tool scripts** are centralized in ENV_SCRIPTS
✅ **Bash** ensures proper shell behavior (variable expansion, etc.)
✅ **Logging** captures both stdout and stderr

---

## Templates Available

- `sourceproj.env.template` - Copy and edit for your setup
- `flow_config.yaml.template` - Copy and edit for your stages

---

## Files Modified

1. `src/config/config_manager.py` - Source env, load YAML
2. `src/executor/stage_executor.py` - Source env before tool
3. `src/agents/physical_design_graph.py` - Use YAML-based stage mapping
