# API Integration Guide - Physical Design Flow

## Overview

This guide explains how to integrate the Physical Design Flow API with your web UI dashboard.

## Architecture

```
Web UI (Remote Server)
    ↓ (HTTP/WebSocket)
REST API Server (FastAPI)
    ↓
OrchestratorAgent
    ├─ Intent Parsing (Claude AI)
    ├─ Execution Planning
    └─ Stage Orchestration
        ├─ StageExecutor
        │   ├─ ConfigManager
        │   └─ Tool Execution
        └─ StateTracker
            ├─ JSON Persistence
            └─ History Management
```

## Starting the API Server

### Basic Usage

```bash
cd /proj1/pd/users/testcase/Bharath/proj/new_py_flow

python src/main.py \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001
```

### Server Configuration

- Default host: `127.0.0.1` (localhost only)
- Default port: `8000`

For remote access, bind to all interfaces:

```bash
python src/main.py \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001 \
  --host 0.0.0.0 \
  --port 8000
```

### Development Mode

With auto-reload:

```bash
python src/main.py \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001 \
  --reload
```

### Multiple Workers

```bash
python src/main.py \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001 \
  --workers 4
```

## API Documentation

Once the server is running, access documentation at:

- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`
- **OpenAPI JSON**: `http://localhost:8000/openapi.json`

## REST Endpoints

### Health & Info

```
GET /health
Response: {"status": "healthy", "service": "Physical Design Flow API"}

GET /info
Response: {
  "service": "Physical Design Flow API",
  "version": "1.0.0",
  "project": "aes_cipher",
  "block": "aes_cipher_top"
}
```

### Flow Execution

#### Execute Flow (Synchronous)

```
POST /flow/execute
Request:
{
  "prompt": "run synthesis",
  "debug_mode": "interactive",  # auto, interactive, human-loop
  "enable_ai": false
}

Response:
{
  "run_id": "aes_cipher_top_bronze_v1_run_001_20260212_143022",
  "status": "completed",
  "stages_executed": ["syn"],
  "stages_failed": [],
  "duration": 1234.5,
  "start_time": "2026-02-12T14:30:22.000000",
  "end_time": "2026-02-12T14:51:56.500000"
}
```

#### Execute Flow (Asynchronous)

```
POST /flow/execute-async
Request: (same as above)

Response:
{
  "run_id": "aes_cipher_top_bronze_v1_run_001_20260212_143022",
  "status": "started",
  "message": "Flow execution started in background"
}
```

### Status Monitoring

#### Get Current Status

```
GET /flow/status

Response:
{
  "run_id": "aes_cipher_top_bronze_v1_run_001_20260212_143022",
  "status": "in_progress",
  "current_stage": "place",
  "stages": {
    "syn": "completed",
    "init_design": "completed",
    "floorplan": "completed",
    "place": "in_progress",
    "cts": "pending"
  },
  "progress_percent": 40,
  "start_time": "2026-02-12T14:30:22.000000",
  "end_time": null,
  "duration": 0.0
}
```

#### Get Available Stages

```
GET /flow/stages

Response: [
  {
    "name": "syn",
    "tool": "genus",
    "description": "Synthesis with Genus",
    "depends_on": []
  },
  {
    "name": "init_design",
    "tool": "innovus",
    "description": "Design initialization",
    "depends_on": ["syn"]
  },
  ...
]
```

#### Get Execution History

```
GET /flow/history

Response: [
  {
    "run_id": "aes_cipher_top_bronze_v1_run_001_20260212_140000",
    "status": "completed",
    "duration": 2500.5,
    "start_time": "2026-02-12T14:00:00.000000",
    "end_time": "2026-02-12T14:41:40.500000",
    "stages_count": 14
  },
  {
    "run_id": "aes_cipher_top_bronze_v1_run_001_20260212_143022",
    "status": "in_progress",
    "duration": 0.0,
    "start_time": "2026-02-12T14:30:22.000000",
    "end_time": null,
    "stages_count": 3
  }
]
```

### Logs Access

#### Get Stage Log

```
GET /flow/logs/syn

Response:
{
  "stage_name": "syn",
  "log_content": "[10:30:22] Starting synthesis...\n[10:45:56] Synthesis completed.",
  "size_bytes": 2048
}
```

#### List All Stage Logs

```
GET /flow/logs

Response:
{
  "syn": "/path/to/syn/logs/syn_20260212_143022.log",
  "init_design": "/path/to/init_design/logs/init_design_20260212_143100.log",
  "floorplan": "/path/to/floorplan/logs/floorplan_20260212_143200.log"
}
```

### Flow Control

```
POST /flow/pause
Response: {"status": "paused"}

POST /flow/resume
Response: {"status": "resumed"}

POST /flow/abort
Response: {"status": "aborted"}
```

## WebSocket Connection

### Real-time Status Updates

Connect to the WebSocket endpoint for live status updates:

```javascript
// JavaScript Example
const ws = new WebSocket('ws://localhost:8000/flow/ws');

ws.onopen = () => {
    console.log('Connected to status stream');
};

ws.onmessage = (event) => {
    const update = JSON.parse(event.data);
    console.log('Status Update:', update);
    // {
    //   "type": "status_update",
    //   "run_id": "...",
    //   "status": "in_progress",
    //   "current_stage": "place",
    //   "progress": 40,
    //   "stages": { ... }
    // }
};

ws.onerror = (error) => {
    console.error('WebSocket error:', error);
};

ws.onclose = () => {
    console.log('Disconnected from status stream');
};
```

### Update Frequency

Status updates are sent every 1 second during execution.

## Natural Language Prompts

The API accepts natural language prompts that are parsed by Claude AI:

### Execution Commands

```
"run synthesis"
"run place and route"
"run complete flow"
"run all PnR stages"
"run signoff checks"
"execute from synthesis to chip finish"
```

### Rerun Commands

```
"rerun synthesis"
"rerun place and route"
"rerun everything"
"redo the flow"
```

### Restart Commands

```
"restart from place"
"restart from floorplan"
"restart routing"
"clean and restart from init"
```

### Status Commands

```
"check status"
"what's the current status"
"show progress"
"list completed stages"
```

### Clean Commands

```
"clean all outputs"
"clean synthesis"
"remove everything"
"reset the flow"
```

## Web UI Integration Examples

### React Example

```jsx
import React, { useState, useEffect } from 'react';

function FlowDashboard() {
  const [status, setStatus] = useState(null);
  const [ws, setWs] = useState(null);

  useEffect(() => {
    // Connect to WebSocket
    const websocket = new WebSocket('ws://api-server:8000/flow/ws');

    websocket.onmessage = (event) => {
      const update = JSON.parse(event.data);
      setStatus(update);
    };

    setWs(websocket);
    return () => websocket.close();
  }, []);

  const executePrompt = async (prompt) => {
    const response = await fetch('http://api-server:8000/flow/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: prompt,
        debug_mode: 'interactive',
        enable_ai: false
      })
    });
    return await response.json();
  };

  return (
    <div>
      <h1>Physical Design Flow Dashboard</h1>
      {status && (
        <div>
          <p>Status: {status.status}</p>
          <p>Progress: {status.progress}%</p>
          <p>Current Stage: {status.current_stage}</p>
          <pre>{JSON.stringify(status.stages, null, 2)}</pre>
        </div>
      )}
      <button onClick={() => executePrompt('run synthesis')}>
        Run Synthesis
      </button>
    </div>
  );
}

export default FlowDashboard;
```

### Python Example

```python
import asyncio
import aiohttp

async def run_flow(prompt):
    async with aiohttp.ClientSession() as session:
        # Execute flow
        async with session.post(
            'http://localhost:8000/flow/execute',
            json={
                'prompt': prompt,
                'debug_mode': 'interactive',
                'enable_ai': False
            }
        ) as resp:
            result = await resp.json()
            print(f"Run ID: {result['run_id']}")
            print(f"Status: {result['status']}")

async def monitor_status():
    async with aiohttp.ClientSession() as session:
        # Get status
        async with session.get(
            'http://localhost:8000/flow/status'
        ) as resp:
            status = await resp.json()
            print(f"Progress: {status['progress_percent']}%")
            print(f"Stages: {status['stages']}")

# Run examples
asyncio.run(run_flow('run synthesis'))
asyncio.run(monitor_status())
```

### cURL Examples

```bash
# Execute flow
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis",
    "debug_mode": "interactive",
    "enable_ai": false
  }'

# Get status
curl http://localhost:8000/flow/status

# Get history
curl http://localhost:8000/flow/history

# Get stage log
curl http://localhost:8000/flow/logs/syn

# List all logs
curl http://localhost:8000/flow/logs
```

## CORS Configuration

The API includes CORS middleware configured for web UI integration. By default, it allows:

- **Origins**: `*` (all origins)
- **Methods**: `GET`, `POST`, `PUT`, `DELETE`, `OPTIONS`
- **Headers**: Any header
- **Credentials**: Enabled

For production, update the CORS configuration in `src/api/flow_api.py`:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://dashboard.company.com"],  # Specific domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## Error Handling

### HTTP Status Codes

- `200 OK` - Successful request
- `400 Bad Request` - Invalid request parameters
- `404 Not Found` - Resource not found (e.g., stage log doesn't exist)
- `500 Internal Server Error` - Server error (check logs)

### Error Response Format

```json
{
  "detail": "Description of the error"
}
```

## State Persistence

The API automatically persists execution state to:

- **Current State**: `.flow_state.json` (in run directory)
- **History**: `.history/execution_YYYYMMDD_HHMMSS.json` (timestamped records)

This allows:
- State recovery on server restart
- Execution history queries
- Flow resumption from previous runs

## Performance Considerations

### Request Timeouts

- Synchronous execution: May take several hours for long flows
- Asynchronous execution: Returns immediately, use WebSocket for progress

### Concurrent Executions

The API supports only one execution at a time per run directory. Concurrent requests to the same run will queue or error.

### Resource Usage

- Memory: ~200MB base + execution overhead
- CPU: Variable based on stage complexity
- Disk: Depends on design size and log verbosity

## Deployment

### Development

```bash
python src/main.py \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001 \
  --host 127.0.0.1 \
  --port 8000
```

### Production

```bash
python src/main.py \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001 \
  --host 0.0.0.0 \
  --port 8000 \
  --workers 4
```

Or using Gunicorn:

```bash
gunicorn \
  -w 4 \
  -k uvicorn.workers.UvicornWorker \
  -b 0.0.0.0:8000 \
  "src.main:create_app(
    project_name='aes_cipher',
    user_name='bharath',
    block_name='aes_cipher_top',
    rtl_tag='bronze_v1',
    run_tag='run_001'
  )"
```

### Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY src/ src/

CMD ["python", "src/main.py", \
  "--project", "aes_cipher", \
  "--user", "bharath", \
  "--block", "aes_cipher_top", \
  "--rtl-tag", "bronze_v1", \
  "--run-tag", "run_001", \
  "--host", "0.0.0.0", \
  "--port", "8000"]
```

## Troubleshooting

### API Server Won't Start

Check:
1. Port is not already in use: `lsof -i :8000`
2. Required Python packages installed: `pip install -r requirements.txt`
3. Directory permissions: `/proj1/pd/users/testcase/Bharath/proj/new_py_flow` is readable

### WebSocket Connection Fails

Check:
1. Server is running: `curl http://localhost:8000/health`
2. CORS settings allow your domain
3. WebSocket port matches API port
4. No firewall blocking WebSocket connections

### Execution Fails

Check:
1. Stage logs in `/flow/logs/{stage_name}` endpoint
2. Console output for error messages
3. Execution history in `/flow/history` endpoint
4. State file: `.flow_state.json` in run directory

## Next Steps

1. **DebugAgent Integration** - Add AI-powered error analysis and auto-fix
2. **Authentication** - Secure the API with JWT tokens
3. **Monitoring** - Add Prometheus metrics and Grafana dashboards
4. **Notifications** - Email/Slack alerts on execution completion
5. **Advanced Scheduling** - Queue management for multiple runs
6. **Flow Analytics** - Historical performance tracking and optimization
