# Quick Start Guide - Updated Architecture

## What's New

- **UnifiedPhysicalDesignAgent**: Single agent with 8 contexts (EXECUTE_*, DEBUG_*, ANALYZE_*)
- **Claude Agent SDK**: Intelligent tool execution with automatic retry logic
- **LangGraph**: Multi-user orchestration with automatic checkpointing
- **Skills System**: Modular knowledge in .md files (easy to customize)
- **Token Optimized**: Selective skill loading (only load what you need)

## Installation

### 1. Install Dependencies

```bash
# Claude Agent SDK (for intelligent tool execution)
pip install claude-agent-sdk

# Already installed
pip list | grep -E "langgraph|anthropic|fastapi"
```

### 2. Verify Installation

```bash
# Check Claude Agent SDK
python3.10 -c "from claude_agent_sdk import query; print('[OK] Claude Agent SDK installed')"

# Check all imports
python3.10 test_syntax.py
```

## Quick Test

### 1. Test Core Components (No config needed)

```bash
python3.10 test_core_logic.py
```

**Expected Output**:
```
[1/5] Testing LangGraph import...
[OK] LangGraph StateGraph imported

[2/5] Testing FlowState model...
[OK] FlowState created successfully

[3/5] Testing DebugAgent error analysis...
[OK] ErrorAnalysis created

[4/5] Testing FixSuggestion model...
[OK] FixSuggestion created

[5/5] Testing PhysicalDesignGraph structure...
[OK] PhysicalDesignGraph imported
[OK] STAGES defined: 13 stages

SUCCESS: Core Architecture Verified!
```

### 2. Start the Server

```bash
# Set your Anthropic API key (optional - system has fallback)
export ANTHROPIC_API_KEY="sk-ant-your-key"

# Start server
python3.10 -m src.main \
  --project test \
  --user bharath \
  --block test_block \
  --rtl-tag v1 \
  --run-tag run_001
```

**Expected Output**:
```
[CONFIG] Initializing ConfigManager...
[OK] ConfigManager initialized

[STATE] Initializing StateTracker...
[OK] StateTracker initialized

[EXEC] Initializing StageExecutor...
[OK] StageExecutor initialized

[AGENT] Initializing OrchestratorAgent...
[OK] OrchestratorAgent initialized

[DEBUG] Initializing DebugAgent...
[OK] DebugAgent initialized

[LANGGRAPH] Initializing PhysicalDesignGraph...
[OK] PhysicalDesignGraph initialized
[OK] Unified Agent with 8 contexts ready

[START] Creating FastAPI application...
[OK] FastAPI application created

[SERVER] Starting Physical Design Flow API Server
======================================================================
Host: 127.0.0.1
Port: 8000
[DOCS] API Documentation:
  Swagger UI: http://127.0.0.1:8000/docs
======================================================================
```

### 3. Execute a Flow (in another terminal)

```bash
# Run synthesis
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis",
    "debug_mode": "auto"
  }'
```

**Response**:
```json
{
  "run_id": "run_...",
  "status": "success",
  "stages_executed": ["_setup", "syn"],
  "stages_failed": [],
  "duration": 120.5,
  "start_time": "2024-01-15T10:30:45",
  "end_time": "2024-01-15T10:32:45"
}
```

## Architecture at a Glance

```
API Request
    ↓
LangGraph (Multi-user orchestration)
    ├─ parse_intent (NLP)
    ├─ create_plan (Planning)
    ├─ execute_stage ←→ UnifiedPhysicalDesignAgent
    ├─ debug_stage ←→ UnifiedPhysicalDesignAgent (DEBUG mode)
    └─ handle_result
    ↓
Claude Agent SDK (Iterative tool loop)
    ├─ System Prompt (base + skills + context)
    ├─ User Prompt (task description)
    ├─ Tools: Read, Edit, Glob, Bash
    └─ Skills: Loaded from skills/*.md
    ↓
Tool Execution (Read files, Edit configs, Run bash commands)
    ↓
Project Files Updated
```

## Execution Contexts

The UnifiedPhysicalDesignAgent has 8 contexts with different behaviors:

### Execution Contexts (Run stages)
- **EXECUTE_SYNTHESIS**: Run synthesis, analyze logs, auto-fix errors
- **EXECUTE_PNR**: Run place & route, fix timing/congestion
- **EXECUTE_STA**: Run static timing analysis

### Debug Contexts (Fix errors)
- **DEBUG_TIMING**: Fix timing violations with constraint modifications
- **DEBUG_LINKING**: Fix linking errors by updating filelist
- **DEBUG_CONVERGENCE**: Fix convergence by adjusting tool settings
- **DEBUG_DRV**: Fix design rule violations with constraints

### Analysis Context
- **ANALYZE_ERROR**: Analyze error and suggest fixes (no modifications)

## Skills System

Skills are stored in `skills/*.md` files:

```
skills/
├── synthesis_skills.md      # Analyze logs, fix timing, optimize settings
├── pnr_skills.md            # Analyze timing/congestion, fix placement
├── debug_skills.md          # Root cause analysis, retry decisions
└── knowledge_skills.md      # Tool commands, best practices
```

**How to Customize Skills**:

1. Edit `skills/*.md` files
2. Add new sections with skill definitions
3. Update `skill_files_map` in `unified_agent.py` if creating new files
4. Restart server
5. Skills are cached automatically

**Example**: Add timing optimization skill to `synthesis_skills.md`:

```markdown
## optimize_timing_constraints

**Purpose**: Apply aggressive timing optimizations

**Actions**:
1. Review clock tree delays
2. Adjust setup margins
3. Optimize critical paths
4. Re-run synthesis

**Best Practices**:
- Be conservative with margins
- Verify with STA after changes
```

## Common Tasks

### 1. Run Full Flow

```bash
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "run complete flow", "debug_mode": "auto"}'
```

### 2. Debug a Stage

```bash
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "debug synthesis",
    "debug_mode": "interactive"
  }'
```

### 3. Check Status

```bash
curl http://localhost:8000/flow/status
```

### 4. View Logs

```bash
curl http://localhost:8000/flow/logs/syn
```

## Debugging Issues

### Issue: "Claude Agent SDK not installed"

```bash
pip install claude-agent-sdk
```

### Issue: "Model not found"

The system tries models in order and falls back to fallback pattern matching.
Make sure your API key is set:

```bash
export ANTHROPIC_API_KEY="sk-ant-your-key"
```

### Issue: "Skills not loading"

Check that skill files exist:

```bash
ls -la skills/
# Should show: synthesis_skills.md, pnr_skills.md, debug_skills.md, knowledge_skills.md
```

### Issue: "Execution stuck"

Check max_iterations setting:

```python
# In src/agents/physical_design_graph.py
physical_design_graph = PhysicalDesignGraph(
    ...
    max_retries=3,  # Max retries per stage
)
```

## Next Steps

1. **Test the system** (already done)
2. **Customize skills** based on your design flow
3. **Add your own stages** to `PhysicalDesignGraph.STAGES`
4. **Integrate with your tools** by updating skill definitions
5. **Monitor and improve** based on execution results

## File References

| File | Purpose |
|------|---------|
| `src/agents/unified_agent.py` | Core agent with 8 contexts |
| `src/agents/physical_design_graph.py` | LangGraph orchestration |
| `src/main.py` | Server initialization |
| `src/api/flow_api.py` | HTTP endpoints |
| `skills/*.md` | Domain knowledge (customizable) |
| `ARCHITECTURE_UPDATED.md` | Detailed architecture |

## API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/flow/execute` | POST | Execute flow |
| `/flow/status` | GET | Get current status |
| `/flow/logs/{stage}` | GET | Get stage log |
| `/flow/history` | GET | Get execution history |
| `/flow/ws` | WebSocket | Real-time updates |

## Performance Metrics

- **Syntax check**: < 1 second
- **Core logic test**: < 2 seconds
- **Server startup**: 5-10 seconds
- **Synthesis iteration**: 15-60 seconds (tool dependent)
- **Token cost per stage**: 2-3K tokens (with skill caching)

## Troubleshooting Checklist

- [ ] Claude Agent SDK installed? `pip list | grep claude-agent-sdk`
- [ ] API key set? `echo $ANTHROPIC_API_KEY`
- [ ] Skills files present? `ls -la skills/`
- [ ] Server starts? `python3.10 -m src.main ...`
- [ ] Endpoint responds? `curl http://localhost:8000/health`
- [ ] Flow executes? `curl -X POST /flow/execute ...`

## Getting Help

1. Check `ARCHITECTURE_UPDATED.md` for detailed architecture
2. Review skill definitions in `skills/*.md`
3. Check server logs for execution details
4. Monitor `/flow/status` endpoint for progress
5. Review stage logs with `/flow/logs/{stage}`

---

**Ready to go!** Start with:
```bash
python3.10 -m src.main --project test --user bharath --block test_block --rtl-tag v1 --run-tag run_001
```
