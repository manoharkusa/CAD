# Issue Tracking & Fix System Design

## Problem Statement

Currently, when synthesis fails, the error is analyzed and fixed. But when placement fails later, we:
- ❌ Don't know about synthesis issues
- ❌ Can't correlate issues across phases
- ❌ Can't learn from previous failures
- ❌ Have no way to plugin custom fixes

**Goal:** Build a system that:
- ✅ Tracks issues across all phases
- ✅ Maintains user context per run
- ✅ Stores fixes in a knowledge base
- ✅ Allows plugging in custom issues & fixes
- ✅ Learns from historical data

---

## Architecture Overview

```
User Flow:
  synthesis → Issue #1: RTL_FILELIST not set
     ├─ Fix applied
     ├─ Success
     └─ [Issue stored with fix]
           ↓
  placement → Issue #2: Timing constraints too loose
     ├─ Check history: Issue #1 related to RTL?
     ├─ Get fix from knowledge base
     ├─ Apply fix
     └─ [Issue stored with fix]
           ↓
  routing → Issue #3: Routing congestion
     ├─ Check if seen before
     ├─ If yes: Apply known fix
     ├─ If no: Analyze & suggest fix
     └─ [New issue added to knowledge base]
```

---

## Data Models

### 1. Issue Model

```python
from datetime import datetime
from enum import Enum
from typing import Optional, List, Dict

class SeverityLevel(Enum):
    """Issue severity classification"""
    CRITICAL = "critical"      # Stops execution
    HIGH = "high"              # Degrades performance
    MEDIUM = "medium"          # Minor impact
    LOW = "low"                # Informational

class IssueStatus(Enum):
    """Issue lifecycle status"""
    DETECTED = "detected"      # Just found
    ANALYZED = "analyzed"      # Root cause identified
    FIXED = "fixed"            # Fix applied & verified
    IGNORED = "ignored"        # User marked as acceptable

class Issue:
    """Track issues across phases"""

    issue_id: str              # Unique ID: syn_001, place_002, etc.
    user_id: str               # Which user (bharath, priya)
    run_id: str                # Which run (run1, run2)
    thread_id: str             # Flow execution thread

    # When/Where
    stage: str                 # syn, place, route, etc.
    timestamp: datetime        # When issue occurred
    phase: str                 # synthesis, pnr, signoff

    # What
    error_type: str            # missing_env, timing_violation, congestion
    error_message: str         # Full error text
    error_log_snippet: str     # Relevant log lines

    # Analysis
    root_cause: str            # What's really wrong
    severity: SeverityLevel    # How bad is it?

    # Fix
    suggested_fix: str         # Recommended action
    fix_applied: bool          # Was fix applied?
    fix_method: str            # How was it fixed? (manual, automatic, learned)
    fix_result: Optional[str]  # Did it work? (success, partial, failed)

    # Metadata
    related_issues: List[str]  # Issue IDs this relates to
    metadata: Dict             # Custom data

    status: IssueStatus
```

### 2. Fix Template Model

```python
class FixTemplate:
    """Pluggable fix templates"""

    template_id: str           # unique_id
    error_pattern: str         # Regex to match errors
    error_type: str            # missing_env, timing, etc.
    stage: str                 # Which stage? (syn, place, route, or "*" for all)

    # The Fix
    fix_category: str          # env, constraint, config, manual
    fix_action: str            # What to do
    fix_parameters: Dict       # Parameters for fix

    # Application
    priority: int              # Try this fix first (0=highest)
    success_rate: float        # How often does it work? (0.0-1.0)
    preconditions: List[str]   # Must be true to apply

    # Metadata
    created_by: str            # Who created this template?
    created_at: datetime
    updated_at: datetime
    description: str
    example_error: str
    notes: str
```

### 3. Run Context Model

```python
class RunContext:
    """Maintain user context across entire flow execution"""

    # Flow identity
    thread_id: str
    user_id: str
    run_id: str
    project: str
    block: str

    # Issues discovered so far
    issues: List[Issue]        # All issues in this run
    issue_count: Dict[str, int] # Count by type {missing_env: 2, timing: 1}

    # Fixes applied
    fixes_applied: List[Dict]  # [{issue_id, fix_id, result}]

    # Decisions
    decisions: List[Dict]      # User decisions on issues
    # {
    #   issue_id: "syn_001",
    #   decision: "ignore" or "fix",
    #   reason: "..."
    # }

    # State across phases
    phase_results: Dict        # {syn: success, place: failed, route: pending}

    # History
    created_at: datetime
    updated_at: datetime
    flow_status: str           # pending, in_progress, completed, failed
```

---

## Database Schema

### Issues Table

```sql
CREATE TABLE issues (
    id VARCHAR(50) PRIMARY KEY,           -- syn_001, place_002
    user_id VARCHAR(50),
    run_id VARCHAR(50),
    thread_id VARCHAR(100),

    stage VARCHAR(50),                    -- syn, place, route
    timestamp DATETIME,
    phase VARCHAR(50),

    error_type VARCHAR(100),
    error_message TEXT,
    error_log_snippet TEXT,

    root_cause TEXT,
    severity VARCHAR(20),                 -- critical, high, medium, low

    suggested_fix TEXT,
    fix_applied BOOLEAN,
    fix_method VARCHAR(50),               -- automatic, manual, learned
    fix_result VARCHAR(50),               -- success, partial, failed

    related_issues JSON,
    metadata JSON,
    status VARCHAR(20),                   -- detected, analyzed, fixed, ignored

    created_at DATETIME,
    updated_at DATETIME,

    FOREIGN KEY (user_id, run_id) REFERENCES runs(user_id, run_id),
    INDEX idx_user_run (user_id, run_id),
    INDEX idx_stage (stage),
    INDEX idx_error_type (error_type),
    INDEX idx_thread (thread_id)
);
```

### Fix Templates Table

```sql
CREATE TABLE fix_templates (
    id VARCHAR(100) PRIMARY KEY,
    error_pattern TEXT,
    error_type VARCHAR(100),
    stage VARCHAR(50),

    fix_category VARCHAR(50),             -- env, constraint, config, manual
    fix_action TEXT,
    fix_parameters JSON,

    priority INT,
    success_rate FLOAT,
    preconditions JSON,

    created_by VARCHAR(50),
    created_at DATETIME,
    updated_at DATETIME,

    description TEXT,
    example_error TEXT,
    notes TEXT,

    INDEX idx_error_type (error_type),
    INDEX idx_stage (stage),
    INDEX idx_priority (priority DESC)
);
```

### Run Context Table

```sql
CREATE TABLE run_contexts (
    thread_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(50),
    run_id VARCHAR(50),
    project VARCHAR(100),
    block VARCHAR(100),

    issues_json JSON,                     -- All issues
    issue_counts JSON,                    -- {missing_env: 2, timing: 1}
    fixes_applied JSON,
    decisions JSON,
    phase_results JSON,

    created_at DATETIME,
    updated_at DATETIME,
    flow_status VARCHAR(20),

    FOREIGN KEY (user_id, run_id) REFERENCES runs(user_id, run_id),
    INDEX idx_user_run (user_id, run_id),
    INDEX idx_thread (thread_id)
);
```

---

## Implementation Architecture

### Layer 1: Issue Manager (Core)

```python
# File: src/issues/issue_manager.py

class IssueManager:
    """Manage issues across flow execution"""

    def __init__(self, db_connection):
        self.db = db_connection
        self.fix_templates = self._load_fix_templates()

    # Create issues
    async def create_issue(
        self,
        stage: str,
        error_type: str,
        error_message: str,
        phase: str,
        thread_id: str,
        user_id: str,
        run_id: str
    ) -> Issue:
        """Create new issue record"""

        issue = Issue(
            issue_id=f"{stage}_{self._next_issue_num(stage)}",
            stage=stage,
            error_type=error_type,
            error_message=error_message,
            thread_id=thread_id,
            user_id=user_id,
            run_id=run_id,
            timestamp=datetime.now(),
            phase=phase
        )

        # Save to database
        await self.db.insert("issues", issue.to_dict())

        return issue

    # Retrieve issues
    async def get_issues(
        self,
        user_id: str,
        run_id: str
    ) -> List[Issue]:
        """Get all issues for a run"""

        rows = await self.db.query(
            "SELECT * FROM issues WHERE user_id = ? AND run_id = ?",
            (user_id, run_id)
        )
        return [Issue.from_dict(row) for row in rows]

    async def get_issues_by_stage(
        self,
        user_id: str,
        run_id: str,
        stage: str
    ) -> List[Issue]:
        """Get issues from specific stage"""

        rows = await self.db.query(
            "SELECT * FROM issues WHERE user_id = ? AND run_id = ? AND stage = ?",
            (user_id, run_id, stage)
        )
        return [Issue.from_dict(row) for row in rows]

    async def get_issue_history(
        self,
        error_type: str,
        user_id: str,
        limit: int = 10
    ) -> List[Issue]:
        """Get historical issues of same type"""

        rows = await self.db.query(
            "SELECT * FROM issues WHERE error_type = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?",
            (error_type, user_id, limit)
        )
        return [Issue.from_dict(row) for row in rows]
```

### Layer 2: Fix Repository (Pluggable)

```python
# File: src/issues/fix_repository.py

class FixRepository:
    """Store and retrieve fix templates"""

    def __init__(self, db_connection):
        self.db = db_connection

    # Register fix templates
    async def register_fix_template(
        self,
        template: FixTemplate
    ) -> str:
        """Register a new fix template"""

        template_id = f"{template.error_type}_{template.stage}_{uuid4()}"

        await self.db.insert(
            "fix_templates",
            {
                "id": template_id,
                "error_pattern": template.error_pattern,
                "error_type": template.error_type,
                "stage": template.stage,
                "fix_category": template.fix_category,
                "fix_action": template.fix_action,
                "fix_parameters": json.dumps(template.fix_parameters),
                "priority": template.priority,
                "success_rate": template.success_rate,
                "created_by": template.created_by,
                "created_at": datetime.now(),
                "description": template.description,
            }
        )

        return template_id

    # Find applicable fixes
    async def find_fixes_for_error(
        self,
        error_type: str,
        error_message: str,
        stage: str
    ) -> List[FixTemplate]:
        """Find applicable fixes for error, ordered by priority"""

        # Get templates for this error type
        rows = await self.db.query(
            """
            SELECT * FROM fix_templates
            WHERE error_type = ? AND (stage = ? OR stage = '*')
            ORDER BY priority ASC, success_rate DESC
            """,
            (error_type, stage)
        )

        templates = [FixTemplate.from_dict(row) for row in rows]

        # Filter by pattern matching
        matching = []
        for template in templates:
            if re.search(template.error_pattern, error_message):
                matching.append(template)

        return matching
```

### Layer 3: Fix Engine (Application)

```python
# File: src/issues/fix_engine.py

class FixEngine:
    """Apply fixes to issues"""

    def __init__(
        self,
        issue_manager: IssueManager,
        fix_repository: FixRepository,
        config_manager,
        debug_agent
    ):
        self.issues = issue_manager
        self.fixes = fix_repository
        self.config = config_manager
        self.debug = debug_agent

    # Analyze issue and suggest fixes
    async def analyze_and_suggest_fixes(
        self,
        issue: Issue,
        context: RunContext
    ) -> List[Dict]:
        """
        Analyze issue and suggest fixes based on:
        1. Applicable fix templates
        2. Historical similar issues
        3. Debug analysis
        """

        suggestions = []

        # 1. Check fix templates
        templates = await self.fixes.find_fixes_for_error(
            issue.error_type,
            issue.error_message,
            issue.stage
        )

        for template in templates:
            suggestions.append({
                "method": "template",
                "priority": template.priority,
                "success_rate": template.success_rate,
                "action": template.fix_action,
                "parameters": template.fix_parameters,
                "reason": f"Matched pattern: {template.description}"
            })

        # 2. Check historical similar issues
        similar_issues = await self.issues.get_issue_history(
            issue.error_type,
            issue.user_id,
            limit=5
        )

        for similar in similar_issues:
            if similar.fix_result == "success":
                suggestions.append({
                    "method": "historical",
                    "priority": 10,  # Lower than template
                    "success_rate": 0.8,
                    "action": similar.suggested_fix,
                    "reason": f"Similar issue {similar.issue_id} was fixed this way"
                })

        # 3. Use debug agent analysis
        debug_result = await self.debug.analyze_error(
            issue.error_message,
            issue.error_log_snippet
        )

        suggestions.append({
            "method": "analysis",
            "priority": 20,
            "success_rate": debug_result.get("confidence", 0.5),
            "action": debug_result.get("suggested_fix"),
            "reason": debug_result.get("root_cause")
        })

        # Sort by priority and success rate
        suggestions.sort(
            key=lambda x: (x["priority"], -x["success_rate"])
        )

        return suggestions

    # Apply fix
    async def apply_fix(
        self,
        issue: Issue,
        fix_suggestion: Dict,
        context: RunContext
    ) -> bool:
        """Apply suggested fix"""

        fix_method = fix_suggestion["method"]

        try:
            if fix_method == "template":
                success = await self._apply_template_fix(
                    issue,
                    fix_suggestion,
                    context
                )
            elif fix_method == "historical":
                success = await self._apply_historical_fix(issue)
            else:
                success = await self._apply_analysis_fix(issue)

            # Record result
            issue.fix_applied = True
            issue.fix_method = fix_method
            issue.fix_result = "success" if success else "partial"
            issue.status = IssueStatus.FIXED

            await self.issues.update_issue(issue)

            return success

        except Exception as e:
            issue.fix_result = "failed"
            issue.status = IssueStatus.ANALYZED
            await self.issues.update_issue(issue)
            return False

    async def _apply_template_fix(
        self,
        issue: Issue,
        fix: Dict,
        context: RunContext
    ) -> bool:
        """Apply template-based fix"""

        action = fix["action"]
        params = fix["parameters"]

        # Examples of template fixes
        if action == "set_environment_variable":
            os.environ[params["var_name"]] = params["value"]
            return True

        elif action == "update_config":
            await self.config.update_config(params["key"], params["value"])
            return True

        elif action == "modify_constraint":
            # Modify SDC or constraint file
            await self._modify_constraints(params)
            return True

        # Add more fix types as needed
        return False
```

### Layer 4: Run Context Tracker

```python
# File: src/issues/run_context.py

class RunContextTracker:
    """Track context across entire flow execution"""

    def __init__(self, db_connection):
        self.db = db_connection
        self.contexts = {}  # In-memory cache: thread_id → RunContext

    async def create_context(
        self,
        thread_id: str,
        user_id: str,
        run_id: str,
        project: str,
        block: str
    ) -> RunContext:
        """Create new run context"""

        context = RunContext(
            thread_id=thread_id,
            user_id=user_id,
            run_id=run_id,
            project=project,
            block=block,
            issues=[],
            fixes_applied=[],
            decisions=[],
            created_at=datetime.now()
        )

        # Save to database
        await self.db.insert(
            "run_contexts",
            {
                "thread_id": thread_id,
                "user_id": user_id,
                "run_id": run_id,
                "project": project,
                "block": block,
                "created_at": datetime.now(),
                "flow_status": "in_progress"
            }
        )

        self.contexts[thread_id] = context
        return context

    async def get_context(self, thread_id: str) -> RunContext:
        """Get run context"""

        if thread_id in self.contexts:
            return self.contexts[thread_id]

        # Load from database
        row = await self.db.query_one(
            "SELECT * FROM run_contexts WHERE thread_id = ?",
            (thread_id,)
        )

        if row:
            context = RunContext.from_dict(row)
            self.contexts[thread_id] = context
            return context

        return None

    async def add_issue_to_context(
        self,
        thread_id: str,
        issue: Issue
    ):
        """Add issue to run context"""

        context = await self.get_context(thread_id)
        context.issues.append(issue)
        context.issue_count[issue.error_type] = \
            context.issue_count.get(issue.error_type, 0) + 1

        # Update database
        await self._save_context(context)

    async def record_fix_applied(
        self,
        thread_id: str,
        issue_id: str,
        fix_id: str,
        result: str
    ):
        """Record fix application"""

        context = await self.get_context(thread_id)
        context.fixes_applied.append({
            "issue_id": issue_id,
            "fix_id": fix_id,
            "result": result,
            "timestamp": datetime.now()
        })

        await self._save_context(context)

    async def _save_context(self, context: RunContext):
        """Save context to database"""

        await self.db.update(
            "run_contexts",
            {
                "issues_json": json.dumps([i.to_dict() for i in context.issues]),
                "issue_counts": json.dumps(context.issue_count),
                "fixes_applied": json.dumps(context.fixes_applied),
                "updated_at": datetime.now()
            },
            "thread_id = ?",
            (context.thread_id,)
        )
```

---

## Integration with PhysicalDesignGraph

### Modified execute_stage_node

```python
# In src/agents/physical_design_graph.py

async def _execute_stage_node(self, state: FlowState) -> dict:
    """Execute stage with issue tracking"""

    # ... existing code ...

    # Get or create issue manager for this run
    issue_manager = IssueManager(self.db)
    fix_engine = FixEngine(issue_manager, fix_repo, self.config_manager, self.debug_agent)
    context_tracker = RunContextTracker(self.db)

    # Get run context
    context = await context_tracker.get_context(state["thread_id"])
    if not context:
        context = await context_tracker.create_context(
            state["thread_id"],
            state["user_id"],
            state["run_id"],
            # ... other params
        )

    try:
        result = await self.stage_executor.execute_stage(...)

        if result["status"] != "success":
            # Create issue record
            issue = await issue_manager.create_issue(
                stage=stage_name,
                error_type="execution_failed",
                error_message=result.get("error", "Unknown error"),
                phase=self._get_phase(stage_name),
                thread_id=state["thread_id"],
                user_id=state["user_id"],
                run_id=state["run_id"]
            )

            # Add to context
            await context_tracker.add_issue_to_context(
                state["thread_id"],
                issue
            )

            # Get fix suggestions based on context
            suggestions = await fix_engine.analyze_and_suggest_fixes(
                issue,
                context
            )

            # Update state with suggestions
            return {
                "error_info": {
                    "error": result["error"],
                    "issue_id": issue.issue_id,
                    "suggestions": suggestions  # ← NEW!
                },
                "stages_failed": [...] + [stage_name],
                "context_issues": context.issues  # ← NEW! Context maintained
            }

    except Exception as e:
        # Similar issue creation
        pass
```

---

## Example: Plugging In Custom Fixes

### How Users Add Custom Fixes

```python
# File: fix_templates/user_fixes.py

# Define custom fix template
timing_fix = FixTemplate(
    error_pattern=r"setup violation|timing constraint",
    error_type="timing_violation",
    stage="place",  # Only for place stage
    fix_category="constraint",
    fix_action="update_config",
    fix_parameters={
        "key": "SETUP_TIME",
        "value": "0.5ns"
    },
    priority=5,
    success_rate=0.85,
    created_by="bharath",
    description="Increase setup time margin for timing violations"
)

congestion_fix = FixTemplate(
    error_pattern=r"routing congestion|route failure",
    error_type="routing_congestion",
    stage="route",
    fix_category="config",
    fix_action="modify_constraint",
    fix_parameters={
        "file": "route.tcl",
        "setting": "set_route_width_weight 0.8"
    },
    priority=3,
    success_rate=0.9,
    created_by="bharath",
    description="Reduce routing width weight for congestion"
)

# Register in system
async def register_custom_fixes():
    repo = FixRepository(db)
    await repo.register_fix_template(timing_fix)
    await repo.register_fix_template(congestion_fix)
```

### User Interface for Issue Tracking

```python
# File: src/api/issue_api.py

@router.get("/issues/{thread_id}")
async def get_issues(thread_id: str):
    """Get all issues for a flow execution"""

    issue_manager = IssueManager(db)
    issues = await issue_manager.get_issues_by_thread(thread_id)

    return {
        "thread_id": thread_id,
        "issues": [i.to_dict() for i in issues],
        "summary": {
            "total": len(issues),
            "by_type": count_by_type(issues),
            "by_stage": count_by_stage(issues)
        }
    }

@router.get("/context/{thread_id}")
async def get_context(thread_id: str):
    """Get full run context with all issues"""

    tracker = RunContextTracker(db)
    context = await tracker.get_context(thread_id)

    return {
        "thread_id": thread_id,
        "user_id": context.user_id,
        "issues": [i.to_dict() for i in context.issues],
        "fixes_applied": context.fixes_applied,
        "phase_results": context.phase_results,
        "summary": {
            "total_issues": len(context.issues),
            "fixed": sum(1 for i in context.issues if i.status == IssueStatus.FIXED),
            "pending": sum(1 for i in context.issues if i.status == IssueStatus.DETECTED)
        }
    }

@router.post("/fixes/register")
async def register_fix(template: FixTemplate):
    """User registers custom fix template"""

    repo = FixRepository(db)
    fix_id = await repo.register_fix_template(template)

    return {"fix_id": fix_id, "status": "registered"}
```

---

## Issue Flow Diagram

```
Flow Execution:
  ┌─ SYNTHESIS ─┐
  │   ├─ Issue: RTL_FILELIST missing
  │   ├─ Create issue record (syn_001)
  │   ├─ Analyze (pattern match + history)
  │   ├─ Suggest fixes (template, historical, analysis)
  │   ├─ Apply fix (set RTL_FILELIST)
  │   └─ Success → Record fix result
  │        ↓
  ├─ PLACEMENT ─┐
  │   ├─ Check context (syn_001 was fixed)
  │   ├─ Issue: Timing violation
  │   ├─ Create issue record (place_002)
  │   ├─ Analyze with context (is this related to RTL_FILELIST fix?)
  │   ├─ Suggest fixes (use historical: similar user had timing issue → increased slack)
  │   ├─ Apply fix
  │   └─ Record in context
  │        ↓
  ├─ ROUTING ─┐
  │   ├─ Issue: Routing congestion
  │   ├─ Create issue record (route_003)
  │   ├─ Analyze (check: did place_002 fix help?)
  │   ├─ Suggest fixes (new issue type, suggest analysis-based fix)
  │   ├─ User approves fix
  │   └─ Record in knowledge base for future
  │
  └─ FLOW COMPLETE
      ├─ Issues: 3 (all fixed)
      ├─ Fixes: 3 applied
      ├─ Context: Maintained throughout
      └─ Knowledge learned for next run
```

---

## Benefits

### 1. **Maintains Context Across Phases**
- Synthesis issue affects placement → System knows this
- Previous fix helps in routing → System applies it
- Historical data informs decisions

### 2. **Pluggable Fix System**
```python
# Users can add fixes without modifying code
async def register_custom_fixes():
    await fix_repo.register_fix_template(my_fix)
```

### 3. **Learning System**
- Each run learns from success/failure
- Historical issues build knowledge base
- Future runs use learned fixes

### 4. **Audit Trail**
- Every issue tracked
- Every fix recorded
- Full visibility into what happened

### 5. **Multi-User Context**
- Each user has their own context
- Users can learn from each other (or not)
- Privacy-aware issue sharing

---

## Database Queries for Analysis

### Query 1: Issues by User Over Time

```sql
SELECT
    user_id,
    DATE(created_at) as date,
    COUNT(*) as issue_count,
    SUM(CASE WHEN status = 'fixed' THEN 1 ELSE 0 END) as fixed_count
FROM issues
GROUP BY user_id, DATE(created_at)
ORDER BY date DESC;
```

### Query 2: Most Common Issues

```sql
SELECT
    error_type,
    COUNT(*) as occurrence,
    AVG(CASE WHEN fix_result = 'success' THEN 1 ELSE 0 END) as fix_success_rate
FROM issues
WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY error_type
ORDER BY occurrence DESC;
```

### Query 3: Most Effective Fixes

```sql
SELECT
    template_id,
    description,
    success_rate,
    COUNT(*) as times_used
FROM fix_templates
JOIN (
    SELECT fix_method FROM issues WHERE fix_applied = true
) as applied_fixes
GROUP BY template_id
ORDER BY success_rate DESC;
```

---

## Summary

This design provides:

✅ **Issue Tracking** - Every error is recorded
✅ **Context Maintenance** - Information flows across phases
✅ **Fix Suggestions** - Based on templates, history, and analysis
✅ **Plugin System** - Users add custom fixes without code changes
✅ **Learning** - System improves from each run
✅ **Audit Trail** - Full visibility
✅ **Multi-User** - Each user's context isolated

**Result:** A mature issue management system that learns and improves! 🎯
