# Phase 1 - Component Mapping Matrix (`src` -> `dev1/src`)

Date: 2026-03-07

## Objective
Bring end-to-end plumbing from `src` (API -> Redis -> Worker -> Postgres) into `dev1/src` while preserving core agent/orchestration logic in `dev1/src`.

## Guardrails for this merge
- `dev1/src/agents/*` (core orchestration and agent logic) is **logic-owned** by dev1 and should remain functionally unchanged in early phases.
- `src/*` contributes **infrastructure capabilities** (job lifecycle API, Redis queue/state, Postgres persistence, event stream).
- Initial integration should be done via **adapters/facades**, not by rewriting dev1 core classes.

---

## A) Current Runtime Flow Mapping

### Legacy `src` flow (already end-to-end)
1. API request enters `src/api/main.py` (`/jobs`, `/jobs/{id}/job_status`, HITL, abort, websocket).
2. Job persisted to Postgres via `src/repository.py` + `src/models/db_models.py` using `src/db.py`.
3. Job state + queue pushed to Redis via `src/redis_client.py`.
4. Worker orchestration in `src/worker/langgraph_supervisor.py` runs synthesis loop and emits events.
5. Claude agent execution in `src/worker/claude_agent.py`.
6. Progress/events published via pubsub (`src/redis_client_pubsub.py`) and state updates reflected via API.

### `dev1/src` flow (core logic-rich)
1. API entrypoints in `dev1/src/main.py` and `dev1/src/api/flow_api.py`.
2. Core orchestration in `dev1/src/agents/physical_design_graph.py` and `dev1/src/agents/orchestrator.py`.
3. Stage execution via `dev1/src/executor/stage_executor.py`.
4. Config/path orchestration via `dev1/src/config/config_manager.py`.
5. State/checkpoint tracking in `dev1/src/tracker/langgraph_saver.py` and `dev1/src/tracker/state_tracker.py`.
6. Issue subsystem (currently sqlite-centric) under `dev1/src/issues/*`.

---

## B) Component-by-Component Decision Matrix

| Capability | Source of Truth (Target) | `src` Asset | `dev1/src` Asset | Decision | Phase |
|---|---|---|---|---|---|
| HTTP API shell | `dev1/src` | `src/api/main.py` | `dev1/src/api/flow_api.py`, `dev1/src/main.py` | **Adapt**: Add job-lifecycle endpoints in dev1 API style | 2/3 |
| Job submit/status contracts | `dev1/src` with compatibility DTOs | `JobCreateRequest/Response`, status models | `ExecuteRequest/Response`, status models | **Adapt**: Introduce compatibility DTO layer | 2 |
| DB session lifecycle | shared infra module (new under `dev1/src`) | `src/db.py` | none equivalent | **Reuse+Adapt** | 3 |
| Postgres ORM schema | shared infra module (new under `dev1/src`) | `src/models/db_models.py` | sqlite models in `dev1/src/issues/models.py` | **Reuse+Adapt** (keep issue sqlite for now) | 3 |
| Repository abstraction | shared infra module (new under `dev1/src`) | `src/repository.py` | dispersed issue db ops | **Adapt**: create `job_repository` adapter API | 3 |
| Redis queue/state | shared infra module (new under `dev1/src`) | `src/redis_client.py`, `src/redis_client_pubsub.py` | langgraph saver redis checkpoint | **Reuse+Adapt** (namespace keys to avoid collision) | 3 |
| Worker orchestration | `dev1/src` core remains | `src/worker/langgraph_supervisor.py` | `dev1/src/agents/physical_design_graph.py` | **Keep dev1 core**, import only lifecycle hooks | 4 |
| Claude agent runtime | `dev1/src` core remains | `src/worker/claude_agent.py` | `dev1/src/agents/*` + sdk usage | **Do not replace** in early phases | 4+ |
| Checkpointing | `dev1/src` | `src.repository.save_checkpoint` + `job_checkpoints` | `dev1/src/tracker/langgraph_saver.py` | **Dual-write adapter** (optional in phase 4) | 4 |
| Issue tracking persistence | `dev1/src` (temporary sqlite) | Postgres audit/error logs | `dev1/src/issues/issue_database.py` | **Leave undisturbed** initially | 5 |

---

## C) Detailed File-Level Mapping (`src` -> target place in `dev1/src`)

### 1) API Layer
- `src/api/main.py`
  - Port endpoint semantics into `dev1/src/api/flow_api.py` as compatibility routes:
    - `POST /jobs`
    - `GET /jobs/{job_id}/job_status`
    - `POST /jobs/{job_id}/human-input`
    - `POST /jobs/{job_id}/abort`
    - `GET /job_state`
    - `WS /ws/jobs/{job_id}`
  - Keep existing `/flow/*` endpoints unchanged.

### 2) Config + DB + Infra
- `src/config.py` -> create `dev1/src/config/runtime_config.py` (env-driven runtime config for db/redis/lifecycle).
- `src/db.py` -> create `dev1/src/infra/db.py` (session factory + dependency provider).
- `src/models/db_models.py` -> create `dev1/src/infra/models/job_models.py` (unaltered schema first, then namespace cleanup later).
- `src/repository.py` -> create `dev1/src/infra/repositories/job_repository.py`.

### 3) Redis + Eventing
- `src/redis_client.py` -> create `dev1/src/infra/redis/job_state_store.py`.
- `src/redis_client_pubsub.py` -> create `dev1/src/infra/redis/job_events.py`.
- Reuse dev1 checkpointer (`tracker/langgraph_saver.py`) for graph checkpoints; keep job-lifecycle state keys separate.

### 4) Worker/Orchestration Integration
- **Do not copy** `src/worker/claude_agent.py` or `src/worker/langgraph_supervisor.py` into dev1 core.
- Instead, add bridge hooks in `dev1/src/agents/physical_design_graph.py`:
  - on job accepted -> set status `PENDING/QUEUED`
  - on execution start -> `IN_PROGRESS/EXECUTING`
  - on stage updates -> progress events
  - on HITL wait -> `WAITING_HUMAN`
  - on completion/failure/abort -> terminal states + summary

### 5) Persistence Coexistence
- Keep `dev1/src/issues/*` sqlite-based system intact in early migration.
- Add non-invasive link field strategy:
  - store `job_id` + `thread_id` associations in issue metadata.
- Optional later phase: move issues to Postgres after job lifecycle parity is achieved.

---

## D) Gap Analysis (must be solved before Phase 2 coding)

1. **ID shape mismatch**
   - `src`: UUID `job_id`, optional `session_id`.
   - `dev1`: `thread_id`, `run_id`, generated `job_*` style IDs in `main.py`.
   - Plan: introduce canonical lifecycle IDs:
     - external: `job_id` (UUID)
     - internal: `thread_id` (dev1)
     - mapping table/cache in lifecycle repository.

2. **Status vocabulary mismatch**
   - `src`: `PENDING/IN_PROGRESS/SUCCESS/FAILED/CANCELLED` + phases.
   - `dev1`: `pending/in_progress/completed/failed`.
   - Plan: add translator enum map in adapter layer.

3. **Persistence split (Postgres vs sqlite)**
   - Keep split temporarily; avoid merging issue DB in phase 1-3.

4. **Queue ownership mismatch**
   - `src` expects Redis queue consumer worker.
   - `dev1` often executes directly via graph invocation.
   - Plan: support both modes behind feature flag:
     - direct invoke (default)
     - queued execution (compatibility mode)

---

## E) Incremental PR Slices Starting After Phase 1

### PR-1: Contracts + adapters skeleton (no behavior change)
- Add `dev1/src/infra/*` package stubs.
- Add ID and status translation utilities.
- Add feature flags (`USE_JOB_LIFECYCLE_API`, `USE_POSTGRES_JOB_REPO`, `USE_REDIS_JOB_STATE`).
- No route switching yet.

### PR-2: Persistence enablement
- Wire Postgres models + repository.
- Add `POST /jobs` + `GET /jobs/{id}/job_status` in compatibility mode.
- Keep `/flow/execute` unchanged.

### PR-3: Runtime state + events
- Wire Redis state and pubsub events.
- Add websocket and `/job_state` compatibility endpoints.

### PR-4: Orchestration bridge
- Hook `physical_design_graph` lifecycle callbacks into new repository/state/event adapters.
- Add HITL/abort compatibility handling without replacing dev1 orchestrator logic.

### PR-5: Consolidation
- Remove duplicate temporary paths and lock final ownership boundaries.

---

## F) Verification Checklist for Phase 1 Exit

- [x] `src` and `dev1/src` runtime components inventoried.
- [x] Ownership rule defined (dev1 core logic preserved).
- [x] File-level mapping with `reuse/adapt/replace` decisions completed.
- [x] PR slicing strategy defined for incremental migration.
- [ ] Phase 2 contract implementation started.

---

## Immediate Next Command (Phase 2 kickoff)
Start with PR-1 (adapters skeleton) under:
- `dev1/src/infra/db.py`
- `dev1/src/infra/models/job_models.py`
- `dev1/src/infra/repositories/job_repository.py`
- `dev1/src/infra/redis/job_state_store.py`
- `dev1/src/infra/redis/job_events.py`
- `dev1/src/infra/mappers/status_mapper.py`
- `dev1/src/infra/mappers/id_mapper.py`

This keeps existing `dev1/src/agents/*` behavior untouched while enabling end-to-end flow integration in controlled steps.
