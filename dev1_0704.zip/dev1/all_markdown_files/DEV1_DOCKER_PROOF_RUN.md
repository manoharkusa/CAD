# DEV1 End-to-End Proof Run (Docker)

## Start Stack

Ensure `dev1/.env` exists (checked in locally for this workspace) and adjust values if needed.

From repository root:

```powershell
docker compose -f dev1/docker-compose.dev1.yml up -d --build
```

Verify services:

```powershell
docker compose -f dev1/docker-compose.dev1.yml ps
```

- API: http://127.0.0.1:8000
- Swagger: http://127.0.0.1:8000/docs

## Execute Lifecycle Proof Run

```powershell
./dev1/scripts/proof_run_dev1.ps1
```

This exercises:
- `POST /jobs`
- `GET /jobs/{job_id}/job_status`
- `POST /jobs/{job_id}/human-input`
- `GET /job_state`
- `POST /jobs/{job_id}/abort`

## Run Relevant Tests

Install test tooling in local venv first:

```powershell
c:/Users/mahes/DataScience/synthesis_agent-main/synthesis_agent-main/.venv/Scripts/python.exe -m pip install pytest
```

Run applicable suites:

```powershell
c:/Users/mahes/DataScience/synthesis_agent-main/synthesis_agent-main/.venv/Scripts/python.exe -m pytest dev1/tests/test_multi_user.py -q
c:/Users/mahes/DataScience/synthesis_agent-main/synthesis_agent-main/.venv/Scripts/python.exe dev1/tests/test_syntax.py
c:/Users/mahes/DataScience/synthesis_agent-main/synthesis_agent-main/.venv/Scripts/python.exe -m pytest dev1/tests/test_issue_tracking.py -q
```

Notes:
- Compose now loads `dev1/.env` automatically (`env_file`) and applies container-safe overrides for Redis/Postgres hostnames.
- Core import/startup hardening now allows running without anthropic/claude SDK installed.
- Detailed request path doc: `dev1/all_markdown_files/REQUEST_LIFECYCLE_DETAILED_FLOW.md`.
- Stage verification checklist: `dev1/all_markdown_files/E2E_STAGE_VALIDATION_CHECKLIST.md`.

## Stop Stack

```powershell
docker compose -f dev1/docker-compose.dev1.yml down
```

To clear volumes too:

```powershell
docker compose -f dev1/docker-compose.dev1.yml down -v
```
