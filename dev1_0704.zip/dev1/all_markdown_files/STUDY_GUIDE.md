# Complete Study Guide: Physical Design Flow Orchestration System

## Table of Contents
1. [System Architecture](#system-architecture)
2. [Core Components](#core-components)
3. [Data Flow](#data-flow)
4. [Multi-User Isolation](#multi-user-isolation)
5. [Stage Execution](#stage-execution)
6. [State Management](#state-management)
7. [Error Handling & Recovery](#error-handling--recovery)
8. [File Structure](#file-structure)
9. [Configuration System](#configuration-system)
10. [Key Decisions & Why](#key-decisions--why)

---

## System Architecture

### High-Level Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        API Layer (FastAPI)                       │
│  - Receives HTTP requests from users                             │
│  - Route: POST /flow/execute, GET /flow/status, etc.            │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                 Authentication & Validation                      │
│  - Verify API key/user_id                                        │
│  - Extract project, block, run_id from request                   │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│              PhysicalDesignGraph (LangGraph)                      │
│  - Stateless orchestration engine                                │
│  - 5 nodes: parse_intent, create_plan, execute_stage,           │
│             debug_stage, handle_result                           │
│  - Routes conditional on success/failure                         │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│              ConfigManager (Per-Request)                          │
│  - Sources sourceproj.env (tcsh/bash auto-detect)               │
│  - Loads flow_config.yaml                                        │
│  - Resolves ENV_SCRIPTS path for tool scripts                    │
│  - Computes work/log directories (stage_group aware)             │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│               StageExecutor (Per-Stage)                           │
│  - Builds shell command with env sourcing                        │
│  - Executes TCL script in asyncio subprocess                     │
│  - Detects env file format (tcsh vs bash)                        │
│  - Captures stdout/stderr, logs output                           │
│  - Returns: success/failed status                                │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Tool Execution (EDA Tools)                      │
│  - Genus (synthesis)                                             │
│  - Innovus (place & route)                                       │
│  - Calibre (verification)                                        │
│  - TCL scripts in ENV_SCRIPTS/{tool_name}/*.tcl                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. PhysicalDesignGraph (LangGraph State Machine)

**File:** `src/agents/physical_design_graph.py`

**Purpose:** Orchestrate the entire flow execution

**Architecture:**
```
FlowState (TypedDict)
├── Input
│   ├── prompt: str (user's command)
│   ├── debug_mode: str (auto/interactive/none)
│   └── user_id: str (multi-user tracking)
│
├── Execution Plan
│   ├── intent: dict (parsed user intent)
│   ├── plan: list[str] (stages to execute: ["syn", "place", "route"])
│   └── current_stage_index: int (progress tracking)
│
├── Results
│   ├── stages_executed: list[str] (successful stages)
│   ├── stages_failed: list[str] (failed stages)
│   └── stage_results: dict (detailed results per stage)
│
└── Error Tracking
    ├── error_info: dict (last error details)
    ├── error_retry_count: int (retry counter)
    └── debug_history: dict (debug attempts)
```

**5 Graph Nodes:**

```
1. parse_intent_node
   ├─ Input: user prompt ("run synthesis and place")
   ├─ Process: Extract intent using Claude or regex
   ├─ Output: intent = {action: "execute", stages: ["syn", "place"], ...}
   └─ Next: create_plan

2. create_plan_node
   ├─ Input: intent
   ├─ Process: Map intent stages to flow_config.yaml stages
   ├─ Output: plan = ["syn", "place"]
   └─ Next: execute_stage

3. execute_stage_node (LOOP: runs multiple times)
   ├─ Input: plan, current_stage_index
   ├─ Process:
   │  ├─ Get tool/script from flow_config.yaml
   │  ├─ Create ConfigManager
   │  ├─ Execute via StageExecutor
   │  └─ Increment current_stage_index on success
   ├─ Output: stage_results[stage_name]
   └─ Routes to:
      ├─ execute_stage (if more stages AND success)
      ├─ debug_stage (if failure)
      └─ handle_result (if all stages done)

4. debug_stage_node
   ├─ Input: error_info
   ├─ Process: DebugAgent analyzes error, suggests fix
   ├─ Output: debug_result, fix_actions
   └─ Routes to:
      ├─ execute_stage (if fix available AND retries < max)
      └─ handle_result (if no fix OR max retries exceeded)

5. handle_result_node
   ├─ Input: execution_status, stages_executed, stages_failed
   ├─ Process: Generate summary report
   ├─ Output: Final execution summary
   └─ End: Return to user
```

**Conditional Routing:**
```
After execute_stage:
  ├─ If error_info is None (success):
  │  ├─ If more stages: → execute_stage (continue loop)
  │  └─ If all done: → handle_result
  └─ If error_info exists (failure):
     └─ → debug_stage

After debug_stage:
  ├─ If fix suggested AND retries < max: → execute_stage (retry)
  └─ Else: → handle_result
```

---

### 2. ConfigManager (Configuration & Path Resolution)

**File:** `src/config/config_manager.py`

**Responsibilities:**
1. Source sourceproj.env (tcsh/bash auto-detect)
2. Load flow_config.yaml
3. Resolve script paths from ENV_SCRIPTS
4. Compute work/log directories with stage_group support

**Initialization Flow:**

```
create_config_manager(
    project_name="semicon_19-02",
    user_name="bharath",
    block_name="aes_cipher_top",
    rtl_tag="bronze_v2",
    run_tag="run2",
)
    │
    ├─ Build run_dir
    │  └─ /proj5/projects/semicon_19-02/pd/users/bharath/aes_cipher_top/bronze_v2/run2/
    │
    ├─ _source_env_file()
    │  ├─ Detect format: check shebang (#!/bin/tcsh or #!/bin/bash)
    │  ├─ If tcsh: run "tcsh -c 'source sourceproj.env && env'"
    │  ├─ If bash: run "source sourceproj.env && env"
    │  ├─ Parse output and update os.environ
    │  └─ Sets: ENV_SCRIPTS, BLOCK_NAME, RTL_FILELIST, SDC, etc.
    │
    ├─ Read tools_root from ENV_SCRIPTS
    │  └─ /proj5/REL/env_scripts/projects/semicon_19-02/latest/tools_scripts
    │
    └─ _load_flow_config()
       ├─ Read YAML file
       └─ Returns config dict with stages and stage_groups
```

**Path Resolution Example:**

```
Query: get_stage_work_dir("init_design")

Process:
  ├─ Get stage_info from flow_config.yaml
  │  └─ init_design: {stage_group: "pnr", dir_name: "init", ...}
  │
  ├─ Check stage_group: "pnr"
  │  └─ Found in stage_groups with base_dir: "pnr"
  │
  └─ Construct path:
     run_dir / base_dir / dir_name / "work"
     = /proj5/.../run2 / pnr / init / work
     = /proj5/.../run2/pnr/init/work ✓

Query: get_tool_script_path("genus", "genus_syn.tcl")

Process:
  ├─ tools_root = /proj5/REL/env_scripts/.../tools_scripts
  └─ Return: tools_root / "genus" / "genus_syn.tcl"
     = /proj5/REL/env_scripts/.../tools_scripts/genus/genus_syn.tcl ✓
```

**Configuration Hierarchy:**

```
sourceproj.env (environment variables)
    │
    ├─ BLOCK_NAME=aes_cipher_top
    ├─ ENV_SCRIPTS=/proj5/REL/env_scripts/.../tools_scripts
    ├─ RTL_FILELIST=/path/to/rtl_files.list
    ├─ SDC=/path/to/constraints.sdc
    └─ (50+ more variables)
         │
         ├─ Read by ConfigManager._source_env_file()
         └─ Made available to TCL scripts via $env(VAR_NAME)

flow_config.yaml (stage definitions)
    │
    ├─ stages:
    │  ├─ syn: {tool: genus, script: genus_syn.tcl, ...}
    │  ├─ init_design: {tool: innovus, script: init_design.tcl, stage_group: pnr, dir_name: init}
    │  └─ place: {tool: innovus, script: place.tcl, stage_group: pnr}
    │
    └─ stage_groups:
       ├─ pnr: {base_dir: pnr, stages: [init_design, place, ...]}
       └─ signoff: {stages: [qrc, sta, pv, lec]}
            │
            ├─ Read by ConfigManager._load_flow_config()
            └─ Used for path resolution (stage_group → base_dir)
```

---

### 3. StageExecutor (Stage Execution)

**File:** `src/executor/stage_executor.py`

**Responsibilities:**
1. Execute a single stage (syn, place, route, etc.)
2. Source environment file with correct shell
3. Build and run tool command
4. Capture logs and handle results

**Execution Flow:**

```
execute_stage(
    stage_name="syn",
    tool_name="genus",
    tool_script="genus_syn.tcl",
)
    │
    ├─ Get script path from ConfigManager
    │  └─ /proj5/REL/env_scripts/.../genus/genus_syn.tcl
    │
    ├─ Get work/log directories from ConfigManager
    │  ├─ work_dir: /proj5/.../run2/syn/work
    │  └─ log_dir: /proj5/.../run2/syn/logs
    │
    ├─ Detect env_file format (tcsh vs bash)
    │  ├─ Read shebang line
    │  └─ Set shell_executable: /bin/tcsh or /bin/bash
    │
    ├─ Build shell command
    │  ├─ If tcsh: tcsh -c 'source sourceproj.env && genus -files script.tcl | tee log'
    │  └─ If bash: source sourceproj.env && genus -files script.tcl | tee log
    │
    ├─ Execute via asyncio.create_subprocess_shell
    │  ├─ cwd: work_dir (change to work directory)
    │  ├─ executable: shell_executable (correct shell)
    │  ├─ env: os.environ.copy() (inherited environment)
    │  └─ Timeout: 3600 seconds (1 hour)
    │
    ├─ Capture output
    │  ├─ stdout: captured and logged
    │  ├─ stderr: captured and logged
    │  └─ return_code: 0 (success) or non-zero (failure)
    │
    └─ Return result
       ├─ status: "success" or "failed"
       ├─ return_code: integer
       ├─ error: error message if failed
       └─ log_file: path to log file
```

**Key Feature: Auto-detect Shell Format**

```
sourceproj.env file format detection:

If file starts with "#!/bin/tcsh":
  └─ Use tcsh to source (handles setenv commands)

If file starts with "#!/bin/bash":
  └─ Use bash to source (handles export commands)

Command construction:

TCSH:
  tcsh -c 'source /path/sourceproj.env && genus -files script.tcl -abort_on_error | tee log'
         └─ Entire command in tcsh context
         └─ All setenv commands work
         └─ Variables available to genus

BASH:
  source /path/sourceproj.env && genus -files script.tcl -abort_on_error | tee log
         └─ Bash syntax
         └─ All export commands work
         └─ Variables available to genus
```

---

### 4. DebugAgent (Error Analysis & Recovery)

**File:** `src/agents/debug_agent.py`

**Purpose:** Automatically analyze failures and suggest fixes

**Process:**

```
When stage fails:
  error_info = {
    stage_name: "syn",
    return_code: 1,
    error: "can't read env(RTL_FILELIST): no such element"
  }
    │
    ├─ DebugAgent._analyze_error()
    │  ├─ Read error log
    │  ├─ Extract error patterns
    │  └─ Classify error type
    │
    └─ Try three approaches:
       ├─ Approach 1: Claude Agent SDK
       │  └─ Use Bash, Read, Grep tools to investigate
       │
       ├─ Approach 2: Direct Anthropic API
       │  └─ Send error + log to Claude for analysis
       │
       └─ Approach 3: Pattern matching
          └─ Regex-based heuristics for common errors

Result:
  debug_result = {
    error_type: "missing_environment_variable",
    root_cause: "RTL_FILELIST not set in sourceproj.env",
    suggested_fix: "Add RTL_FILELIST=/path/to/rtl_files.list",
    confidence: 0.95
  }
    │
    └─ Return to graph for retry decision
       ├─ If fix available AND retries < 3: → execute_stage (retry)
       └─ If no fix OR max retries: → handle_result (fail)
```

---

## Data Flow

### End-to-End Request Flow

```
User sends API request:
┌─────────────────────────────────────────────┐
│ POST /flow/execute                          │
│ {                                           │
│   "prompt": "run synthesis and placement",  │
│   "user_id": "bharath",                     │
│   "project": "semicon_19-02",               │
│   "block": "aes_cipher_top",                │
│   "rtl_tag": "bronze_v2",                   │
│   "run_id": "run2"                          │
│ }                                           │
└─────────────────────────────────────────────┘
         │
         ├─ Authenticate user_id
         │
         ├─ Create ConfigManager
         │  ├─ Source sourceproj.env
         │  └─ Load flow_config.yaml
         │
         ├─ Create thread_id: "bharath_aes_cipher_top_run2_20260224_145632"
         │
         ├─ Initialize FlowState
         │  ├─ user_id: "bharath"
         │  ├─ prompt: "run synthesis and placement"
         │  ├─ debug_mode: "interactive"
         │  └─ execution_status: "pending"
         │
         ├─ Invoke PhysicalDesignGraph
         │  │
         │  ├─ Node 1: parse_intent_node
         │  │  └─ Output: intent = {action: "execute", stages: ["syn", "place"]}
         │  │
         │  ├─ Node 2: create_plan_node
         │  │  └─ Output: plan = ["syn", "place"]
         │  │
         │  ├─ Node 3a: execute_stage_node (first iteration)
         │  │  ├─ Stage: "syn" (index 0)
         │  │  ├─ Get tool/script from flow_config: genus / genus_syn.tcl
         │  │  ├─ Call StageExecutor.execute_stage()
         │  │  │  ├─ Resolve paths (work_dir, log_dir, script_path)
         │  │  │  ├─ Detect env format: tcsh
         │  │  │  ├─ Build command: tcsh -c 'source sourceproj.env && genus ...'
         │  │  │  ├─ Execute in asyncio subprocess
         │  │  │  └─ Log output
         │  │  └─ Return: {status: "success", return_code: 0}
         │  │
         │  ├─ Node 3b: execute_stage_node (second iteration)
         │  │  ├─ Stage: "place" (index 1)
         │  │  ├─ Get tool/script from flow_config: innovus / place.tcl
         │  │  ├─ Call StageExecutor.execute_stage()
         │  │  │  ├─ Resolve paths (work_dir under pnr/, etc.)
         │  │  │  ├─ Execute ...
         │  │  │  └─ Log output
         │  │  └─ Return: {status: "success", return_code: 0}
         │  │
         │  └─ Node 5: handle_result_node
         │     ├─ Check: all stages successful
         │     ├─ Compile: execution_status = "completed"
         │     └─ Return summary
         │
         ├─ Checkpoint state (if using Redis/SQLite)
         │  └─ Save final FlowState with thread_id
         │
         └─ Return to user
           ┌────────────────────────────────────────┐
           │ {                                      │
           │   "thread_id": "bharath_..._145632",  │
           │   "status": "completed",               │
           │   "stages_executed": ["syn", "place"], │
           │   "stages_failed": []                  │
           │ }                                      │
           └────────────────────────────────────────┘
```

---

## Multi-User Isolation

### How Multiple Users Don't Interfere

```
User 1 (bharath) sends: run2
User 2 (priya) sends:   run3
(Same time)

┌──────────────────────────┐      ┌──────────────────────────┐
│ bharath's Request        │      │ priya's Request          │
│ ─────────────────        │      │ ─────────────────        │
│ user_id: bharath         │      │ user_id: priya           │
│ run_id: run2             │      │ run_id: run3             │
└──────┬───────────────────┘      └──────┬───────────────────┘
       │                                 │
       ├─ thread_id:                     ├─ thread_id:
       │  bharath_aes_cipher_top_run2_ts │  priya_aes_cipher_top_run3_ts
       │                                 │
       ├─ ConfigManager:                 ├─ ConfigManager:
       │  run_dir: .../bharath/.../run2/ │  run_dir: .../priya/.../run3/
       │                                 │
       ├─ FlowState (checkpointed):      ├─ FlowState (checkpointed):
       │  thread_id: bharath_..._run2    │  thread_id: priya_..._run3
       │                                 │
       ├─ Execution:                     ├─ Execution:
       │  work_dir: .../run2/syn/work/   │  work_dir: .../run3/syn/work/
       │  log_dir:  .../run2/syn/logs/   │  log_dir:  .../run3/syn/logs/
       │  outputs:  .../run2/syn/outputs │  outputs:  .../run3/syn/outputs
       │                                 │
       └─ Results go to:                 └─ Results go to:
          .../bharath/.../run2/          .../priya/.../run3/
```

**Isolation Mechanisms:**

1. **Directory Isolation**
   - Each user/run combo gets separate directory tree
   - Tools run in different work directories
   - Log files don't mix

2. **Thread ID Isolation**
   - Each user session gets unique thread_id
   - Checkpointer isolates state by thread_id
   - State updates don't cross threads

3. **Process Isolation**
   - Each stage runs as separate subprocess
   - No shared memory between users
   - Environment variables sourced per-request

4. **Configuration Isolation**
   - ConfigManager created per-request
   - Each user's flow_config.yaml loaded independently
   - Different ENV_SCRIPTS paths possible

---

## Stage Execution

### Detailed Stage Lifecycle

```
Stage: "init_design"
from flow_config.yaml:
  {
    tool: innovus,
    script: init_design.tcl,
    stage_group: pnr,
    dir_name: init
  }

Execution Steps:

1. ConfigManager.get_stage_tool_script("init_design")
   └─ Returns: ("innovus", "init_design.tcl")

2. ConfigManager.get_tool_script_path("innovus", "init_design.tcl")
   └─ Returns: /proj5/REL/env_scripts/.../innovus/init_design.tcl

3. ConfigManager.get_stage_work_dir("init_design")
   └─ Checks: stage_group="pnr", dir_name="init"
   └─ Returns: /proj5/.../run2/pnr/init/work

4. ConfigManager.get_stage_log_dir("init_design")
   └─ Checks: stage_group="pnr", dir_name="init"
   └─ Returns: /proj5/.../run2/pnr/init/logs

5. StageExecutor.execute_stage()
   ├─ Detect env_file format: tcsh
   ├─ Build command:
   │  tcsh -c 'source /proj5/.../sourceproj.env && \
   │            innovus -files /proj5/.../innovus/init_design.tcl \
   │            -abort_on_error | tee /proj5/.../pnr/init/logs/init_design.log'
   │
   ├─ Execute subprocess:
   │  ├─ cwd: /proj5/.../pnr/init/work
   │  ├─ shell: tcsh
   │  ├─ env: os.environ (inherited)
   │  └─ stdout/stderr: captured
   │
   └─ Return: {status: "success", return_code: 0, log_file: "...log"}

6. PhysicalDesignGraph updates state:
   ├─ stages_executed.append("init_design")
   ├─ stage_results["init_design"] = {status: "success", ...}
   ├─ current_stage_index = 1 (increment to next)
   └─ error_info = None (clear on success)

7. Check routing:
   ├─ error_info is None (success)
   ├─ current_stage_index < len(plan) (more stages)
   └─ Route: execute_stage (continue to next stage)
```

**What Happens in TCL Script:**

```tcl
# init_design.tcl
set design_name $env(BLOCK_NAME)           # Read from sourced env
set top_module $env(TOP_MODULE)            # "aes_cipher_top"

# Create work directory structure
if {![file exists "./outputs"]} {
    file mkdir "./outputs"
}

# Read previous stage outputs
read_def ../place/outputs/$design_name.def

# Run innovus commands
init_design -ioFile ./io.io

# Generate outputs
write_def ./outputs/$design_name.def
write_sdc ./outputs/$design_name.sdc

puts "Design initialization complete"
exit
```

---

## State Management

### FlowState Journey

```
Initial State (when request arrives):
{
  user_id: "bharath",
  run_id: "run2",
  prompt: "run pnr stages",
  debug_mode: "interactive",
  intent: None,
  plan: [],
  current_stage_index: 0,
  stages_executed: [],
  stages_failed: [],
  stage_results: {},
  error_info: None,
  error_retry_count: 0,
  execution_status: "pending"
}

After parse_intent_node:
{
  ... (above) ...
  intent: {action: "execute", stages: ["init_design", "place", "route"], ...},
  execution_status: "in_progress"
}

After create_plan_node:
{
  ... (above) ...
  plan: ["init_design", "place", "route"]
}

During execute_stage_node (init_design):
{
  ... (above) ...
  current_stage_index: 0,
  stage_results: {
    "init_design": {status: "success", return_code: 0, ...}
  },
  stages_executed: ["init_design"],
  error_info: None
}
  ↓ (increment index)
{
  current_stage_index: 1  # Now pointing to "place"
}

During execute_stage_node (place):
{
  current_stage_index: 1,
  stage_results: {
    "init_design": {...},
    "place": {status: "success", return_code: 0, ...}
  },
  stages_executed: ["init_design", "place"],
  error_info: None
}
  ↓ (increment index)
{
  current_stage_index: 2  # Now pointing to "route"
}

During execute_stage_node (route - suppose it fails):
{
  current_stage_index: 2,
  stage_results: {
    "init_design": {...},
    "place": {...},
    "route": {status: "failed", return_code: 1, error: "..."}
  },
  stages_executed: ["init_design", "place"],
  stages_failed: ["route"],
  error_info: {
    error: "routing failed due to congestion",
    stage: "route"
  },
  error_retry_count: 0
  ──→ Routes to: debug_stage
}

During debug_stage_node:
{
  error_info: {
    error: "routing failed due to congestion",
    root_cause: "timing constraints too tight"
  },
  debug_result: {
    action: "retry",
    suggested_fix: "increase timing margin"
  },
  error_retry_count: 1  # incremented
  ──→ Routes to: execute_stage (retry route)
}

During execute_stage_node (route - retry):
{
  current_stage_index: 2,  # Still on route (retrying)
  error_retry_count: 1,
  stage_results: {
    "route": {status: "failed (attempt 2)", ...}  # Still failed
  }
  ──→ If retry_count < 3: debug_stage
      Else: handle_result
}

Final State (handle_result_node):
{
  user_id: "bharath",
  run_id: "run2",
  prompt: "run pnr stages",
  plan: ["init_design", "place", "route"],
  stages_executed: ["init_design", "place"],
  stages_failed: ["route"],
  error_info: {last error},
  execution_status: "failed",
  end_time: "2026-02-24T14:56:32Z"
}
  └─ Checkpointed to database with thread_id
  └─ Returned to user as response
```

---

## Error Handling & Recovery

### Error Flow

```
Stage execution fails:
  process.returncode != 0
      │
      ├─ Capture stderr
      ├─ Set error_info = {error: stderr, stage: stage_name}
      └─ Route: → debug_stage

DebugAgent analyzes error:
  ├─ Read log file
  ├─ Parse error message
  ├─ Match patterns
  └─ Suggest fix (if confident)

Possible outcomes:

1. Error recognized & fix suggested
   error_retry_count < max_retries (3)
   └─ Route: → execute_stage (retry with fix)

2. Error recognized but max retries exceeded
   error_retry_count >= 3
   └─ Route: → handle_result (give up)

3. Error not recognized
   debug_result = None
   └─ Route: → handle_result (log error, stop)

4. Multiple errors
   Keep retrying with different strategies
   Until: success OR max retries OR unrecoverable error
```

**Retry Logic:**

```python
# In _route_after_execution()
if error_info is None:
    # Success - continue to next stage
    if current_stage_index < len(plan):
        return "execute_stage"  # Continue
    else:
        return "handle_result"   # All done
else:
    # Failure - go to debug
    return "debug_stage"

# In _route_after_debug()
error_retry_count = state.get("error_retry_count", 0)
max_retries = state.get("max_retries", 3)

if debug_result["action"] == "retry" and error_retry_count < max_retries:
    return "execute_stage"  # Retry
else:
    return "handle_result"  # Give up
```

---

## File Structure

```
/proj1/pd/users/testcase/Bharath/proj/new_py_flow/
│
├── src/
│   ├── __init__.py
│   │
│   ├── config/
│   │   ├── __init__.py
│   │   └── config_manager.py              ← Sources env, loads YAML
│   │
│   ├── executor/
│   │   ├── __init__.py
│   │   └── stage_executor.py              ← Executes stages
│   │
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── physical_design_graph.py       ← LangGraph orchestration (5 nodes)
│   │   ├── debug_agent.py                 ← Error analysis
│   │   └── orchestrator.py                ← Legacy (deprecated)
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   └── flow_api.py                    ← FastAPI endpoints
│   │
│   ├── tracker/
│   │   └── langgraph_saver.py             ← Checkpointing (SQLite/Redis)
│   │
│   └── main.py                            ← Server startup
│
├── sourceproj.env.template                ← Environment file template
├── flow_config.yaml.template              ← Stage definitions template
│
├── SETUP_GUIDE.md                         ← Setup instructions
├── MIGRATION_GUIDE.md                     ← Directory structure migration
├── TCSH_SHELL_FIX.md                      ← Shell format handling
└── STUDY_GUIDE.md                         ← This file

/proj5/projects/semicon_19-02/pd/users/bharath/aes_cipher_top/bronze_v2/run2/
│
├── sourceproj.env                         ← Actual environment (tcsh format)
├── flow_config.yaml                       ← Actual stage definitions
│
├── syn/
│   ├── work/                              ← Genus runs here
│   ├── logs/
│   │   └── syn.log                        ← Execution log
│   └── outputs/
│       ├── aes_cipher_top.v               ← Generated HDL
│       └── aes_cipher_top.sdc             ← Generated constraints
│
├── pnr/
│   ├── init/
│   │   ├── work/                          ← Innovus runs here
│   │   ├── logs/
│   │   │   └── init_design.log
│   │   └── outputs/
│   │
│   ├── place/
│   │   ├── work/
│   │   ├── logs/
│   │   └── outputs/
│   │
│   └── route/
│       ├── work/
│       ├── logs/
│       └── outputs/
│
└── reports/  (optional - created by TCL scripts)
    ├── qor.rpt
    ├── timing.rpt
    └── ...
```

---

## Configuration System

### flow_config.yaml Structure

```yaml
stages:
  syn:                           # Stage name
    tool: genus                  # Tool to use
    script: genus_syn.tcl        # Script file in ENV_SCRIPTS/genus/
    timeout: 3600               # Execution timeout (seconds)
    description: Synthesis       # Human-readable description

  init_design:
    tool: innovus
    script: init_design.tcl
    timeout: 1800
    description: Design initialization
    stage_group: pnr            # ← Grouping (optional)
    dir_name: init              # ← Custom directory name (optional)

  place:
    tool: innovus
    script: place.tcl
    timeout: 3600
    description: Placement
    stage_group: pnr            # Belongs to pnr group

stage_groups:
  pnr:                          # Group name
    base_dir: pnr               # All pnr stages go under pnr/
    stages:
      - init_design
      - floorplan
      - place
      - cts
      - post_cts
      - route
      - postroute
      - chip_finish

  signoff:                      # No base_dir - stages at run root
    stages:
      - qrc
      - sta
      - pv
      - lec

  flow:                         # Convenience group
    stages:
      - syn
      - init_design
      - floorplan
      - place
      - cts
      - post_cts
      - route
      - postroute
      - chip_finish
      - qrc
      - sta
      - pv
      - lec
```

### sourceproj.env Structure

```bash
#!/bin/tcsh                     # Format indicator

# Project details
setenv PROJ_ROOT "/proj5/projects/semicon_19-02/"
setenv PROJ_NAME "semicon_19-02"
setenv BLOCK_NAME "aes_cipher_top"

# Critical for tools
setenv ENV_SCRIPTS "/proj5/REL/env_scripts/projects/semicon_19-02/latest/tools_scripts"
setenv RTL_FILELIST "/path/to/rtl_files.list"
setenv SDC "/path/to/constraints.sdc"

# Tool environment setup
source $CAD_ROOT/env_scripts/tools/genus/...env
source $CAD_ROOT/env_scripts/tools/innovus/...env

# Used by TCL scripts
setenv TECH_LIB "/path/to/tech/lib"
setenv STANDARD_CELLS "/path/to/std/cells"
```

---

## Key Decisions & Why

### 1. Why LangGraph (StateGraph)?

**Decision:** Use LangGraph StateGraph for orchestration

**Alternatives:** Direct Python functions, Airflow, Prefect

**Why LangGraph:**
- ✅ Stateless by design (multi-user safe)
- ✅ Built-in checkpointing for crash recovery
- ✅ Async/await support
- ✅ TypedDict for state (type-safe)
- ✅ Conditional routing (if/then logic)
- ✅ Minimal overhead
- ✅ Easy to debug (visualize graph)

### 2. Why ConfigManager Per-Request?

**Decision:** Create ConfigManager fresh for each request

**Alternative:** Global ConfigManager for all users

**Why Per-Request:**
- ✅ Each user gets isolated configuration
- ✅ Different run directories per user
- ✅ No state sharing between users
- ✅ Easier to debug (each user's config independent)
- ✅ Supports horizontal scaling (multiple servers)

### 3. Why Stage Groups + base_dir?

**Decision:** Support nested directories with stage groups

**Alternative:** Flat directory structure, or hard-code paths

**Why This Approach:**
- ✅ Matches Makefile structure (pnr/, signoff/)
- ✅ Flexible for different projects
- ✅ Handles name mappings (init_design → init)
- ✅ Easy to reconfigure without code changes
- ✅ Clear organization

### 4. Why Auto-Detect Shell Format?

**Decision:** Detect tcsh vs bash and use appropriate shell

**Alternative:** Force users to convert to bash, or always use tcsh

**Why Auto-Detect:**
- ✅ Works with existing setups (tcsh sourceproj.env)
- ✅ Supports both formats transparently
- ✅ No user configuration needed
- ✅ Handles migration gracefully
- ✅ Future-proof (easy to add more formats)

### 5. Why Async/Await for Tool Execution?

**Decision:** Use asyncio.create_subprocess_shell for parallel stages

**Alternative:** Synchronous subprocess.run (blocks), threading

**Why Async:**
- ✅ Multiple stages run concurrently
- ✅ Non-blocking I/O
- ✅ Better scalability
- ✅ Integrates with FastAPI
- ✅ Clean error handling

### 6. Why Thread-ID Based Isolation?

**Decision:** Create unique thread_id per user/run combination

**Alternative:** Global locks, database per user, file locking

**Why Thread-ID:
- ✅ LangGraph native support (checkpointer)
- ✅ Clean separation of concerns
- ✅ Easy to track flow history
- ✅ Enables resumption from checkpoints
- ✅ Scales horizontally

---

## How Everything Connects

### Simplified Flow

```
User Request
    │
    ├─ Authenticate (verify API key → user_id)
    │
    ├─ Create ConfigManager (read sourceproj.env + flow_config.yaml)
    │
    ├─ Create thread_id (unique per user/run)
    │
    ├─ Initialize FlowState (metadata + empty results)
    │
    ├─ Invoke PhysicalDesignGraph
    │  │
    │  ├─ parse_intent_node: "run pnr" → ["init_design", "place", "route"]
    │  │
    │  ├─ create_plan_node: stages → execution order
    │  │
    │  ├─ execute_stage_node × N (for each stage)
    │  │  ├─ Get tool/script from flow_config
    │  │  ├─ Resolve paths (work_dir, script_path)
    │  │  ├─ Call StageExecutor
    │  │  │  ├─ Detect env format (tcsh/bash)
    │  │  │  ├─ Build shell command
    │  │  │  ├─ Execute subprocess
    │  │  │  └─ Log output
    │  │  └─ Update results
    │  │
    │  ├─ [If error] debug_stage_node
    │  │  ├─ Analyze error log
    │  │  ├─ Try fix (if available)
    │  │  └─ Decide: retry or fail
    │  │
    │  └─ handle_result_node: Compile final summary
    │
    ├─ Checkpoint state (save to database)
    │
    └─ Return response to user
```

### What Makes It Multi-User?

1. **Isolation at API level:** Each request includes user_id
2. **Isolation at state level:** FlowState + thread_id unique per user
3. **Isolation at filesystem level:** Different directories per user/run
4. **Isolation at process level:** Tool processes run in separate work dirs
5. **Isolation at database level:** Checkpointer keyed by thread_id

**Result:** 10 users can run flows simultaneously with zero interference! 🎉

---

## Summary

This system is a **multi-user, fault-tolerant physical design flow orchestrator** that:

- ✅ Manages complex EDA tool chains (Genus → Innovus → Calibre)
- ✅ Isolates users completely (no interference)
- ✅ Recovers from failures automatically (error analysis + retry)
- ✅ Handles environment sourcing (tcsh/bash auto-detect)
- ✅ Supports flexible stage definitions (YAML-based)
- ✅ Checkpoints state for resumption
- ✅ Scales to multiple users concurrently
- ✅ Provides comprehensive logging and debugging

Perfect for managing semiconductor design flows! 🚀
