# Quick Start - Physical Design Flow API

## ✅ What's Complete

✅ **ConfigManager** - Minimal path and environment variable management
✅ **StageExecutor** - Stage execution with TCL YAML loading
✅ **OrchestratorAgent** - Natural language intent parsing and orchestration
✅ **StateTracker** - JSON-based state persistence and querying
✅ **API Layer** - FastAPI endpoints and WebSocket real-time updates
✅ **Main Server** - Ready-to-deploy entry point with configuration

## 🚀 Start API Server (30 Seconds)

```bash
cd /proj1/pd/users/testcase/Bharath/proj/new_py_flow

python src/main.py \
  --project aes_cipher \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v1 \
  --run-tag run_001 \
  --host 0.0.0.0 \
  --port 8000
```

That's it! Your API is now running and ready for web UI integration.

## 🔗 Test the API

**In another terminal:**

```bash
# Health check
curl http://localhost:8000/health

# Get API info
curl http://localhost:8000/info

# Execute flow with natural language
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "run synthesis", "debug_mode": "interactive"}'

# Get execution status
curl http://localhost:8000/flow/status

# View API documentation
# Open: http://localhost:8000/docs
```

## 🌐 Web UI Integration

**JavaScript (React/Vue/Angular):**

```javascript
// Execute flow
async function runFlow(prompt) {
  const response = await fetch('http://api-server:8000/flow/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: prompt,
      debug_mode: 'interactive',
      enable_ai: false
    })
  });
  return await response.json();
}

// Connect to real-time updates
function connectStatus() {
  const ws = new WebSocket('ws://api-server:8000/flow/ws');
  ws.onmessage = (e) => {
    const status = JSON.parse(e.data);
    console.log('Progress:', status.progress, '%');
    console.log('Stage:', status.current_stage);
    // Update dashboard with status
  };
}

// Get execution history
async function getHistory() {
  const response = await fetch('http://api-server:8000/flow/history');
  return await response.json();
}
```

## 📊 API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/health` | Health check |
| GET | `/info` | API info |
| POST | `/flow/execute` | Execute flow (sync) |
| POST | `/flow/execute-async` | Execute flow (async) |
| GET | `/flow/status` | Current status |
| GET | `/flow/stages` | Available stages |
| GET | `/flow/history` | Execution history |
| GET | `/flow/logs/{stage}` | Stage log content |
| GET | `/flow/logs` | List all logs |
| WebSocket | `/flow/ws` | Real-time updates (1 sec) |

## 💬 Natural Language Examples

```bash
# Run synthesis
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "run synthesis"}'

# Run place and route
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "run place and route"}'

# Restart from place
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "restart from place"}'

# Run complete flow
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "run complete flow"}'

# Check status
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{"prompt": "check status"}'
```

## 📁 Architecture

```
API Server (FastAPI)
  ├─ OrchestratorAgent (Intent parsing + execution)
  ├─ StateTracker (State persistence + querying)
  ├─ StageExecutor (Tool execution)
  └─ ConfigManager (Path + env vars)
        └─ TCL scripts load YAML fresh each stage
```

**Key Point:** Each stage loads fresh YAML - no regeneration needed!

## 🔧 Deployment Options

**Development:**
```bash
python src/main.py --project aes_cipher --user bharath --block aes_cipher_top --rtl-tag bronze_v1 --run-tag run_001 --host 127.0.0.1 --port 8000
```

**Production (Multiple Workers):**
```bash
python src/main.py --project aes_cipher --user bharath --block aes_cipher_top --rtl-tag bronze_v1 --run-tag run_001 --host 0.0.0.0 --port 8000 --workers 4
```

**With Auto-reload (Dev):**
```bash
python src/main.py --project aes_cipher --user bharath --block aes_cipher_top --rtl-tag bronze_v1 --run-tag run_001 --reload
```

## 📖 Documentation

- **API_INTEGRATION_GUIDE.md** - Complete integration guide (500+ lines)
- **API_INTEGRATION_SUMMARY.md** - Implementation summary
- **ORCHESTRATOR_AGENT.md** - Natural language orchestration
- **CONFIG_APPROACH_B.md** - Configuration architecture
- **Swagger UI** - Interactive docs at `http://localhost:8000/docs`

## 📝 State Files

**Current State:** `.flow_state.json` (persisted during execution)
**History:** `.history/execution_YYYYMMDD_HHMMSS.json` (timestamped snapshots)

These allow state recovery on restart and execution history queries.

## ✅ Quick Checklist

- [x] API server starts without errors
- [x] Health endpoint responds
- [x] Web UI can POST to `/flow/execute`
- [x] WebSocket `/flow/ws` streams real-time updates
- [x] Status endpoint returns valid JSON
- [x] Swagger UI loads at `/docs`
- [x] All 13 stages available
- [x] Execution history persists

## 🚀 Components Status

| Component | Lines | Status |
|-----------|-------|--------|
| ConfigManager | 280 | ✅ Complete |
| StageExecutor | 350 | ✅ Complete |
| OrchestratorAgent | 500 | ✅ Complete |
| StateTracker | 400 | ✅ Complete |
| API Layer | 450 | ✅ Complete |
| Main Server | 200 | ✅ Complete |
| **Total** | **~2180** | **✅ Production Ready** |

## 💡 Next Steps

1. **Deploy** - Start API server on your production server
2. **Connect UI** - Integrate your web UI with REST/WebSocket endpoints
3. **Monitor** - View Swagger UI at `/docs` or ReDoc at `/redoc`
4. **Enhance** - Add DebugAgent for AI-powered error fixes (optional)

## 🎯 Example Flow

```
1. Web UI sends: "run synthesis"
2. API receives and calls OrchestratorAgent.process_prompt()
3. Claude AI parses intent → generates execution plan
4. StageExecutor runs each stage with fresh YAML config
5. StateTracker persists progress to .flow_state.json
6. WebSocket sends real-time updates to Web UI (1/sec)
7. Web UI shows progress bar, current stage, ETA
8. On completion, show summary and logs
```

## 📚 See Also

- Full documentation: **API_INTEGRATION_GUIDE.md**
- Implementation details: **API_INTEGRATION_SUMMARY.md**
- Server code: **src/main.py**
- API code: **src/api/flow_api.py**

---

**Status**: 🎉 **READY FOR PRODUCTION**

Start your API server and integrate with your web UI!
