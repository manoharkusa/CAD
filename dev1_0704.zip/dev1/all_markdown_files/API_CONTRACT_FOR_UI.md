# API Contract for UI Integration

## Overview

This document defines the exact API contract between the Physical Design Flow Web UI and the backend server.

## Base URL

```
http://localhost:8000
```

## Directory Structure Mapping

The UI dropdowns map to the file system:

```
UI Dropdowns                    Directory Structure
─────────────                   ───────────────────
Project (dropdown)         →    /proj/{project_name}/...
User (dropdown)            →    .../pd/users/{user_name}/...
Block (dropdown)           →    .../{block_name}/...
RTL Tag (dropdown)         →    .../{rtl_tag}/...
Experiment (dropdown)      →    .../{experiment_name}/
```

## API Endpoints

### 1. Execute Experiment (Start Flow)

**Endpoint**: `POST /flow/execute`

**Request**:
```json
{
  "prompt": "string",
  "debug_mode": "string (optional, default: 'interactive')",
  "enable_ai": "boolean (optional, default: false)",
  "user_id": "string (from UI dropdown)",
  "project": "string (from UI dropdown)",
  "block": "string (from UI dropdown)",
  "rtl_tag": "string (from UI dropdown)",
  "experiment_name": "string (from UI dropdown)"
}
```

**Response (200 OK)**:
```json
{
  "thread_id": "string",
  "experiment_name": "string",
  "status": "string (pending|in_progress|completed|failed)",
  "stages_executed": ["string"],
  "stages_failed": ["string"],
  "duration": "float",
  "start_time": "string (ISO 8601)",
  "end_time": "string (ISO 8601, null if running)"
}
```

**Example Request**:
```bash
curl -X POST http://localhost:8000/flow/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "run synthesis and place",
    "debug_mode": "interactive",
    "user_id": "alice",
    "project": "aes_cipher",
    "block": "aes_top",
    "rtl_tag": "v1.0",
    "experiment_name": "baseline"
  }'
```

**Example Response**:
```json
{
  "thread_id": "alice_aes_top_baseline_20260216_143022",
  "experiment_name": "baseline",
  "status": "in_progress",
  "stages_executed": [],
  "stages_failed": [],
  "duration": 0.0,
  "start_time": "2026-02-16T14:30:22.123456",
  "end_time": null
}
```

**UI Action After Response**:
- Save `thread_id` for this experiment
- Show progress UI with status "in_progress"
- Display start_time
- Start polling status endpoint every 5 seconds

---

### 2. Check Experiment Status

**Endpoint**: `GET /flow/status`

**Query Parameters**:
- `thread_id` (required): From execute response

**Response (200 OK)**:
```json
{
  "thread_id": "string",
  "run_id": "string",
  "status": "string (pending|in_progress|completed|failed)",
  "current_stage": "string (null if completed)",
  "stages": {
    "stage_name": "string (completed|failed|pending|in_progress)"
  },
  "progress_percent": "integer (0-100)",
  "start_time": "string (ISO 8601)",
  "end_time": "string (ISO 8601, null if running)",
  "duration": "float"
}
```

**Example Request**:
```bash
curl "http://localhost:8000/flow/status?thread_id=alice_aes_top_baseline_20260216_143022"
```

**Example Response**:
```json
{
  "thread_id": "alice_aes_top_baseline_20260216_143022",
  "run_id": "baseline",
  "status": "in_progress",
  "current_stage": "place",
  "stages": {
    "syn": "completed",
    "init_design": "completed",
    "floorplan": "completed",
    "place": "in_progress",
    "cts": "pending",
    "route": "pending"
  },
  "progress_percent": 50,
  "start_time": "2026-02-16T14:30:22.123456",
  "end_time": null,
  "duration": 0.0
}
```

**UI Action Based on Response**:
- Update progress bar: `progress_percent`
- Update stage list: Show status for each stage in `stages`
- Highlight current_stage if not null
- If status == "completed" or "failed": Stop polling
- Update duration display

**Error Handling**:
```json
{
  "detail": "Thread alice_aes_top_baseline_20260216_143022 not found"
}
```
Status Code: 404

---

### 3. Get Full Experiment History

**Endpoint**: `GET /thread/{thread_id}/history`

**Response (200 OK)**:
```json
{
  "thread_id": "string",
  "state": {
    "prompt": "string",
    "user_id": "string",
    "run_id": "string",
    "stages_executed": ["string"],
    "stages_failed": ["string"],
    "stage_results": {
      "stage_name": {
        "status": "string (success|failed)",
        "iterations": "integer",
        "actions": ["string"],
        "final_output": "string",
        "files_modified": ["string"],
        "error_message": "string (null if success)"
      }
    },
    "execution_status": "string"
  },
  "checkpoint_id": "string"
}
```

**Example Request**:
```bash
curl "http://localhost:8000/thread/alice_aes_top_baseline_20260216_143022/history"
```

**UI Usage**:
- Display detailed execution results
- Show stage-by-stage breakdown
- Display error messages if status == "failed"
- Show files modified per stage

---

### 4. Resume Experiment

**Endpoint**: `POST /thread/{thread_id}/resume`

**Request**: Empty body

**Response (200 OK)**:
```json
{
  "thread_id": "string",
  "experiment_name": "string",
  "status": "string",
  "stages_executed": ["string"],
  "stages_failed": ["string"],
  "duration": "float",
  "start_time": "string (ISO 8601)",
  "end_time": "string (ISO 8601, null if continuing)"
}
```

**Example Request**:
```bash
curl -X POST "http://localhost:8000/thread/alice_aes_top_baseline_20260216_143022/resume"
```

**UI Usage**:
- Show resume button if experiment failed or was interrupted
- After resume: Return to status polling (same as /flow/execute)
- Update progress UI

**Error Handling**:
- 404: Thread not found
- 501: Multi-user mode not enabled

---

### 5. Delete Experiment (Cleanup)

**Endpoint**: `DELETE /thread/{thread_id}`

**Response (200 OK)**:
```json
{
  "message": "string"
}
```

**Example Request**:
```bash
curl -X DELETE "http://localhost:8000/thread/alice_aes_top_baseline_20260216_143022"
```

**UI Usage**:
- Show delete button in experiment list/history
- Confirm deletion before calling API
- Refresh experiment list after deletion

---

### 6. List All Experiments (Optional)

**Endpoint**: `GET /threads`

**Response (200 OK)**:
```json
{
  "threads": ["string"]
}
```

**Example Response**:
```json
{
  "threads": [
    "alice_aes_top_baseline_20260216_143022",
    "alice_aes_top_opt_v1_20260216_143100",
    "alice_sha_top_expr_001_20260216_144000",
    "bob_aes_mid_synthesis_v2_20260216_150000"
  ]
}
```

**UI Usage** (Optional):
- Show all experiments in a list/history view
- Filter by user if needed

---

## UI Workflow

### Scenario 1: Run New Experiment

```
1. User selects from dropdowns:
   - Project: "aes_cipher"
   - User: "alice"
   - Block: "aes_top"
   - RTL Tag: "v1.0"
   - Experiment: "baseline"

2. User enters prompt:
   - "run synthesis and place"

3. UI calls: POST /flow/execute
   Request:
   {
     "prompt": "run synthesis and place",
     "user_id": "alice",
     "project": "aes_cipher",
     "block": "aes_top",
     "rtl_tag": "v1.0",
     "experiment_name": "baseline"
   }

4. UI receives thread_id: "alice_aes_top_baseline_20260216_143022"

5. UI starts polling: GET /flow/status?thread_id=alice_aes_top_baseline_20260216_143022
   - Poll every 5 seconds
   - Update progress bar
   - Show current stage
   - Stop polling when status == "completed" or "failed"

6. When completed:
   - Show results
   - Offer resume, view history, or delete options
```

### Scenario 2: View Completed Experiment

```
1. User clicks on experiment in history list

2. UI calls: GET /thread/{thread_id}/history

3. UI displays:
   - All stages with status
   - Error messages if failed
   - Files modified
   - Execution duration
```

### Scenario 3: Resume Failed Experiment

```
1. User sees "FAILED" status

2. User clicks "Resume"

3. UI calls: POST /thread/{thread_id}/resume

4. UI resumes polling: GET /flow/status?thread_id=...
   - Continues from where it left off
   - Shows checkpoint recovery message
```

---

## Error Responses

All error responses follow this format:

```json
{
  "detail": "string (error message)"
}
```

### Common Error Cases

**1. Thread Not Found (404)**
```bash
curl "http://localhost:8000/flow/status?thread_id=invalid"
```
```json
{
  "detail": "Thread invalid not found"
}
```

**2. Multi-User Mode Disabled (501)**
```json
{
  "detail": "Multi-user mode not enabled"
}
```

**3. Invalid Request (422)**
```json
{
  "detail": "Invalid input: ..."
}
```

**4. Server Error (500)**
```json
{
  "detail": "Internal server error: ..."
}
```

---

## UI Implementation Guide

### Dropdown Loading

On page load:

```javascript
// Get available projects, users, blocks, rtl_tags, experiments
// from directory structure or API endpoint (not provided, use file browser)

// Example structure:
const projects = ["aes_cipher", "sha_top", "ddr_controller"];
const users = ["alice", "bob", "charlie"];
const blocks = ["aes_top", "aes_mid", "aes_sram"];
const rtlTags = ["v1.0", "v1.1", "v2.0"];
const experiments = ["baseline", "opt_v1", "synthesis_v2"];
```

### Status Polling

```javascript
async function pollStatus(threadId) {
  const response = await fetch(`/flow/status?thread_id=${threadId}`);
  const status = await response.json();

  // Update UI
  updateProgressBar(status.progress_percent);
  updateStageList(status.stages);
  updateCurrentStage(status.current_stage);

  // Continue polling if running
  if (status.status === "in_progress") {
    setTimeout(() => pollStatus(threadId), 5000);  // Poll every 5 seconds
  } else {
    // Show final result
    showResults(status);
  }
}
```

### Execute and Poll

```javascript
async function executeExperiment(params) {
  // 1. Execute
  const execResponse = await fetch("/flow/execute", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params)
  });
  const result = await execResponse.json();
  const threadId = result.thread_id;

  // 2. Save thread_id for later
  localStorage.setItem("currentThreadId", threadId);

  // 3. Start polling
  pollStatus(threadId);
}
```

---

## Thread ID Format

For reference, thread_id format is:
```
{user}_{block}_{experiment}_{timestamp}

Examples:
- alice_aes_top_baseline_20260216_143022
- bob_sha_top_opt_v1_20260216_143100
- charlie_ddr_synthesis_v2_20260216_144000
```

This enables:
- Query all experiments for a user: Use thread_id prefix "alice_"
- Query all experiments on a block: Use thread_id prefix "alice_aes_top_"
- Query specific experiment: Use full thread_id

---

## Best Practices

### 1. Always Include All Dropdowns

```javascript
// GOOD
{
  "prompt": "run synthesis",
  "user_id": "alice",
  "project": "aes_cipher",
  "block": "aes_top",
  "rtl_tag": "v1.0",
  "experiment_name": "baseline"
}

// BAD (missing parameters)
{
  "prompt": "run synthesis",
  "user_id": "alice"
}
```

### 2. Handle Polling Gracefully

```javascript
// Set timeout in case polling hangs
const maxAttempts = 360;  // 30 minutes with 5-second poll
let attempts = 0;

async function pollWithTimeout(threadId) {
  if (attempts++ > maxAttempts) {
    showError("Flow execution timeout");
    return;
  }

  const status = await getStatus(threadId);
  if (status.status === "in_progress") {
    setTimeout(() => pollWithTimeout(threadId), 5000);
  }
}
```

### 3. Display Meaningful Messages

```javascript
// Based on status field:
"pending"      → "Waiting to start..."
"in_progress"  → "Running stage: {current_stage}"
"completed"    → "✓ Experiment completed successfully"
"failed"       → "✗ Experiment failed. Error: {error_message}"
```

### 4. Store Thread IDs

```javascript
// Save experiment history
const experiments = JSON.parse(localStorage.getItem("experiments") || "[]");
experiments.push({
  threadId: response.thread_id,
  experimentName: response.experiment_name,
  timestamp: new Date().toISOString(),
  status: "in_progress"
});
localStorage.setItem("experiments", JSON.stringify(experiments));
```

---

## Summary

✅ **Core Endpoints**:
- POST /flow/execute - Start experiment
- GET /flow/status?thread_id=... - Poll status
- GET /thread/{thread_id}/history - Get results
- POST /thread/{thread_id}/resume - Resume failed experiment
- DELETE /thread/{thread_id} - Cleanup

✅ **Key Fields**:
- `thread_id` - Unique per experiment run
- `experiment_name` - Echo of selected experiment
- `status` - Current execution state
- `progress_percent` - Visual progress indicator

✅ **UI Parameters**:
- From dropdown: user_id, project, block, rtl_tag, experiment_name
- From text input: prompt
- From settings: debug_mode (optional)

✅ **Error Handling**:
- 404: Thread not found
- 501: Multi-user mode disabled
- 422: Invalid request
- 500: Server error

Ready for UI integration!
