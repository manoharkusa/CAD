# Migration Guide: StateTracker → LangGraph

This guide explains how to upgrade from the current StateTracker-based architecture to LangGraph for multi-user support.

## Quick Summary

| Aspect | Before (StateTracker) | After (LangGraph) |
|--------|----------------------|-------------------|
| **File-based State** | `.flow_state.json` | SQLite/PostgreSQL DB |
| **Multi-user** | ❌ Race conditions | ✅ Thread isolation |
| **Concurrent Flows** | ❌ 1 flow at a time | ✅ 10+ simultaneous |
| **Crash Recovery** | ❌ Manual | ✅ Automatic |
| **Components** | OrchestratorAgent + StateTracker | PhysicalDesignGraph + LangGraphSaver |
| **Dependencies** | anthropic, fastapi | anthropic, fastapi, **langgraph** |

---

## Phase 1: Installation & Setup (Week 1)

### Step 1: Install LangGraph

```bash
# Install LangGraph
pip install langgraph>=0.0.30

# Or add to requirements.txt:
langgraph>=0.0.30
anthropic>=0.7.0
fastapi
uvicorn
pyyaml
```

### Step 2: Verify Installation

```python
# Test import
from langgraph.graph import StateGraph
from src.tracker.langgraph_saver import get_saver

print("✓ LangGraph installed and working")
```

---

## Phase 2: Component Migration (Week 2-3)

### What Stays the Same ✅

```python
# No changes needed to:
- DebugAgent (src/agents/debug_agent.py)
- StageExecutor (src/executor/stage_executor.py)
- ConfigManager (src/config/)
- STAGES definitions
```

### What Changes 🔄

**Remove (Deprecated)**:
```
src/agents/orchestrator.py        # Replaced by PhysicalDesignGraph
src/tracker/state_tracker.py      # Replaced by LangGraph Saver
```

**Add (New)**:
```
src/agents/physical_design_graph.py  # LangGraph-based orchestration
src/tracker/langgraph_saver.py       # Thread-safe checkpoint storage
```

---

## Phase 3: API Integration (Week 3)

### Current API (StateTracker-based)

```python
# src/main.py (BEFORE)

orchestrator_agent = OrchestratorAgent(
    config_manager=config_manager,
    stage_executor=stage_executor,
    state_tracker=state_tracker,
)
orchestrator_agent.debug_agent = debug_agent

# Execution
result = await orchestrator_agent.process_prompt(
    prompt="run synthesis",
    debug_mode="auto"
)
```

### New API (LangGraph-based)

```python
# src/main.py (AFTER)

from src.tracker.langgraph_saver import get_saver, create_thread_id

# Create graph-based orchestrator
design_graph = PhysicalDesignGraph(
    config_manager=config_manager,
    stage_executor=stage_executor,
    debug_agent=debug_agent,
    max_retries=3,
)

# Create checkpoint saver (development)
saver = get_saver(backend="sqlite")

# Execution with multi-user support
thread_id = create_thread_id(user_id="bharath")
result = await design_graph.invoke(
    prompt="run synthesis",
    debug_mode="auto",
    user_id="bharath",
)

# With persistence (LangGraph)
config = {"configurable": {"thread_id": thread_id}}
result = design_graph.get_graph().invoke(state, config)
```

### API Endpoint Updates

#### Before (Single Flow)

```python
@app.post("/flow/execute")
async def execute_flow(prompt: str, debug_mode: str = "auto"):
    result = await orchestrator_agent.process_prompt(prompt, debug_mode)
    return result
```

#### After (Multi-User)

```python
@app.post("/flow/execute")
async def execute_flow(
    prompt: str,
    debug_mode: str = "auto",
    user_id: Optional[str] = None,
):
    # Generate thread ID for this user's flow
    thread_id = create_thread_id(user_id)

    # Initialize state
    state = {
        "prompt": prompt,
        "debug_mode": debug_mode,
        "user_id": user_id,
        # ... other fields
    }

    # Get saver config
    config = {"configurable": {"thread_id": thread_id}}

    # Run graph with persistence
    result = await design_graph.get_graph().ainvoke(
        state,
        config=config,
    )

    return {
        "thread_id": thread_id,
        "user_id": user_id,
        "result": result,
    }


@app.get("/flow/status/{thread_id}")
async def get_flow_status(thread_id: str):
    # Get latest checkpoint for this flow
    config = {"configurable": {"thread_id": thread_id}}
    state = saver.get(config)

    if state:
        return {
            "thread_id": thread_id,
            "status": state.get("execution_status"),
            "stages_executed": state.get("stages_executed", []),
            "stages_failed": state.get("stages_failed", []),
        }
    else:
        return {"error": "Thread not found"}


@app.post("/flow/resume/{thread_id}")
async def resume_flow(thread_id: str):
    # Resume from last checkpoint
    config = {"configurable": {"thread_id": thread_id}}
    state = saver.get(config)

    if not state:
        return {"error": "Thread not found"}

    # Continue execution from checkpointed state
    result = await design_graph.get_graph().ainvoke(
        state,
        config=config,
    )

    return result
```

---

## Phase 4: Data Migration (Week 3)

### Migrate Existing Execution History

```python
"""
Migrate existing .flow_state.json to LangGraph database
"""

import json
from pathlib import Path
from src.tracker.langgraph_saver import get_saver

# Initialize both savers
old_state_file = Path(".flow_state.json")
new_saver = get_saver(backend="sqlite")

if old_state_file.exists():
    # Load old state
    with open(old_state_file) as f:
        old_state = json.load(f)

    # Convert to new format
    new_state = {
        "prompt": old_state.get("current_stage", "unknown"),
        "execution_status": old_state.get("status", "pending"),
        "stages_executed": [
            stage for stage, execution in old_state.get("stages", {}).items()
            if execution["status"] == "completed"
        ],
        "stages_failed": [
            stage for stage, execution in old_state.get("stages", {}).items()
            if execution["status"] == "failed"
        ],
        "stage_results": old_state.get("stages", {}),
        "start_time": old_state.get("start_time"),
    }

    # Save to new saver
    thread_id = f"migrated_{old_state.get('run_id', 'unknown')}"
    config = {"configurable": {"thread_id": thread_id}}
    new_saver.put(config, new_state, metadata={"migrated": True})

    print(f"✓ Migrated execution to thread: {thread_id}")
```

---

## Testing & Validation

### Unit Tests

```python
# tests/test_physical_design_graph.py

import pytest
from src.agents.physical_design_graph import PhysicalDesignGraph, FlowState

@pytest.mark.asyncio
async def test_parse_intent_node(design_graph):
    """Test intent parsing node"""
    state: FlowState = {
        "prompt": "run synthesis",
        "current_stage_index": 0,
    }
    result = await design_graph._parse_intent_node(state)
    assert result["intent"] is not None
    assert "action" in result["intent"]


@pytest.mark.asyncio
async def test_graph_execution(design_graph):
    """Test full graph execution"""
    result = await design_graph.invoke(
        prompt="run synthesis",
        debug_mode="auto",
        user_id="test_user",
    )

    assert result["execution_status"] in ["completed", "failed"]
    assert "stages_executed" in result
    assert "run_id" in result


def test_thread_isolation(saver):
    """Test that concurrent flows don't interfere"""
    config1 = {"configurable": {"thread_id": "user1_flow_1"}}
    config2 = {"configurable": {"thread_id": "user2_flow_1"}}

    state1 = {"stages_executed": ["syn"]}
    state2 = {"stages_executed": ["place"]}

    saver.put(config1, state1)
    saver.put(config2, state2)

    # Verify isolation
    assert saver.get(config1)["stages_executed"] == ["syn"]
    assert saver.get(config2)["stages_executed"] == ["place"]
```

### Integration Tests

```python
# tests/test_multi_user.py

@pytest.mark.asyncio
async def test_concurrent_flows(design_graph, saver):
    """Test multiple concurrent user flows"""

    # Start flow for user1
    thread1 = create_thread_id("user1")
    config1 = get_config_for_thread(thread1)

    # Start flow for user2
    thread2 = create_thread_id("user2")
    config2 = get_config_for_thread(thread2)

    # Both run concurrently
    result1 = await design_graph.invoke("run syn", "auto", "user1")
    result2 = await design_graph.invoke("run pnr", "auto", "user2")

    # Verify no interference
    assert result1["user_id"] == "user1"
    assert result2["user_id"] == "user2"

    # Verify separate checkpoints
    checkpoints1 = saver.get_all(thread1)
    checkpoints2 = saver.get_all(thread2)

    assert len(checkpoints1) > 0
    assert len(checkpoints2) > 0
    # No overlap!
```

---

## Deployment Checklist

### Development Environment

- [ ] Install LangGraph: `pip install langgraph`
- [ ] Create PhysicalDesignGraph instance
- [ ] Initialize SqliteSaver (default)
- [ ] Test single-flow execution
- [ ] Test concurrent flows
- [ ] Verify checkpoint creation in `.langgraph/checkpoints.db`

### Production Environment

- [ ] Install LangGraph and psycopg2: `pip install langgraph psycopg2-binary`
- [ ] Set up PostgreSQL database
- [ ] Initialize PostgresSaver with connection string
- [ ] Update config with DB credentials
- [ ] Test crash recovery (simulate server failure)
- [ ] Load test with multiple concurrent users
- [ ] Monitor database growth
- [ ] Set up automated backups

### Monitoring

```python
# Monitor active flows
from src.tracker.langgraph_saver import CheckpointBrowser

browser = CheckpointBrowser(saver)

# List all threads
threads = browser.list_threads()
print(f"Active flows: {len(threads)}")

# Show specific thread
browser.show_thread_summary("user_123_run_20240115_103045")
```

---

## Rollback Plan (If Issues)

### Quick Rollback

```bash
# If LangGraph causes issues, revert to StateTracker

# 1. Remove LangGraph
pip uninstall langgraph

# 2. Restore original files
git checkout src/agents/orchestrator.py
git checkout src/tracker/state_tracker.py

# 3. Remove new files
rm src/agents/physical_design_graph.py
rm src/tracker/langgraph_saver.py

# 4. Restart server with old code
python src/main.py ...
```

### Data Recovery

```python
# Export LangGraph checkpoints back to JSON
from src.tracker.langgraph_saver import CheckpointBrowser

browser = CheckpointBrowser(saver)
checkpoints = browser.list_checkpoints("user_id_run_xxx")

# Save latest to .flow_state.json
latest = checkpoints[-1]
with open(".flow_state.json", "w") as f:
    json.dump(latest["data"], f, indent=2)
```

---

## Performance Considerations

### Database Size

```
SQLite (.langgraph/checkpoints.db):
- Grows ~500KB per 100 flows
- Typical checkpoint: 5-10KB
- Set up weekly cleanup of old flows

PostgreSQL:
- Better scalability for 1000+ flows
- Connection pooling recommended
- Set up table partitioning by thread_id
```

### Query Performance

```python
# Checkpoint retrieval: <50ms (SQLite), <100ms (PostgreSQL)
# Optimal with index on (thread_id, created_at)
# Already configured in langgraph_saver.py
```

### Disk I/O

```
Checkpoints per flow: ~5-10
Checkpoint size: ~5KB
Total I/O per flow: ~50KB
Per 100 concurrent flows: ~5MB/sec peak
```

---

## Backward Compatibility

### OrchestratorAgent Deprecation

```python
# Keep OrchestratorAgent for backward compatibility but mark deprecated

class OrchestratorAgent:
    """
    DEPRECATED: Use PhysicalDesignGraph instead

    This class is kept for backward compatibility.
    Internally uses PhysicalDesignGraph.
    """

    def __init__(self, ...):
        import warnings
        warnings.warn(
            "OrchestratorAgent is deprecated. Use PhysicalDesignGraph instead.",
            DeprecationWarning,
            stacklevel=2
        )
        self._graph = PhysicalDesignGraph(...)

    async def process_prompt(self, prompt, debug_mode="auto"):
        return await self._graph.invoke(prompt, debug_mode)
```

### Gradual Migration

```
Week 1: Install LangGraph, run tests
Week 2: New code uses PhysicalDesignGraph, old code still works
Week 3: Migrate API endpoints gradually
Week 4: Deprecate StateTracker, full LangGraph usage
Month 2: Remove StateTracker code
```

---

## Troubleshooting

### Issue: "Database is locked" (SQLite)

**Symptom**: Random failures with concurrent access
**Solution**: Use PostgreSQL for production, or increase SQLite timeout

```python
# sqlite3 timeout (in langgraph_saver.py)
conn = sqlite3.connect(
    self.db_path,
    timeout=30.0  # 30 second timeout
)
```

### Issue: Thread ID Conflicts

**Symptom**: Two flows getting same thread_id
**Solution**: Ensure microseconds in thread_id generation

```python
# create_thread_id already includes microseconds
thread_id = f"{user_id}_run_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
```

### Issue: Large Checkpoint Database

**Symptom**: .langgraph/checkpoints.db growing too large
**Solution**: Clean up old checkpoints regularly

```python
# Delete flows older than 30 days
import sqlite3
conn = sqlite3.connect(".langgraph/checkpoints.db")
cursor = conn.cursor()
cursor.execute("""
    DELETE FROM checkpoints
    WHERE created_at < datetime('now', '-30 days')
""")
conn.commit()
```

---

## Next Steps

1. **Week 1**: Install LangGraph, read architecture docs
2. **Week 2**: Run integration tests, validate multi-user support
3. **Week 3**: Migrate API endpoints, test in staging
4. **Week 4**: Deploy to production with PostgreSQL
5. **Ongoing**: Monitor performance, collect metrics

---

## Support & Documentation

- **Architecture**: See `LANGGRAPH_ARCHITECTURE.md`
- **DebugAgent**: See `DEBUG_AGENT.md` (unchanged)
- **API Examples**: See `LANGGRAPH_USAGE_EXAMPLES.md` (coming)
- **Performance Tuning**: See `LANGGRAPH_PERFORMANCE.md` (coming)

