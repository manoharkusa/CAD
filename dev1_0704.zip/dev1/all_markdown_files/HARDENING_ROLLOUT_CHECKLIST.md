# Hardening Pass - End-to-End Merge Rollout Checklist

Date: 2026-03-07

## Scope Completed
- Lifecycle compatibility API is canonical in `dev1/src/main.py`.
- Duplicate lifecycle routes in `dev1/src/api/flow_api.py` are marked deprecated.
- Shared lifecycle runtime bootstrap is centralized in `dev1/src/infra/bootstrap.py`.
- Shared lifecycle helper logic is centralized in `dev1/src/infra/lifecycle_utils.py`.
- Optional dependency hardening added for missing `anthropic` and `claude_agent_sdk`.

## Feature Flag Matrix

### Dev (initial verification)
- `USE_JOB_LIFECYCLE_API=true`
- `USE_POSTGRES_JOB_REPO=false`
- `USE_REDIS_JOB_STATE=false`

Expected:
- Compatibility routes register and respond.
- No hard dependency on Postgres/Redis for boot.

### Integration (persistence checks)
- `USE_JOB_LIFECYCLE_API=true`
- `USE_POSTGRES_JOB_REPO=true`
- `USE_REDIS_JOB_STATE=false`

Expected:
- `POST /jobs` persists to Postgres.
- `GET /jobs/{job_id}/job_status` resolves from Postgres fallback.

### Staging (full E2E path)
- `USE_JOB_LIFECYCLE_API=true`
- `USE_POSTGRES_JOB_REPO=true`
- `USE_REDIS_JOB_STATE=true`

Expected:
- Job enqueue/state path active in Redis.
- WebSocket and lifecycle events available.
- Abort/HITL route behavior active.

### Production (cutover)
- Same as staging.
- Keep deprecations visible for one release cycle, then remove duplicates in `flow_api.py`.

## Smoke Test Sequence

1. Health/info
   - `GET /health`
   - `GET /info`

2. Lifecycle API (compat)
   - `POST /jobs`
   - `GET /jobs/{job_id}/job_status`
   - `POST /jobs/{job_id}/human-input`
   - `POST /jobs/{job_id}/abort`
   - `GET /job_state?job_id=<id>`

3. Worker bridge
   - `POST /flow/execute` with valid request payload
   - confirm job lifecycle status/phase transitions through bridge updates

4. Eventing
   - connect `WS /ws/jobs/{job_id}`
   - verify queued/start/stage/complete (or failure) events

## Operational Safeguards
- If Redis unavailable, keep `USE_REDIS_JOB_STATE=false` and run Postgres-only mode.
- If Postgres unavailable, keep `USE_POSTGRES_JOB_REPO=false` for route-level validation.
- If AI SDKs (`anthropic`, `claude_agent_sdk`) are missing, system now falls back gracefully for intent/debug analysis.

## De-duplication Policy
- Canonical lifecycle endpoints: `dev1/src/main.py`.
- Deprecated mirror endpoints retained temporarily in `dev1/src/api/flow_api.py` only for compatibility.
- Remove deprecated mirror routes after one release cycle and successful staging soak.

## Known Environment Gaps
- `pytest` not currently installed in active venv; automated pytest suite is blocked until installed.

## Suggested Final Validation Commands
- `python -m pip install pytest`
- `python dev1/tests/test_syntax.py`
- `python -m pytest dev1/tests/test_multi_user.py -q`
- `python dev1/tests/test_issue_tracking.py`

(Use your venv-qualified python path in this workspace.)
