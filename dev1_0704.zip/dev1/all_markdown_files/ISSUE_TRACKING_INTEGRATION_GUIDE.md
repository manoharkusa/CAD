# Issue Tracking System - Integration Guide

## Overview

The Issue Tracking System is now fully implemented and ready to use. It provides:

- **Issue Management**: Create, track, and manage issues during flow execution
- **Fix Templates**: Predefined fixes for common errors with machine learning-based success rates
- **Context Tracking**: Maintain context across entire flow execution
- **Fix Engine**: Automatically suggest and apply fixes
- **HTTP API**: REST endpoints for issue management
- **Database Backend**: SQLite for persistent storage

## Files Created

### Core System Files

```
src/issues/
├── __init__.py               # Module initialization
├── models.py                 # Issue, FixTemplate, RunContext classes
├── issue_manager.py          # Create/retrieve/manage issues
├── issue_database.py         # Database operations
├── fix_repository.py         # Store/retrieve fix templates
├── fix_engine.py             # Apply fixes and learning
├── context_tracker.py        # Track run context across phases
└── flow_integration.py       # Integration with PhysicalDesignGraph

src/api/
└── issue_api.py              # HTTP API endpoints

fix_templates/
├── __init__.py
└── predefined_fixes.py       # Built-in fix templates
```

## Quick Start

### 1. Initialize Issue Tracking

```python
from src.issues.flow_integration import create_flow_with_issue_tracking

# Create integration
issue_tracking = create_flow_with_issue_tracking(db_path="flow_issues.db")
```

### 2. Create Context When Flow Starts

```python
# When flow execution begins
issue_tracking.create_context_for_flow(
    thread_id="user1_run001_2024",
    user_id="user1",
    run_id="run001",
    project="semicon_19-02",
    block="aes_cipher_top"
)
```

### 3. Handle Errors

```python
try:
    # Execute stage
    result = await execute_stage(...)
except Exception as e:
    error_info = issue_tracking.handle_stage_error(
        thread_id=thread_id,
        user_id=user_id,
        run_id=run_id,
        stage="syn",
        error=str(e),
        phase="synthesis",
        log_snippet=log_output,
        root_cause="RTL compilation failed"
    )

    # error_info contains:
    # - issue_id: Unique issue identifier
    # - error_type: Classified error type
    # - suggested_fixes: List of fix templates
    # - should_retry: Whether to retry

    if error_info["should_retry"]:
        # Apply first suggested fix
        fix_template = suggested_fixes[0]
        fix_result = issue_tracking.fix_engine.apply_fix(
            issue_id=error_info["issue_id"],
            fix_template=fix_template
        )
```

### 4. Record Successes

```python
issue_tracking.record_stage_success(thread_id, "syn")
```

### 5. Record Phase Completion

```python
issue_tracking.record_phase_completion(thread_id, "synthesis", "completed")
```

### 6. Get Final Report

```python
report = issue_tracking.record_flow_completion(thread_id, "completed")

# Get detailed issue report
issue_report = issue_tracking.get_issue_report(user_id, run_id)

print(f"Total issues: {issue_report['total_issues']}")
print(f"Critical: {issue_report['critical_issues']}")
print(f"Resolved: {issue_report['resolved_issues']}")
print(f"Pending: {issue_report['pending_issues']}")
```

## HTTP API Usage

### Initialize API

```python
from src.api.issue_api import init_issue_api

# Initialize with database path
init_issue_api(db_path="flow_issues.db")

# Then in FastAPI app
app.include_router(issue_api.router)
```

### Create Issue

```bash
curl -X POST http://localhost:8000/issues/create \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "user1",
    "run_id": "run001",
    "thread_id": "user1_run001_2024",
    "stage": "syn",
    "error_type": "ENV_VARIABLE_MISSING",
    "error_message": "can't read env(RTL_FILELIST)",
    "phase": "synthesis",
    "severity": "critical"
  }'
```

### List Issues

```bash
curl http://localhost:8000/issues/list?user_id=user1&run_id=run001
```

### Get Summary

```bash
curl http://localhost:8000/issues/summary?user_id=user1&run_id=run001
```

### Suggest Fixes

```bash
curl -X POST http://localhost:8000/issues/suggest-fixes \
  -H "Content-Type: application/json" \
  -d '{
    "issue_id": "syn_001",
    "limit": 5
  }'
```

### Apply Fix

```bash
curl -X POST http://localhost:8000/issues/apply-fix \
  -H "Content-Type: application/json" \
  -d '{
    "issue_id": "syn_001",
    "fix_template_id": "rtl_filelist_001",
    "context": {
      "user_id": "user1",
      "run_id": "run001"
    }
  }'
```

### Get Context

```bash
curl http://localhost:8000/issues/context/user1_run001_2024
```

### Record Phase Result

```bash
curl -X POST "http://localhost:8000/issues/context/user1_run001_2024/phase-result?phase=synthesis&result=completed"
```

## Integration with PhysicalDesignGraph

### Example: Modified execute_stage_node

```python
from src.issues.flow_integration import FlowIssueIntegration

async def execute_stage_node(state: FlowState) -> Dict[str, Any]:
    """Execute stage with issue tracking"""

    issue_tracking = FlowIssueIntegration("flow_issues.db")

    # Ensure context exists
    if state.get("current_stage_index") == 0:
        issue_tracking.create_context_for_flow(
            thread_id=state["run_id"],  # Or proper thread_id
            user_id=state.get("user_id", "unknown"),
            run_id=state["run_id"],
            project="project",
            block="block"
        )

    current_index = state.get("current_stage_index", 0)
    plan = state.get("plan", [])

    if current_index >= len(plan):
        return {"execution_status": "completed"}

    stage_name = plan[current_index]

    try:
        # Execute stage
        config_manager = create_config_manager(...)
        stage_executor = StageExecutor(config_manager)

        result = await stage_executor.execute_stage(
            stage_name=stage_name,
            tool_name="genus",
            tool_script=f"{stage_name}.tcl",
            tool_executable="genus"
        )

        if result["status"] == "success":
            issue_tracking.record_stage_success(state["run_id"], stage_name)

            return {
                "stages_executed": state.get("stages_executed", []) + [stage_name],
                "current_stage_index": current_index + 1,
                "error_info": None,
                "execution_status": "in_progress"
            }
        else:
            # Handle error with issue tracking
            error_info = issue_tracking.handle_stage_error(
                thread_id=state["run_id"],
                user_id=state.get("user_id", "unknown"),
                run_id=state["run_id"],
                stage=stage_name,
                error=result.get("error", "Unknown error"),
                phase="execution",
                log_snippet=result.get("log", "")
            )

            return {
                "error_info": error_info,
                "stages_failed": state.get("stages_failed", []) + [stage_name],
                "execution_status": "failed"
            }

    except Exception as e:
        # Handle exception with issue tracking
        error_info = issue_tracking.handle_stage_error(
            thread_id=state["run_id"],
            user_id=state.get("user_id", "unknown"),
            run_id=state["run_id"],
            stage=stage_name,
            error=str(e),
            phase="execution"
        )

        return {
            "error_info": error_info,
            "stages_failed": state.get("stages_failed", []) + [stage_name],
            "execution_status": "failed"
        }
```

## Issue Tracking Database Schema

### issues table

```sql
CREATE TABLE issues (
    id VARCHAR(50) PRIMARY KEY,          -- syn_001, place_002, etc
    user_id VARCHAR(50),
    run_id VARCHAR(50),
    thread_id VARCHAR(100),
    stage VARCHAR(50),                   -- syn, place, route, signoff
    timestamp DATETIME,
    phase VARCHAR(50),                   -- synthesis, pnr, signoff
    error_type VARCHAR(100),             -- ENV_VARIABLE_MISSING, TIMING_VIOLATION, etc
    error_message TEXT,                  -- Full error message
    error_log_snippet TEXT,              -- Log excerpt
    root_cause TEXT,                     -- Analysis of root cause
    severity VARCHAR(20),                -- critical, high, medium, low
    suggested_fix TEXT,
    fix_applied BOOLEAN,
    fix_method VARCHAR(50),
    fix_result VARCHAR(50),
    related_issues TEXT,                 -- JSON array of related issue IDs
    metadata TEXT,                       -- JSON with custom data
    status VARCHAR(20),                  -- detected, analyzed, fixed, ignored
    created_at DATETIME,
    updated_at DATETIME
);
```

### fix_templates table

```sql
CREATE TABLE fix_templates (
    id VARCHAR(100) PRIMARY KEY,         -- rtl_filelist_001, timing_violation_001
    error_pattern TEXT,                  -- Regex pattern for error matching
    error_type VARCHAR(100),
    stage VARCHAR(50),
    fix_category VARCHAR(50),
    fix_action TEXT,                     -- modify_rtl, adjust_constraints, etc
    fix_parameters TEXT,                 -- JSON with fix parameters
    priority INT,                        -- Higher = more likely to be used
    success_rate FLOAT,                  -- 0.0 to 1.0
    preconditions TEXT,                  -- JSON array of preconditions
    created_by VARCHAR(50),
    created_at DATETIME,
    updated_at DATETIME,
    description TEXT,
    example_error TEXT,
    notes TEXT
);
```

### run_contexts table

```sql
CREATE TABLE run_contexts (
    thread_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(50),
    run_id VARCHAR(50),
    project VARCHAR(100),
    block VARCHAR(100),
    issues_json TEXT,                    -- JSON array of all issues
    issue_counts TEXT,                   -- JSON with counts by error type
    fixes_applied TEXT,                  -- JSON array of fixes applied
    decisions TEXT,                      -- JSON array of decisions made
    phase_results TEXT,                  -- JSON with phase results
    created_at DATETIME,
    updated_at DATETIME,
    flow_status VARCHAR(20)
);
```

## Predefined Fix Templates

The system comes with 7 predefined fix templates:

1. **rtl_filelist_001** - RTL_FILELIST environment variable not found
   - Error: `can't read env(RTL_FILELIST)`
   - Success rate: 95%
   - Fix: Update sourceproj.env

2. **timing_violation_001** - Timing violations in design
   - Error: `setup violation`, `hold violation`
   - Success rate: 75%
   - Fix: Adjust timing constraints

3. **congestion_001** - Routing congestion
   - Error: `congestion`, `routing overflow`
   - Success rate: 65%
   - Fix: Adjust placement

4. **drc_violation_001** - Design rule violations
   - Error: `DRC violation`, `spacing violation`
   - Success rate: 80%
   - Fix: Review and fix violations

5. **memory_issue_001** - Out of memory errors
   - Error: `memory`, `out of memory`, `malloc`
   - Success rate: 70%
   - Fix: Increase memory allocation

6. **tool_script_not_found_001** - Script not found
   - Error: `not found`, `No such file`
   - Success rate: 98%
   - Fix: Verify ENV_SCRIPTS path

7. **syntax_error_001** - TCL syntax errors
   - Error: `syntax error`, `unexpected`
   - Success rate: 85%
   - Fix: Review script syntax

## Adding Custom Fix Templates

```python
from src.issues import FixRepository, FixTemplate

fix_repo = FixRepository("flow_issues.db")

# Create custom template
custom_fix = FixTemplate(
    template_id="custom_power_001",
    error_pattern=r"power.*violation|excessive.*power",
    error_type="POWER_VIOLATION",
    stage="signoff",
    fix_category="power",
    fix_action="update_config",
    fix_parameters={
        "file": "power_constraints.tcl",
        "setting": "power_budget",
        "hint": "Reduce power budget by 10%"
    },
    priority=85,
    success_rate=0.70,
    created_by="design_team",
    description="Reduce power violations by adjusting budget"
)

# Add to repository
fix_repo.add_template(custom_fix)
```

## Error Classification

Errors are automatically classified into types:

- **ENV_VARIABLE_MISSING** - Missing environment variables
- **TIMING_VIOLATION** - Setup/hold violations
- **ROUTING_CONGESTION** - Routing or placement issues
- **DRC_VIOLATION** - Design rule violations
- **MEMORY_ISSUE** - Out of memory errors
- **FILE_NOT_FOUND** - Missing files or paths
- **SYNTAX_ERROR** - TCL or script syntax errors
- **UNKNOWN_ERROR** - Other errors

Severity is automatically determined based on error type:
- **CRITICAL** - ENV_VARIABLE_MISSING, FILE_NOT_FOUND, SYNTAX_ERROR, MEMORY_ISSUE
- **HIGH** - TIMING_VIOLATION, DRC_VIOLATION
- **MEDIUM** - ROUTING_CONGESTION
- **LOW** - Others

## Learning System

The fix engine learns from applied fixes:

```python
fix_engine = FixEngine("flow_issues.db")

# After fix application, provide feedback
if was_successful:
    # Success rate increased by 5% (up to 1.0)
    fix_engine.learn_from_fix(issue_id, template, was_successful=True)
else:
    # Success rate decreased by 5% (down to 0.0)
    fix_engine.learn_from_fix(issue_id, template, was_successful=False)
```

## Querying Issues

### Get all issues for a run

```python
issue_manager = IssueManager("flow_issues.db")
issues = issue_manager.get_issues("user1", "run001")
```

### Get issues by stage

```python
issues = issue_manager.get_issues_by_stage("user1", "run001", "syn")
```

### Get issues by error type

```python
issues = issue_manager.get_issues_by_error_type("user1", "run001", "TIMING_VIOLATION")
```

### Get similar historical issues

```python
similar = issue_manager.get_similar_issues("TIMING_VIOLATION", "user1", limit=5)
```

### Get issue summary

```python
summary = issue_manager.get_issue_summary("user1", "run001")

# Output:
# {
#   "total": 5,
#   "by_status": {"detected": 2, "fixed": 3},
#   "by_stage": {"syn": 2, "place": 3},
#   "by_error_type": {"TIMING_VIOLATION": 3, "MEMORY_ISSUE": 2},
#   "by_severity": {"high": 3, "medium": 2},
#   "critical_count": 0,
#   "fixed_count": 3,
#   "pending_count": 2
# }
```

## Configuration

### Database Path

Set database path when initializing:

```python
issue_tracking = FlowIssueIntegration(db_path="/path/to/flow_issues.db")
```

### Using Different Database Backends

The system uses SQLite by default. For production:

1. **PostgreSQL**: Modify `issue_database.py` to use psycopg2
2. **MySQL**: Modify `issue_database.py` to use mysql-connector-python

## Production Considerations

1. **Database Backup**: Regularly backup `flow_issues.db`
2. **Retention Policy**: Archive old issues periodically
3. **Performance**: Add database indexes as needed
4. **Monitoring**: Track fix success rates and adjust priorities
5. **Access Control**: Implement authentication for API endpoints
6. **Logging**: Enable database query logging for debugging

## Next Steps

1. **Integrate with PhysicalDesignGraph**: Add issue tracking to physical_design_graph.py
2. **Mount API**: Add issue_api router to FastAPI app
3. **Test**: Run issue tracking tests
4. **Monitor**: Track fix success rates and adjust templates
5. **Enhance**: Add custom fixes based on observed issues

## Example: Complete Flow with Issue Tracking

```python
from src.issues.flow_integration import create_flow_with_issue_tracking

async def run_flow_with_issues():
    issue_tracking = create_flow_with_issue_tracking(db_path="issues.db")

    thread_id = "user1_run001_20240224"
    user_id = "user1"
    run_id = "run001"

    # Create context
    issue_tracking.create_context_for_flow(
        thread_id, user_id, run_id, "semicon_19-02", "aes_cipher_top"
    )

    # Execute stages
    stages = ["syn", "place", "route", "signoff"]

    for stage in stages:
        try:
            print(f"Executing {stage}...")
            # result = await execute_stage(stage)
            issue_tracking.record_stage_success(thread_id, stage)
            issue_tracking.record_phase_completion(thread_id, stage, "completed")
        except Exception as e:
            print(f"Error in {stage}: {e}")
            error_info = issue_tracking.handle_stage_error(
                thread_id, user_id, run_id, stage, str(e)
            )

            if error_info["should_retry"] and error_info["suggested_fixes"]:
                print(f"Retrying with fix...")
                # Apply fix and retry
            else:
                print("Cannot auto-fix, stopping")
                break

    # Get report
    report = issue_tracking.record_flow_completion(thread_id, "completed")
    issue_report = issue_tracking.get_issue_report(user_id, run_id)

    print(f"\n=== REPORT ===")
    print(f"Total Issues: {issue_report['total_issues']}")
    print(f"Critical: {issue_report['critical_issues']}")
    print(f"Resolved: {issue_report['resolved_issues']}")
    print(f"Pending: {issue_report['pending_issues']}")

    return report
```

## Support

For questions or issues with the Issue Tracking System:

1. Check existing issues and fixes
2. Review error logs in the database
3. Consult predefined fix templates
4. Contact the development team
