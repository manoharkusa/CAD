# Keep-Dev1 Cutover Plan

Date: 2026-03-07
Status: Ready for execution

## Objective

Finalize `dev1` as the sole runtime codepath for lifecycle orchestration, while keeping rollback options explicit and low-risk.

## Scope of Cutover

In scope:
- Canonical lifecycle API routes in `dev1/src/main.py`
- Redis lifecycle state/eventing adapters in `dev1/src/infra/redis`
- Postgres lifecycle persistence in `dev1/src/infra/models` + repository layer
- Graph lifecycle bridge wiring in `dev1/src/agents/physical_design_graph.py` + `main.py`
- Dev1 runtime env and compose stack (`dev1/.env`, `dev1/docker-compose.dev1.yml`)

Out of scope:
- Rewriting core graph logic beyond lifecycle integration
- New endpoint surface expansion
- Schema redesign outside current lifecycle tables

## Preconditions (must be true)

1. Docker proof run passes end-to-end
   - `POST /jobs`
   - `GET /jobs/{job_id}/job_status`
   - `POST /jobs/{job_id}/human-input`
   - `GET /job_state`
   - `POST /jobs/{job_id}/abort`
2. Storage evidence confirmed in both Redis and Postgres
3. Automated checks pass:
   - `dev1/tests/test_syntax.py`
   - `dev1/tests/test_multi_user.py`
   - `dev1/tests/test_issue_tracking.py`
4. `.env` defaults and docker override keys validated

## Cutover Phases

### Phase 1: Freeze and announce
- Freeze non-critical changes in `dev1/src` during cutover window.
- Communicate canonical ownership:
  - API lifecycle = `dev1/src/main.py`
  - deprecated mirrors in `dev1/src/api/flow_api.py` are compatibility-only.

Exit criteria:
- Team acknowledgement completed.

### Phase 2: Production-like deploy with feature flags
Set:
- `USE_JOB_LIFECYCLE_API=true`
- `USE_POSTGRES_JOB_REPO=true`
- `USE_REDIS_JOB_STATE=true`

Validate:
- API boots cleanly with schema init
- Redis + Postgres connections healthy
- `/health` and `/info` reflect expected state

Exit criteria:
- Services healthy for one full deploy cycle.

### Phase 3: Lifecycle smoke + observability
Run smoke flow and verify:
- API response correctness
- Redis keys and pub/sub activity
- Postgres status/phase progression
- WebSocket event stream (`/ws/jobs/{job_id}`)

Exit criteria:
- 100% smoke pass with no unresolved blocker defects.

### Phase 4: Stability soak
- Run repeated lifecycle requests under normal load.
- Track:
  - job creation error rate
  - status query latency
  - Redis adapter errors
  - Postgres write errors

Exit criteria:
- Error rate within agreed threshold (typically ~0 fatal errors in soak window).

### Phase 5: Deprecation enforcement
- Keep deprecated mirrors in `flow_api.py` for one release cycle.
- Add explicit deprecation note in release communications.
- After soak cycle, remove deprecated route implementations.

Exit criteria:
- No consumers depend on deprecated path.

## Rollback Plan

Trigger rollback if any of these occur:
- sustained 5xx on lifecycle routes
- inconsistent status between Redis and Postgres
- inability to create or read job state

Rollback actions:
1. Set flags to degrade gracefully:
   - Redis issue: `USE_REDIS_JOB_STATE=false`
   - Postgres issue: `USE_POSTGRES_JOB_REPO=false`
2. Keep `USE_JOB_LIFECYCLE_API=true` if route-level behavior is still required.
3. Re-run smoke checks in degraded mode.
4. Capture incident report and root cause before re-enabling full path.

## Ownership Checklist

Engineering:
- [ ] Execute cutover phases and smoke matrix
- [ ] Monitor logs and metrics during soak
- [ ] Close or triage all cutover defects

QA:
- [ ] Run `E2E_STAGE_VALIDATION_CHECKLIST.md`
- [ ] Confirm HITL and abort behavior with evidence

Release/Operations:
- [ ] Publish cutover window + rollback contact
- [ ] Confirm post-cutover runbook location

## Post-Cutover Tasks

1. Remove deprecated compatibility endpoints from `dev1/src/api/flow_api.py`.
2. Archive superseded migration notes not needed for operations.
3. Keep only actively used runbooks in root README links.
4. Tag release marker for first `dev1-only` runtime build.

## Reference Docs

- `README.md`
- `dev1/all_markdown_files/DEV1_DOCKER_PROOF_RUN.md`
- `dev1/all_markdown_files/REQUEST_LIFECYCLE_DETAILED_FLOW.md`
- `dev1/all_markdown_files/E2E_STAGE_VALIDATION_CHECKLIST.md`
