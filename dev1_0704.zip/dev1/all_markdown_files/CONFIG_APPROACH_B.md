# Configuration Management - Approach B (TCL-based YAML Loading)

## Overview

**Approach B** uses a minimal Python ConfigManager that manages paths and environment variables, while letting TCL (via `yaml_config_reader.tcl`) handle all YAML loading, merging, and validation.

## Architecture

```
For Each Stage Execution:
┌─────────────────────────────────────────────┐
│ Python: OrchestratorAgent                   │
│  ├─ Get environment variables from          │
│  │   ConfigManager                          │
│  ├─ Pass yaml_config_reader.tcl to tool    │
│  └─ Execute: tool -files yaml_reader.tcl   │
│               -files stage_script.tcl       │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│ TCL: yaml_config_reader.tcl (in EDA tool)  │
│  ├─ Read env vars: TECH_YAML, PROJECT_YAML │
│  ├─ Load all YAML files fresh              │
│  ├─ Merge: flow → tech → project → block   │
│  ├─ Validate protected keys                │
│  ├─ Load SRAM macros from mem_list         │
│  └─ Return globals: PROJECT_CONFIG, etc.   │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│ TCL: Stage script (genus_syn.tcl, etc.)    │
│  ├─ Source yaml_config_reader.tcl done ✓   │
│  ├─ Access: $::PROJECT_CONFIG               │
│  ├─ Access: $::SRAM_MACRO_TYPES             │
│  └─ Execute tool logic                     │
└─────────────────────────────────────────────┘
```

## ConfigManager

### Minimal Python Class

The ConfigManager just handles:
1. Path validation
2. Environment variable generation
3. Utility methods for path resolution

**No YAML parsing in Python!**

### Usage

```python
from src.config import create_config_manager

# Create ConfigManager
config_mgr = create_config_manager(
    project_name="aes_cipher_top",
    user_name="bharath",
    block_name="aes_cipher_top",
    rtl_tag="bronze_v1",
    run_tag="run_001"
)

# Get environment variables for TCL
env_vars = config_mgr.get_env_vars()

# Output:
# {
#     'TECH_YAML': '/proj1/aes_cipher_top/pd/.../tech_scripts/tech.yaml',
#     'PROJECT_YAML': '/proj1/aes_cipher_top/pd/.../project_scripts/project.yaml',
#     'BLOCK_YAML': '/proj1/aes_cipher_top/pd/.../block_scripts/block.yaml',
#     'FLOW_YAML': '/proj1/aes_cipher_top/pd/.../tool_scripts/flow.yaml',
#     'BLOCK_NAME': 'aes_cipher_top',
#     'MEM_LIST': '/proj1/aes_cipher_top/pd/.../block_inputs/mem_list.txt'
# }
```

## Stage Execution

### Using StageExecutor

```python
from src.executor import StageExecutor

# Create executor with ConfigManager
executor = StageExecutor(config_mgr)

# Execute a stage
result = await executor.execute_stage(
    stage_name="syn",
    tool_name="genus",
    tool_script="tool_scripts/genus_syn.tcl",
    tool_executable="genus"
)

# Returns:
# {
#     'status': 'success',
#     'stage': 'syn',
#     'tool': 'genus',
#     'duration': 125.3,
#     'return_code': 0,
#     'log_file': '/path/to/syn/logs/syn_20260211_101530.log',
#     'timestamp': '2026-02-11T10:15:30.123456'
# }
```

### What Happens Behind the Scenes

1. **ConfigManager.get_env_vars()** returns environment variables with absolute paths to YAML files
2. **StageExecutor** passes these env vars when executing the EDA tool
3. **EDA tool invocation:**
   ```bash
   genus -files /path/to/yaml_config_reader.tcl \
         -files /path/to/tool_scripts/genus_syn.tcl
   ```
4. **TCL yaml_config_reader.tcl runs:**
   - Reads env vars (TECH_YAML, PROJECT_YAML, BLOCK_YAML, etc.)
   - Loads each YAML file via `load_yaml_file`
   - Merges them: flow → tech → project → block
   - Validates protected keys
   - Loads SRAM macros from MEM_LIST
   - Creates globals: `$::PROJECT_CONFIG`, `$::SRAM_MACRO_TYPES`, etc.
5. **Stage script runs:**
   ```tcl
   # yaml_config_reader already ran, just use the globals
   puts "Block: [dict get $::PROJECT_CONFIG block_info name]"
   puts "Metal Stack: [dict get $::PROJECT_CONFIG metal_stack name]"
   ```

## Configuration Hierarchy

### Precedence Order (from highest to lowest)

1. **block.yaml** (block-specific overrides)
   - Location: `block_scripts/block.yaml`
   - Can override: timing, placement, derating, etc.
   - Cannot override: metal_stack, VT, corners (protected)

2. **project.yaml** (project defaults)
   - Location: `project_scripts/project.yaml`
   - Selects: metal_stack, VT, corners, PDK options
   - Can override: everything not in block.yaml

3. **flow.yaml** (tool mappings)
   - Location: `tool_scripts/flow.yaml`
   - Maps: tool_name → script_path
   - Referenced by: project.yaml

4. **tech.yaml** (PDK catalog)
   - Location: `tech_scripts/tech.yaml`
   - Defines: available metal stacks, VTs, SRAM macros
   - Cannot be overridden

### Example YAML Files

**tech_scripts/tech.yaml:**
```yaml
technology:
  name: TSMC28HPHP
  process_node: 28

available_metal_stacks:
  - name: 1P9M_4X2Y2R
    config_file: /proj1/pdk/.../metal_stack/1P9M_4X2Y2R.yaml

available_std_cell_vts:
  - vt_type: SVT
    config_file: /proj1/pdk/.../stdcells/svt/svt.yaml
```

**project_scripts/project.yaml:**
```yaml
project_info:
  project_name: aes_cipher_top
  version: v1.0

pdk:
  metal_stack: 1P9M_4X2Y2R
  std_cell_vt: svt

tools:
  synthesis: genus
  place_route: innovus
  sta: tempus
```

**block_scripts/block.yaml:**
```yaml
block_info:
  name: aes_cipher_top
  rtl_tag: bronze_v1

# Override project settings (except protected keys)
block_inputs:
  sdc: aes_cipher_top.sdc
  rtl_filelist: file_list.tcl
  mem_list: mem_list.txt
```

**block_inputs/mem_list.txt:**
```
# SRAM macros used in this block
ct_f_spsram_512x54
ct_f_spsram_256x98
```

## Key Benefits of Approach B

✅ **Fresh YAML load every stage** - Config always up-to-date
✅ **Single source of truth** - YAML files are authoritative
✅ **No intermediate files** - Python just manages paths
✅ **Built-in validation** - Protected keys, catalog checks in TCL
✅ **SRAM auto-loading** - mem_list automatically processed
✅ **Minimal Python code** - Just env vars, TCL does heavy lifting
✅ **Leverages existing system** - Uses yaml_config_reader.tcl
✅ **Easy debugging** - Inspect actual YAML files

## Environment Variables Set by ConfigManager

| Variable | Purpose | Example |
|----------|---------|---------|
| TECH_YAML | PDK catalog location | `/proj1/pdk/.../tech.yaml` |
| PROJECT_YAML | Project defaults | `/proj1/project/.../project.yaml` |
| BLOCK_YAML | Block overrides | `/proj1/project/.../block.yaml` |
| FLOW_YAML | Tool mappings | `/proj1/project/.../flow.yaml` |
| BLOCK_NAME | Block identifier | `aes_cipher_top` |
| MEM_LIST | SRAM macro list | `/proj1/project/.../mem_list.txt` |

## TCL Access to Configuration

### In any TCL script:

```tcl
# Source the config reader (done by StageExecutor)
source yaml_config_reader.tcl

# Or call directly if needed:
init_yaml_configs

# Access configuration globals:
set block_name [dict get $::PROJECT_CONFIG block_info name]
set metal_stack [dict get $::PROJECT_CONFIG metal_stack name]
set sram_types [dict keys $::SRAM_MACRO_TYPES]

# Get SRAM information:
set sram_lefs [zget_all_sram_lefs]
set sram_libs [zget_all_sram_libs tt0p9v25c]
set sram_gds [zget_all_sram_gds]

# List available SRAM corners:
set corners [zget_all_sram_corners]
```

## Regeneration for Each Stage

ConfigManager regenerates config for each stage:

```python
# In OrchestratorAgent
for stage in execution_plan:
    # Get fresh env vars before each stage
    env_vars = config_mgr.get_env_vars()

    # Execute stage (TCL loads fresh YAML)
    result = await executor.execute_stage(
        stage_name=stage,
        ...
    )

    # Between stages, user can modify:
    # - block_scripts/block.yaml
    # - block_inputs/mem_list.txt
    # - Other input files
    #
    # Next stage will automatically pick up changes!
```

## Summary

**Approach B (TCL-based YAML Loading):**

- Python: Minimal (just paths and env vars)
- TCL: Does all the work (YAML loading, merging, validation)
- Fresh config every stage
- Easy to debug
- Single source of truth (YAML files)
- Leverages existing yaml_config_reader.tcl

This is the **recommended approach** for your architecture.
