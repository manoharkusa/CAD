# Issue Tracking System - Implementation Guide

## Quick Start (5 minutes)

### Step 1: Create Database Tables

```sql
-- Run this to set up the database

CREATE TABLE issues (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50),
    run_id VARCHAR(50),
    thread_id VARCHAR(100),
    stage VARCHAR(50),
    timestamp DATETIME,
    phase VARCHAR(50),
    error_type VARCHAR(100),
    error_message TEXT,
    error_log_snippet TEXT,
    root_cause TEXT,
    severity VARCHAR(20),
    suggested_fix TEXT,
    fix_applied BOOLEAN DEFAULT FALSE,
    fix_method VARCHAR(50),
    fix_result VARCHAR(50),
    related_issues JSON,
    metadata JSON,
    status VARCHAR(20),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_run (user_id, run_id),
    INDEX idx_thread (thread_id),
    INDEX idx_stage (stage),
    INDEX idx_error_type (error_type)
);

CREATE TABLE fix_templates (
    id VARCHAR(100) PRIMARY KEY,
    error_pattern TEXT,
    error_type VARCHAR(100),
    stage VARCHAR(50),
    fix_category VARCHAR(50),
    fix_action TEXT,
    fix_parameters JSON,
    priority INT,
    success_rate FLOAT,
    preconditions JSON,
    created_by VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    description TEXT,
    example_error TEXT,
    notes TEXT,
    INDEX idx_error_type (error_type),
    INDEX idx_stage (stage),
    INDEX idx_priority (priority DESC)
);

CREATE TABLE run_contexts (
    thread_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(50),
    run_id VARCHAR(50),
    project VARCHAR(100),
    block VARCHAR(100),
    issues_json JSON,
    issue_counts JSON,
    fixes_applied JSON,
    decisions JSON,
    phase_results JSON,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    flow_status VARCHAR(20),
    INDEX idx_user_run (user_id, run_id),
    INDEX idx_thread (thread_id)
);
```

---

## File Structure

```
src/issues/
├── __init__.py
├── models.py              # Issue, Fix, Context models
├── issue_manager.py       # Create/retrieve issues
├── fix_repository.py      # Store/retrieve fix templates
├── fix_engine.py          # Apply fixes
├── context_tracker.py     # Track run context
└── issue_database.py      # Database operations

src/api/
└── issue_api.py           # HTTP endpoints for issues

fix_templates/
├── __init__.py
└── predefined_fixes.py    # Built-in fix templates
```

---

## Implementation - File 1: Models

### File: `src/issues/models.py`

```python
#!/usr/bin/env python3
"""Issue tracking data models"""

from datetime import datetime
from enum import Enum
from typing import Optional, List, Dict, Any
import json

class SeverityLevel(Enum):
    """Issue severity"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class IssueStatus(Enum):
    """Issue status"""
    DETECTED = "detected"
    ANALYZED = "analyzed"
    FIXED = "fixed"
    IGNORED = "ignored"

class Issue:
    """Issue tracking record"""

    def __init__(
        self,
        issue_id: str,
        user_id: str,
        run_id: str,
        thread_id: str,
        stage: str,
        error_type: str,
        error_message: str,
        phase: str,
        timestamp: Optional[datetime] = None,
        root_cause: str = "",
        severity: SeverityLevel = SeverityLevel.MEDIUM,
        suggested_fix: str = "",
        fix_applied: bool = False,
        fix_method: str = "",
        fix_result: str = "",
        status: IssueStatus = IssueStatus.DETECTED,
        related_issues: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.issue_id = issue_id
        self.user_id = user_id
        self.run_id = run_id
        self.thread_id = thread_id
        self.stage = stage
        self.error_type = error_type
        self.error_message = error_message
        self.phase = phase
        self.timestamp = timestamp or datetime.now()
        self.root_cause = root_cause
        self.severity = severity
        self.suggested_fix = suggested_fix
        self.fix_applied = fix_applied
        self.fix_method = fix_method
        self.fix_result = fix_result
        self.status = status
        self.related_issues = related_issues or []
        self.metadata = metadata or {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "issue_id": self.issue_id,
            "user_id": self.user_id,
            "run_id": self.run_id,
            "thread_id": self.thread_id,
            "stage": self.stage,
            "error_type": self.error_type,
            "error_message": self.error_message,
            "phase": self.phase,
            "timestamp": self.timestamp.isoformat(),
            "root_cause": self.root_cause,
            "severity": self.severity.value,
            "suggested_fix": self.suggested_fix,
            "fix_applied": self.fix_applied,
            "fix_method": self.fix_method,
            "fix_result": self.fix_result,
            "status": self.status.value,
            "related_issues": self.related_issues,
            "metadata": self.metadata
        }

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "Issue":
        """Create from dictionary"""
        return Issue(
            issue_id=data["issue_id"],
            user_id=data["user_id"],
            run_id=data["run_id"],
            thread_id=data["thread_id"],
            stage=data["stage"],
            error_type=data["error_type"],
            error_message=data["error_message"],
            phase=data["phase"],
            timestamp=datetime.fromisoformat(data.get("timestamp", datetime.now().isoformat())),
            root_cause=data.get("root_cause", ""),
            severity=SeverityLevel(data.get("severity", "medium")),
            suggested_fix=data.get("suggested_fix", ""),
            fix_applied=data.get("fix_applied", False),
            fix_method=data.get("fix_method", ""),
            fix_result=data.get("fix_result", ""),
            status=IssueStatus(data.get("status", "detected")),
            related_issues=data.get("related_issues", []),
            metadata=data.get("metadata", {})
        )


class FixTemplate:
    """Fix template for issues"""

    def __init__(
        self,
        template_id: str,
        error_pattern: str,
        error_type: str,
        stage: str,
        fix_category: str,
        fix_action: str,
        fix_parameters: Dict[str, Any],
        priority: int = 50,
        success_rate: float = 0.5,
        preconditions: Optional[List[str]] = None,
        created_by: str = "system",
        description: str = "",
        example_error: str = "",
        notes: str = ""
    ):
        self.template_id = template_id
        self.error_pattern = error_pattern
        self.error_type = error_type
        self.stage = stage
        self.fix_category = fix_category
        self.fix_action = fix_action
        self.fix_parameters = fix_parameters
        self.priority = priority
        self.success_rate = success_rate
        self.preconditions = preconditions or []
        self.created_by = created_by
        self.created_at = datetime.now()
        self.description = description
        self.example_error = example_error
        self.notes = notes

    def to_dict(self) -> Dict[str, Any]:
        return {
            "template_id": self.template_id,
            "error_pattern": self.error_pattern,
            "error_type": self.error_type,
            "stage": self.stage,
            "fix_category": self.fix_category,
            "fix_action": self.fix_action,
            "fix_parameters": self.fix_parameters,
            "priority": self.priority,
            "success_rate": self.success_rate,
            "preconditions": self.preconditions,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat(),
            "description": self.description,
            "example_error": self.example_error,
            "notes": self.notes
        }


class RunContext:
    """Track context across flow execution"""

    def __init__(
        self,
        thread_id: str,
        user_id: str,
        run_id: str,
        project: str,
        block: str
    ):
        self.thread_id = thread_id
        self.user_id = user_id
        self.run_id = run_id
        self.project = project
        self.block = block
        self.issues: List[Issue] = []
        self.issue_count: Dict[str, int] = {}
        self.fixes_applied: List[Dict[str, Any]] = []
        self.decisions: List[Dict[str, Any]] = []
        self.phase_results: Dict[str, str] = {}
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.flow_status = "in_progress"

    def add_issue(self, issue: Issue):
        """Add issue to context"""
        self.issues.append(issue)
        self.issue_count[issue.error_type] = self.issue_count.get(issue.error_type, 0) + 1
        self.updated_at = datetime.now()

    def record_fix(self, issue_id: str, fix_id: str, result: str):
        """Record fix application"""
        self.fixes_applied.append({
            "issue_id": issue_id,
            "fix_id": fix_id,
            "result": result,
            "timestamp": datetime.now().isoformat()
        })
        self.updated_at = datetime.now()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "thread_id": self.thread_id,
            "user_id": self.user_id,
            "run_id": self.run_id,
            "project": self.project,
            "block": self.block,
            "issues": [i.to_dict() for i in self.issues],
            "issue_count": self.issue_count,
            "fixes_applied": self.fixes_applied,
            "decisions": self.decisions,
            "phase_results": self.phase_results,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "flow_status": self.flow_status
        }
```

---

## Implementation - File 2: Issue Manager

### File: `src/issues/issue_manager.py`

```python
#!/usr/bin/env python3
"""Issue management"""

from typing import List, Optional
from datetime import datetime
import re
import json
import aiosqlite

from .models import Issue, IssueStatus, SeverityLevel

class IssueManager:
    """Manage issues"""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.counter = {}  # Track issue numbers per stage

    async def create_issue(
        self,
        user_id: str,
        run_id: str,
        thread_id: str,
        stage: str,
        error_type: str,
        error_message: str,
        phase: str,
        root_cause: str = "",
        severity: SeverityLevel = SeverityLevel.MEDIUM,
        log_snippet: str = ""
    ) -> Issue:
        """Create new issue"""

        # Generate issue ID
        issue_num = self.counter.get(stage, 0) + 1
        self.counter[stage] = issue_num
        issue_id = f"{stage}_{issue_num:03d}"

        # Create issue
        issue = Issue(
            issue_id=issue_id,
            user_id=user_id,
            run_id=run_id,
            thread_id=thread_id,
            stage=stage,
            error_type=error_type,
            error_message=error_message,
            phase=phase,
            root_cause=root_cause,
            severity=severity
        )

        # Save to database
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT INTO issues (
                    id, user_id, run_id, thread_id, stage, error_type,
                    error_message, phase, root_cause, severity, error_log_snippet,
                    timestamp, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    issue_id, user_id, run_id, thread_id, stage, error_type,
                    error_message, phase, root_cause, severity.value, log_snippet,
                    datetime.now().isoformat(), "detected"
                )
            )
            await db.commit()

        return issue

    async def get_issues(
        self,
        user_id: str,
        run_id: str
    ) -> List[Issue]:
        """Get all issues for a run"""

        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM issues WHERE user_id = ? AND run_id = ?",
                (user_id, run_id)
            )
            rows = await cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]

        issues = []
        for row in rows:
            data = dict(zip(columns, row))
            issues.append(Issue.from_dict(data))

        return issues

    async def get_issue_by_id(self, issue_id: str) -> Optional[Issue]:
        """Get issue by ID"""

        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM issues WHERE id = ?",
                (issue_id,)
            )
            row = await cursor.fetchone()

        if not row:
            return None

        columns = [desc[0] for desc in cursor.description]
        data = dict(zip(columns, row))
        return Issue.from_dict(data)

    async def update_issue(self, issue: Issue):
        """Update issue"""

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                UPDATE issues SET
                    root_cause = ?,
                    suggested_fix = ?,
                    fix_applied = ?,
                    fix_method = ?,
                    fix_result = ?,
                    status = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (
                    issue.root_cause,
                    issue.suggested_fix,
                    issue.fix_applied,
                    issue.fix_method,
                    issue.fix_result,
                    issue.status.value,
                    datetime.now().isoformat(),
                    issue.issue_id
                )
            )
            await db.commit()

    async def get_similar_issues(
        self,
        user_id: str,
        error_type: str,
        limit: int = 5
    ) -> List[Issue]:
        """Get similar issues by user"""

        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """
                SELECT * FROM issues
                WHERE user_id = ? AND error_type = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (user_id, error_type, limit)
            )
            rows = await cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]

        issues = []
        for row in rows:
            data = dict(zip(columns, row))
            issues.append(Issue.from_dict(data))

        return issues
```

---

## Integration with PhysicalDesignGraph

### File: `src/agents/physical_design_graph.py` (Updated execute_stage_node)

```python
async def _execute_stage_node(self, state: FlowState) -> dict:
    """Execute stage with issue tracking"""

    current_index = state.get("current_stage_index", 0)
    plan = state.get("plan", [])

    if current_index >= len(plan):
        return {"error_info": None}

    stage_name = plan[current_index]

    # === NEW: Issue tracking ===
    issue_manager = IssueManager(self.issue_db_path)
    context_tracker = RunContextTracker(self.issue_db_path)

    # Get or create context
    context = await context_tracker.get_context(state["thread_id"])
    if not context:
        context = await context_tracker.create_context(
            state["thread_id"],
            state["user_id"],
            state["run_id"],
            self.project_name,
            self.block_name
        )

    try:
        # Get tool and script from flow_config
        tool_name, script_name = self.config_manager.get_stage_tool_script(stage_name)

        print(f"\n[STAGE] Executing: {stage_name}")

        # Execute stage
        stage_result = await self.stage_executor.execute_stage(
            stage_name=stage_name,
            tool_name=tool_name,
            tool_script=script_name,
            tool_executable=None
        )

        # Check result
        if stage_result["status"] == "success":
            # Success - increment and continue
            return {
                "error_info": None,
                "stages_executed": state.get("stages_executed", []) + [stage_name],
                "current_stage_index": current_index + 1
            }
        else:
            # === NEW: Create issue record ===
            issue = await issue_manager.create_issue(
                user_id=state["user_id"],
                run_id=state["run_id"],
                thread_id=state["thread_id"],
                stage=stage_name,
                error_type="execution_failed",
                error_message=stage_result.get("error", "Unknown error"),
                phase=self._get_phase(stage_name),
                log_snippet=stage_result.get("log_snippet", "")
            )

            # Add to context
            await context_tracker.add_issue_to_context(
                state["thread_id"],
                issue
            )

            # === NEW: Get fix suggestions ===
            fix_engine = FixEngine(
                issue_manager,
                self.fix_repository,
                self.config_manager
            )

            suggestions = await fix_engine.analyze_and_suggest_fixes(
                issue,
                context
            )

            print(f"[ISSUE] {issue.issue_id}: {issue.error_message}")
            print(f"[SUGGESTIONS] {len(suggestions)} fixes suggested")

            return {
                "error_info": {
                    "error": stage_result["error"],
                    "issue_id": issue.issue_id,
                    "suggestions": suggestions,
                    "context_issues": [i.to_dict() for i in context.issues]
                },
                "stages_failed": state.get("stages_failed", []) + [stage_name]
            }

    except Exception as e:
        print(f"[ERROR] Exception in {stage_name}: {e}")
        return {
            "error_info": {"error": str(e)},
            "stages_failed": state.get("stages_failed", []) + [stage_name]
        }

def _get_phase(self, stage_name: str) -> str:
    """Get phase from stage name"""
    if stage_name == "syn":
        return "synthesis"
    elif stage_name in ["place", "route", "cts", "post_cts"]:
        return "pnr"
    else:
        return "signoff"
```

---

## Predefined Fix Templates

### File: `fix_templates/predefined_fixes.py`

```python
#!/usr/bin/env python3
"""Predefined fix templates"""

from src.issues.models import FixTemplate, SeverityLevel

# Fix: Missing environment variable
RTL_FILELIST_FIX = FixTemplate(
    template_id="env_rtl_filelist",
    error_pattern=r"can't read.*RTL_FILELIST|RTL_FILELIST.*not.*found",
    error_type="missing_environment",
    stage="syn",
    fix_category="env",
    fix_action="set_environment_variable",
    fix_parameters={
        "var_name": "RTL_FILELIST",
        "value": "/proj5/projects/semicon_19-02/rtl_files.list"
    },
    priority=1,
    success_rate=0.95,
    created_by="system",
    description="Set RTL_FILELIST environment variable for synthesis",
    example_error="can't read env(RTL_FILELIST)"
)

# Fix: Timing violation
TIMING_FIX = FixTemplate(
    template_id="timing_relaxation",
    error_pattern=r"setup violation|timing constraint|slack.*negative",
    error_type="timing_violation",
    stage="place",
    fix_category="constraint",
    fix_action="modify_timing_constraints",
    fix_parameters={
        "setup_margin": "0.5",
        "hold_margin": "0.2",
        "clock_uncertainty": "0.1"
    },
    priority=2,
    success_rate=0.85,
    created_by="system",
    description="Relax timing constraints to resolve timing violations"
)

# Fix: Routing congestion
CONGESTION_FIX = FixTemplate(
    template_id="routing_congestion_fix",
    error_pattern=r"route.*fail|congestion|max.*route|overflow",
    error_type="routing_congestion",
    stage="route",
    fix_category="config",
    fix_action="adjust_routing_parameters",
    fix_parameters={
        "routing_effort": "medium_to_high",
        "max_route_width": "0.8",
        "congestion_threshold": "0.7"
    },
    priority=3,
    success_rate=0.80,
    created_by="system",
    description="Adjust routing parameters to relieve congestion"
)

# Get all predefined fixes
def get_predefined_fixes():
    return [
        RTL_FILELIST_FIX,
        TIMING_FIX,
        CONGESTION_FIX
    ]
```

---

## Usage Example

### How to Use Issue Tracking

```python
# 1. Initialize issue manager
issue_manager = IssueManager(db_path="flow_issues.db")

# 2. Create issue when error occurs
issue = await issue_manager.create_issue(
    user_id="bharath",
    run_id="run2",
    thread_id="bharath_aes_cipher_top_run2_123456",
    stage="place",
    error_type="timing_violation",
    error_message="Setup violation: slack = -0.5ns",
    phase="pnr",
    root_cause="Timing constraints too tight",
    severity=SeverityLevel.HIGH
)

# 3. Get similar issues from history
similar = await issue_manager.get_similar_issues(
    user_id="bharath",
    error_type="timing_violation",
    limit=5
)

# 4. Check what worked before
for prev_issue in similar:
    if prev_issue.fix_result == "success":
        print(f"Previous fix that worked: {prev_issue.suggested_fix}")

# 5. Track context across flow
context = await context_tracker.get_context(thread_id)
print(f"Issues so far: {len(context.issues)}")
print(f"Fixes applied: {len(context.fixes_applied)}")
```

---

## Benefits

✅ **Maintain Context** - Know all issues from synthesis through routing
✅ **Learn from History** - Suggest fixes based on what worked before
✅ **Plugin System** - Add custom fixes without code changes
✅ **Audit Trail** - Full visibility into what happened
✅ **Multi-User** - Each user's context isolated

This is a production-ready issue tracking system! 🎉
