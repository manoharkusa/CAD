# Script-by-Script Learning Plan

## Overview

This plan guides you through understanding each Python file in the system. Each section includes:
- **What it does** - Core responsibility
- **Key functions/classes** - Main components
- **How it connects** - Dependencies and relationships
- **Learn by** - Study approach
- **Key concepts** - Things to understand
- **Example usage** - How it's called

---

## Phase 1: Foundation (Understanding the basics)

### File 1: `src/__init__.py`
**Purpose:** Package initialization and exports

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/__init__.py`

**What it does:**
- Defines package metadata (version, author)
- Exports public API (ConfigManager, StageExecutor)
- Documents the architecture approach

**Key exports:**
```python
from .config import ConfigManager, create_config_manager
from .executor import StageExecutor
```

**Key concepts:**
- Package structure in Python
- Public vs private APIs
- Module organization

**Learn by:**
1. Read the file (it's small)
2. Understand what gets exported
3. See how submodules are organized

**Time:** 5 minutes

---

### File 2: `src/config/__init__.py`
**Purpose:** Config module initialization

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/config/__init__.py`

**What it does:**
- Exports ConfigManager from config_manager.py
- Defines the config module's public interface

**Key exports:**
```python
from .config_manager import ConfigManager, create_config_manager
```

**Learn by:**
1. See what's exported
2. Understand it's just a re-export

**Time:** 3 minutes

---

## Phase 2: Configuration Layer (Understanding path resolution)

### File 3: `src/config/config_manager.py` ⭐ IMPORTANT
**Purpose:** Configuration management and path resolution

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/config/config_manager.py`

**What it does:**
1. **Sources environment variables** from sourceproj.env (tcsh/bash auto-detect)
2. **Loads flow_config.yaml** for stage definitions
3. **Resolves all paths** (work_dir, log_dir, script_path)
4. **Manages environment state** for tool execution

**Key classes & functions:**
```python
class ConfigManager:
    def __init__(...)           # Initialize with project params
    def _source_env_file()      # Source sourceproj.env (tcsh/bash)
    def _load_flow_config()     # Load flow_config.yaml

    # Path resolution methods
    def get_stage_tool_script(stage_name) → (tool, script)
    def get_tool_script_path(tool_name, script_name) → Path
    def get_stage_work_dir(stage_name) → Path
    def get_stage_log_dir(stage_name) → Path

    # Environment methods
    def get_env_var(key) → str
    def get_all_env_vars() → Dict

def create_config_manager(...) → ConfigManager  # Factory function
```

**Key concepts:**
1. **Shell format detection** - How to detect tcsh vs bash
2. **Environment sourcing** - Using subprocess.run to source env files
3. **YAML parsing** - Loading configuration files
4. **Path construction** - Building correct directory paths
5. **Stage groups** - Using base_dir and dir_name for nested paths
6. **Type hints** - TypedDict and Tuple usage

**How it connects:**
- Called by PhysicalDesignGraph to get configuration
- Called by StageExecutor to get work directories
- Used by API layer to create per-request config

**Learn by:**
1. Read the docstring
2. Read `__init__` method (understand initialization flow)
3. Read `_source_env_file()` (understand environment sourcing)
4. Read `_load_flow_config()` (understand YAML loading)
5. Read path resolution methods (understand path logic)
6. Trace through an example:
   - What's the run_dir for user="bharath", run_tag="run2"?
   - What's the script_path for tool="genus", script="genus_syn.tcl"?
   - What's the work_dir for stage="place" (with stage_group="pnr")?

**Example usage:**
```python
config = create_config_manager(
    project_name="semicon_19-02",
    user_name="bharath",
    block_name="aes_cipher_top",
    rtl_tag="bronze_v2",
    run_tag="run2",
    proj_root="/proj5/projects"
)

# Get stage tool and script
tool, script = config.get_stage_tool_script("syn")
# → Returns: ("genus", "genus_syn.tcl")

# Get full script path
script_path = config.get_tool_script_path(tool, script)
# → Returns: /proj5/REL/env_scripts/.../genus/genus_syn.tcl

# Get work directory (with stage_group support)
work_dir = config.get_stage_work_dir("place")
# → Returns: /proj5/.../run2/pnr/place/work
```

**Time to understand:** 30-40 minutes

**Exercises:**
1. What happens if sourceproj.env doesn't exist?
2. How does the tcsh vs bash detection work?
3. What's the difference between `stage_name` and `dir_name`?
4. Why use stage_groups with base_dir?

---

## Phase 3: Execution Layer (Understanding tool execution)

### File 4: `src/executor/__init__.py`
**Purpose:** Executor module initialization

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/executor/__init__.py`

**What it does:**
- Exports StageExecutor from stage_executor.py

**Time:** 2 minutes

---

### File 5: `src/executor/stage_executor.py` ⭐ IMPORTANT
**Purpose:** Execute individual stages (syn, place, route, etc.)

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/executor/stage_executor.py`

**What it does:**
1. **Resolves all paths** for a stage (script, work, logs)
2. **Detects environment file format** (tcsh/bash)
3. **Builds shell command** with environment sourcing
4. **Executes subprocess** asynchronously
5. **Captures output** and logs results
6. **Returns execution status** (success/failure)

**Key classes & functions:**
```python
class StageExecutor:
    def __init__(config_manager)

    async def execute_stage(
        stage_name,
        tool_name,
        tool_script,
        tool_executable=None
    ) → Dict[str, Any]

    async def _run_tool(
        cmd,
        work_dir,
        log_file,
        stage_name,
        shell_executable
    ) → Dict[str, Any]
```

**Key concepts:**
1. **Shell command construction** - Building complex shell commands with pipes
2. **Environment format detection** - Detecting tcsh vs bash
3. **Async subprocess execution** - Non-blocking tool execution
4. **Output capture** - Capturing stdout and stderr
5. **Error handling** - Handling timeouts and failures

**Command structure:**
```bash
# For tcsh files:
tcsh -c 'source /path/sourceproj.env && genus -files /path/script.tcl -abort_on_error | tee /path/log'

# For bash files:
source /path/sourceproj.env && genus -files /path/script.tcl -abort_on_error | tee /path/log
```

**How it connects:**
- Called by PhysicalDesignGraph.execute_stage_node()
- Receives stage info from ConfigManager
- Uses asyncio for non-blocking execution
- Returns results back to PhysicalDesignGraph

**Learn by:**
1. Read the docstring
2. Understand execute_stage() flow
3. Understand shell format detection
4. Understand command building
5. Understand async/await usage
6. Trace through an example:
   - How is the command built for "place" stage?
   - What happens if script_path doesn't exist?
   - How is output captured?

**Example usage:**
```python
executor = StageExecutor(config_manager)

result = await executor.execute_stage(
    stage_name="syn",
    tool_name="genus",
    tool_script="genus_syn.tcl",
    tool_executable="genus"
)

# Returns:
# {
#   "status": "success",
#   "stage": "syn",
#   "return_code": 0,
#   "log_file": "/path/to/syn.log"
# }
```

**Time to understand:** 30-40 minutes

**Exercises:**
1. What happens if the subprocess times out?
2. How are stdout and stderr handled?
3. Why use asyncio instead of synchronous execution?
4. What does the pipe `|` do in the command?

---

## Phase 4: Orchestration Layer (Understanding flow management)

### File 6: `src/agents/physical_design_graph.py` ⭐⭐ MOST IMPORTANT
**Purpose:** LangGraph-based orchestration engine

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/agents/physical_design_graph.py`

**What it does:**
1. **Defines FlowState** (TypedDict) - complete execution state
2. **Creates 5 graph nodes** - intent, plan, execute, debug, result
3. **Routes between nodes** - conditional routing based on success/failure
4. **Manages state transitions** - state updates during execution
5. **Integrates DebugAgent** - error analysis and recovery

**Key classes & functions:**
```python
class FlowState(TypedDict):
    # All state fields
    user_id, run_id, prompt, debug_mode
    intent, plan, current_stage_index
    stages_executed, stages_failed, stage_results
    error_info, error_retry_count
    execution_status, ...

class PhysicalDesignGraph:
    def __init__(max_retries=3)

    def _initialize_components(project, user, block, rtl_tag, experiment)

    # 5 Graph nodes
    async def _parse_intent_node(state) → Dict
    async def _create_plan_node(state) → Dict
    async def _execute_stage_node(state) → Dict
    async def _debug_stage_node(state) → Dict
    async def _handle_result_node(state) → Dict

    # Routing functions
    def _route_after_execution(state) → str
    def _route_after_debug(state) → str

    def _build_graph()  # Build LangGraph
    async def invoke(prompt, params...) → Dict
```

**FlowState fields:**
```python
{
    # Input
    "prompt": str,
    "debug_mode": str,

    # Processing
    "intent": Optional[dict],
    "plan": list[str],
    "current_stage_index": int,

    # Results
    "stages_executed": list[str],
    "stages_failed": list[str],
    "stage_results": dict[str, dict],

    # Error tracking
    "error_info": Optional[dict],
    "error_retry_count": int,

    # Metadata
    "user_id": str,
    "run_id": str,
    "execution_status": str,
}
```

**The 5 Nodes:**

```
1. parse_intent_node
   Input: prompt ("run synthesis and place")
   Output: intent = {action: "execute", stages: ["syn", "place"]}

2. create_plan_node
   Input: intent
   Output: plan = ["syn", "place"]

3. execute_stage_node (LOOP - runs multiple times)
   Input: plan, current_stage_index
   Process: Execute current stage using StageExecutor
   Output: update stage_results, increment index
   Routes to:
     - execute_stage (if success & more stages)
     - debug_stage (if error)
     - handle_result (if all done)

4. debug_stage_node (CONDITIONAL - only if error)
   Input: error_info
   Process: Use DebugAgent to analyze error
   Output: debug_result with suggested fix
   Routes to:
     - execute_stage (if fix & retries < max)
     - handle_result (otherwise)

5. handle_result_node
   Input: all execution data
   Output: final summary
   Returns to user
```

**How it connects:**
- Called by API layer (flow_api.py)
- Uses ConfigManager to load configuration
- Uses StageExecutor to run stages
- Uses DebugAgent to analyze errors
- Returns final result to user

**Key concepts:**
1. **StateGraph** - LangGraph graph structure
2. **TypedDict** - Type-safe state definition
3. **Async/await** - Asynchronous node execution
4. **Conditional routing** - Decision logic based on state
5. **State transitions** - How state changes through nodes
6. **Error recovery** - Retry logic with max limits

**Learn by:**
1. Read FlowState definition (understand all fields)
2. Read each node one by one
3. Understand the routing logic
4. Trace through an example flow:
   - What happens when "run syn and place" is submitted?
   - What's the state after parse_intent?
   - What's the state after each execute_stage?
   - What happens if place fails?
5. Read _build_graph() (understand graph structure)

**Example flow:**
```
User submits: "run synthesis and place"
     ↓
parse_intent_node:
  State: {prompt: "run ...", intent: None, ...}
  Output: {prompt: "run ...", intent: {stages: ["syn", "place"]}, ...}
     ↓
create_plan_node:
  Input: intent = {stages: ["syn", "place"]}
  Output: plan = ["syn", "place"], current_stage_index = 0
     ↓
execute_stage_node (iteration 1):
  current_stage_index = 0 → stage = "syn"
  Execute synthesis using StageExecutor
  Result: success
  Output: stages_executed = ["syn"], current_stage_index = 1
  Routes to: execute_stage (more stages)
     ↓
execute_stage_node (iteration 2):
  current_stage_index = 1 → stage = "place"
  Execute placement using StageExecutor
  Result: success
  Output: stages_executed = ["syn", "place"], current_stage_index = 2
  current_stage_index >= len(plan) → all done
  Routes to: handle_result
     ↓
handle_result_node:
  Generate summary
  Return to user
```

**Time to understand:** 60-90 minutes

**Exercises:**
1. What happens if synthesis fails?
2. How many times can a stage be retried?
3. What's the difference between parse_intent and create_plan?
4. Why is current_stage_index important?
5. How does the loop work in execute_stage_node?

---

### File 7: `src/agents/debug_agent.py` ⭐ IMPORTANT
**Purpose:** Error analysis and recovery suggestions

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/agents/debug_agent.py`

**What it does:**
1. **Analyzes error logs** - Reads and parses error messages
2. **Tries 3 approaches** to understand errors:
   - Claude Agent SDK with tools (Bash, Read, Grep)
   - Direct Anthropic API
   - Pattern matching fallback
3. **Suggests fixes** - Provides actionable recovery steps
4. **Returns debug result** - Error classification and suggested action

**Key classes & functions:**
```python
class DebugAgent:
    def __init__(config_manager, state_tracker, max_retry_attempts)

    async def analyze_error(error_info, log_file) → Dict

    # Three approaches
    async def _debug_with_claude_agent_sdk(error) → Dict
    async def _debug_with_direct_api(error) → Dict
    def _debug_with_pattern_matching(error) → Dict
```

**Debug result format:**
```python
{
    "error_type": "missing_environment_variable",
    "root_cause": "RTL_FILELIST not set",
    "suggested_fix": "Add RTL_FILELIST to sourceproj.env",
    "confidence": 0.95,
    "action": "retry"  # or "fail"
}
```

**How it connects:**
- Called by PhysicalDesignGraph.debug_stage_node()
- Receives error_info from failed execution
- Returns fix suggestion back to graph
- Graph decides whether to retry

**Learn by:**
1. Understand error analysis flow
2. Understand three debugging approaches
3. See how Claude AI is used
4. Understand pattern matching fallback
5. Understand confidence scoring

**Time to understand:** 20-30 minutes

**Exercises:**
1. What's the difference between the three approaches?
2. How does Claude Agent SDK help debug?
3. When would pattern matching be used?
4. What does "confidence" mean?

---

## Phase 5: API Layer (Understanding HTTP interface)

### File 8: `src/api/flow_api.py` ⭐ IMPORTANT
**Purpose:** FastAPI endpoints for HTTP interface

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/api/flow_api.py`

**What it does:**
1. **Handles HTTP requests** - POST, GET endpoints
2. **Validates input** - Request models and parameters
3. **Calls PhysicalDesignGraph** - Invokes orchestration
4. **Returns responses** - ExecuteResponse, StatusResponse
5. **Manages async execution** - Handles concurrent requests

**Key classes & functions:**
```python
class ExecuteRequest(BaseModel):
    prompt: str
    user_id: str
    project: str
    block: str
    rtl_tag: str
    run_id: str
    debug_mode: Optional[str]

class ExecuteResponse(BaseModel):
    thread_id: str
    status: str
    stages_executed: list[str]
    stages_failed: list[str]

# Endpoints
@router.post("/execute") → ExecuteResponse
@router.get("/status/{thread_id}") → StatusResponse
@router.post("/resume/{thread_id}") → ExecuteResponse
```

**Endpoints:**
```
POST /flow/execute
  Request: {prompt, user_id, project, block, rtl_tag, run_id}
  Response: {thread_id, status, stages_executed, stages_failed}

GET /flow/status/{thread_id}
  Response: Current execution status

POST /flow/resume/{thread_id}
  Response: Resume from checkpoint
```

**How it connects:**
- Receives HTTP requests from users/clients
- Creates ConfigManager from request parameters
- Calls PhysicalDesignGraph.invoke()
- Returns results as JSON

**Learn by:**
1. Understand BaseModel (Pydantic)
2. Understand async def endpoints
3. Trace through an example request
4. Understand error handling

**Time to understand:** 20-30 minutes

---

## Phase 6: Server & Startup

### File 9: `src/main.py` ⭐ IMPORTANT
**Purpose:** Server initialization and startup

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/main.py`

**What it does:**
1. **Parses command-line arguments** - Project, user, block, etc.
2. **Creates FastAPI app** - Sets up HTTP server
3. **Initializes components**:
   - ConfigManager (global)
   - PhysicalDesignGraph
   - LangGraph checkpointer
4. **Mounts API routes** - Registers endpoints
5. **Starts server** - Listens on host:port

**Key functions:**
```python
def parse_args() → Namespace
def create_app() → FastAPI
def main()
```

**Startup flow:**
```
Parse arguments (project, user, block, rtl_tag, run_tag, host, port)
    ↓
Create FastAPI app
    ↓
Create ConfigManager (for initialization context)
    ↓
Create PhysicalDesignGraph
    ↓
Create LangGraph checkpointer (SQLite)
    ↓
Mount API routes
    ↓
Start server on host:port
```

**Command line:**
```bash
python3 src/main.py \
  --project semicon_19-02 \
  --user bharath \
  --block aes_cipher_top \
  --rtl-tag bronze_v2 \
  --run-tag run2 \
  --host 0.0.0.0 \
  --port 8080
```

**Learn by:**
1. Understand command-line argument parsing
2. Understand FastAPI app creation
3. Trace through initialization
4. Understand app.state usage

**Time to understand:** 15-20 minutes

---

## Phase 7: Checkpointing & State Persistence

### File 10: `src/tracker/langgraph_saver.py`
**Purpose:** LangGraph checkpointing (SQLite-based)

**File Path:** `/proj1/pd/users/testcase/Bharath/proj/new_py_flow/src/tracker/langgraph_saver.py`

**What it does:**
1. **Saves flow state** to SQLite database
2. **Retrieves state** for resumption
3. **Isolates state** by thread_id
4. **Enables crash recovery** - Resume from checkpoint

**Key functions:**
```python
class SqliteSaverCompat:
    async def aput(config, values, metadata) → None
    async def aget(config) → Optional[Dict]
    async def aget_all() → List[Dict]
    async def adelete_thread(config) → None

def get_saver(db_path) → SqliteSaverCompat
def create_thread_id(user_id) → str
def get_config_for_thread(thread_id) → Dict
```

**Learn by:**
1. Understand SQLite schema
2. Understand thread_id usage
3. Understand checkpoint format

**Time to understand:** 15-20 minutes

---

## Phase 8: Orchestrator (Legacy - for reference)

### File 11: `src/agents/orchestrator.py`
**Purpose:** Legacy orchestrator (being replaced by PhysicalDesignGraph)

**Status:** ⚠️ DEPRECATED - Use PhysicalDesignGraph instead

**Learn by:**
1. Reference only
2. Understand old approach for comparison

**Time:** Skip for now

---

## Complete Learning Roadmap

### Day 1: Foundations (3-4 hours)
1. ✅ Read `src/__init__.py` (5 min)
2. ✅ Read `src/config/__init__.py` (3 min)
3. ✅ **Study `src/config/config_manager.py`** (40 min)
   - Trace an example manually
4. ✅ Read `src/executor/__init__.py` (2 min)
5. ✅ **Study `src/executor/stage_executor.py`** (40 min)
   - Understand asyncio usage
   - Trace shell command building

### Day 2: Orchestration (4-5 hours)
1. ✅ **Study `src/agents/physical_design_graph.py`** (90 min)
   - Understand FlowState
   - Trace each node
   - Understand routing
2. ✅ **Study `src/agents/debug_agent.py`** (30 min)
   - Understand error analysis

### Day 3: API & Server (3-4 hours)
1. ✅ **Study `src/api/flow_api.py`** (30 min)
   - Understand endpoints
2. ✅ **Study `src/main.py`** (20 min)
   - Understand startup
3. ✅ **Study `src/tracker/langgraph_saver.py`** (20 min)
   - Understand checkpointing

### Day 4: Integration & Testing (3-4 hours)
1. ✅ Trace a complete request end-to-end
2. ✅ Understand multi-user isolation
3. ✅ Understand error recovery
4. ✅ Run actual examples

---

## Understanding Progression

### Level 1: Basic (After Day 1)
- ✅ Understand ConfigManager
- ✅ Understand StageExecutor
- ✅ Know how commands are built
- ✅ Know how tools are executed

### Level 2: Intermediate (After Day 2)
- ✅ Understand PhysicalDesignGraph
- ✅ Understand 5 nodes and routing
- ✅ Understand state transitions
- ✅ Understand error recovery

### Level 3: Advanced (After Day 3)
- ✅ Understand full HTTP flow
- ✅ Understand server startup
- ✅ Understand checkpointing
- ✅ Understand multi-user isolation

### Level 4: Expert (After Day 4)
- ✅ Trace complete requests
- ✅ Debug issues
- ✅ Modify code confidently
- ✅ Propose enhancements

---

## Key Patterns to Learn

### Pattern 1: Async/Await
```python
async def execute_stage(...):
    result = await subprocess_execution()
    return result
```
**Learn:** Non-blocking execution, concurrent requests

### Pattern 2: Type Hints
```python
def get_stage_work_dir(self, stage_name: str) -> Path:
```
**Learn:** Type safety, IDE support

### Pattern 3: Conditional Routing
```python
def _route_after_execution(state):
    if error_info is None:
        return "execute_stage"  # Continue
    else:
        return "debug_stage"    # Handle error
```
**Learn:** State machines, routing logic

### Pattern 4: Environment Variables
```python
source_env_file() → os.environ updated
os.environ.get("VAR_NAME")
```
**Learn:** Shell environment integration

### Pattern 5: Dependency Injection
```python
StageExecutor(config_manager)  # Inject dependency
```
**Learn:** Testability, loose coupling

---

## Hands-On Exercises

### Exercise 1: Add a new stage
**Objective:** Add a new "timing" stage to flow_config.yaml
1. Update `flow_config.yaml`
2. Trace through ConfigManager
3. Verify paths are correct
4. Execute the stage

### Exercise 2: Modify error analysis
**Objective:** Update DebugAgent to recognize a new error
1. Add pattern to pattern matching
2. Test with actual error log
3. Verify suggestion appears

### Exercise 3: Add new endpoint
**Objective:** Add new `/flow/cancel/{thread_id}` endpoint
1. Add to flow_api.py
2. Implement cancellation logic
3. Test with curl

### Exercise 4: Debug a request
**Objective:** Trace a complete request end-to-end
1. Add print statements at each step
2. Submit a request
3. Follow the execution
4. See state transformations

---

## Common Questions While Learning

**Q: Why is ConfigManager created per-request?**
A: To support multi-user isolation. Each user gets their own configuration.

**Q: Why use async/await?**
A: Non-blocking execution allows many users to run flows concurrently.

**Q: Why detect tcsh vs bash?**
A: sourceproj.env files use tcsh syntax, but systems may run bash.

**Q: Why 5 nodes in the graph?**
A: Separation of concerns: parse intent, make plan, execute, debug, and return result.

**Q: Why use thread_id?**
A: LangGraph uses thread_id to isolate checkpoints per user/run.

---

## Summary

| File | Purpose | Time | Priority |
|------|---------|------|----------|
| config_manager.py | Path resolution | 40 min | ⭐⭐⭐ |
| stage_executor.py | Tool execution | 40 min | ⭐⭐⭐ |
| physical_design_graph.py | Orchestration | 90 min | ⭐⭐⭐ |
| debug_agent.py | Error analysis | 30 min | ⭐⭐ |
| flow_api.py | HTTP API | 30 min | ⭐⭐ |
| main.py | Server startup | 20 min | ⭐⭐ |
| langgraph_saver.py | Checkpointing | 20 min | ⭐ |

**Total Learning Time:** 10-12 hours spread over 4 days

---

## Next Steps After Learning

1. **Run examples** - Execute each script manually
2. **Debug issues** - Add breakpoints, trace execution
3. **Modify code** - Add features confidently
4. **Propose enhancements** - Suggest improvements
5. **Teach others** - Explain the architecture

Good luck! 🚀
