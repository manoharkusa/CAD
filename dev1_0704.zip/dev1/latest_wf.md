```mermaid
graph TD
    START((START)) --> parse_intent["parse_intent"]
    parse_intent --> create_plan["create_plan"]
    create_plan --> confirm_plan["confirm_plan"]
    confirm_plan -->|execute_stage| execute_stage["execute_stage"]
    confirm_plan -->|handle_result| handle_result["handle_result"]
    execute_stage -->|retry| execute_stage
    execute_stage -->|debug| debug_stage["debug_stage"]
    execute_stage -->|done| handle_result
    debug_stage -->|retry| execute_stage
    debug_stage -->|stop| handle_result
    handle_result --> END((END))
```