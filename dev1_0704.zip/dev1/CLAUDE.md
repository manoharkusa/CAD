# Physical Design Flow Orchestration System

## Project Overview

This is an AI-powered Physical Design (PD) flow orchestration system that automates ASIC/FPGA synthesis and place-and-route workflows. It uses Claude AI for intelligent debugging, validation, and error recovery.

## Tech Stack

- **Backend**: FastAPI + Uvicorn
- **AI**: Anthropic Claude API + Claude Agent SDK
- **Orchestration**: LangGraph (state machine)
- **Database**: PostgreSQL (SQLAlchemy ORM)
- **Cache/State**: Redis
- **EDA Tools**: Cadence (Genus, Innovus) / Synopsys (DC Shell, ICC2)

## Directory Structure

```
dev1/
├── src/
│   ├── main.py                 # FastAPI app, lifecycle API, SSE events
│   ├── agents/
│   │   ├── physical_design_graph.py  # LangGraph orchestrator (main flow)
│   │   └── debug_agent.py            # AI-powered error debugging
│   ├── api/
│   │   └── flow_api.py         # REST API routes
│   ├── config/
│   │   ├── config_manager.py   # Stage/tool configuration
│   │   ├── env_loader.py       # Environment variable loading
│   │   └── runtime_config.py   # Runtime configuration
│   ├── executor/
│   │   ├── stage_executor.py   # EDA tool execution (Slurm/local)
│   │   └── validation_runner.py # Skills-based stage validation
│   ├── infra/
│   │   ├── db.py               # SQLAlchemy engine/session
│   │   ├── models/
│   │   │   ├── job_models.py        # Job, JobConfiguration, etc.
│   │   │   └── design_run_models.py # DesignRun, StageProgress
│   │   ├── repositories/
│   │   │   ├── job_repository.py         # Job CRUD
│   │   │   └── design_run_repository.py  # Run tracking & locking
│   │   ├── redis/
│   │   │   └── job_state_store.py   # Redis state management
│   │   └── lifecycle_utils.py       # Event helpers
│   ├── tracker/
│   │   └── state_tracker.py    # Execution state tracking
│   └── worker/
│       └── background_worker.py # Async job processing
├── skills/
│   ├── validation/             # Stage validation skills (YAML frontmatter)
│   │   ├── syn_genus.skill.md
│   │   ├── syn_dc_shell.skill.md
│   │   ├── place_innovus.skill.md
│   │   └── ...
│   ├── debug_skills.md         # Debug agent instructions
│   ├── synthesis_skills.md     # Synthesis knowledge
│   └── pnr_skills.md           # Place & Route knowledge
├── fix_templates/              # Auto-fix templates for common errors
├── e2e/                        # End-to-end test fixtures
├── tests/                      # Unit tests
├── docker-compose.dev1.yml     # Docker services
├── Dockerfile.api              # API container
├── requirements.txt            # Python dependencies
├── .env                        # Environment variables
└── flow_config.yaml            # Stage definitions (per-project)
```

## Key Components

### 1. PhysicalDesignGraph (`src/agents/physical_design_graph.py`)

LangGraph-based orchestrator that manages the flow execution:

```python
# Nodes in the graph:
# parse_intent -> create_plan -> confirm_plan -> execute_stage -> debug_stage -> handle_result

# Key methods:
async def invoke(prompt, debug_mode, project_name, block_name, ...)
def _execute_stage_node(state)   # Runs EDA tool + validation
def _debug_stage_node(state)     # AI debugging on failure
```

**Debug Modes:**
- `auto`: Automatically apply fixes
- `interactive`: Prompt user for confirmation
- `human-loop`: Always require human approval
- `none`: No debugging, fail immediately

### 2. DebugAgent (`src/agents/debug_agent.py`)

AI-powered error analysis and fix generation:

```python
# Uses Claude Agent SDK for tool access:
# - Read: Read log files
# - Bash: Run diagnostic commands
# - Grep: Search for error patterns
# - Glob: Find relevant files
# - Write/Edit: Apply fixes

async def debug_stage(stage_name, error_info, mode)
```

**UI Integration:**
- `_emit_log()`: Terminal output only
- `_emit_ui_log()`: Send to web UI via callback
- `_format_tool_call()`: Human-readable tool descriptions

### 3. ValidationRunner (`src/executor/validation_runner.py`)

Skills-based stage validation using Claude Agent SDK:

```python
# Loads skill files with YAML frontmatter:
# ---
# stage: syn
# tool: genus
# ---

async def validate_stage(stage_name, stage_result, work_dir, log_dir)
```

### 4. DesignRunRepository (`src/infra/repositories/design_run_repository.py`)

Concurrent run prevention and progress tracking:

```python
# Partial unique index prevents duplicate runs:
# CREATE UNIQUE INDEX idx_unique_running_design
# ON design_runs (project, block, rtl_tag, experiment)
# WHERE status = 'running';

def try_acquire_lock(project, block, rtl_tag, experiment)
def check_prerequisites_met(project, block, rtl_tag, experiment, required_stages)
```

## API Endpoints

### Lifecycle API (`/api/v1/lifecycle/`)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/jobs` | POST | Create new job |
| `/jobs/{job_id}` | GET | Get job status |
| `/jobs/{job_id}/human-input` | POST | Submit human decision |
| `/jobs/{job_id}/abort` | POST | Abort running job |
| `/jobs/{job_id}/events` | WebSocket | Real-time events |

### Flow API (`/api/flow/`)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/execute` | POST | Execute flow synchronously |
| `/execute-async` | POST | Execute flow in background |
| `/status` | GET | Get current status |
| `/stages` | GET | List available stages |
| `/history` | GET | Get execution history |

## Configuration

### Environment Variables (`.env`)

```bash
# Database
POSTGRES_URI=postgresql+psycopg2://user:pass@host:5432/db

# Redis
REDIS_URL=redis://localhost:6379/0

# AI
ANTHROPIC_API_KEY=sk-ant-...

# Project defaults
PROJECT_NAME=my_project
BLOCK_NAME=my_block
```

### Flow Config (`flow_config.yaml`)

Located in: `$PROJ_ROOT/$PROJECT/pd/users/$USER/$BLOCK/$RTL_TAG/$EXPERIMENT/flow_config.yaml`

```yaml
stages:
  syn:
    tool: genus          # or dc_shell
    script: syn.tcl
    timeout: 3600
    depends_on: []

  place:
    tool: innovus        # or icc2
    script: place.tcl
    timeout: 7200
    depends_on: [syn]

  cts:
    tool: innovus
    script: cts.tcl
    depends_on: [place]

  route:
    tool: innovus
    script: route.tcl
    depends_on: [cts]

stage_groups:
  flow: [syn, place, cts, route]
  frontend: [syn]
  backend: [place, cts, route]
```

## Running the System

### Local Development

```bash
# Start dependencies
docker-compose -f docker-compose.dev1.yml up -d postgres redis

# Run API server
cd /proj5/bharath/dev1
python -m src.main --host 0.0.0.0 --port 8000

# Or with uvicorn directly
uvicorn src.asgi:app --host 0.0.0.0 --port 8000 --reload
```

### Docker

```bash
# Build and run
docker-compose -f docker-compose.dev1.yml up -d

# With volume mounts for project access
docker run -d \
  -v /proj1:/proj1 \
  -v /proj5:/proj5 \
  -e POSTGRES_URI="..." \
  pd-worker:latest
```

## Common Tasks

### Adding a New Stage

1. Add to `flow_config.yaml`:
```yaml
stages:
  new_stage:
    tool: innovus
    script: new_stage.tcl
    depends_on: [previous_stage]
```

2. Create validation skill `skills/validation/new_stage_innovus.skill.md`:
```markdown
---
name: validate-new-stage-innovus
stage: new_stage
tool: innovus
type: validation
---

# New Stage Validation

## Files to Check
- Log: `logs/innovus.log`

## Success Indicators
- "Completed successfully" in log

## Metrics to Extract
- WNS, TNS, DRC count
```

### Debugging Issues

1. Check terminal logs for `[DEBUG]` prefix
2. UI receives events via `_emit_ui_log()` with payload:
   - `type: "analysis"` - streaming analysis
   - `type: "analysis_complete"` - full summary
   - `format: "markdown"` - render as markdown

### Database Schema

```sql
-- Core tables
jobs                    -- Job tracking
job_configurations      -- Job config storage
execution_history       -- Stage execution records
human_interactions      -- HITL decisions

-- Design run tracking
design_runs            -- Active runs with locking
stage_progress         -- Per-stage progress
```

## Key Patterns

### Lifecycle Events

Events emitted to UI via SSE/WebSocket:

| Event | Payload | When |
|-------|---------|------|
| `started` | `{run_id, plan}` | Flow begins |
| `stage_started` | `{stage}` | Stage execution starts |
| `stage_completed` | `{stage, validation_passed}` | Stage finishes |
| `stage_failed` | `{stage, error}` | Stage fails |
| `validation_started` | `{stage}` | Validation begins |
| `validation_completed` | `{stage, passed, metrics}` | Validation done |
| `hitl_required` | `{message, options}` | Human input needed |
| `completed` | `{stages_executed}` | Flow completes |
| `failed` | `{error}` | Flow fails |

### Error Handling Flow

```
Stage Fails
    ↓
DebugAgent.debug_stage()
    ↓
Claude analyzes logs (Agent SDK)
    ↓
Generate fix suggestions
    ↓
[auto mode] → Apply fix → Retry
[interactive] → Ask user → Apply/Skip
[human-loop] → Wait for human decision
```

### Validation Flow

```
Stage Succeeds
    ↓
ValidationRunner.validate_stage()
    ↓
Load skill file (YAML frontmatter)
    ↓
Claude checks logs/reports (Agent SDK)
    ↓
Extract metrics (WNS, area, etc.)
    ↓
Pass → Continue to next stage
Fail → Trigger debug flow
```

## Testing

```bash
# Run unit tests
pytest tests/

# E2E test with fixtures
pytest e2e/
```

## Troubleshooting

### Agent SDK Not Available
```
[WARN] SPD Agent SDK not installed
```
Solution: `pip install claude-agent-sdk`

### Redis Connection Failed
Check `REDIS_URL` in `.env` and ensure Redis is running.

### Database Migration
```python
from src.infra.db import initialize_lifecycle_schema
initialize_lifecycle_schema()  # Creates/updates tables
```

### UI Not Receiving Analysis
Ensure `_emit_ui_log()` is called with:
```python
payload={"format": "markdown", "type": "analysis"}
```
