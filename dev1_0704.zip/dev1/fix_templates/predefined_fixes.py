#!/usr/bin/env python3
"""Predefined fix templates for common issues"""

from typing import List
from src.issues.models import FixTemplate


def get_rtl_filelist_fix() -> FixTemplate:
    """Fix for RTL_FILELIST environment variable not found"""

    return FixTemplate(
        template_id="rtl_filelist_001",
        error_pattern=r"can't read env\(RTL_FILELIST\)|RTL_FILELIST not found",
        error_type="ENV_VARIABLE_MISSING",
        stage="syn",
        fix_category="environment",
        fix_action="update_config",
        fix_parameters={
            "file": "sourceproj.env",
            "setting": "RTL_FILELIST",
            "hint": "Add RTL_FILELIST variable to sourceproj.env"
        },
        priority=100,
        success_rate=0.95,
        preconditions=["user_id", "run_id"],
        created_by="system",
        description="Add missing RTL_FILELIST environment variable",
        example_error="can't read env(RTL_FILELIST): no such variable",
        notes="RTL_FILELIST must point to the location of RTL files"
    )


def get_timing_violation_fix() -> FixTemplate:
    """Fix for timing violations"""

    return FixTemplate(
        template_id="timing_violation_001",
        error_pattern=r"setup violation|hold violation|timing.*failed",
        error_type="TIMING_VIOLATION",
        stage="pnr",
        fix_category="constraints",
        fix_action="adjust_constraints",
        fix_parameters={
            "type": "clock_period",
            "value": "Increase by 5%",
            "hint": "Relax timing constraints"
        },
        priority=80,
        success_rate=0.75,
        preconditions=["user_id", "run_id", "project"],
        created_by="system",
        description="Adjust timing constraints for timing violations",
        example_error="Setup violation detected on path XYZ",
        notes="Start with 5% increase and re-run. Verify timing reports."
    )


def get_congestion_fix() -> FixTemplate:
    """Fix for routing congestion"""

    return FixTemplate(
        template_id="congestion_001",
        error_pattern=r"congestion|overflow|routing.*failed",
        error_type="ROUTING_CONGESTION",
        stage="place",
        fix_category="placement",
        fix_action="modify_rtl",
        fix_parameters={
            "file": "placement.tcl",
            "change": "Adjust placement density or move instances",
            "hint": "Reduce placement density or reorganize instance placement"
        },
        priority=70,
        success_rate=0.65,
        preconditions=["user_id", "run_id"],
        created_by="system",
        description="Fix routing congestion through placement adjustment",
        example_error="Routing overflows detected in region XYZ",
        notes="May require RTL changes or placement adjustments"
    )


def get_drc_violation_fix() -> FixTemplate:
    """Fix for design rule violations"""

    return FixTemplate(
        template_id="drc_violation_001",
        error_pattern=r"DRC violation|design rule.*violation|spacing",
        error_type="DRC_VIOLATION",
        stage="signoff",
        fix_category="drc",
        fix_action="update_config",
        fix_parameters={
            "type": "drc_check",
            "value": "Review and fix violations manually",
            "tool": "calibre"
        },
        priority=75,
        success_rate=0.80,
        preconditions=["user_id", "run_id"],
        created_by="system",
        description="Fix design rule violations detected by DRC check",
        example_error="DRC violation M1: spacing violation XYZ",
        notes="Review DRC report and apply manual fixes"
    )


def get_memory_issue_fix() -> FixTemplate:
    """Fix for out of memory or memory limit issues"""

    return FixTemplate(
        template_id="memory_issue_001",
        error_pattern=r"memory|out of memory|malloc|heap",
        error_type="MEMORY_ISSUE",
        stage="syn",
        fix_category="configuration",
        fix_action="update_config",
        fix_parameters={
            "setting": "tool_memory_limit",
            "value": "Double current limit",
            "hint": "Increase tool memory allocation"
        },
        priority=85,
        success_rate=0.70,
        preconditions=["user_id", "run_id"],
        created_by="system",
        description="Increase memory allocation for tool execution",
        example_error="Genus: out of memory. Allocating 4GB but available is 2GB",
        notes="Check system memory before increasing limits"
    )


def get_tool_script_not_found_fix() -> FixTemplate:
    """Fix for tool script not found error"""

    return FixTemplate(
        template_id="tool_script_not_found_001",
        error_pattern=r"not found|No such file|cannot open",
        error_type="FILE_NOT_FOUND",
        stage="syn",
        fix_category="path",
        fix_action="update_config",
        fix_parameters={
            "file": "sourceproj.env",
            "setting": "ENV_SCRIPTS",
            "hint": "Verify ENV_SCRIPTS path and script location"
        },
        priority=95,
        success_rate=0.98,
        preconditions=["user_id", "run_id"],
        created_by="system",
        description="Fix missing tool script or configuration path",
        example_error="Cannot find tool_script.tcl in ENV_SCRIPTS",
        notes="Verify sourceproj.env and ENV_SCRIPTS configuration"
    )


def get_syntax_error_fix() -> FixTemplate:
    """Fix for TCL or script syntax errors"""

    return FixTemplate(
        template_id="syntax_error_001",
        error_pattern=r"syntax error|invalid command|unexpected",
        error_type="SYNTAX_ERROR",
        stage="syn",
        fix_category="rtl",
        fix_action="modify_rtl",
        fix_parameters={
            "file": "tool_script.tcl",
            "change": "Review and fix syntax errors",
            "hint": "Check TCL script syntax"
        },
        priority=90,
        success_rate=0.85,
        preconditions=["user_id", "run_id"],
        created_by="system",
        description="Fix syntax errors in tool scripts",
        example_error="Syntax error in tool_script.tcl: unexpected EOF",
        notes="Review error location in script and correct"
    )


def get_default_fixes() -> List[FixTemplate]:
    """Get all default fix templates"""

    return [
        get_rtl_filelist_fix(),
        get_timing_violation_fix(),
        get_congestion_fix(),
        get_drc_violation_fix(),
        get_memory_issue_fix(),
        get_tool_script_not_found_fix(),
        get_syntax_error_fix(),
    ]


def register_default_fixes_to_repository(fix_repository) -> None:
    """Register all default fixes to a repository"""

    for fix in get_default_fixes():
        fix_repository.add_template(fix)
        print(f"✓ Registered fix template: {fix.template_id}")
