---
name: validate-cts-icc2
description: Validate clock tree synthesis completed successfully with Synopsys ICC2
stage: cts
tool: icc2
type: validation
---

# CTS Validation (ICC2)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "Error:" in logs/icc2.log to find errors
2. Grep for "Skew" in reports to extract clock metrics
3. Grep for "clock_opt completed" to verify completion
4. Only Read specific lines if you need more context
```

---

## Files to Check
- Log: `logs/cts.log` or `logs/icc2.log`
- Report: `reports/cts_qor.rpt` or `reports/clock_qor.rpt`

## Success Indicators
- Log contains "clock_opt completed" or "CTS done"
- No "Error:" messages
- Clock QoR report exists

## Metrics to Extract
- **Clock Skew**: Look for "Clock Skew:" followed by value
- **Latency**: Look for "Clock Latency:" or "Insertion delay:"
- **Hold Slack**: Look for "Hold WNS:" or hold slack value

## Pass Criteria
- clock_opt completed
- No Error messages
- Clock skew < 150ps
- Hold slack not severely negative

## Fail Criteria
- "Error:" in log
- Clock skew > 200ps
- Severe hold violations (< -100ps)

## Common Issues to Check
- Verify clock constraints are correct
- Check for missing clock definitions
- Look for clock reconvergence issues
