---
name: validate-placement-innovus
description: Validate placement stage completed successfully with Cadence Innovus
stage: place
tool: innovus
type: validation
---

# Placement Validation (Innovus)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "ERROR" in logs/place.log to find errors
2. Grep for "Utilization:" in reports to extract metrics
3. Grep for "placeDesign completed" to verify completion
4. Only Read specific lines if you need more context
```

---

## Files to Check
- Log: `logs/place.log` or `logs/innovus.log`
- Report: `reports/place_summary.rpt` or `reports/placement.rpt`

## Success Indicators
- Log contains "placeDesign completed" or "Placement done"
- No "**ERROR**" messages in log
- Placement report exists

## Metrics to Extract
- **Utilization**: Look for "Utilization:" followed by percentage (e.g., "Utilization: 72.5%")
- **WNS (estimated)**: Look for "Estimated WNS:" or "WNS:" in timing estimate
- **TNS (estimated)**: Look for "Estimated TNS:" or "TNS:"
- **Congestion**: Look for "Overflow:" or congestion percentage

## Pass Criteria
- Placement completed without errors
- Utilization <= 85% (healthy range is 70-85%)
- No severe congestion (overflow should be < 1.5x normal)
- Estimated timing reasonable for this stage

## Fail Criteria
- "**ERROR**" messages in log
- Utilization > 90% (too dense, routing will fail)
- Severe congestion hotspots reported
- Placement did not complete

## Common Issues to Check
- High utilization may require floorplan adjustment
- Congestion hotspots indicate placement density issues
- Large estimated timing violations may indicate constraint problems
