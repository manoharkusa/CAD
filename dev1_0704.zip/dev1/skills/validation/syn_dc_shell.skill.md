---
name: validate-synthesis-dc
description: Validate synthesis stage completed successfully with Synopsys DC Shell
stage: syn
tool: dc_shell
type: validation
---

# Synthesis Validation (DC Shell / Design Compiler)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "Error:" in logs/dc_shell.log to find errors
2. Grep for "slack" in reports/dc_qor.rpt to extract timing
3. Grep for "Optimization Complete" to verify completion
4. Only Read specific lines if you need more context
```

---

## Files to Check
- Log: `logs/dc_shell.log` or `logs/synthesis.log`
- Report: `reports/dc_qor.rpt` or `reports/*.qor`

## Success Indicators
- Log contains "Optimization Complete" or "compile_ultra completed"
- Log contains "Current design is now" (design loaded successfully)
- No lines starting with "Error:"
- Output netlist written successfully

## Metrics to Extract
- **WNS**: Look for "slack (MET)" or "slack (VIOLATED)" with timing value
- **TNS**: Look for "Total Negative Slack" in report
- **Area**: Look for "Combinational area:" and "Noncombinational area:" numbers
- **Cell Count**: Look for "Number of cells:" or total cell count

## Pass Criteria
- "Optimization Complete" or "compile" completion message in log
- No "Error:" lines in log
- WNS >= -0.5ns (acceptable for synthesis)
- All modules resolved (no "Unresolved reference" errors)

## Fail Criteria
- "Error:" lines present in log
- Design did not compile (no completion message)
- Severe timing violations (WNS < -0.5ns)
- Unresolved module or cell references

## Common Issues to Check
- "Unresolved reference" indicates missing library or RTL
- "Cannot read file" indicates path issues
- High area may indicate inefficient synthesis settings
- Check for memory warnings if design is large
