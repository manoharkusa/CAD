---
name: validate-routing-innovus
description: Validate routing stage completed successfully with Cadence Innovus
stage: route
tool: innovus
type: validation
---

# Routing Validation (Innovus)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "ERROR" in logs/route.log to find errors
2. Grep for "DRC" or "violations" in reports to extract DRC count
3. Grep for "routeDesign completed" to verify completion
4. Only Read specific lines if you need more context
```

---

## Files to Check
- Log: `logs/route.log` or `logs/innovus.log`
- Report: `reports/route_summary.rpt` or `reports/routing.rpt`
- DRC Report: `reports/route_drc.rpt`

## Success Indicators
- Log contains "routeDesign completed" or "Routing done"
- Log contains "optDesign -postRoute completed" (if post-route opt ran)
- No "**ERROR**" messages
- DRC report shows zero or acceptable violations

## Metrics to Extract
- **DRC Count**: Look for "Total number of DRCs:" or DRC violation count
- **Shorts**: Look for "SHORT violations:" count
- **Opens**: Look for "OPEN violations:" count
- **Spacing**: Look for "SPACING violations:" count
- **WNS**: Post-route timing WNS
- **Via Count**: Look for "Total vias:" count

## Pass Criteria
- Routing completed without errors
- DRC count = 0 (or all waived)
- No shorts or opens
- Post-route timing within expected degradation

## Fail Criteria
- "**ERROR**" in log
- DRC count > 0 (unless waived)
- Shorts or opens present
- Routing did not complete

## Common Issues to Check
- Shorts indicate overlapping wires
- DRC violations need fixing or waiving
- High via count may indicate suboptimal routing
- Check for antenna violations
