---
name: validate-cts-innovus
description: Validate clock tree synthesis completed successfully with Cadence Innovus
stage: cts
tool: innovus
type: validation
---

# CTS Validation (Innovus)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "ERROR" in logs/cts.log to find errors
2. Grep for "Skew:" in reports to extract clock metrics
3. Grep for "ccopt_design completed" to verify completion
4. Only Read specific lines if you need more context
```

---

## Files to Check
- Log: `logs/cts.log` or `logs/innovus.log`
- Report: `reports/cts_summary.rpt` or `reports/clock_tree.rpt`

## Success Indicators
- Log contains "ccopt_design completed" or "Clock tree synthesis done"
- No "**ERROR**" messages
- Clock tree report generated

## Metrics to Extract
- **Clock Skew**: Look for "Skew:" followed by value in ps or ns
- **Insertion Delay**: Look for "Insertion Delay:" or "Latency:"
- **Clock Tree Depth**: Look for "Max depth:" or "Levels:"
- **Buffer Count**: Look for "Buffers inserted:" or buffer count

## Pass Criteria
- CTS completed without errors
- Clock skew < 150ps (typical target)
- Insertion delay within expected range
- No hold violations worse than -50ps

## Fail Criteria
- "**ERROR**" in log
- Clock skew > 200ps (too high)
- CTS did not complete
- Severe hold violations

## Common Issues to Check
- High skew may indicate clock constraint issues
- Excessive buffers may indicate routing congestion
- Hold violations need fixing before proceeding
