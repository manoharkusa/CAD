---
name: validate-synthesis-genus
description: Validate synthesis stage completed successfully with Cadence Genus
stage: syn
tool: genus
type: validation
---

# Synthesis Validation (Genus)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "Error:" in logs/syn.log to find errors
2. Grep for "WNS:" in reports/timing_summary.rpt to extract timing
3. Grep for "Unresolved" in reports/check_design.rpt to find issues
4. Only Read specific lines if you need more context
```

---

## Files to Check

### Required Reports
- Log: `logs/syn.log`
- Timing Check: `reports/check_timing.rpt`
- Design Check: `reports/check_design.rpt`
- Timing Summary: `reports/timing_summary.rpt`
- QoR Report: `reports/report_qor.rpt`

---

## 1. Check Timing Report (`reports/check_timing.rpt`)

### STRICT ERRORS - Must be resolved before proceeding

The following issues in check_timing.rpt are **critical errors** that must be fixed:

| Issue | Pattern to Search | Severity |
|-------|-------------------|----------|
| Sequential clock pins without clock waveform | `Sequential clock pins without clock waveform` or `clock pins that do not have a clock waveform` | **ERROR** |
| Inputs without clocked external delays | `Inputs without clocked external delays` or `input ports without input delay` | **ERROR** |
| Outputs without clocked external delays | `Outputs without clocked external delays` or `output ports without output delay` | **ERROR** |
| Generated clocks without clock waveform | `Generated clocks without clock waveform` or `generated clock.*without.*waveform` | **ERROR** |
| Pins/ports with conflicting case constants | `Pins/ports with conflicting case constants` or `conflicting case` | **ERROR** |

### How to Check
```
Look for sections with non-zero counts for the above issues.
Example patterns:
  "Sequential clock pins without clock waveform: 5"  -> ERROR (count > 0)
  "Inputs without clocked external delays: 0"        -> OK (count = 0)
```

### Pass Criteria
- All strict error categories must have count = 0

### Fail Criteria
- Any of the strict error categories has count > 0

---

## 2. Check Design Report (`reports/check_design.rpt`)

### ERROR Categories - Must be resolved

| Issue | Pattern to Search | Severity |
|-------|-------------------|----------|
| Unresolved References | `Unresolved Reference` or `UNRESOLVED` or `unresolved module` | **ERROR** |
| Undriven Leaf Pin(s) | `Undriven Leaf Pin` or `undriven.*leaf.*pin` | **ERROR** |
| Multidriven Leaf Pin(s) | `Multidriven Leaf Pin` or `multi.*driven.*leaf.*pin` | **ERROR** |

### WARNING Categories - Should be reviewed but non-blocking

| Issue | Pattern to Search | Severity |
|-------|-------------------|----------|
| Unconnected ports | `Unconnected port` | WARNING |
| Floating pins | `Floating pin` | WARNING |
| Feedthrough paths | `Feedthrough` | WARNING |
| Combinational loops | `Combinational loop` (unless count > 0, then ERROR) | WARNING |
| Black boxes | `Black box` or `blackbox` | WARNING |
| Constant pins | `Constant pin` or `tied to constant` | WARNING |

### How to Check
```
Look for issue counts in the report.
Example patterns:
  "Unresolved References: 3"    -> ERROR (count > 0)
  "Undriven Leaf Pins: 12"      -> ERROR (count > 0)
  "Multidriven Leaf Pins: 0"    -> OK (count = 0)
  "Unconnected ports: 5"        -> WARNING (report but don't fail)
```

### Pass Criteria
- Unresolved References = 0
- Undriven Leaf Pins = 0
- Multidriven Leaf Pins = 0

### Fail Criteria
- Any ERROR category has count > 0

---

## 3. Timing Summary Report (`reports/timing_summary.rpt`)

### WNS (Worst Negative Slack) Check

**Rule: WNS must not exceed 10% of the clock period**

| Condition | Severity |
|-----------|----------|
| WNS > 10% of clock period | **ERROR** |
| WNS > 5% of clock period | WARNING |
| WNS <= 5% of clock period | OK |

### How to Calculate
```
Example:
  Clock period = 2.0 ns
  10% threshold = 0.2 ns

  If WNS = -0.15 ns -> OK (|WNS| < 10% of period)
  If WNS = -0.25 ns -> ERROR (|WNS| > 10% of period)
```

### Patterns to Extract
- Clock period: Look for `Period:`, `Clock Period:`, `create_clock -period`
- WNS: Look for `WNS:`, `Worst Negative Slack:`, `Setup WNS:`
- TNS: Look for `TNS:`, `Total Negative Slack:`

### Pass Criteria
- |WNS| <= 10% of clock period

### Fail Criteria
- |WNS| > 10% of clock period

---

## 4. Log File Checks (`logs/genus.log`)

### Success Indicators
- Contains "Synthesis completed successfully" or "Writing output files"
- Contains "Optimization complete" or "opt_design.*complete"
- No lines with "Error:" or "**ERROR" (case insensitive)

### Error Patterns to Flag
| Pattern | Severity |
|---------|----------|
| `Error:` or `**ERROR` | **ERROR** |
| `FATAL:` or `Fatal:` | **ERROR** |
| `Cannot resolve` or `cannot find` | **ERROR** |
| `License` + `denied` or `unavailable` | **ERROR** |
| `Warning:` | WARNING (count and report) |

---

## Metrics to Extract

| Metric | Pattern | Unit |
|--------|---------|------|
| WNS | `WNS:` or `Worst Negative Slack:` followed by number | ns |
| TNS | `TNS:` or `Total Negative Slack:` followed by number | ns |
| Clock Period | `Period:` or `create_clock -period` followed by number | ns |
| Total Area | `Total Area:` or `Area:` followed by number | um² |
| Cell Count | `Number of cells:` or `Cell count:` or `Instance count:` | count |
| DRV Count | `DRV:` or `Design Rule Violations:` | count |
| Buffer Count | `Buffer count:` or `Buffers inserted:` | count |
| Inverter Count | `Inverter count:` | count |

---

## Validation Summary

### Overall Pass Criteria
1. **check_timing.rpt**: All strict error categories = 0
2. **check_design.rpt**: Unresolved References = 0, Undriven Leaf Pins = 0, Multidriven Leaf Pins = 0
3. **timing_summary.rpt**: |WNS| <= 10% of clock period
4. **genus.log**: No Error/FATAL messages, synthesis completion message present

### Overall Fail Criteria
- Any of the above pass criteria not met

### Warnings to Report (non-blocking)
- check_design warnings (unconnected ports, floating pins, etc.)
- Warning count from log file
- WNS between 5-10% of clock period

---

## Common Issues and Resolutions

| Issue | Likely Cause | Resolution |
|-------|--------------|------------|
| Sequential clock pins without waveform | Missing clock definition | Add `create_clock` constraint for all clock pins |
| Inputs without clocked external delays | Missing input delay constraints | Add `set_input_delay` for all input ports |
| Outputs without clocked external delays | Missing output delay constraints | Add `set_output_delay` for all output ports |
| Generated clocks without waveform | Missing generated clock definition | Add `create_generated_clock` for derived clocks |
| Conflicting case constants | SDC conflicts | Review and fix `set_case_analysis` constraints |
| Unresolved References | Missing RTL or library | Check RTL filelist and library paths |
| Undriven Leaf Pins | Incomplete connections | Check RTL for unconnected module ports |
| Multidriven Leaf Pins | Multiple drivers | Report user to Fix RTL to have single driver per net |
| WNS too negative | Timing not met | optimize critical paths by creating path groups for critical endpoint patterns |
