---
name: validate-pv-calibre
description: Validate physical verification completed successfully with Mentor Calibre
stage: pv
tool: calibre
type: validation
---

# Physical Verification Validation (Calibre)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "TOTAL DRC Results Count" in DRC log to get violation count
2. Grep for "CORRECT" or "INCORRECT" in LVS log to check LVS status
3. Grep for "fatal" or "error" to find critical issues
4. Only Read specific lines if you need more context
```

---

## Files to Check
- DRC Log: `logs/calibre_drc.log` or `logs/drc.log`
- LVS Log: `logs/calibre_lvs.log` or `logs/lvs.log`
- DRC Report: `reports/drc_summary.rpt`
- LVS Report: `reports/lvs_summary.rpt`

## Success Indicators
- DRC log contains "TOTAL DRC Results Count = 0" or "DRC Clean"
- LVS log contains "CORRECT" or "LVS Clean"
- No fatal errors in either log

## Metrics to Extract
- **DRC Errors**: Look for "TOTAL DRC Results Count" or total error count
- **LVS Errors**: Look for "INCORRECT" count or device mismatches
- **ERC Errors**: Look for ERC violation count if run
- **Antenna Violations**: Look for antenna check results

## Pass Criteria
- DRC errors = 0 (or all waived)
- LVS result is "CORRECT"
- No ERC violations
- Antenna violations = 0 (or fixed)

## Fail Criteria
- DRC errors > 0 (unwaived)
- LVS result is "INCORRECT"
- Fatal errors in logs
- Missing reports

## Common Issues to Check
- DRC errors may need layout fixes
- LVS mismatches indicate netlist/layout inconsistency
- Antenna violations need diode insertion
- Check for density rule violations
