---
name: validate-placement-icc2
description: Validate placement stage completed successfully with Synopsys ICC2
stage: place
tool: icc2
type: validation
---

# Placement Validation (ICC2 / IC Compiler II)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "Error:" in logs/icc2.log to find errors
2. Grep for "Utilization" in reports to extract metrics
3. Grep for "place_opt completed" to verify completion
4. Only Read specific lines if you need more context
```

---

## Files to Check
- Log: `logs/place.log` or `logs/icc2.log`
- Report: `reports/place_qor.rpt` or `reports/placement_qor.rpt`

## Success Indicators
- Log contains "place_opt completed" or "Placement optimization done"
- No "Error:" messages in log
- QoR report generated

## Metrics to Extract
- **Utilization**: Look for "Cell Utilization:" or "Utilization:" percentage
- **WNS**: Look for "WNS:" followed by timing value
- **TNS**: Look for "TNS:" followed by timing value
- **DRV Count**: Look for "DRV:" or design rule violation count

## Pass Criteria
- place_opt completed successfully
- No Error messages
- Utilization <= 85%
- Estimated timing within expected range

## Fail Criteria
- "Error:" messages in log
- Utilization > 90%
- Placement did not complete
- Severe DRV issues

## Common Issues to Check
- Check for placement blockage conflicts
- Verify macro placement is correct
- Look for high fanout net warnings
