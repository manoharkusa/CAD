---
name: validate-routing-icc2
description: Validate routing stage completed successfully with Synopsys ICC2
stage: route
tool: icc2
type: validation
---

# Routing Validation (ICC2)

## IMPORTANT: Tool Usage Guidelines

**DO NOT read entire log or report files.** These files can be very large (10K+ lines) and reading them wastes tokens.

**USE Grep tool** to search for specific patterns:
- Use `Grep` with the exact patterns listed in each section below
- Search for error patterns, metrics, and success indicators
- Only use `Read` tool for small report files (< 100 lines) or when you need specific context around a match

**Example workflow:**
```
1. Grep for "Error:" in logs/icc2.log to find errors
2. Grep for "DRC" or "violations" in reports to extract DRC count
3. Grep for "route_auto completed" to verify completion
4. Only Read specific lines if you need more context
```

---

## Files to Check
- Log: `logs/route.log` or `logs/icc2.log`
- Report: `reports/route_qor.rpt`
- DRC Report: `reports/route_drc.rpt`

## Success Indicators
- Log contains "route_auto completed" or "route_opt completed"
- No "Error:" messages
- DRC report generated

## Metrics to Extract
- **DRC Count**: Look for "Number of DRC violations:" or total DRCs
- **WNS**: Post-route WNS value
- **TNS**: Post-route TNS value
- **Wire Length**: Total wire length if reported

## Pass Criteria
- Routing completed
- No Error messages
- DRC = 0 (or waived)
- Timing maintained

## Fail Criteria
- "Error:" in log
- DRC > 0 (unwaived)
- Routing incomplete

## Common Issues to Check
- Check for congestion-related DRCs
- Verify via rules are met
- Look for antenna rule violations
