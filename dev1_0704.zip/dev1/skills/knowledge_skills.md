# Knowledge Skills

Domain-specific knowledge about EDA tools and design automation best practices.

## tool_command_generator

**Purpose**: Generate correct commands for EDA tools with proper syntax and arguments.

**Actions**:
1. Generate correct dc_shell (Design Compiler) synthesis commands
2. Generate innovus or icc2 commands for PNR
3. Generate STA tool commands
4. Include proper logging and output redirection
5. Handle tool-specific options correctly
6. Verify syntax before execution

**Synthesis Command**:
```bash
cd work && dc_shell -f ../scripts/dc_syn.tcl 2>&1 | tee ../logs/synthesis.log
```

**PNR Command (Innovus)**:
```bash
cd work && innovus -init ../scripts/innovus.init -batch -log ../logs/innovus.log
```

**STA Command (PT)**:
```bash
cd work && pt_shell -f ../scripts/pt_syn.tcl 2>&1 | tee ../logs/pt.log
```

**Key Options**:
- `-f script.tcl`: Execute TCL script
- `2>&1`: Redirect stderr to stdout
- `| tee log.txt`: Save to log while showing output
- `-batch`: Non-interactive mode
- `-log file.log`: Tool-specific logging

## best_practices

**Purpose**: Apply proven design automation best practices.

**Synthesis Best Practices**:
- Use incremental optimization (avoid full re-synthesis)
- Add 10-15% margin to timing constraints
- Don't over-constrain (too many constraints conflict)
- Check convergence: tool should report improvement each iteration
- Use hierarchical synthesis for large designs
- Keep tool settings consistent across runs

**PNR Best Practices**:
- Plan floorplan early (don't optimize blindly)
- Use macros strategically for timing paths
- Balance utilization (70-85% is healthy)
- Add margin for routing closure
- Run detailed routing after placement for verification
- Use hierarchical PNR for large designs

**Timing Closure Best Practices**:
- Add margin incrementally (10% at a time)
- Verify with STA after each tool run
- Check setup AND hold, not just setup
- Monitor clock tree delays separately
- Use derating for PVT variations
- Leave buffer margin for ECOs

**Common Mistakes to Avoid**:
- Over-constraining (conflicting constraints)
- Setting clock period too tight
- Not checking convergence
- Modifying RTL as a debug step (only config/constraints)
- Ignoring design rule violations
- Not documenting constraint changes

**Decision Points**:
- Timing not met: increase margin, optimize critical path, or relax period
- Convergence stuck: change tool settings, break into sub-blocks
- Area too large: target specific modules, reduce optimization effort
- Runtime too long: use incremental approaches, reduce effort
