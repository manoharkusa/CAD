# Debug Skills

Skills for analyzing errors and deciding on fix strategies.

## root_cause_analysis

**Purpose**: Determine the root cause of failures, not just symptoms.

**Actions**:
1. Read the complete error message and context
2. Identify immediate cause (symptom)
3. Trace back through log to root cause
4. Consider: constraints, tool settings, design issues
5. Determine if it's a design problem or flow issue
6. Assess: fixable vs requires design review

**Analysis Approach**:
- Symptom: "Timing violation on data path"
- Trace: Which constraint? Clock period too tight?
- Root: Design fundamentally slow OR constraint aggressive?
- Action: Relax constraint OR redesign path

**Error Categories**:
1. **Timing Violations**
   - Root: Design logic too slow OR constraints too tight
   - Fix: Relax margins, optimize critical path, or increase clock period

2. **Linking Errors**
   - Root: Missing library cell OR missing RTL module
   - Fix: Add to filelist or update library

3. **Convergence Issues**
   - Root: Conflicting objectives OR no feasible solution
   - Fix: Relax constraints, change optimization strategy, or redesign

4. **DRV Violations**
   - Root: Cell overloading OR inadequate buffering
   - Fix: Increase buffer stage, reduce fanout, or upsize cells

## intelligent_retry_decision

**Purpose**: Intelligently decide whether to retry after fix or declare failure.

**Actions**:
1. Evaluate error severity (critical vs warning)
2. Check if previous attempts addressed similar issues
3. Consider iteration count (stopping at max)
4. Determine if problem is self-correcting
5. Assess likelihood of fix improving situation
6. Decide: apply fix and retry OR escalate to human

**Decision Factors**:
- Iteration count: Stop at max (default 5)
- Error pattern: Different each iteration? Or same issue?
- Fix impact: Will this likely improve? (0-100% confidence)
- Time: Any progress toward solution?

**Decision Matrix**:
| Iteration | Error Pattern | Confidence | Decision |
|-----------|--------------|-----------|----------|
| 1-3 | Different | >70% | RETRY |
| 1-3 | Same | <50% | ESCALATE |
| 4-5 | Any | <50% | ESCALATE |
| 5+ | Any | Any | STOP |

**Escalation Criteria**:
- Same error repeats after fix: escalate to human review
- Multiple different errors: fundamental design issue
- Resource limits (time/iterations): escalate
- High complexity: exceed automated fix capability
