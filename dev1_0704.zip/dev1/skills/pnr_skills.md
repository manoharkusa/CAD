# Place and Route Skills

Skills for executing place & route and fixing PNR-related issues.

## analyze_timing_report

**Purpose**: Analyze timing reports to identify violations and critical paths.

**Actions**:
1. Read reports/check_timing.rpt from PNR tool
2. Identify setup/hold violations
3. Extract critical path information
4. Analyze clock tree delays
5. Calculate timing margin
6. Determine feasibility of timing closure

**Report Analysis**:
- Setup slack < 0: need buffer insertion or cell sizing
- Hold slack < 0: need delay on paths or smaller cells
- Clock skew issues: tree imbalance
- Path length: routing congestion indicator

## analyze_congestion

**Purpose**: Analyze routing congestion and placement density.

**Actions**:
1. Read congestion reports from reports/
2. Identify congested regions (local and global)
3. Analyze via and wire utilization
4. Determine if placement is bottleneck
5. Suggest floorplan adjustments
6. Recommend macro relocation

**Congestion Indicators**:
- Local congestion > 1.0: hotspots in routing
- Global congestion: overall routing pressure
- Via utilization: via/metal capacity
- Wire utilization: horizontal/vertical balance

## fix_placement

**Purpose**: Suggest placement adjustments to improve timing and congestion.

**Actions**:
1. Analyze placement density
2. Identify critical paths from timing report
3. Suggest macro/cell relocation
4. Recommend floorplan changes
5. Consider power distribution
6. Balance workload across die

**Placement Strategies**:
- Reduce path lengths for critical paths
- Spread heat sources for thermal balance
- Group related cells for timing closure
- Keep macros away from congested areas
