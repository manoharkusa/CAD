# Synthesis Skills

Skills for executing synthesis and fixing synthesis-related issues.

## analyze_synthesis_log

**Purpose**: Analyze DC Shell synthesis log and identify errors, warnings, and issues.

**Actions**:
1. Read the full synthesis log file
2. Identify all error messages (look for "Error:")
3. Identify warnings (look for "Warning:")
4. Categorize issues: linking, timing, convergence, memory
5. Extract line numbers and context for each issue
6. Determine severity: critical, warning, informational

**Best Practices**:
- Always read the COMPLETE log file, not just the end
- Look for patterns: repeated errors indicate root issue
- Timing violations often appear near the end
- Link errors appear early in the log
- Convergence issues appear during optimization

## fix_timing_constraints

**Purpose**: Suggest and apply timing constraint modifications to fix violations.

**Actions**:
1. Analyze timing violations from reports/check_timing.rpt
2. Understand the constraint type: setup, hold, max_delay
3. Identify critical paths and slack values
4. Modify *.sdc files with proper syntax
5. Use conservative margins (10-15%)
6. Validate SDC syntax after changes
7. Re-run synthesis to verify fix

**SDC Syntax Examples**:
```tcl
# Set input delay (relative to clock)
set_input_delay -clock clk -max 2.0 [get_ports data_in]

# Set output delay
set_output_delay -clock clk -max 1.5 [get_ports data_out]

# Set clock uncertainty
set_clock_uncertainty 0.1 [get_clocks clk]

# Add margin to existing constraints
set_setup_margin 0.1
```

**Common Fixes**:
- Increase input/output delays (relax constraints)
- Add clock uncertainty
- Modify clock period
- Reduce drive strength requirements
- Increase transition times

## optimize_synthesis_settings

**Purpose**: Adjust dc_syn.tcl settings to improve synthesis results.

**Actions**:
1. Analyze optimization logs for convergence issues
2. Identify stuck or looping optimization
3. Modify Design Compiler settings strategically
4. Balance quality vs runtime
5. Document changes made

**Common Settings**:
```tcl
# Effort level
set_effort level medium   # low, medium, high, ultra

# Optimization directives
set_app_var allow_seq_output_inversion true
set_compile_seqmap_propagate_constants true
set_fix_multiple_port_nets true

# Memory and timeout
set_app_var compile_clock_gating_through_hierarchical_ports true
```

**When to Use**:
- Timing not met: increase effort (high/ultra)
- Long compile time: reduce effort (low)
- Convergence issues: change strategy
- QoR issues: enable specific optimizations
