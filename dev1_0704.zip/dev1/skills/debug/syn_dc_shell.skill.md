---
name: debug-synthesis-dc-shell
description: Debug instructions for synthesis stage with Synopsys DC Shell
stage: syn
tool: dc_shell
type: debug
---

# Synthesis Debug Instructions (DC Shell)

## Log Files to Analyze
- Primary: `logs/dc_shell.log` or `logs/synthesis.log`
- Reports: `reports/check_timing.rpt`, `reports/check_design.rpt`

---

## Common Errors and Fixes

### 1. Unconstrained Endpoints

**Error Pattern:**
```
Warning: There are N unconstrained endpoints
Unconstrained input/output ports
```

**Root Cause:** Missing input/output delay constraints.

**Fix Strategy:**
1. Add `set_input_delay` for all input ports (except clocks)
2. Add `set_output_delay` for all output ports

**Example Fix:**
```tcl
#Agent_info: Added by SPD agent (add I/O delays for unconstrained endpoints) [TIMESTAMP]
set_input_delay -clock clk 0.5 [all_inputs]
set_output_delay -clock clk 0.5 [all_outputs]
```

---

### 2. Clock Not Defined

**Error Pattern:**
```
Warning: Clock 'clk' is not defined
Error: No clock defined in design
```

**Root Cause:** Missing `create_clock` constraint.

**Fix Strategy:**
1. Add `create_clock` for primary clock
2. Check clock port name matches RTL

**Example Fix:**
```tcl
#Agent_info: Added by SPD agent (define missing clock) [TIMESTAMP]
create_clock -name clk -period 2.0 [get_ports clk]
```

---

### 3. Cannot Find Library Cell

**Error Pattern:**
```
Error: Cannot find cell '<CELL_NAME>' in library
Library linking error
```

**Root Cause:** Library cell not available or wrong library loaded.

**Fix Strategy:**
1. If cell name is UPPERCASE: Check target_library in block.yaml
2. Verify library path is correct
3. May need to update library or use different cell

---

### 4. Cannot Read Design

**Error Pattern:**
```
Error: Cannot read design file
Encountered problems processing file
```

**Root Cause:** RTL syntax error or missing file.

**Fix Strategy:**
1. Check the file path exists
2. Verify RTL syntax is correct
3. Update filelist if path is wrong

---

### 5. Multiple Driver Error

**Error Pattern:**
```
Error: Net has multiple drivers
Multi-driven net detected
```

**Root Cause:** RTL issue - signal driven by multiple sources.

**Fix Strategy:**
1. This requires RTL fix - escalate to user
2. Report the specific net name

---

### 6. Timing Constraint Conflicts

**Error Pattern:**
```
Warning: Constraint conflict detected
Error: Conflicting case analysis
```

**Root Cause:** SDC has conflicting constraints.

**Fix Strategy:**
1. Check for duplicate `set_case_analysis`
2. Remove conflicting constraints
3. Verify clock relationships

---

## DC Shell Specific Commands

When debugging DC Shell issues, useful investigation commands:
- `report_constraint -all_violators` - Show all violations
- `check_timing` - Check timing constraints
- `check_design` - Check design issues
- `report_clocks` - Verify clock definitions

---

## Editable Files Priority

When fixing errors, prefer editing in this order:
1. `block_inputs/*.sdc` - Timing constraints
2. `block_inputs/mem_list.txt` - SRAM/memory list
3. `block_inputs/*.rtl.f` - RTL filelist
4. `block_scripts/block.yaml` - Flow configuration

---

## Do NOT Modify

- Tool scripts (`tool_scripts/**/*`)
- Tech scripts (`tech_scripts/**/*`)
- Library files (`.db`, `.lib`, `.lef`)
