---
name: debug-synthesis-genus
description: Debug instructions for synthesis stage with Cadence Genus
stage: syn
tool: genus
type: debug
---

# Synthesis Debug Instructions (Genus)

## Log Files to Analyze
- Primary: `logs/genus.log` or `logs/synthesis.log`
- Reports: `reports/check_timing.rpt`, `reports/check_design.rpt`

---

## Common Errors and Fixes

### 1. Inputs Without Clocked External Delays

**Error Pattern:**
```
Inputs without clocked external delays: N (where N > 0)
```

**Root Cause:** Input ports missing `set_input_delay` constraints in SDC file.

**Fix Strategy:**
1. Find which inputs are unconstrained from check_timing.rpt
2. Add `set_input_delay` for each unconstrained input port
3. Use appropriate clock reference

**Example Fix:**
```tcl
#Agent_info: Added by SPD agent (add set_input_delay for unconstrained inputs) [TIMESTAMP]
set_input_delay -clock clk 0.5 [get_ports {rst data_in[*] valid}]
```

---

### 2. Outputs Without Clocked External Delays

**Error Pattern:**
```
Outputs without clocked external delays: N (where N > 0)
```

**Root Cause:** Output ports missing `set_output_delay` constraints in SDC file.

**Fix Strategy:**
1. Find which outputs are unconstrained from check_timing.rpt
2. Add `set_output_delay` for each unconstrained output port
3. Use appropriate clock reference

**Example Fix:**
```tcl
#Agent_info: Added by SPD agent (add set_output_delay for unconstrained outputs) [TIMESTAMP]
set_output_delay -clock clk 0.5 [get_ports {data_out[*] done ready}]
```

---

### 3. Sequential Clock Pins Without Clock Waveform

**Error Pattern:**
```
Sequential clock pins without clock waveform: N (where N > 0)
```

**Root Cause:** Clock not defined with `create_clock` or `create_generated_clock`.

**Fix Strategy:**
1. Identify the clock pin from the report
2. Add `create_clock` for primary clocks
3. Add `create_generated_clock` for derived clocks

**Example Fix:**
```tcl
#Agent_info: Added by SPD agent (add clock definition for unconstrained clock pins) [TIMESTAMP]
create_clock -name clk -period 2.0 [get_ports clk]
```

---

### 4. File Not Found / Invalid Path

**Error Pattern:**
```
File not found: <path>
Cannot read file: <path>
```

**Root Cause:** Incorrect path in filelist or missing file.

**Fix Strategy:**
1. Verify the file exists
2. Check for typos in the path
3. Update filelist or mem_list.txt with correct path

---

### 5. Unresolved References

**Error Pattern:**
```
Unresolved Reference: <module_name>
Cannot resolve module: <module_name>
```

**Root Cause:** RTL module not included in filelist or library cell not found.

**Fix Strategy:**
1. If RTL module (lowercase): Add to filelist
2. If library cell (UPPERCASE): Check library path in block.yaml

---

### 6. Syntax Errors

**Error Pattern:**
```
Error: invalid command name "<cmd>"
Syntax error at line N
```

**Root Cause:** TCL syntax error in SDC or script file.

**Fix Strategy:**
1. Check the line number mentioned
2. Fix TCL syntax (brackets, quotes, spacing)
3. Validate TCL syntax before retry

---

## Editable Files Priority

When fixing errors, prefer editing in this order:
1. `block_inputs/*.sdc` - Timing constraints (most common fixes)
2. `block_inputs/mem_list.txt` - SRAM/memory list
3. `block_inputs/*.rtl.f` - RTL filelist
4. `block_scripts/block.yaml` - Flow configuration (rare)

---

## Do NOT Modify

- Tool scripts (`tool_scripts/**/*`)
- Tech scripts (`tech_scripts/**/*`)
- Library files (`.lib`, `.lef`, `.v`)
