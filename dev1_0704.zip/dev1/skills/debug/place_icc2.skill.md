---
name: debug-place-icc2
description: Debug instructions for placement stage with Synopsys ICC2
stage: place
tool: icc2
type: debug
---

# Placement Debug Instructions (ICC2)

## Log Files to Analyze
- Primary: `logs/icc2.log` or `logs/place.log`
- Reports: `reports/place_timing.rpt`, `reports/place_qor.rpt`

---

## Common Errors and Fixes

### 1. Placement Congestion

**Error Pattern:**
```
Error: Placement congestion exceeds threshold
Cannot complete placement
```

**Root Cause:** Routing congestion too high.

**Fix Strategy:**
1. Reduce target utilization
2. Enable congestion-driven placement
3. Add placement blockages if needed

---

### 2. Cell Not Placed

**Error Pattern:**
```
Warning: Cell <name> could not be placed
Unplaced instances remaining
```

**Root Cause:** Insufficient area or constraints.

**Fix Strategy:**
1. Check floorplan size
2. Reduce utilization
3. Check placement blockages

---

### 3. Timing Not Met

**Error Pattern:**
```
Setup WNS: -X.XX
Hold WNS: -X.XX
```

**Root Cause:** Timing constraints not achievable.

**Fix Strategy:**
1. Add path groups for critical paths
2. Adjust clock uncertainty
3. Review SDC constraints

---

## Editable Files

1. `block_inputs/*.sdc` - Timing constraints
2. `block_scripts/block.yaml` - ICC2 settings
