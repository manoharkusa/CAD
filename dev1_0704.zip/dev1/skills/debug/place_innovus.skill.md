---
name: debug-place-innovus
description: Debug instructions for placement stage with Cadence Innovus
stage: place
tool: innovus
type: debug
---

# Placement Debug Instructions (Innovus)

## Log Files to Analyze
- Primary: `logs/innovus.log` or `logs/place.log`
- Reports: `reports/place_timing.rpt`, `reports/place_drc.rpt`

---

## Common Errors and Fixes

### 1. Placement Density Too High

**Error Pattern:**
```
Error: Placement density exceeds limit
Cannot place all cells
Placement failed: insufficient area
```

**Root Cause:** Design utilization too high for floorplan.

**Fix Strategy:**
1. Check target utilization in block.yaml
2. Reduce target utilization (e.g., 0.7 -> 0.6)
3. Or increase floorplan area if possible

**Example Fix (block.yaml):**
```yaml
#Agent_info: Added by SPD agent (reduce placement density) [TIMESTAMP]
place:
  target_utilization: 0.6
```

---

### 2. Clock Not Propagated

**Error Pattern:**
```
Warning: Clock not propagated to all registers
Unconstrained sequential elements
```

**Root Cause:** Clock definition or propagation issue.

**Fix Strategy:**
1. Verify clock is defined in SDC
2. Check `set_propagated_clock` usage
3. Add clock definition if missing

---

### 3. Timing Violations After Placement

**Error Pattern:**
```
WNS: -X.XXX ns
TNS: -XXX ns
Setup violations detected
```

**Root Cause:** Design cannot meet timing at current utilization.

**Fix Strategy:**
1. Add path groups for critical endpoints
2. Increase optimization effort
3. Reduce target utilization

**Example Fix (SDC):**
```tcl
#Agent_info: Added by SPD agent (add path group for critical timing) [TIMESTAMP]
group_path -name critical_paths -from [get_clocks clk] -to [get_ports data_out*]
```

---

### 4. DRC Violations

**Error Pattern:**
```
DRC violations: N
Design rule check failed
```

**Root Cause:** Cell placement violates design rules.

**Fix Strategy:**
1. Increase placement margin
2. Reduce utilization
3. Check for macro placement issues

---

### 5. Missing DEF/LEF

**Error Pattern:**
```
Cannot read DEF file
LEF file not found
```

**Root Cause:** Missing physical data files.

**Fix Strategy:**
1. Check file paths in block.yaml
2. Verify files exist
3. Update paths if incorrect

---

## Editable Files Priority

1. `block_inputs/*.sdc` - Timing constraints
2. `block_scripts/block.yaml` - Placement settings
3. `block_inputs/mem_list.txt` - Memory placement

---

## Do NOT Modify

- Floorplan files (unless explicitly requested)
- Technology LEF files
- Tool scripts
