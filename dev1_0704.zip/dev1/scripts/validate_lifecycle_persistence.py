from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import psycopg2
import requests


@dataclass
class ValidationResult:
    name: str
    passed: bool
    details: str


def _require_env(name: str, default: Optional[str] = None) -> str:
    value = os.getenv(name, default)
    if not value:
        raise RuntimeError(f"Missing required setting: {name}")
    return value


def _poll_status(api_base: str, job_id: str, timeout_s: int = 90) -> Dict[str, Any]:
    deadline = time.time() + timeout_s
    last: Dict[str, Any] = {}
    while time.time() < deadline:
        response = requests.get(f"{api_base}/jobs/{job_id}/job_status", timeout=15)
        response.raise_for_status()
        last = response.json()
        status = str(last.get("status", "")).upper()
        if status in {"SUCCESS", "FAILED", "CANCELLED"}:
            return last
        time.sleep(2)
    return last


def _get_rows(pg_uri: str, job_id: str) -> Dict[str, Any]:
    with psycopg2.connect(pg_uri) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT status, phase, current_tool, retry_count
                FROM jobs
                WHERE job_id::text = %s
                """,
                (job_id,),
            )
            job_row = cur.fetchone()

            cur.execute(
                """
                SELECT
                    script_path,
                    instructions_path,
                    allowed_paths,
                    max_retries,
                    max_iterations,
                    prompt,
                    user_name,
                    project,
                    block,
                    rtl_tag,
                    experiment_name,
                    debug_mode,
                    require_plan_confirmation,
                    config_payload
                FROM job_configurations
                WHERE job_id::text = %s
                ORDER BY config_id DESC
                LIMIT 1
                """,
                (job_id,),
            )
            cfg_row = cur.fetchone()

            cur.execute(
                """
                SELECT action_type, tool_name, input_params, output_result
                FROM execution_history
                WHERE job_id::text = %s
                ORDER BY timestamp DESC
                LIMIT 25
                """,
                (job_id,),
            )
            history_rows = cur.fetchall()

            cur.execute(
                """
                SELECT current_node, next_node, state
                FROM job_checkpoints
                WHERE job_id::text = %s
                ORDER BY created_at DESC
                LIMIT 50
                """,
                (job_id,),
            )
            checkpoint_rows = cur.fetchall()

    return {
        "job": job_row,
        "config": cfg_row,
        "history": history_rows,
        "checkpoints": checkpoint_rows,
    }


def _to_jsonable(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_jsonable(x) for x in obj]
    if isinstance(obj, tuple):
        return [_to_jsonable(x) for x in obj]
    if hasattr(obj, "isoformat"):
        try:
            return obj.isoformat()
        except Exception:
            return str(obj)
    return obj


def run_validation() -> int:
    api_base = _require_env("VALIDATION_API_BASE", "http://127.0.0.1:8000")
    pg_uri = _require_env("POSTGRES_URI", "postgresql://postgres:password@localhost:5432/synthesis_agent")

    payload = {
        "prompt": "run syn then continue flow",
        "session_id": f"validation-session-{int(time.time())}",
        "user_name": "validation_user",
        "project": "validation_project",
        "block": "validation_block",
        "rtl_tag": "validation_rtl",
        "experiment_name": f"validation_run_{int(time.time())}",
        "debug_mode": "interactive",
        "script_path": "validation_script_path",
        "instructions_path": "validation_instructions_path",
        "allowed_paths": ["/tmp/a", "/tmp/b"],
        "max_retries": 4,
        "max_iterations": 7,
        "require_plan_confirmation": False,
    }

    create_resp = requests.post(f"{api_base}/jobs", json=payload, timeout=20)
    create_resp.raise_for_status()
    created = create_resp.json()
    job_id = created["job_id"]

    final_status = _poll_status(api_base, job_id)
    db_rows = _get_rows(pg_uri, job_id)

    checks: List[ValidationResult] = []

    job_row = db_rows["job"]
    checks.append(
        ValidationResult(
            "jobs_row_exists",
            job_row is not None,
            f"jobs row present={job_row is not None}",
        )
    )

    cfg = db_rows["config"]
    checks.append(
        ValidationResult(
            "job_config_exists",
            cfg is not None,
            f"job_config row present={cfg is not None}",
        )
    )

    if cfg is not None:
        (
            script_path,
            instructions_path,
            allowed_paths,
            max_retries,
            max_iterations,
            prompt,
            user_name,
            project,
            block,
            rtl_tag,
            experiment_name,
            debug_mode,
            require_plan_confirmation,
            config_payload,
        ) = cfg

        checks.extend(
            [
                ValidationResult("config_script_path", script_path == payload["script_path"], f"db={script_path}"),
                ValidationResult(
                    "config_max_iterations",
                    int(max_iterations or 0) == payload["max_iterations"],
                    f"db={max_iterations}",
                ),
                ValidationResult("config_prompt", prompt == payload["prompt"], f"db={prompt}"),
                ValidationResult("config_user_name", user_name == payload["user_name"], f"db={user_name}"),
                ValidationResult("config_project", project == payload["project"], f"db={project}"),
                ValidationResult("config_block", block == payload["block"], f"db={block}"),
                ValidationResult("config_rtl_tag", rtl_tag == payload["rtl_tag"], f"db={rtl_tag}"),
                ValidationResult(
                    "config_require_plan_confirmation",
                    bool(require_plan_confirmation) is payload["require_plan_confirmation"],
                    f"db={require_plan_confirmation}",
                ),
                ValidationResult(
                    "config_payload_present",
                    isinstance(config_payload, dict) and config_payload.get("max_iterations") == payload["max_iterations"],
                    f"db_config_payload_keys={sorted((config_payload or {}).keys()) if isinstance(config_payload, dict) else 'n/a'}",
                ),
            ]
        )

    history_rows = db_rows["history"]
    checks.append(
        ValidationResult(
            "history_written",
            len(history_rows) > 0,
            f"history_rows={len(history_rows)}",
        )
    )

    checkpoint_rows = db_rows["checkpoints"]
    checks.append(
        ValidationResult(
            "checkpoints_written",
            len(checkpoint_rows) > 0,
            f"checkpoint_rows={len(checkpoint_rows)}",
        )
    )

    execute_stage_rows = [row for row in checkpoint_rows if row[0] == "execute_stage"]
    checks.append(
        ValidationResult(
            "execute_stage_current_node_present",
            len(execute_stage_rows) > 0,
            f"execute_stage_rows={len(execute_stage_rows)}",
        )
    )

    execute_stage_with_loop_next = [row for row in checkpoint_rows if row[0] == "execute_stage" and row[1] in {"execute_stage", "debug_stage", "handle_result"}]
    checks.append(
        ValidationResult(
            "execute_stage_next_node_present",
            len(execute_stage_with_loop_next) > 0,
            f"loop_next_rows={len(execute_stage_with_loop_next)}",
        )
    )

    stage_state_rows = [row for row in checkpoint_rows if isinstance(row[2], dict) and row[2].get("current_stage")]
    checks.append(
        ValidationResult(
            "checkpoint_state_has_stage",
            len(stage_state_rows) > 0,
            f"state_with_stage_rows={len(stage_state_rows)}",
        )
    )

    report = {
        "job_id": job_id,
        "final_status": final_status,
        "checks": [result.__dict__ for result in checks],
        "db_snapshot": _to_jsonable(db_rows),
    }

    print(json.dumps(report, indent=2, default=str))

    failed = [item for item in checks if not item.passed]
    if failed:
        print(f"\nValidation failed: {len(failed)} checks failed")
        return 1

    print("\nValidation passed: all checks succeeded")
    return 0


if __name__ == "__main__":
    raise SystemExit(run_validation())
