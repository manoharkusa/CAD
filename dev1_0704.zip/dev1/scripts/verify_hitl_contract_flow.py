from __future__ import annotations

import json
import time
import requests

BASE = "http://127.0.0.1:8000"


def create_job(tag: str) -> str:
    payload = {
        "prompt": "run syn",
        "session_id": f"hitl-{tag}-{int(time.time())}",
        "user_name": "hitl_user",
        "project": "hitl_project",
        "block": "hitl_block",
        "rtl_tag": "hitl_rtl",
        "experiment_name": f"hitl_exp_{tag}_{int(time.time())}",
        "debug_mode": "interactive",
        "script_path": "demo_script",
        "instructions_path": "demo_instructions",
        "allowed_paths": ["/tmp"],
        "max_retries": 3,
        "max_iterations": 5,
        "require_plan_confirmation": True,
    }
    r = requests.post(f"{BASE}/jobs", json=payload, timeout=20)
    r.raise_for_status()
    return r.json()["job_id"]


def wait_for_phase(job_id: str, wanted: str, timeout_s: int = 60) -> dict:
    deadline = time.time() + timeout_s
    last = {}
    while time.time() < deadline:
        r = requests.get(f"{BASE}/jobs/{job_id}/job_status", timeout=15)
        r.raise_for_status()
        last = r.json()
        if str(last.get("phase")) == wanted:
            return last
        time.sleep(1)
    return last


def post_human_input(job_id: str, body: dict) -> tuple[int, str]:
    r = requests.post(f"{BASE}/jobs/{job_id}/human-input", json=body, timeout=20)
    return r.status_code, r.text


def get_history(job_id: str, limit: int = 200) -> dict:
    r = requests.get(f"{BASE}/jobs/{job_id}/history", params={"limit": limit}, timeout=20)
    r.raise_for_status()
    return r.json()


def main() -> None:
    out = {
        "userinput_then_approved": {},
        "declined": {},
    }

    # Scenario A: UserInput should not resume; Approved should resume
    job_a = create_job("a")
    out["userinput_then_approved"]["job_id"] = job_a
    out["userinput_then_approved"]["waiting"] = wait_for_phase(job_a, "WAITING_FOR_HUMAN")

    st, body = post_human_input(job_a, {
        "response": "UserInput",
        "additional_context": "Please compare QoR before final decision",
    })
    out["userinput_then_approved"]["userinput_response"] = {"status": st, "body": body}

    r = requests.get(f"{BASE}/jobs/{job_a}/job_status", timeout=15)
    out["userinput_then_approved"]["after_userinput_status"] = r.json()

    st, body = post_human_input(job_a, {"response": "Approved"})
    out["userinput_then_approved"]["approved_response"] = {"status": st, "body": body}

    time.sleep(2)
    r = requests.get(f"{BASE}/jobs/{job_a}/job_status", timeout=15)
    out["userinput_then_approved"]["after_approved_status"] = r.json()
    history_a = get_history(job_a)
    reeval_items = [
        item for item in history_a.get("items", [])
        if item.get("event_type") == "plan_re_evaluated"
    ]
    out["userinput_then_approved"]["plan_re_evaluated_count"] = len(reeval_items)
    out["userinput_then_approved"]["plan_re_evaluated_latest"] = reeval_items[0] if reeval_items else None

    # Scenario B: Declined at plan gate
    job_b = create_job("b")
    out["declined"]["job_id"] = job_b
    out["declined"]["waiting"] = wait_for_phase(job_b, "WAITING_FOR_HUMAN")

    st, body = post_human_input(job_b, {"response": "Declined", "additional_context": "Need updated constraints"})
    out["declined"]["declined_response"] = {"status": st, "body": body}

    time.sleep(2)
    r = requests.get(f"{BASE}/jobs/{job_b}/job_status", timeout=15)
    out["declined"]["after_declined_status"] = r.json()

    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
