$ErrorActionPreference = 'Stop'

$base = 'http://127.0.0.1:8000'

Write-Host "[1] Health check"
Invoke-RestMethod -Uri "$base/health" -Method Get | ConvertTo-Json -Depth 5

Write-Host "[2] Create lifecycle job"
$createPayload = @{
  script_path = "demo_script.tcl"
  instructions_path = "demo_instructions.md"
  allowed_paths = @("./")
  max_retries = 3
  max_iterations = 5
  user_id = $null
  session_id = $null
} | ConvertTo-Json

$job = Invoke-RestMethod -Uri "$base/jobs" -Method Post -Body $createPayload -ContentType 'application/json'
$jobId = $job.job_id
Write-Host "Created job_id: $jobId"

Write-Host "[3] Check lifecycle job status"
Invoke-RestMethod -Uri "$base/jobs/$jobId/job_status" -Method Get | ConvertTo-Json -Depth 5

Write-Host "[4] Submit human input"
$hitlPayload = @{ response = "approved"; additional_context = "proof-run" } | ConvertTo-Json
Invoke-RestMethod -Uri "$base/jobs/$jobId/human-input" -Method Post -Body $hitlPayload -ContentType 'application/json' | ConvertTo-Json -Depth 5

Write-Host "[5] Read full job state"
Invoke-RestMethod -Uri "$base/job_state?job_id=$jobId" -Method Get | ConvertTo-Json -Depth 6

Write-Host "[6] Request abort"
Invoke-RestMethod -Uri "$base/jobs/$jobId/abort" -Method Post | ConvertTo-Json -Depth 5

Write-Host "[7] Final status"
Invoke-RestMethod -Uri "$base/jobs/$jobId/job_status" -Method Get | ConvertTo-Json -Depth 5

Write-Host "Proof run completed for job_id=$jobId"
